<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'home/index';
$route['sitemap.xml'] = 'home/sitemap';
$route['tum-kategoriler'] = 'home/categories';
$route['ilan-pazari'] = 'home/marketPlace';
$route['ilan-pazari/(:num)'] = 'home/marketPlace/$1';
$route['kategori/(:any)'] = 'home/category/$1';
$route['kategori/(:any)/(:any)'] = 'home/category/$1/$2';
$route['makale-listesi'] = 'home/blogs';
$route['yayinci/(:any)'] = 'home/streamer/$1';
$route['yayincilar'] = 'home/streamers';
$route['donation/(:any)'] = 'client/dashboard/streamer_donation/$1';
$route['makale-listesi/(:any)'] = 'home/blogs/$1';

// Admin Routes
$route['admin'] = 'Panel';
$route['admin/dashboard'] = 'admin/dashboard';
$route['admin/overView'] = 'admin/dashboard/overView';
$route['admin/cases'] = 'admin/CaseBox/cases';
$route['admin/caseAdd'] = 'admin/CaseBox/caseAdd';
$route['admin/caseEdit/(:any)'] = 'admin/CaseBox/caseEdit/$1';
$route['admin/userCases'] = 'admin/CaseBox/userCases';

// Dealer controller için özel rota
$route['admin/dealer'] = 'admin/dealer/index';
$route['admin/dealer/(:any)'] = 'admin/dealer/$1';
$route['admin/credit_management'] = 'admin/credit_management/index';

// Task Wall Admin Routes
$route['admin/task'] = 'admin/task/index';
$route['admin/task/approve_task/(:num)'] = 'admin/task/approve_task/$1';
$route['admin/task/reject_task/(:num)'] = 'admin/task/reject_task/$1';
$route['admin/task/proofs'] = 'admin/task/proofs';
$route['admin/task/proofs/(:num)'] = 'admin/task/proofs/$1';
$route['admin/task/approve_proof/(:num)'] = 'admin/task/approve_proof/$1';
$route['admin/task/reject_proof/(:num)'] = 'admin/task/reject_proof/$1';
// Admin Servers Routes - MUST BE BEFORE admin catch-all
$route['admin/servers'] = 'admin/servers/index';
$route['admin/servers/approve/(:num)'] = 'admin/servers/approve/$1';
$route['admin/servers/reject/(:num)'] = 'admin/servers/reject/$1';
$route['admin/servers/edit/(:num)'] = 'admin/servers/edit/$1';
$route['admin/servers/update/(:num)'] = 'admin/servers/update/$1';

// Diğer admin rotaları
$route['admin/home_featured'] = 'admin/home_featured/index';
$route['admin/home_featured/delete_card/(:num)'] = 'admin/home_featured/delete_card/$1';
$route['admin/home_featured/(:any)'] = 'admin/home_featured/$1';

$route['admin/marketplace_products'] = 'admin/marketplace_products';
$route['admin/marketplace_products/edit/(:num)'] = 'admin/marketplace_products/edit_product/$1';
$route['admin/marketplace_products/delete/(:num)'] = 'admin/marketplace_products/delete_product/$1';

// Admin Wheel Routes - MUST BE BEFORE admin catch-all
$route['admin/wheel'] = 'admin/wheel/index';
$route['admin/wheel/add'] = 'admin/wheel/add';
$route['admin/wheel/edit/(:num)'] = 'admin/wheel/edit/$1';
$route['admin/wheel/delete/(:num)'] = 'admin/wheel/delete/$1';
$route['admin/wheel/toggle_status/(:num)'] = 'admin/wheel/toggle_status/$1';

$route['admin/(:any)'] = 'admin/product/$1';
$route['client/balance'] = 'client/balance/index';
$route['client/balance/transferBalance'] = 'client/balance/transferBalance';
$route['client/balance/withdrawBalance'] = 'client/balance/withdrawBalance';
$route['client/balance/transferBetweenBalances'] = 'client/balance/transferBetweenBalances';
$route['client/balance/acceptCreditOffer'] = 'client/balance/acceptCreditOffer';
$route['client/balance/payCreditDebt'] = 'client/balance/payCreditDebt';

// Task Wall Routes - MUST BE BEFORE catch-all routes
$route['tasks'] = 'task/index';
$route['tasks/detail/(:num)'] = 'task/detail/$1';
$route['tasks/create'] = 'task/create';
$route['tasks/do_create'] = 'task/do_create';
$route['tasks/do_proof/(:num)'] = 'task/do_proof/$1';
$route['tasks/my-tasks'] = 'task/my_tasks';
$route['tasks/my-proofs'] = 'task/my_proofs';

// Wheel (Şans Çarkı) Routes
$route['cark'] = 'wheel/index';
$route['wheel/spin'] = 'wheel/spin';
$route['wheel/check_status'] = 'wheel/check_status';
// Servers (Sunucular) - client tarafı (MUTLAKA client wildcard'larından ÖNCE)
$route['sunucular/urun-ekle/(:num)'] = 'serverproducts/create/$1';
$route['sunucular/urun-ekle/(:num)/kaydet'] = 'serverproducts/store/$1';

$route['client/sunucu-ekle'] = 'servers/create';
$route['client/sunucu-ekle/kaydet'] = 'servers/store';   // senin controller yorumundaki yol buysa

// Sunucular liste

// Sunucu detay (blog gibi)
$route['sunucular/detay/(:num)'] = 'servers/detail/$1';
$route['sunucular/begen/(:num)'] = 'servers/like/$1';

// (İstersen kategori için ayrı URL bırak)
// $route['sunucular/kategori/(:any)'] = 'servers/category/$1';

$route['sunucular'] = 'servers/index';
//  $route['sunucular/(:any)'] = 'servers/category/$1'; // bunu kullanacaksan Servers.php’de category() olmalı

$route['client'] = 'client/dashboard/index';
$route['client/urun-ekle'] = 'client/dashboard/addProductPage';
$route['client/(:any)'] = 'client/dashboard/$1';
$route['client/(:any)/(:any)'] = 'client/dashboard/$1/$2';

$route['kasalar'] = 'Home/cases';
$route['case/(:any)'] = 'Home/showCase/$1';

$route['referans'] = 'Reference/index';
$route['bilet/:any'] = 'Support/detail/$1';
$route['makale/(:any)'] = 'home/blog/$1';
$route['sifremi-unuttum'] = 'home/reNewPassword';
$route['newPassword/(:any)'] = 'home/newPassword/$1';
$route['hesap'] = 'login/index';
$route['magaza/(:any)'] = 'home/shop/$1';
$route['sepet'] = 'home/cart';
$route['tc-dogrulama'] = 'home/addTc';
$route['payment'] = 'payment/index';
$route['callback'] = 'client/dashboard/callback';
$route['sayfa/(:any)'] = 'home/page/$1';
$route['reNewPassword'] = 'home/reNewPassword';
$route['mail-onay/(:any)'] = 'home/confirmUserMail/$1';
$route['cronapi/run/(:any)'] = 'CronApi/run/$1';

/* API ROUTES */
$route['api/v1/(:any)'] = 'api/ExternalAPI/$1';
$route['api/v1/products/(:any)'] = 'api/ExternalAPI/products_by_id/$1';
$route['api/v1/categories/(:any)'] = 'api/ExternalAPI/categories_by_id/$1';
$route['api/v1/(:any)/(:any)'] = 'api/ExternalAPI/$1/$2';
$route['api/docs'] = 'api/ExternalAPIDocs';
$route['api/docs/openapi'] = 'api/ExternalAPIDocs/openapi';
$route['api/(:any)'] = 'api/API/$1';
$route['provider-callback'] = 'API/provider_callback';
$route['provider-callback/hyper'] = 'API/provider_callback_hyper';
$route['provider-callback/hyper/(:any)'] = 'API/provider_callback_hyper/$1';



// CATCH-ALL route - MUST BE LAST
$route['(:any)'] = 'home/getProduct/$1';

$route['404_override'] = 'home/error';
$route['translate_uri_dashes'] = FALSE;
