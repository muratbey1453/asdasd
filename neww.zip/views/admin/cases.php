<div id="layoutSidenav_content">

    <main>
        <div class="container-fluid">

            <div class="page-title">
                <h5 class="mb-0">Kasalar</h5>
            </div>

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= base_url(); ?>admin/cases">Kasalar</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Kasalar</li>
                </ol>
            </nav>

            <div class="page-btn">
                <div class="btns">
                    <a href="<?= base_url(); ?>admin/caseAdd" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Kasa Ekle</a>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered border dataTable table-product">
                            <thead class="thead-light">
                            <tr>
                                <th>Kasa Adı</th>
                                <th>Fiyat</th>
                                <th>Açıklama</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($cases as $c) { ?>
                                <tr>
                                    <td><img src="<?= base_url("assets/img/case/".$c->img); ?>" alt=""> <?= $c->name ?> <?= ($c->active != 1) ? "<small class='text-danger'>(Deaktif)</small>" : NULL ?></td>
                                    <td><?= $c->price ?>₺</td>
                                    <td>
                                        <?= (strlen($c->description) > 100) ? substr($c->description, 0, 100) . "..." : ((strlen($c->description) > 0) ? $c->description : "-");  ?>
                                    </td>
                                    <td>
                                        <a href="<?= base_url(); ?>admin/caseEdit/<?= $c->id ?>"><i class="fa fa-edit"></i></a>
                                    </td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </main>




