
<div id="layoutSidenav_content">

    <main>
        <div class="container-fluid">

            <div class="page-title">
                <h5>Kasa Bilgileri</h5>
                <h3 class="text-muted"><?= $case->name ?></h3>
            </div>

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= base_url(); ?>admin/cases">Kasalar</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Kasa Bilgileri (<?= $case->name ?>)</li>
                </ol>
            </nav>

            <div class="row">

                <div class="col-12 col-md-10 col-lg-6 mx-auto">
                    <div class="card">
                        <div class="card-header">Ürün Bilgileri</div>
                        <div class="card-body">
                            <a href="#modalPicture" class="btn btn-primary btn-pmc" data-toggle="modal"><i class="fa fa-pen"></i></a>
                            <img src="<?= base_url("assets/img/case/".$case->img) ?>" class="product-info-img">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Kasa Adı:
                                    <strong><?= $case->name ?></strong>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Fiyat:
                                    <strong><?= $case->price ?>₺</strong>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    İçerik Ortalama Fiyat:
                                    <strong class="text-primary">
                                        <?php
                                        $total = 0;
                                        $count = 0;
                                        foreach ($case->items as $item) {
                                            $total += $item->product->price;
                                            $count++;
                                        }
                                        echo ($count > 0) ? number_format($total / $count, 2) . "₺" : "-";
                                        ?>
                                    </strong>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Şansa Bağlı Ortalama Fiyat:
                                    <strong>
                                        <?php
                                        //ağırlıklı ortalamaya göre şansa bağlı ortalama fiyat hesaplanıyor
                                        $total = 0;
                                        $count = 0;
                                        foreach ($case->items as $item) {
                                            $total += $item->product->price * $item->chance;
                                            $count += $item->chance;
                                        }
                                        echo ($count > 0) ? number_format($total / $count, 2) . "₺" : "-";
                                        ?>
                                    </strong>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-md-10 col-lg-6 mx-auto">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            Düzenle
                            <a href="<?=base_url('admin/CaseBox/caseDelete/') . $case->id; ?>" class="btn btn-danger btn-sm"><i class="far fa-trash-alt"></i> Sil</a>
                        </div>
                        <div class="card-body">
                            <form action="<?= base_url('admin/product/edit/cases/cases/') . $case->id . '/case' ?>" method="POST">
                                <div class="form-group">
                                    <label for="inputPName">Kasa Adı:</label>
                                    <input type="text" class="form-control" id="inputPName" value="<?= $case->name ?>" name="name" required>
                                </div>
                                <div class="form-group">
                                    <label for="inputPPrice">Fiyat:</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control" aria-label="Ürün Fiyatı" aria-describedby="basic-addon1" value="<?= $case->price ?>" name="price" required>
                                        <div class="input-group-append">
                                            <span class="input-group-text" id="basic-addon1">₺</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputPText">Kasa Bilgisi:</label>
                                    <textarea name="description" class="form-control" id="editor" required><?= ($case->description) ? $case->description : "Bu Kasa İçin Açıklama Girilmedi." ?></textarea>
                                </div>

                                <div class="form-group">
                                    <label for="inputPCate">Kasa Durumu:</label>
                                    <select class="custom-select" name="active" required>
                                        <option value="<?= $case->active ?>" selected>
                                            <?php
                                            if ($case->active == 1) {
                                            echo "Aktif";
                                            ?>
                                        <option value="2">DeAktif</option>
                                        <?php } else {
                                            echo "Deaktif"; ?>
                                            <option value="1">Aktif</option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <button class="btn btn-primary float-right"><i class="far fa-save"></i> Güncelle</button>
                            </form>
                        </div>
                    </div>
                </div>

            </div>

            <div class="row">
                <!-- Case items datatable, add buttons, edit buttons and remove buttons -->
                <!-- add button -->
                <div class="col-md-12 mx-auto">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            Ürünler

                            <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modalEditItem" data-id="0" data-href="<?= base_url("admin/product/insert/cases/case_items/case") ?>"><i class="fa fa-plus"></i> Ürün Ekle</button>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped table-bordered table-hover" id="caseItemsTable">
                                <thead>
                                <tr>
                                    <th>Ürün Adı</th>
                                    <th>Ürün Fiyatı</th>
                                    <th>Ürün Durumu</th>
                                    <th>Şans Oranı</th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($case->items as $item) { ?>
                                    <tr data-id="<?= $item->id ?>" data-price="<?= $item->product->price ?>" data-chance="<?= $item->chance ?>">
                                        <td><?= $item->product->name ?></td>
                                        <td><?= $item->product->price ?>₺</td>
                                        <td><?= ($item->active == 1) ? "Aktif" : "Deaktif" ?></td>
                                        <td><?= $item->chance ?>%</td>
                                        <td>
                                            <!-- edit modal -->
                                            <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modalEditItem" data-id="<?= $item->id ?>" data-product="<?= $item->product_id ?>" data-chance="<?= $item->chance ?>" data-active="<?= $item->active ?>" data-href="<?= base_url("admin/product/edit/cases/case_items/{$item->id}/case") ?>"><i class="fa fa-pen"></i></button>
                                            <a href="<?= base_url("admin/product/delete/cases/case_items/{$item->id}")  ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                                        </td>
                                    </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- edit modal -->
                <div class="modal fade" id="modalEditItem" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h6 class="modal-title">Kasa Ürünü <span id="add_tag" style="display: none;">Ekle</span><span id="edit_tag" style="display: none;">Düzenle</span></h6>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="case_id" value="<?= $case->id ?>">
                                    <input type="hidden" name="item_id" value="0" disabled>
                                    <div class="form-group">
                                        <label for="inputPName">Ürün Adı:</label>
                                        <select class="custom-select" name="product_id" required>
                                            <option value="" selected disabled>Ürün Seçiniz</option>
                                            <?php foreach ($products as $product) { ?>
                                                <option value="<?= $product->id ?>" data-price="<?= $product->price ?>"><?= $product->name ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPPrice">Şans Oranı:</label>
                                        <div class="input-group">
                                            <input type="number" class="form-control" aria-label="Şans Oranı" aria-describedby="basic-addon1" value="" name="chance" step="0.01" required>
                                            <div class="input-group-append">
                                                <span class="input-group-text" id="basic-addon1">%</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="alert alert-info" role="alert" style="display: none;" id="average_price_alert">
                                        <strong>Şansa Bağlı Ortalama Fiyat:</strong> <span id="average_price">0</span>₺
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPCate">Ürün Durumu:</label>
                                        <select class="custom-select" name="active" required>
                                            <option value="1">Aktif</option>
                                            <option value="2">DeAktif</option>
                                        </select>
                                    </div>
                                    <button type="submit" class="btn btn-primary btn-block"><i class="far fa-save"></i> Kaydet</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>


            </div>

        </div>
    </main>

    <div class="modal fade" id="modalPicture" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h6 class="modal-title">Ürün Görselini Değiştir</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?= base_url('admin/product/edit/cases/cases/') . $case->id . '/case' ?>" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="customFileLangHTML" name="img" required>
                                <label class="custom-file-label" for="customFileLangHTML" data-browse="Seç">Görseli Seçmek İçin Tıkla</label>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block"><i class="far fa-save"></i> Kaydet</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        ClassicEditor
            .create( document.querySelector( '#editor' ) )
            .catch( error => {
                console.error( error );
            });

        $('#modalEditItem').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var href = button.data('href');
            console.log(href);
            var product = button.data('product');
            var chance = button.data('chance');
            var active = button.data('active');
            var id = button.data('id');

            var modal = $(this);
            if (id == 0) {
                $('#add_tag').show();
                $('#edit_tag').hide();

                modal.find('form').attr('action', href);
                modal.find('input[name="item_id"]').val("0");
                //item_id is 0, cant be post
                modal.find('input[name="item_id"]').attr('disabled', true);
                modal.find('select[name="product_id"]').val("");
                modal.find('input[name="chance"]').val("");
                modal.find('select[name="active"]').val("");
                modal.find('#average_price_alert').hide();
            } else {
                $('#add_tag').hide();
                $('#edit_tag').show();

                modal.find('form').attr('action', href);
                modal.find('input[name="item_id"]').val(id);
                modal.find('select[name="product_id"]').val(product);
                modal.find('input[name="chance"]').val(chance);
                modal.find('select[name="active"]').val(active);

                //calculate average price
                var price = $('#modalEditItem select[name="product_id"] option:selected').data('price');
                var average_price = calculateAveragePrice();
                $('#modalEditItem #average_price').text(average_price);
                $('#modalEditItem #average_price_alert').show();
            }
        });
        //on change #modalEditItem input[name="chance"] calculate average price
        $('#modalEditItem').on('keyup', 'input[name="chance"]', function() {
            var chance = $(this).val();
            if (chance < 0) {
                chance = 0;
                $(this).val(0);
            } else {
                chance = parseFloat(chance);
            }
            var product_id = $('#modalEditItem select[name="product_id"]').val();
            if (product_id != null) {
                var price = $('#modalEditItem select[name="product_id"] option:selected').data('price');
                var item_id = $('#modalEditItem input[name="item_id"]').val();

                var average_price = calculateAveragePrice(chance, price, item_id);
                $('#modalEditItem #average_price').text(average_price);
                $('#modalEditItem #average_price_alert').show();
            }
        });
        //#modalEditItem select[name="product_id"] calculate average price
        $('#modalEditItem').on('change', 'select[name="product_id"]', function() {
            var product_id = $(this).val();
            if (product_id != null) {
                var price = $('#modalEditItem select[name="product_id"] option:selected').data('price');
                var chance = $('#modalEditItem input[name="chance"]').val();
                if (chance < 0) {
                    chance = 0;
                    $(this).val(0);
                } else {
                    chance = parseFloat(chance);
                }
                var item_id = $('#modalEditItem input[name="item_id"]').val();

                var average_price = calculateAveragePrice(chance, price, item_id);
                $('#modalEditItem #average_price').text(average_price);
                $('#modalEditItem #average_price_alert').show();
            }
        });


        function calculateAveragePrice(chance=0, price=0, item_id=0) {
            var average_price = chance * price;
            var total_chance = chance;
            if (chance == 0 && price == 0) {
                average_price = 0;
                total_chance = 0;
            }

            $("#caseItemsTable tbody tr").each(function() {
                var row_item_chance = $(this).data('chance');
                var row_item_price = $(this).data('price');
                var row_item_id = $(this).data('id');

                if (row_item_id != item_id) {
                    average_price += (row_item_chance * row_item_price);
                    total_chance += row_item_chance;
                }
            });

            return (average_price/total_chance).toFixed(2);
        }

    </script>
