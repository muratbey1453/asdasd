<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <div class="page-title">
                <h5 class="mb-0">Ürün Düzenle</h5>
            </div>

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= base_url('admin'); ?>">Ana Sayfa</a></li>
                    <li class="breadcrumb-item"><a href="<?= base_url('admin/marketplace_products'); ?>">İlan Pazarı İlanları</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Düzenle</li>
                </ol>
            </nav>

            <div class="card">
                <div class="card-body">
                    <?php echo form_open_multipart('admin/marketplace_products/edit_product/' . $product->id); ?>
                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Ürün Adı</label>
                                    <input type="text" name="name" class="form-control" value="<?= $product->name ?>" required>
                                </div>
                                
                                <?php $isServerProduct = isset($product->server_id) && (int)$product->server_id > 0; ?>

                                <?php if ($isServerProduct): ?>
                                <div class="form-group">
                                    <label>Sunucu</label>
                                    <select name="server_id" class="form-control" required>
                                        <?php foreach($approvedServers as $srv): ?>
                                            <option value="<?= $srv->id ?>" <?= (int)$product->server_id === (int)$srv->id ? 'selected' : '' ?>>
                                                <?= $srv->title ?><?= !empty($srv->game) ? ' (' . $srv->game . ')' : '' ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <input type="hidden" name="category_id" value="0">
                                    <small class="text-muted">Sunucu ürünlerinde kategori yerine sunucu seçilir.</small>
                                </div>
                                <?php else: ?>
                                <div class="form-group">
                                    <label>Kategori</label>
                                    <select name="category_id" class="form-control" required>
                                        <?php foreach($categories as $cat): ?>
                                            <option value="<?= $cat->id ?>" <?= (int)$product->category_id === (int)$cat->id ? 'selected' : '' ?>><?= $cat->name ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <?php endif; ?>
                                
                                <div class="form-group">
                                    <label>Fiyat</label>
                                    <input type="number" name="price" class="form-control" value="<?= $product->price ?>" step="0.01" required>
                                </div>

                                <div class="form-group">
                                    <label>Durum</label>
                                    <select name="isActive" class="form-control">
                                        <option value="1" <?= $product->isActive == 1 ? 'selected' : '' ?>>Aktif</option>
                                        <option value="0" <?= $product->isActive == 0 ? 'selected' : '' ?>>Pasif</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Mevcut Görsel</label>
                                    <div class="mb-2">
                                        <img src="<?= base_url('assets/img/product/' . $product->img) ?>" class="img-fluid rounded" style="max-height: 200px;">
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label>Yeni Görsel Yükle (Opsiyonel)</label>
                                    <input type="file" name="image" class="form-control-file">
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group mt-3">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Kaydet</button>
                            <a href="<?= base_url('admin/marketplace_products') ?>" class="btn btn-secondary">İptal</a>
                        </div>
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </main>
</div>
