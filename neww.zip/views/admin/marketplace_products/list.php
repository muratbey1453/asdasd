<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <div class="page-title">
                <h5 class="mb-0">İlan Pazarı İlanları</h5>
            </div>

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= base_url('admin'); ?>">Ana Sayfa</a></li>
                    <li class="breadcrumb-item active" aria-current="page">İlan Pazarı İlanları</li>
                </ol>
            </nav>

            <?php if($this->session->flashdata('success')): ?>
                <div class="alert alert-success"><?= $this->session->flashdata('success') ?></div>
            <?php endif; ?>
            <?php if($this->session->flashdata('error')): ?>
                <div class="alert alert-danger"><?= $this->session->flashdata('error') ?></div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered" id="dataTable">
                            <thead class="thead-light">
                                <tr>
                                    <th width="80">Görsel</th>
                                    <th>Ürün Adı</th>
                                    <th>Kategori</th>
                                    <th>Fiyat</th>
                                    <th>Satıcı</th>
                                    <th>Durum</th>
                                    <th width="100">İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($products)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">Henüz ilan eklenmemiş.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($products as $product): ?>
                                        <tr>
                                            <td>
                                                <img src="<?= base_url('assets/img/product/' . $product->img) ?>" alt="" style="height: 50px; width: 50px; object-fit: cover; border-radius: 4px;">
                                            </td>
                                            <td><?= $product->name ?></td>
                                            <td><?php if(!empty($product->server_id) && (int)$product->server_id > 0): ?><span class="badge badge-primary">Sunucu</span> <?= !empty($product->server_title) ? $product->server_title : ("Sunucu #".(int)$product->server_id) ?><?php else: ?><?= !empty($product->category_name) ? $product->category_name : "-" ?><?php endif; ?></td>
                                            <td><?= number_format($product->price, 2) ?> ₺</td>
                                            <td>
                                                <span class="badge badge-info"><?= $product->seller_name ?></span>
                                            </td>
                                            <td>
                                                <?php if($product->isActive == 1): ?>
                                                    <span class="badge badge-success">Aktif</span>
                                                <?php else: ?>
                                                    <span class="badge badge-danger">Pasif</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?= base_url('admin/marketplace_products/edit_product/' . $product->id) ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                                                <a href="<?= base_url('admin/marketplace_products/delete_product/' . $product->id) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Silmek istediğinize emin misiniz?')"><i class="fa fa-trash-alt"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>
