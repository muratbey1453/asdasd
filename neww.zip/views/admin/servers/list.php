<?php
// application/views/admin/servers/list.php
// Beklenen değişkenler: $title, $pending (array), $approved (array), $games (array)
$pending = $pending ?? [];
$approved = $approved ?? [];
?>

<div class="container-fluid">
  <div class="row">
    <div class="col-12">

      <?php if ($this->session->flashdata('adminMsg')): ?>
        <div class="alert alert-info mb-3"><?= $this->session->flashdata('adminMsg') ?></div>
      <?php elseif ($this->session->flashdata('message')): ?>
        <div class="alert alert-info mb-3"><?= $this->session->flashdata('message') ?></div>
      <?php endif; ?>

      <div class="card">
        <div class="card-header d-flex align-items-center justify-content-between">
          <h4 class="card-title mb-0"><?= html_escape($title ?? 'Sunucular') ?></h4>
          <div class="small text-muted">Bekleyen: <b><?= count($pending) ?></b> &nbsp;|&nbsp; Onaylı: <b><?= count($approved) ?></b></div>
        </div>
        <div class="card-body">

          <ul class="nav nav-pills mb-3" role="tablist">
            <li class="nav-item" role="presentation">
              <button class="nav-link active" data-bs-toggle="pill" data-bs-target="#tab-pending" type="button" role="tab">Onay Bekleyen (<?= count($pending) ?>)</button>
            </li>
            <li class="nav-item" role="presentation">
              <button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-approved" type="button" role="tab">Onaylı (<?= count($approved) ?>)</button>
            </li>
          </ul>

          <div class="tab-content">
            <div class="tab-pane fade show active" id="tab-pending" role="tabpanel">
              <?php if (empty($pending)): ?>
                <div class="alert alert-secondary">Onay bekleyen sunucu yok.</div>
              <?php else: ?>
                <div class="table-responsive">
                  <table class="table table-hover align-middle">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Oyun</th>
                        <th>Sunucu</th>
                        <th>IP/Host</th>
                        <th>Sahip</th>
                        <th>Tarih</th>
                        <th class="text-end">İşlem</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($pending as $s): ?>
                        <tr>
                          <td><?= (int)$s->id ?></td>
                          <td><?= html_escape($games[$s->game] ?? $s->game) ?></td>
                          <td>
                            <div class="fw-semibold"><?= html_escape($s->title) ?></div>
                            <?php if (!empty($s->short_desc)): ?>
                              <div class="text-muted small"><?= html_escape($s->short_desc) ?></div>
                            <?php endif; ?>
                          </td>
                          <td><?= html_escape($s->ip) ?></td>
                          <td>
                            <div><?= html_escape(trim(($s->name ?? '').' '.($s->surname ?? ''))) ?></div>
                            <div class="text-muted small"><?= html_escape($s->email ?? '') ?><?= !empty($s->shop_name) ? ' • '.html_escape($s->shop_name) : '' ?></div>
                          </td>
                          <td class="text-muted"><?= html_escape($s->created_at) ?></td>
                          <td class="text-end">
                            <a href="<?= base_url('admin/servers/approve/'.(int)$s->id) ?>" class="btn btn-success btn-sm">Onayla</a>
                            <a href="<?= base_url('admin/servers/reject/'.(int)$s->id) ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Reddetmek istiyor musun?')">Reddet</a>
                          </td>
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              <?php endif; ?>
            </div>

            <div class="tab-pane fade" id="tab-approved" role="tabpanel">
              <?php if (empty($approved)): ?>
                <div class="alert alert-secondary">Onaylı sunucu yok.</div>
              <?php else: ?>
                <div class="table-responsive">
                  <table class="table table-hover align-middle">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Oyun</th>
                        <th>Sunucu</th>
                        <th>IP/Host</th>
                        <th>Sahip</th>
                        <th>Onay</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($approved as $s): ?>
                        <tr>
                          <td><?= (int)$s->id ?></td>
                          <td><?= html_escape($games[$s->game] ?? $s->game) ?></td>
                          <td>
                            <div class="fw-semibold"><?= html_escape($s->title) ?></div>
                            <?php if (!empty($s->short_desc)): ?>
                              <div class="text-muted small"><?= html_escape($s->short_desc) ?></div>
                            <?php endif; ?>
                          </td>
                          <td><?= html_escape($s->ip) ?></td>
                          <td>
                            <div><?= html_escape(trim(($s->name ?? '').' '.($s->surname ?? ''))) ?></div>
                            <div class="text-muted small"><?= html_escape($s->email ?? '') ?><?= !empty($s->shop_name) ? ' • '.html_escape($s->shop_name) : '' ?></div>
                          </td>
                          <td class="text-muted"><?= html_escape($s->approved_at ?? '') ?></td>
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              <?php endif; ?>
            </div>
          </div>

        </div>
      </div>

    </div>
  </div>
</div>
