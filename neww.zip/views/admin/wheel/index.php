<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Çark Yönetimi</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="<?= base_url('admin/dashboard') ?>">Ana Sayfa</a></li>
                <li class="breadcrumb-item active">Çark Yönetimi</li>
            </ol>

            <?php if ($this->session->flashdata('message')): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <?= $this->session->flashdata('message') ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- Oran Uyarısı -->
            <?php if ($total_probability != 100): ?>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <strong>Dikkat:</strong> Toplam oran <strong><?= $total_probability ?>%</strong>. Toplamın 100% olması önerilir.
                </div>
            <?php else: ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle me-2"></i>
                    Toplam oran: <strong>100%</strong> ✓
                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-xl-8">
                    <div class="card mb-4">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <div>
                                <i class="fas fa-gift me-1"></i>
                                Çark Öğeleri
                            </div>
                            <a href="<?= base_url('admin/wheel/add') ?>" class="btn btn-primary btn-sm">
                                <i class="fas fa-plus me-1"></i>Yeni Öğe Ekle
                            </a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Sıra</th>
                                            <th>Renk</th>
                                            <th>Etiket</th>
                                            <th>Tip</th>
                                            <th>Değer</th>
                                            <th>Oran</th>
                                            <th>Durum</th>
                                            <th>İşlemler</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($items as $item): ?>
                                            <tr>
                                                <td><?= $item->sort_order ?></td>
                                                <td>
                                                    <div style="width: 30px; height: 30px; border-radius: 6px; background: <?= $item->color ?>; display: flex; align-items: center; justify-content: center;">
                                                        <i class="<?= $item->icon ?>" style="color: white; font-size: 14px;"></i>
                                                    </div>
                                                </td>
                                                <td><strong><?= $item->label ?></strong></td>
                                                <td>
                                                    <?php 
                                                    $type_badges = [
                                                        'balance' => '<span class="badge bg-success text-white">Bakiye</span>',
                                                        'product' => '<span class="badge bg-info text-white">Ürün</span>',
                                                        'nothing' => '<span class="badge bg-secondary text-white">Boş</span>'
                                                    ];
                                                    echo $type_badges[$item->type] ?? '<span class="badge bg-dark text-white">?</span>';
                                                    ?>
                                                </td>
                                                <td>
                                                    <?php if ($item->type == 'balance'): ?>
                                                        <span class="text-success fw-bold"><?= number_format($item->value, 2) ?> TL</span>
                                                    <?php elseif ($item->type == 'product'): ?>
                                                        <span class="text-info">Ürün #<?= $item->value ?></span>
                                                    <?php else: ?>
                                                        <span class="text-muted">-</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <span class="badge bg-primary text-white"><?= $item->probability ?>%</span>
                                                </td>
                                                <td>
                                                    <?php if ($item->is_active): ?>
                                                        <span class="badge bg-success text-white">Aktif</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-danger text-white">Pasif</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a href="<?= base_url('admin/wheel/edit/' . $item->id) ?>" class="btn btn-sm btn-outline-primary">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <a href="<?= base_url('admin/wheel/delete/' . $item->id) ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Bu öğeyi silmek istediğinize emin misiniz?')">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Son Çevirmeler -->
                <div class="col-xl-4">
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-history me-1"></i>
                            Son Çevirmeler
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Kullanıcı</th>
                                            <th>Kazanılan</th>
                                            <th>Tarih</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recent_spins as $spin): ?>
                                            <tr>
                                                <td><small><?php
                                                $masked_name = substr($spin->name, 0, 2) . str_repeat('*', max(0, strlen($spin->name) - 2));
                                                $masked_surname = substr($spin->surname, 0, 2) . str_repeat('*', max(0, strlen($spin->surname) - 2));
                                                echo $masked_name . ' ' . $masked_surname;
                                            ?></small></td>
                                                <td>
                                                    <?php if ($spin->reward_type == 'balance'): ?>
                                                        <span class="badge bg-success text-white"><?= number_format($spin->reward_value, 2) ?> TL</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-secondary text-white"><?= $spin->reward_label ?></span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><small><?= date('d.m H:i', strtotime($spin->spin_date)) ?></small></td>
                                            </tr>
                                        <?php endforeach; ?>
                                        <?php if (empty($recent_spins)): ?>
                                            <tr>
                                                <td colspan="3" class="text-center text-muted">Henüz çevirme yok</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>
