
<div id="layoutSidenav_content">

    <main>
        <div class="container-fluid">

            <div class="page-title">
                <h5 class="mb-0">Kasa Ekle</h5>
            </div>

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= base_url(); ?>admin/cases">Kasalar</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Kasa Ekle</li>
                </ol>
            </nav>


            <div class="card">
                <div class="card-body">
                    <form action="<?= base_url(); ?>admin/product/insert/cases/cases/case" method="POST" enctype="multipart/form-data">
                        <div class="form-group row">
                            <label for="inputPName" class="col-sm-2 col-form-label">Kasa Adı:</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="name" id="caseName" onchange="doSlug()" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputPName" class="col-sm-2 col-form-label">Slug:</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="slug" id="caseSlug" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputPPrice" class="col-sm-2 col-form-label">Fiyat:</label>
                            <div class="col-sm-10">
                                <div class="input-group">
                                    <input type="text" class="form-control" id="inputPPrice" aria-label="Ürün Fiyatı" aria-describedby="basic-addon1" name="price" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text" id="basic-addon1">₺</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputPImg" class="col-sm-2 col-form-label">Kasa Görseli:</label>
                            <div class="col-sm-10">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="customFileLangHTML" name="img" required>
                                    <label class="custom-file-label" for="customFileLangHTML" data-browse="Seç">Ürün Görselini Seçmek İçin Tıkla</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputPText" class="col-sm-2 col-form-label">Ürün Bilgisi: <small>(HTML)</small></label>
                            <div class="col-sm-10">
                                <textarea id="editor" rows="10" class="form-control" name="description"></textarea>
                            </div>
                        </div>



                        <button class="btn btn-primary float-right"><i class="fa fa-plus"></i> Ekle</button>
                    </form>
                </div>
            </div>

        </div>
    </main>

    <script>
        ClassicEditor
            .create( document.querySelector( '#editor' ) )
            .catch( error => {
                console.error( error );
            } );
    </script>

    <script>
        function doSlug()
        {
            var title = $("#caseName").val();
            console.log(title);
            title = str(title);
            $('#caseSlug').val(title);
        }

        function str(str) {
            str = str.replace(/^\s+|\s+$/g, ''); // trim
            str = str.toLowerCase();

            // remove accents, swap ñ for n, etc
            var from = "ãàáäâẽèéëêìíïîıõòóöôùúüûñç·/_,:;şğ";
            var to   = "aaaaaeeeeeiiiiiooooouuuunc------sg";
            for (var i=0, l=from.length ; i<l ; i++) {
                str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
            }

            str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
                .replace(/\s+/g, '-') // collapse whitespace and replace by -
                .replace(/-+/g, '-'); // collapse dashes

            return str;
        };
    </script>
