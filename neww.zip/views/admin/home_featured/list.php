<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <div class="page-title">
                <h5 class="mb-0">Ana Sayfa Öne Çıkan Kartlar</h5>
            </div>

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= base_url('admin'); ?>">Ana Sayfa</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Öne Çıkan Kartlar</li>
                </ol>
            </nav>

            <div class="d-flex justify-content-between align-items-center mb-3">
                <div></div>
                <div>
                    <?php if (count($cards) < 4): ?>
                        <a href="<?= base_url('admin/home_featured/add') ?>" class="btn btn-success"><i class="fa fa-plus"></i> Yeni Kart Ekle</a>
                    <?php else: ?>
                        <button class="btn btn-secondary" disabled>Maksimum 4 Kart Eklenebilir</button>
                    <?php endif; ?>
                </div>
            </div>

            <?php if($this->session->flashdata('success')): ?>
                <div class="alert alert-success"><?= $this->session->flashdata('success') ?></div>
            <?php endif; ?>
            <?php if($this->session->flashdata('error')): ?>
                <div class="alert alert-danger"><?= $this->session->flashdata('error') ?></div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <thead class="thead-light">
                                <tr>
                                    <th width="100">Görsel</th>
                                    <th>Başlık</th>
                                    <th>Link</th>
                                    <th>Sıra</th>
                                    <th width="150">İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($cards)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">Henüz kart eklenmemiş.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($cards as $card): ?>
                                        <tr>
                                            <td>
                                                <img src="<?= base_url('assets/img/home_featured/' . $card->image) ?>" alt="" style="height: 50px; object-fit: cover; border-radius: 4px;">
                                            </td>
                                            <td><?= $card->title ?></td>
                                            <td><?= $card->link ?></td>
                                            <td><?= $card->sort_order ?></td>
                                            <td>
                                                <a href="<?= base_url('admin/home_featured/edit_card/' . $card->id) ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                                                <a href="<?= base_url('admin/home_featured/delete_card/' . $card->id) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Silmek istediğinize emin misiniz?')"><i class="fa fa-trash-alt"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>
