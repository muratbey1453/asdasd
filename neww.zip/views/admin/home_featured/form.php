<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <div class="page-title">
                <h5 class="mb-0"><?= isset($card) ? 'Kart Düzenle' : 'Yeni Kart Ekle' ?></h5>
            </div>

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= base_url('admin'); ?>">Ana Sayfa</a></li>
                    <li class="breadcrumb-item"><a href="<?= base_url('admin/home_featured'); ?>">Öne Çıkan Kartlar</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?= isset($card) ? 'Düzenle' : 'Ekle' ?></li>
                </ol>
            </nav>

            <div class="card">
                <div class="card-body">
                    <?php echo form_open_multipart(isset($card) ? 'admin/home_featured/edit_card/' . $card->id : 'admin/home_featured/add'); ?>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label>Başlık</label>
                                <input type="text" name="title" class="form-control" required value="<?= isset($card) ? $card->title : '' ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label>Link</label>
                                <input type="text" name="link" class="form-control" required value="<?= isset($card) ? $card->link : '' ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label>Sıralama</label>
                                <input type="number" name="sort_order" class="form-control" required value="<?= isset($card) ? $card->sort_order : '0' ?>">
                            </div>
                        </div>
                    </div>

                    <div class="form-group mb-3">
                        <label>Görsel</label>
                        <?php if(isset($card)): ?>
                            <div class="mb-2">
                                <img src="<?= base_url('assets/img/home_featured/' . $card->image) ?>" alt="" style="height: 100px; border-radius: 4px;">
                            </div>
                        <?php endif; ?>
                        <input type="file" name="image" class="form-control" <?= isset($card) ? '' : 'required' ?>>
                        <small class="text-muted">Önerilen boyut: 400x200px</small>
                    </div>

                    <button type="submit" class="btn btn-primary">Kaydet</button>
                    
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </main>
</div>
