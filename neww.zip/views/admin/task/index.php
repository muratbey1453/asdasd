<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Görev Yönetimi</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url('admin/dashboard') ?>">Ana Sayfa</a></li>
                        <li class="breadcrumb-item active">Görev Yönetimi</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            <?php if($this->session->flashdata('message')): ?>
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <i class="icon fas fa-check"></i> <?= $this->session->flashdata('message') ?>
                </div>
            <?php endif; ?>
            
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Tüm Görevler</h3>
                            <div class="card-tools">
                                <a href="<?= base_url('admin/task/proofs') ?>" class="btn btn-primary btn-sm">
                                    <i class="fas fa-eye"></i> Tüm Kanıtları Gör
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <table id="tasksTable" class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th style="width: 50px;">ID</th>
                                        <th>Başlık</th>
                                        <th style="width: 120px;">Kullanıcı ID</th>
                                        <th style="width: 100px;">Ücret</th>
                                        <th style="width: 100px;">Kota</th>
                                        <th style="width: 120px;">Durum</th>
                                        <th style="width: 150px;">Oluşturma</th>
                                        <th style="width: 200px;">İşlemler</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($tasks)): ?>
                                        <?php foreach($tasks as $task): ?>
                                            <tr>
                                                <td><?= $task->id ?></td>
                                                <td>
                                                    <strong><?= $task->title ?></strong>
                                                    <?php if(!empty($task->image)): ?>
                                                        <br><small class="text-muted"><i class="fas fa-image"></i> Görsel var</small>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?= $task->user_id ?></td>
                                                <td><strong><?= number_format($task->reward_amount, 2) ?> TL</strong></td>
                                                <td>
                                                    <div class="progress progress-xs">
                                                        <div class="progress-bar bg-success" style="width: <?= ($task->current_count / $task->total_limit) * 100 ?>%"></div>
                                                    </div>
                                                    <small><?= $task->current_count ?>/<?= $task->total_limit ?></small>
                                                </td>
                                                <td>
                                                    <?php 
                                                        if($task->status == 0) echo '<span class="badge badge-warning">Onay Bekliyor</span>';
                                                        elseif($task->status == 1) echo '<span class="badge badge-success">Aktif</span>';
                                                        elseif($task->status == 2) echo '<span class="badge badge-secondary">Pasif</span>';
                                                        elseif($task->status == 3) echo '<span class="badge badge-danger">İptal</span>';
                                                        elseif($task->status == 4) echo '<span class="badge badge-info">Tamamlandı</span>';
                                                    ?>
                                                </td>
                                                <td><small><?= date('d.m.Y H:i', strtotime($task->created_at)) ?></small></td>
                                                <td class="text-center">
                                                    <?php if($task->status == 0): ?>
                                                        <a href="<?= base_url('admin/task/approve_task/'.$task->id) ?>" 
                                                           class="btn btn-success btn-xs" 
                                                           onclick="return confirm('Bu görevi onaylıyor musunuz?')"
                                                           title="Onayla">
                                                            <i class="fas fa-check"></i>
                                                        </a>
                                                        <a href="<?= base_url('admin/task/reject_task/'.$task->id) ?>" 
                                                           class="btn btn-danger btn-xs" 
                                                           onclick="return confirm('Reddetmek istediğinize emin misiniz? Ücret iade edilecektir.')"
                                                           title="Reddet">
                                                            <i class="fas fa-times"></i>
                                                        </a>
                                                    <?php elseif($task->status == 1): ?>
                                                        <a href="<?= base_url('admin/task/reject_task/'.$task->id) ?>" 
                                                           class="btn btn-danger btn-xs" 
                                                           onclick="return confirm('Görevi iptal etmek istediğinize emin misiniz? Kalan kota ücreti iade edilecektir.')"
                                                           title="İptal Et">
                                                            <i class="fas fa-ban"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <a href="<?= base_url('admin/task/proofs/'.$task->id) ?>" 
                                                       class="btn btn-info btn-xs" 
                                                       title="Kanıtları Gör">
                                                        <i class="fas fa-eye"></i> Kanıtlar
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<script>
$(function () {
    $("#tasksTable").DataTable({
        "responsive": true,
        "lengthChange": true,
        "autoWidth": false,
        "order": [[0, "desc"]],
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Turkish.json"
        },
        "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#tasksTable_wrapper .col-md-6:eq(0)');
});
</script>
