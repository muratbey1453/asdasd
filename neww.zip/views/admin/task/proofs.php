<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Kanıt İnceleme</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url('admin/dashboard') ?>">Ana Sayfa</a></li>
                        <li class="breadcrumb-item"><a href="<?= base_url('admin/task') ?>">Görevler</a></li>
                        <li class="breadcrumb-item active">Kanıtlar</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            <?php if($this->session->flashdata('message')): ?>
                <div class="alert alert-success alert-dismissible fade show" id="flashMessage">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <i class="icon fas fa-check"></i> <?= $this->session->flashdata('message') ?>
                </div>
                <script>
                    setTimeout(function() {
                        $('#flashMessage').alert('close');
                    }, 5000);
                </script>
            <?php endif; ?>
            
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Gönderilen Kanıtlar</h3>
                            <div class="card-tools">
                                <a href="<?= base_url('admin/task') ?>" class="btn btn-default btn-sm">
                                    <i class="fas fa-arrow-left"></i> Görevlere Dön
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <table id="proofsTable" class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th style="width: 50px;">ID</th>
                                        <th style="width: 80px;">Görev ID</th>
                                        <th style="width: 100px;">Kullanıcı ID</th>
                                        <th>Kanıt Metni</th>
                                        <th style="width: 80px;">Görsel</th>
                                        <th style="width: 110px;">Durum</th>
                                        <th style="width: 130px;">Tarih</th>
                                        <th style="width: 180px;">İşlemler</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($proofs)): ?>
                                        <?php foreach($proofs as $proof): ?>
                                            <tr>
                                                <td><?= $proof->id ?></td>
                                                <td>
                                                    <a href="<?= base_url('admin/task/proofs/'.$proof->task_id) ?>" class="badge badge-primary">
                                                        #<?= $proof->task_id ?>
                                                    </a>
                                                </td>
                                                <td><?= $proof->user_id ?></td>
                                                <td>
                                                    <div style="max-width: 300px; overflow: hidden; text-overflow: ellipsis;">
                                                        <?= mb_substr($proof->proof_text, 0, 100) ?>
                                                        <?php if(strlen($proof->proof_text) > 100): ?>
                                                            <a href="#" class="text-primary" data-toggle="modal" data-target="#proofModal<?= $proof->id ?>">...devamı</a>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                <td class="text-center">
                                                    <?php if(!empty($proof->proof_image)): ?>
                                                        <a href="<?= base_url('assets/img/proofs/'.$proof->proof_image) ?>" target="_blank">
                                                            <img src="<?= base_url('assets/img/proofs/'.$proof->proof_image) ?>" 
                                                                 style="height: 40px; border-radius: 4px;" 
                                                                 alt="Kanıt">
                                                        </a>
                                                    <?php else: ?>
                                                        <span class="text-muted">-</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php 
                                                        if($proof->status == 0) echo '<span class="badge badge-warning">Bekliyor</span>';
                                                        elseif($proof->status == 1) echo '<span class="badge badge-success">Onaylandı</span>';
                                                        elseif($proof->status == 2) echo '<span class="badge badge-danger">Reddedildi</span>';
                                                    ?>
                                                </td>
                                                <td><small><?= date('d.m.Y H:i', strtotime($proof->created_at)) ?></small></td>
                                                <td class="text-center">
                                                    <?php if($proof->status == 0): ?>
                                                        <a href="<?= base_url('admin/task/approve_proof/'.$proof->id) ?>" 
                                                           class="btn btn-success btn-xs" 
                                                           onclick="return confirm('Onaylıyor musunuz? Kullanıcıya ödeme yapılacaktır.')"
                                                           title="Onayla">
                                                            <i class="fas fa-check"></i> Onayla
                                                        </a>
                                                        <button type="button" 
                                                                class="btn btn-danger btn-xs" 
                                                                data-toggle="modal" 
                                                                data-target="#rejectModal<?= $proof->id ?>"
                                                                title="Reddet">
                                                            <i class="fas fa-times"></i> Reddet
                                                        </button>
                                                    <?php else: ?>
                                                        <button class="btn btn-secondary btn-xs" disabled>İşlem Tamamlandı</button>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            
                                            <!-- Proof Detail Modal -->
                                            <div class="modal fade" id="proofModal<?= $proof->id ?>">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title">Kanıt Detayı #<?= $proof->id ?></h4>
                                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p><?= nl2br($proof->proof_text) ?></p>
                                                            <?php if(!empty($proof->proof_image)): ?>
                                                                <img src="<?= base_url('assets/img/proofs/'.$proof->proof_image) ?>" class="img-fluid" alt="Kanıt">
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <!-- Reject Modal -->
                                            <div class="modal fade" id="rejectModal<?= $proof->id ?>">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header bg-danger">
                                                            <h4 class="modal-title">Kanıtı Reddet</h4>
                                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                        </div>
                                                        <form action="<?= base_url('admin/task/reject_proof/'.$proof->id) ?>" method="post">
                                                            <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />
                                                            <div class="modal-body">
                                                                <div class="form-group">
                                                                    <label>Red Nedeni *</label>
                                                                    <textarea class="form-control" name="reason" rows="3" required placeholder="Lütfen ret nedeninizi açıklayın..."></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-default" data-dismiss="modal">İptal</button>
                                                                <button type="submit" class="btn btn-danger">Reddet</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<script>
$(function () {
    $("#proofsTable").DataTable({
        "responsive": true,
        "lengthChange": true,
        "autoWidth": false,
        "order": [[0, "desc"]],
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Turkish.json"
        },
        "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#proofsTable_wrapper .col-md-6:eq(0)');
});
</script>
