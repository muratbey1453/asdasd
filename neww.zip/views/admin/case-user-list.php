<div id="layoutSidenav_content">

    <main>
        <div class="container-fluid">

            <div class="page-title">
                <h5 class="mb-0">Kasadan Çıkanlar</h5>
            </div>

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= base_url("admin/cases"); ?>">Kasa</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Kasadan Çıkanlar</li>
                </ol>
            </nav>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered border dataTable table-product">
                            <thead class="thead-light">
                            <tr>
                                <th>ID</th>
                                <th>Kasa</th>
                                <th>Çıkan Ürün</th>
                                <th>Stok</th>
                                <th>Tutar</th>
                                <th>Tarih</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($user_cases as $u): ?>
                                <tr>
                                    <td><a href="<?= base_url('admin/users')."?edit_user=".$u->user->id ?>"><?= $u->user->name." ".$u->user->surname ?></a></td>
                                    <td><a href="<?= base_url('admin/caseEdit/' . $u->case->id) ?>"><?= $u->case->name ?></a></td>
                                    <?php if($u->product->id != -1){ ?>
                                    <td><a href="<?= base_url('admin/product/detail/' . $u->product->id) ?>"><?= $u->product->name ?></a></td>
                                    <?php }else{ ?>
                                    <td><span>Teslimat Bekleniyor</span></td>
                                    <?php } ?>
                                    <td><?= $u->stock->product ?></td>
                                    <td><?= $u->price ?>₺</td>
                                    <td><?= $u->date ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </main>
