<div id="layoutSidenav_content">

                <main>
                    <div class="container-fluid">

                        <div class="page-title">
                            <h5 class="mb-0">Ürünler</h5>
                        </div>

                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>admin/products">Mağaza</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Ürünler</li>
                            </ol>
                        </nav>

                        <div class="page-btn">
                            <div class="btns">
                                <a href="#editProductPrice" data-toggle="modal" class="btn btn-success btn-sm"> Toplu Fiyatlandırma</a>
                                <a href="<?= base_url(); ?>admin/product/addProduct" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Ürün Ekle</a>
                            </div>
                        </div>

                        <div class="modal fade" id="editProductPrice" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h6 class="modal-title">Toplu Fiyatlandırma</h6>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?= base_url('admin/product/editProductPrice/') ?>"  method="post">
                                            <div class="form-group">
                                                <label for="inputWT" class="float-left">Yüzde cinsinden fiyat değişikliği miktarı</label>
                                                <input type="number" class="form-control" id="inputWT" name="percent" min="0" step="0.01" required="required">
                                            </div>
                                            <div class="form-group">
                                                <label for="inputPCate">Seçim:</label>
                                                <select class="custom-select" name="choose" required>
                                                        <option value="1">Fiyatları Yükselt</option>
                                                        <option value="2">Fiyatları İndir</option>
                                                </select>
                                            </div>
                                            <div class="float-right">
                                                <button type="button" class="btn btn-link btn-sm" data-dismiss="modal">İptal</button>
                                            <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Ekle</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover table-bordered border dataTable table-product">
                                        <thead class="thead-light">
                                            <tr>
                                                <th>Ürün Adı</th>
                                                <th>Fiyat</th>
                                                <th>Stok</th>
                                                <th>API Fiyat Farkı</th>
                                                <th>Kategori</th>
                                                <th>Satıcı</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($product as $p) { ?>
                                                <tr>
                                                <td><img src="<?= base_url(); ?>assets/img/product/<?= $p->img ?>" alt=""> <?= $p->name ?> <?= ($p->isActive == 2) ? "<small class='text-danger'>(Deaktif)</small>" : NULL ?></td>
                                                <td><?= ($p->discount > 0) ? "<s class='text-danger'><small>" . $p->price . "₺</small></s><br> " . $p->discount : $p->price ?>₺</td>
                                                <td class="text-primary"><?php if ($p->isStock == 1) {
                                                    $stok = $this->db->where('isActive', 1)->where('product_id', $p->id)->count_all_results('stock'); 
                                                    echo $stok;
                                                }else{
                                                  echo "Stok Gerektirmeyen Ürün";  
                                                } ?>
                                                </td>
                                                <td>%<?= $p->difference_percent ?></td>
                                                <td><?php $category = $this->db->where('id', $p->category_id)->get('category')->row(); ?> <?= ($category) ? $category->name : "Kategori Bulunamadı" ?> </td>
                                                <td><?php if ($p->seller_id == 0) {
                                                    echo "Yönetici";
                                                }else if($p->seller_id != 0) {
                                                    $seller = $this->db->where('id', $p->seller_id)->get('user')->row();
                                                    if ($seller->isAdmin == 1) {
                                                        echo "Yönetici";
                                                    }else{
                                                        echo $seller->name . " " . $seller->surname;
                                                    }
                                                } ?></td>
                                                <td>
                                                    <a href="#productDiscount<?= $p->id ?>" class="text-success" data-toggle="modal"><i class="fas fa-tags"></i></a>
                                                    <div class="modal fade" id="productDiscount<?=$p->id?>" tabindex="-1" role="dialog" aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h6 class="modal-title">İndirim Düzenle</h6>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form action="<?= base_url('admin/product/edit/products/product/') . $p->id ?>"  method="post">
                                                                    <div class="form-group">
                                                                        <label for="inputWT" class="float-left">Başlık</label>
                                                                        <input type="number" class="form-control" id="inputWT" name="discount" min="0" value="<?= $p->discount ?>" step="0.01" required="required">
                                                                        <small class="float-left">İndirim yok ise 0 olarak bırakın</small>
                                                                    </div>
                                                                    <div class="float-right">
                                                                        <button type="button" class="btn btn-link btn-sm" data-dismiss="modal">İptal</button>
                                                                    <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Ekle</button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                    <a href="<?= base_url(); ?>admin/product/detail/<?= $p->id ?>"><i class="fa fa-edit"></i></a>
                                                </td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
                </main>

               
