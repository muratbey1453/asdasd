<?php $category = $this->db->where('id', $product->category_id)->get('category')->row();
?>
<section class="fp-section-page fp-products-page">
    <div class="container">
        <div class="fp-breadcrumb">
            <ul class="list-inline list-unstyled mb-0 list">
                <li><a href="<?= base_url('tum-kategoriler'); ?>" class="link">Tüm Kategoriler</a></li>
                <li><a href="<?= base_url('kategori/') . $category->slug ?>" class="link"><?=$category->name?></a></li>
                <li><a href="#" class="link active"><?=$product->name?></a></li>
            </ul>
        </div>
        <div class="fp-card fp-product-card">
            <div class="fp-card-body">
                <div class="row">
                    <div class="col-lg-9">
                        <div class="row">
                            <div class="col-lg-5">
                                <div class="img-cover"><img src="<?= base_url('assets/img/product/') . $product->img; ?>" alt="" class="img-product img-aspect"></div>
                            </div>
                            <div class="col-lg-7">
                                <div class="content">
                                    <h1 class="product-name"><?= $product->name ?></h1>
                                    <div class="text">
                                        <p><?=substr($product->desc, 0, 200) . "..."; ?></p>
                                    </div>
                                    <a href="#urun-hakkinda" class="link-more">Devamını Oku <i class="ri-arrow-down-s-line"></i></a>
                                    <div class="action-area">
                                        <div class="price">
                                            <?php
                                            $price = json_decode(calculatePrice($product->id, 1), true);
                                            $total = ($price['price'] - $price['normalPrice']) / $price['normalPrice'] * 100;
                                            ?>
                                            <?php if ($price['isDiscount'] == 1) { ?>
                                                <div class="price-new"><?= $price['price'] ?> TL</div>
                                                <div class="price-old"><?= $price['normalPrice'] ?> TL</div>
                                            <?php }else{ ?>
                                                <div class="price-new"><?= $price['price'] ?> TL</div>
                                            <?php } ?>
                                        </div>
                                        <?php $inf = json_decode($product->text); ?>
                                        <?php $a = 1; ?>
                                        <?php foreach ($inf as $i) {
                                            if (!empty($i)) { ?>
                                                <input type="text" class="form-control mb-2" id="extras<?=$a?>" name="<?= $i ?>" placeholder="<?= $i ?>" required style="min-height:50px">
                                                <div id="extras<?=$a?>Feedback" class="invalid-feedback"><?= $i ?> alanını boş bırakamazsınız!</div>
                                                <?php $a++; } } ?>
                                        <div class="grid">
                                            <div class="fp-quantity">
                                                <a href="#" class="fp-quantity-btn minus"><i class="ri-subtract-line"></i></a>
                                                <input type="number" class="form-control" min="1" name="amount" id="amount" value="1">
                                                <a href="#" class="fp-quantity-btn plus"><i class="ri-add-line"></i></a>
                                            </div>
                                            <?php if (!empty($this->session->userdata('info')) || $properties->isGuest == 1) { ?>
                                                <?php if ($product->isStock == 0 || $stock > 0 || $properties->isStock == 1){ ?>
                                                    <a id="addItem" onclick="addItem();" class="btn btn-primary"><i class="ri-shopping-cart-2-line icon icon-left"></i> Sepete Ekle</a>
                                                <?php }else{ ?>
                                                    <a class="btn btn-primary">Stok Bulunamadı</a>
                                                <?php } ?>
                                            <?php }else{ ?>
                                                <a href="<?= base_url('hesap') ?>" class="btn btn-warning"><i class="ri-shopping-cart-2-line icon icon-left"></i> Giriş Yapmalısın</a>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                    $seller = ($product->seller_id == 0) ? convertToObject([
                        "isAdmin" => 1
                    ]) : $this->db->where(['id' => $product->seller_id, "type" => 2])->get('user')->row();
                    ?>
                    <?php if (empty($seller) || $seller->isAdmin == 1) {
                        /*$seller = $this->db->where('isAdmin', 1)->get('user')->row();
                        $seller->shop_name = $properties->name;
                        $seller->shop_img = "assets/img/site/".$properties->img;
                        $seller->success_invoice = $this->db->count_all_results('invoice');
                        $seller->link = base_url('tum-kategoriler');
                        $seller->message = base_url('client/ticket');*/
                    } else {
                        /*
                        $seller->shop_img = "assets/img/shop/".$seller->shop_img;
                        $seller->success_invoice = $this->db->where('seller_id', $seller->id)->count_all_results('invoice');
                        $seller->link = base_url('magaza/') . $seller->shop_slug;
                        $seller->message = "#modal-seller-message";*/
                        ?>
                        <div class="col-lg-3">
                            <div class="fp-seller-card">
                                <img src="<?= base_url('assets/img/shop/') . $seller->shop_img ?>" alt="" class="img-profile">
                                <h4 class="name"><?=$seller->shop_name?></h4>
                                <div class="info"><i class="ri-store-line icon"></i> <?= $this->db->where('seller_id', $seller->id)->count_all_results('invoice'); ?> Başarılı Satış</div>
                                <a href="<?= base_url('magaza/') . $seller->shop_slug ?>" class="btn btn-opacity-primary"><i class="ri-grid-fill icon icon-left"></i> Tüm İlanlar</a>
                                <a href="#modal-seller-message" data-bs-target="#modal-seller-message" data-bs-toggle="modal" class="btn btn-opacity-success"><i class="ri-question-answer-line icon icon-left"></i> Mesaj Gönder</a>
                            </div>
                        </div>
                        <div class="modal fade" id="modal-seller-message" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Satıcıya Mesaj Gönder</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?= base_url('client/addSupport')."?shop=".$seller->shop_slug; ?>" method="POST">
                                            <div class="mb-3">
                                                <label for="">Konu</label>
                                                <input type="text" class="form-control" name="title" required="">
                                            </div>
                                            <div class="mb-3">
                                                <label for="">Mesaj</label>
                                                <textarea rows="3" class="form-control" name="message"></textarea>
                                            </div>
                                            <button type="submit" class="btn btn-primary w-100 d-block">Gönder</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
        <div class="fp-card" id="urun-hakkinda">
            <div class="fp-card-body">
                <ul class="fp-tabs-nav fp-tabs-nav-system list-inline list-unstyled">
                    <li><a href="#" class="link active" id="urun-hakkinda">Ürün Hakkında</a></li>
                    <li><a href="#" class="link" id="yorumlar">Yorumlar</a></li>
                </ul>
                <div class="fp-tabs">
                    <div class="fp-tabs-content active" id="urun-hakkinda-content">
                        <div class="fp-product-context">
                            <p><?= $product->desc; ?></p>
                        </div>
                    </div>
                    <div class="fp-tabs-content" id="yorumlar-content">
                        <?php if (!empty($history)) { ?>
                            <div class="fp-comments-total">
                                <div class="text">Toplam Puan <span class="fw-medium">(<?= calculateAverageRating($comments); ?>)</span></div>
                                <div class="fp-stars">
                                    <?php

                                    $averageStars = calculateAverageRating($comments);
                                    $filledStars = floor($averageStars);
                                    $emptyStars = 5 - $filledStars;
                                    for ($i = 0; $i < $filledStars; $i++) {
                                        echo '<i class="ri-star-fill"></i>';
                                    }
                                    for ($i = 0; $i < $emptyStars; $i++) {
                                        echo '<i class="ri-star-line"></i>';
                                    }
                                    ?>
                                </div>
                            </div>
                            <?php foreach ($history as $comment) { ?>
                                <?php $user = $this->db->where('id', $comment->user_id)->get('user')->row(); ?>
                                <div class="fp-comment-item">
                                    <div class="user">
                                        <div class="name"><?= $user->name . " " . $user->surname ?></div>
                                        <div class="fp-stars">
                                            <?php
                                            $filledStars = $comment->star;
                                            $emptyStars = 5 - $filledStars;
                                            for ($i = 0; $i < $filledStars; $i++) {
                                                echo '<i class="ri-star-fill"></i>';
                                            }
                                            for ($i = 0; $i < $emptyStars; $i++) {
                                                echo '<i class="ri-star-line"></i>';
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <p class="text"><?= $comment->comment ?></p>
                                        <div class="date"><?= $comment->date ?></div>
                                    </div>
                                </div>
                            <?php } ?>
                        <?php } else { ?>
                            <div class="alert alert-info mb-0">Henüz yorum bulunmamaktadır.</div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<section class="fp-section">
    <div class="container">
        <div class="fp-section-head">
            <h4 class="title mb-0">İlgini Çekebilir</h4>
            <a href="<?=base_url('kategori/') . $category->slug?>" class="btn btn-white rounded-pill">Tüm Ürünler <i class="ri-arrow-right-s-line icon icon-right"></i></a>
        </div>
        <?php $products = $this->db->limit(8)->where('category_id', $category->id)->where('isActive', 1)->get('product')->result(); ?>
        <?php foreach($products as $p){ ?>
            <div class="fp-product-horizontal">
                <div class="left">
                    <div class="img"><img src="<?= base_url('assets/img/product/') . $p->img ?>" alt="Ürün Resmi" class="img-product"></div>
                    <div class="content">
                        <a class="product-name" href="<?= base_url($p->slug) ?>"><?= $p->name ?></a>
                        <p class="text mb-0"><i class="ri-information-fill"></i> Ürün hakkında detaylı bilgi için ürün sayfasını inceleyebilirsiniz.</p>
                    </div>
                    <?php $price = json_decode(calculatePrice($p->id, 1), true); ?>
                    <div class="price">
                        <?php if ($price['isDiscount'] == 1) { ?>
                            <div class="price-new"><?= $price['price'] ?> TL</div>
                            <div class="price-old"><?= $price['normalPrice'] ?> TL</div>
                        <?php }else{ ?>
                            <div class="price-new"><?= $price['price'] ?> TL</div>
                        <?php } ?>
                    </div>
                </div>
                <div class="price">
                    <?php if ($price['isDiscount'] == 1) { ?>
                        <div class="price-new"><?= $price['price'] ?> TL</div>
                        <div class="price-old"><?= $price['normalPrice'] ?> TL</div>
                    <?php }else{ ?>
                        <div class="price-new"><?= $price['price'] ?> TL</div>
                    <?php } ?>
                </div>
                <div class="right">
                    <div class="fp-quantity">
                        <a href="#" class="fp-quantity-btn minus"><i class="ri-subtract-line"></i></a>
                        <input type="number" class="form-control" min="1" value="1" name="amounts" id="amounts">
                        <a href="#" class="fp-quantity-btn plus"><i class="ri-add-line"></i></a>
                    </div>
                    <?php if (!empty($this->session->userdata('info')) || $properties->isGuest == 1) { ?>
                        <?php if ($product->isStock == 1 && $properties->isStock == 1){ ?>
                            <a href="#" class="btn btn-primary" id="addItem<?=$p->id?>" onclick="addItem(<?=$p->id?>)"><i class="ri-shopping-cart-2-line icon icon-left"></i> Sepete Ekle</a>
                        <?php }else{ ?>
                            <a href="<?=base_url($p->slug)?>" class="btn btn-primary"> Ürünü İncele</a>
                        <?php } ?>
                    <?php }else{ ?>
                        <a href="<?= base_url('hesap') ?>" class="btn btn-warning"><i class="ri-shopping-cart-2-line icon icon-left"></i> Giriş Yapmalısın</a>
                    <?php } ?>
                </div>
            </div>
        <?php } ?>
    </div>
</section>
<script type="text/javascript">
    function addItem() {
        var extras = {
            name1: $("#extras1").attr("name"),
            number1: $("#extras1").val(),
            name2: $("#extras2").attr("name"),
            number2: $("#extras2").val(),
            name3: $("#extras3").attr("name"),
            number3: $("#extras3").val()
        };
        var is_valid = true;
        if ($("#extras1").prop("required") && extras.number1.length === 0) {
            $("#extras1").addClass("is-invalid");
            is_valid = false;
        } else {
            $("#extras1").removeClass("is-invalid").addClass("is-valid");
            setTimeout(function() {
                $("#extras1").removeClass("is-valid");
            }, 1000);
        }
        extras.name2 = $("#extras2").attr("name");
        extras.number2 = $("#extras2").val();
        if ($("#extras2").prop("required") && extras.number2.length === 0) {
            $("#extras2").addClass("is-invalid");
            is_valid = false;
        } else {
            $("#extras2").removeClass("is-invalid").addClass("is-valid");
            setTimeout(function() {
                $("#extras2").removeClass("is-valid");
            }, 1000);
        }
        extras.name3 = $("#extras3").attr("name");
        extras.number3 = $("#extras3").val();
        if ($("#extras3").prop("required") && extras.number3.length === 0) {
            $("#extras3").addClass("is-invalid");
            is_valid = false;
        } else {
            $("#extras3").removeClass("is-invalid").addClass("is-valid");
            setTimeout(function() {
                $("#extras3").removeClass("is-valid");
            }, 1000);
        }
        if (!is_valid) return;
        var amount = $("#amount").val();
        var dataToSend = {
            id: <?= $product->id ?>,
            extras: extras,
            amount: amount
        };
        $.post({
            url: "<?= base_url(); ?>/home/addToCartItem",
            type: "POST",
            data: dataToSend,
            success: function (response) {
                console.log(response);
                $("#cart").html(response);
                $('#addItem').html("Sepete Eklendi");
                setTimeout(function () {
                    $('#addItem').html("Sepete Ekle");
                }, 500);
            }
        });
        $.ajax({
            url: "<?= base_url('API/getCartAmount'); ?>",
            type: "POST",
            data: {},
            success: function (amount) {
                $('#MobileNavbarCart').html('Sepet (' + amount + ')');
            }
        });
    }

    function addItems(productId) {
        var extras = {};
        extras.name1 = $("#extras1").attr("name");
        extras.number1 = $("#extras1").val();
        extras.name2 = $("#extras2").attr("name");
        extras.number2 = $("#extras2").val();
        extras.name3 = $("#extras3").attr("name");
        extras.number3 = $("#extras3").val();
        var amounts = $("#amounts").val();
        $.post({
            url: "<?= base_url('home/addToCartItem'); ?>",
            type: "POST",
            data: {"id": productId, "extras": extras, "amount": amounts},
            success:function(e){
                $("#cart").html(e);
                $('#addItems' + productId).html('Sepete Eklendi');
                setTimeout(function() {
                    $('#addItems' + productId).html('<i class="ri-shopping-cart-2-line icon icon-left"></i>Sepete Ekle');
                }, 500);
            }
        });
        $.ajax({
            url: "<?= base_url('API/getCartAmount'); ?>",
            type: "POST",
            data: {},
            success:function(amount){
                console.log(amount);
                $('#MobileNavbarCart').html('Sepet (' + amount + ')');
            }
        });
    }
</script> 
