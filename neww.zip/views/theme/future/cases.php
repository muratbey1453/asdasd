<style>
    /* Base Styles (Light Mode defaults using variables) */
    .fp-case-item {
        background-color: var(--bg-white);
        border-radius: 24px;
        height: 100%;
        border: 1px solid var(--border);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        position: relative;
    }

    .fp-case-item:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.05);
    }

    .fp-case-item .img {
        padding-bottom: 100%; /* Square */
        background: radial-gradient(circle, rgba(0, 137, 255, 0.05) 0%, rgba(0,0,0,0) 70%);
        position: relative;
        width: 100%;
    }
    
    .fp-case-item .img img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: contain;
        filter: drop-shadow(0 0 10px rgba(0, 137, 255, 0.2));
        transition: transform 0.3s ease;
    }

    .fp-case-item:hover .img img {
        transform: scale(1.05);
    }

    .fp-case-item .content {
        margin-top: 0;
        padding: 15px;
        flex-grow: 1;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }

    .fp-case-item .product-name {
        font-size: 16px !important;
        height: auto !important;
        margin-bottom: 10px;
        color: var(--text-color);
        text-align: center;
        font-weight: 700;
        display: block;
        text-decoration: none;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .fp-case-item .price {
        font-size: 18px !important;
        background-color: var(--bg-white-2);
        border-radius: 8px;
        padding: 8px;
        color: var(--text-color);
        font-weight: 700;
        width: 100%;
        text-align: center;
        margin-top: auto;
        display: block;
    }
    
    .fp-case-item .price .price-decimal {
        font-size: 0.75em;
        opacity: 0.7;
    }

    /* Dark Mode Overrides (The "Gambling" Aesthetic) */
    html[data-theme="dark"] .fp-case-item {
        background-color: #111;
        border-color: #222;
    }
    
    html[data-theme="dark"] .fp-case-item:hover {
        box-shadow: 0 10px 30px rgba(0,0,0,0.5);
    }

    html[data-theme="dark"] .fp-case-item .img {
        background: radial-gradient(circle, rgba(0, 137, 255, 0.1) 0%, rgba(0,0,0,0) 70%);
    }

    html[data-theme="dark"] .fp-case-item .img img {
        filter: drop-shadow(0 0 15px rgba(0, 137, 255, 0.4));
    }

    html[data-theme="dark"] .fp-case-item .product-name {
        color: #fff;
    }

    html[data-theme="dark"] .fp-case-item .price {
        background-color: #1a1a1a;
        color: #fff;
    }
    
    html[data-theme="dark"] .fp-case-item .price .price-decimal {
        opacity: 0.8;
    }
</style>

<div class="container mt-5">
    <div class="row row-products">
    <?php foreach($cases as $p) { 
        $price_parts = explode('.', $p->price);
        if (count($price_parts) == 1) {
             // If no decimal part, check for comma
             $price_parts = explode(',', $p->price);
        }
        $integer_part = $price_parts[0];
        $decimal_part = isset($price_parts[1]) ? $price_parts[1] : '00';
    ?>
    <div class="col-6 col-md-4 col-lg-3 col-xl-2 mb-4">
        <div class="fp-product-item fp-case-item">
            <a class="img" href="<?= base_url("case/" . $p->slug) ?>">
                <img src="<?= base_url('assets/img/case/') . $p->img ?>" alt="Ürün Resmi" class="img-product">
            </a>
            <div class="content">
                <a class="product-name" href="<?= base_url("case/" . $p->slug) ?>"><?= $p->name ?></a>
                <div class="price">
                    <span class="price-new"><?= $integer_part ?><span class="price-decimal">.<?= $decimal_part ?></span> TL</span>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>
</div>
</div>
