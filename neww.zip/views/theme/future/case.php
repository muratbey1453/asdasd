
<section class="top-slider kasalar-sayfasi margintop10">
	<div class="container">
		<div class="title-group">
			<div class="title">
				<span class="text-primary"><?= $case->name ?> (<?= $case->price ?>₺) </span>
			</div>
		</div>
	</div>
	<div class="container-fluid">
  <div class="kasalar-items kasalar-items-swiper swiper-container" id="caseSwiper">
    
    <!-- ORTA ÇİZGİ (MARKER) -->
    <div class="case-center-marker" aria-hidden="true">
      <span class="case-center-marker__tip"></span>
    </div>

    <div class="swiper-wrapper">
      <?php foreach ($case->items as $item): ?>
        <div class="swiper-slide" data-product-id="<?= $item->product->id ?>">
          <div class="item <?= get_color_by_chance($item->chance) ?>">
            <div class="absolute">
              <div class="bottom">
                <h3 class="text-white"><?= $item->product->name ?></h3>
                <span><?= $item->product->price ?>₺</span>
              </div>
            </div>
            <img src="<?= base_url("assets/img/product/".$item->product->img) ?>" alt="">
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="button-group">
    <button class="btn btn-primary open"
            data-button-type="case"
            data-case-id="<?= $case->id ?>">
      <span><?= $case->price ?>₺ Karşılığında <?= $case->name ?> Adlı Kasayı Aç</span>
    </button>
  </div>
</div>

		
		<?php $caseItems = $this->db->where('case_id', $case->id)->get('case_items')->result(); ?>
<div class="modal fade" id="caseWinModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content case-win-modal">
      <div class="modal-header border-0 pb-0">
        <h5 class="modal-title">🎉 Kazandın!</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
      </div>

      <div class="modal-body pt-2">
        <div class="case-win-body">
          <div class="case-win-imgwrap">
            <img id="caseWinImg" src="" alt="">
          </div>

          <div class="case-win-info">
            <div id="caseWinRarity" class="case-win-rarity"></div>

            <h4 id="caseWinName" class="case-win-name"></h4>

            <div class="case-win-meta">
              <span id="caseWinPrice"></span>
              <span id="caseWinChance"></span>
            </div>

            <a id="caseWinLink" class="btn btn-outline-light w-100 mt-3" href="#" style="display:none;">
              Ürünü Gör
            </a>

            <button type="button" class="btn btn-primary w-100 mt-2" data-bs-dismiss="modal">
              Tamam
            </button>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

<style>
    /* ORTA KAZANÇ ÇİZGİSİ */
.kasalar-sayfasi .kasalar-items-swiper {
  position: relative;
}

.kasalar-sayfasi .case-center-marker {
  position: absolute;
  left: 50%;
  top: 10px;
  bottom: 10px;
  width: 2px;
  transform: translateX(-50%);
  z-index: 50;
  pointer-events: none;
  border-radius: 99px;
  background: linear-gradient(
    to bottom,
    rgba(255,255,255,0) 0%,
    rgba(0, 238, 255, 0.95) 25%,
    rgba(9, 110, 226, 0.95) 75%,
    rgba(255,255,255,0) 100%
  );
  box-shadow: 0 0 18px rgba(255,255,255,0.25);
}

html[data-theme="dark"] .kasalar-sayfasi .case-center-marker {
  background: linear-gradient(
    to bottom,
    rgba(255,41,130,0) 0%,
    rgba(255,41,130,0.95) 25%,
    rgba(255,41,130,0.95) 75%,
    rgba(255,41,130,0) 100%
  );
  box-shadow: 0 0 22px rgba(255,41,130,0.35);
}

/* küçük ok ucu */
.kasalar-sayfasi .case-center-marker__tip {
  position: absolute;
  top: 8px;
  left: 50%;
  transform: translateX(-50%);
  width: 0; height: 0;
  border-left: 8px solid transparent;
  border-right: 8px solid transparent;
  border-top: 10px solid rgba(238, 255, 0, 0.95);
  filter: drop-shadow(0 6px 10px rgba(0,0,0,0.35));
}

html[data-theme="dark"] .kasalar-sayfasi .case-center-marker__tip {
  border-top-color: rgba(255,41,130,0.95);
}

    /* Global Theme Support - Scoped to this page */
    .kasalar-sayfasi {
        background-color: var(--background) !important;
        padding-bottom: 50px;
    }
    
    /* Dark Mode Specific Background */
    html[data-theme="dark"] .kasalar-sayfasi {
        background-color: #000 !important;
    }

	.kasalar-sayfasi .top-slider {
		
	}
	.kasalar-sayfasi .title-group {
		display: flex;
		-ms-flex-pack: center;
		justify-content: center;
		position: relative;
        margin-bottom: 30px;
	}

	.kasalar-sayfasi .title-group .title span {
		font-family: 'Poppins', sans-serif;
		font-size: 32px;
		font-weight: 800;
		text-align: center;
		color: var(--text-color) !important;
        text-transform: uppercase;
        letter-spacing: 1px;
	}
    
    html[data-theme="dark"] .kasalar-sayfasi .title-group .title span {
        color: #fff !important;
        text-shadow: 0 0 10px rgba(255, 255, 255, 0.3);
    }

	.kasalar-sayfasi .swiper-container {
		margin-left: auto;
		margin-right: auto;
		position: relative;
		overflow: visible;
		list-style: none;
		padding: 20px 0;
		z-index: 1;
	}
	
    /* Slider Items Redesign */
	.kasalar-sayfasi .kasalar-items .item {
		width: 100%;
		position: relative;
		overflow: hidden;
        background-color: var(--bg-white) !important;
        border-radius: 16px;
        border: 1px solid var(--border) !important;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
	}
    
    html[data-theme="dark"] .kasalar-sayfasi .kasalar-items .item {
        background-color: #111 !important;
        border-color: #222 !important;
    }

    .kasalar-sayfasi .kasalar-items .item:hover {
        transform: translateY(-5px);
        z-index: 10;
    }

    /* Rarity Glows - Only strong in dark mode */
	.kasalar-sayfasi .kasalar-items .item.blue { border-color: #7ad5ff !important; }
	.kasalar-sayfasi .kasalar-items .item.red { border-color: #ff3434 !important; }
	.kasalar-sayfasi .kasalar-items .item.orange { border-color: #ff8034 !important; }
	.kasalar-sayfasi .kasalar-items .item.grey { border-color: #959595 !important; }

    html[data-theme="dark"] .kasalar-sayfasi .kasalar-items .item.blue { box-shadow: 0 0 15px rgba(122, 213, 255, 0.2); }
    html[data-theme="dark"] .kasalar-sayfasi .kasalar-items .item.red { box-shadow: 0 0 15px rgba(255, 52, 52, 0.2); }
    html[data-theme="dark"] .kasalar-sayfasi .kasalar-items .item.orange { box-shadow: 0 0 15px rgba(255, 128, 52, 0.2); }
    html[data-theme="dark"] .kasalar-sayfasi .kasalar-items .item.grey { box-shadow: 0 0 15px rgba(149, 149, 149, 0.2); }

    /* Remove old overlay */
	.kasalar-sayfasi .kasalar-items .item:after {
		display: none;
	}

	.kasalar-sayfasi .kasalar-items .item .absolute {
		position: absolute;
		margin: 0 auto;
		width: 100%;
		bottom: 0;
		z-index: 2;
        background: linear-gradient(to top, rgba(255,255,255,0.95) 0%, rgba(255,255,255,0.8) 40%, rgba(255,255,255,0) 100%);
        padding: 30px 10px 20px 10px;
	}
    
    html[data-theme="dark"] .kasalar-sayfasi .kasalar-items .item .absolute {
        background: linear-gradient(to top, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.8) 40%, rgba(0,0,0,0) 100%);
    }

	.kasalar-sayfasi .kasalar-items .item .absolute .bottom h3 {
		font-size: 18px;
		font-weight: 600;
		color: var(--text-color) !important;
        margin-bottom: 5px;
	}
    
    html[data-theme="dark"] .kasalar-sayfasi .kasalar-items .item .absolute .bottom h3 {
        color: #fff !important;
        text-shadow: 0 2px 4px rgba(0,0,0,0.8);
    }

	.kasalar-sayfasi .kasalar-items .item .absolute .bottom span {
		font-size: 16px;
		font-weight: 500;
		color: var(--text-gray) !important;
		width: 100%;
		display: block;
	}
    
    html[data-theme="dark"] .kasalar-sayfasi .kasalar-items .item .absolute .bottom span {
        color: #ddd !important;
        text-shadow: 0 2px 4px rgba(0,0,0,0.8);
    }

    .kasalar-sayfasi .top-slider .item img {
		width: 100% !important;
		height: auto !important;
        aspect-ratio: 1/1;
        object-fit: contain;
        padding: 20px;
	}
    
    html[data-theme="dark"] .kasalar-sayfasi .top-slider .item img {
        filter: drop-shadow(0 0 10px rgba(255,255,255,0.1));
    }

    /* Button Group */
	.kasalar-sayfasi .button-group {
		justify-content: center;
		display: flex;
		margin-top: 40px;
        margin-bottom: 20px;
	}

	.kasalar-sayfasi .button-group button {
		padding: 15px 30px;
		border: 0;
        cursor: pointer;
        transition: all 0.3s ease;
	}

	.kasalar-sayfasi .button-group button.open {
		border-radius: 50px;
		background: linear-gradient(135deg, #ff2982 0%, #ff00cc 100%);
		font-family: 'Poppins', sans-serif;
		font-size: 16px;
		font-weight: 700;
		color: #fff;
		text-transform: uppercase;
        box-shadow: 0 0 20px rgba(255, 41, 130, 0.6);
        letter-spacing: 1px;
	}

    .kasalar-sayfasi .button-group button.open:hover {
        transform: scale(1.05);
        box-shadow: 0 0 30px rgba(255, 41, 130, 0.8);
    }

	.kasalar-sayfasi .button-group button.open span {
        background: transparent;
		margin-left: 10px;
		padding: 0;
		font-size: 12px;
		font-weight: 600;
        opacity: 0.9;
	}

    /* Text Group */
	.kasalar-sayfasi .text-group .text p {
		font-family: 'Poppins', sans-serif;
		font-size: 14px;
		font-weight: 400;
		text-align: center;
		color: var(--text-gray) !important;
        margin-top: 10px;
	}

    /* Bottom Product Grid - Redesigned */
    .kasalar-sayfasi .fp-product-item {
        background-color: var(--bg-white) !important;
        border-radius: 12px !important;
        border: 1px solid var(--border) !important;
        padding: 15px !important;
        height: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: space-between;
        position: relative;
        overflow: hidden !important;
        margin-bottom: 30px;
        transition: transform 0.3s ease, border-color 0.3s ease;
    }
    
    html[data-theme="dark"] .kasalar-sayfasi .fp-product-item {
        background-color: #1a1a1a !important;
        border-color: #333 !important;
    }

    .kasalar-sayfasi .fp-product-item:hover {
        transform: translateY(-5px);
    }

    /* Rarity Styling for Grid Items */
    .kasalar-sayfasi .fp-product-item.blue { border-color: #7ad5ff !important; }
    .kasalar-sayfasi .fp-product-item.red { border-color: #ff3434 !important; }
    .kasalar-sayfasi .fp-product-item.orange { border-color: #ff8034 !important; }
    .kasalar-sayfasi .fp-product-item.grey { border-color: #959595 !important; }

    html[data-theme="dark"] .kasalar-sayfasi .fp-product-item.blue { background: linear-gradient(180deg, rgba(122, 213, 255, 0.05) 0%, rgba(26, 26, 26, 1) 100%) !important; }
    html[data-theme="dark"] .kasalar-sayfasi .fp-product-item.red { background: linear-gradient(180deg, rgba(255, 52, 52, 0.05) 0%, rgba(26, 26, 26, 1) 100%) !important; }
    html[data-theme="dark"] .kasalar-sayfasi .fp-product-item.orange { background: linear-gradient(180deg, rgba(255, 128, 52, 0.05) 0%, rgba(26, 26, 26, 1) 100%) !important; }
    html[data-theme="dark"] .kasalar-sayfasi .fp-product-item.grey { background: linear-gradient(180deg, rgba(149, 149, 149, 0.05) 0%, rgba(26, 26, 26, 1) 100%) !important; }

    .kasalar-sayfasi .fp-product-item.blue .product-name { color: #7ad5ff !important; }
    .kasalar-sayfasi .fp-product-item.red .product-name { color: #ff3434 !important; }
    .kasalar-sayfasi .fp-product-item.orange .product-name { color: #ff8034 !important; }
    .kasalar-sayfasi .fp-product-item.grey .product-name { color: #999 !important; }
    
    html[data-theme="dark"] .kasalar-sayfasi .fp-product-item.grey .product-name { color: #ccc !important; }


    .kasalar-sayfasi .fp-product-item .img {
        width: 100%;
        padding-bottom: 80%;
        position: relative;
        margin-bottom: 10px;
        z-index: 2;
    }

    .kasalar-sayfasi .fp-product-item .img img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: contain;
    }
    
    html[data-theme="dark"] .kasalar-sayfasi .fp-product-item .img img {
        filter: drop-shadow(0 0 5px rgba(255,255,255,0.1));
    }

    .kasalar-sayfasi .fp-product-item .content {
        width: 100%;
        text-align: center;
        z-index: 2;
        padding: 0 !important;
    }

    .kasalar-sayfasi .fp-product-item .product-info-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 8px;
        width: 100%;
    }

    .kasalar-sayfasi .fp-product-item .product-name {
        font-size: 13px !important;
        font-weight: 600 !important;
        text-decoration: none;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        max-width: 65%;
        text-align: left;
    }

    .kasalar-sayfasi .fp-product-item .price {
        background-color: transparent !important;
        padding: 0 !important;
        text-align: right;
        font-size: 13px !important;
        font-weight: 700 !important;
        margin: 0 !important;
        display: block !important;
    }

    .kasalar-sayfasi .fp-product-item .price .price-new {
        color: var(--text-color) !important;
    }
    
    html[data-theme="dark"] .kasalar-sayfasi .fp-product-item .price .price-new {
        color: #fff !important;
    }
    
    .kasalar-sayfasi .fp-product-item .chance-row {
        width: 100%;
        text-align: left;
        font-size: 11px;
        color: var(--text-gray) !important;
        border-top: 1px solid var(--border) !important;
        padding-top: 8px;
    }
    
    html[data-theme="dark"] .kasalar-sayfasi .fp-product-item .chance-row {
        color: #666 !important;
        border-top: 1px solid rgba(255,255,255,0.1) !important;
    }

    .kasalar-sayfasi .fp-product-item .seller {
        display: none; 
    }

    /* Hide slider fades for cleaner look */
	.kasalar-sayfasi .top-slider .kasalar-items::before,
	.kasalar-sayfasi .top-slider .kasalar-items:after,
    .kasalar-sayfasi .top-slider .title-group:after {
		display: none;
	}
    
    /* Section Title */
    .kasalar-sayfasi .section-title {
        text-align: center;
        color: var(--text-color) !important;
        font-family: 'Poppins', sans-serif;
        font-size: 24px;
        font-weight: 700;
        margin-bottom: 30px;
        margin-top: 50px;
        text-transform: uppercase;
        letter-spacing: 1px;
        position: relative;
        display: inline-block;
    }
    
    html[data-theme="dark"] .kasalar-sayfasi .section-title {
        color: #fff !important;
    }
    
    .kasalar-sayfasi .section-title-wrapper {
        text-align: center;
        width: 100%;
    }

</style>

<div class="container">
    <div class="section-title-wrapper">
        <h3 class="section-title">Kasada Bulunan Ürünler</h3>
    </div>
    <div class="row row-products justify-content-center">
    <?php foreach($caseItems as $caseItem) { ?>
    <?php $p = $this->db->where('id', $caseItem->product_id)->get('product')->row(); ?>
    <div class="col-6 col-md-4 col-lg-3 col-xl-2 mb-4">
        <div class="fp-product-item <?= get_color_by_chance($caseItem->chance) ?>">
            <a class="img" href="<?= base_url($p->slug) ?>">
                <img src="<?= base_url('assets/img/product/') . $p->img ?>" alt="Ürün Resmi" class="img-product">
            </a>
            <div class="content">
                <div class="product-info-row">
                    <a class="product-name" href="<?= base_url($p->slug) ?>"><?= $p->name ?></a>
                    <div class="price">
                        <?php 
                            $price = json_decode(calculatePrice($p->id, 1), true);
                        ?>
                        <div class="price-new"><?= $price['price'] ?> ₺</div>
                    </div>
                </div>
                <div class="chance-row">
                    Kazanma Şansı: <?= $caseItem->chance ?>%
                </div>
            </div>
        </div>
    </div>
    <?php } ?>
</div>
</div>
        
	</div>
</section>
</main>

<link rel="stylesheet" href="<?= base_url("assets/future/css/swiper-bundle.min.css") ?>">
<script src="<?= base_url("assets/future/js/swiper-bundle.min.js") ?>"></script>

<style>
    /* Global Dark Theme Fixes */
    .kasalar-sayfasi {
        background-color: #000; /* Ensure dark background */
        padding-bottom: 50px;
    }

	.top-slider {
		
	}
	.title-group {
		display: flex;
		-ms-flex-pack: center;
		justify-content: center;
		position: relative;
        margin-bottom: 30px;
	}

	.title-group .title span {
		font-family: 'Poppins', sans-serif;
		font-size: 32px;
		font-weight: 800;
		text-align: center;
		color: #fff; /* White title */
        text-transform: uppercase;
        letter-spacing: 1px;
        text-shadow: 0 0 10px rgba(255, 255, 255, 0.3);
	}
	.swiper-container {
		margin-left: auto;
		margin-right: auto;
		position: relative;
		overflow: visible; /* Allow glow to show */
		list-style: none;
		padding: 20px 0; /* Space for hover/glow */
		z-index: 1;
	}
	
    /* Slider Items Redesign */
	.kasalar-items .item {
		width: 100%;
		position: relative;
		overflow: hidden;
        background-color: #111;
        border-radius: 16px;
        border: 1px solid #222;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
	}

    .kasalar-items .item:hover {
        transform: translateY(-5px);
        z-index: 10;
    }

    /* Rarity Glows */
	.kasalar-items .item.blue {
		border: 1px solid #7ad5ff;
        box-shadow: 0 0 15px rgba(122, 213, 255, 0.2);
	}
	.kasalar-items .item.red {
		border: 1px solid #ff3434;
        box-shadow: 0 0 15px rgba(255, 52, 52, 0.2);
	}
	.kasalar-items .item.orange {
		border: 1px solid #ff8034;
        box-shadow: 0 0 15px rgba(255, 128, 52, 0.2);
	}
	.kasalar-items .item.grey {
		border: 1px solid #959595;
        box-shadow: 0 0 15px rgba(149, 149, 149, 0.2);
	}

    /* Remove old overlay */
	.kasalar-items .item:after {
		display: none;
	}

	.kasalar-items .item .absolute {
		position: absolute;
		margin: 0 auto;
		width: 100%;
		bottom: 0;
		z-index: 2;
        /* Improved text visibility background */
        background: linear-gradient(to top, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.8) 40%, rgba(0,0,0,0) 100%);
        padding: 30px 10px 20px 10px;
	}

	.kasalar-items .item .absolute .bottom h3 {
		font-size: 18px;
		font-weight: 600;
		color: #fff;
        margin-bottom: 5px;
        text-shadow: 0 2px 4px rgba(0,0,0,0.8); /* Stronger shadow */
	}

	.kasalar-items .item .absolute .bottom span {
		font-size: 16px;
		font-weight: 500;
		color: #ddd;
		width: 100%;
		display: block;
        text-shadow: 0 2px 4px rgba(0,0,0,0.8); /* Stronger shadow */
	}

    .top-slider .item img {
		width: 100% !important;
		height: auto !important;
        aspect-ratio: 1/1;
        object-fit: contain;
        padding: 20px;
        filter: drop-shadow(0 0 10px rgba(255,255,255,0.1));
	}

    /* Button Group */
	.button-group {
		justify-content: center;
		display: flex;
		margin-top: 40px;
        margin-bottom: 20px;
	}

	.button-group button {
		padding: 15px 30px;
		border: 0;
        cursor: pointer;
        transition: all 0.3s ease;
	}

	.button-group button.open {
		border-radius: 50px; /* Pill shape */
		background: linear-gradient(135deg, #ff2982 0%, #ff00cc 100%);
		font-family: 'Poppins', sans-serif;
		font-size: 16px;
		font-weight: 700;
		color: #fff;
		text-transform: uppercase;
        box-shadow: 0 0 20px rgba(255, 41, 130, 0.6);
        letter-spacing: 1px;
	}

    .button-group button.open:hover {
        transform: scale(1.05);
        box-shadow: 0 0 30px rgba(255, 41, 130, 0.8);
    }

	.button-group button.open span {
        background: transparent;
		margin-left: 10px;
		padding: 0;
		font-size: 12px;
		font-weight: 600;
        opacity: 0.9;
	}

    /* Text Group */
	.text-group .text p {
		font-family: 'Poppins', sans-serif;
		font-size: 14px;
		font-weight: 400;
		text-align: center;
		color: #888;
        margin-top: 10px;
	}

    /* Bottom Product Grid - Tall Card Design */
    .fp-product-item {
        background-color: #111 !important;
        border-radius: 24px !important;
        border: 1px solid #222 !important;
        padding: 15px !important;
        height: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: space-between;
        position: relative;
        overflow: visible !important;
        margin-bottom: 30px;
        transition: transform 0.3s ease;
    }

    .fp-product-item:hover {
        transform: translateY(-5px);
        border-color: #333 !important;
    }

    .fp-product-item .img {
        width: 100%;
        padding-bottom: 100%;
        position: relative;
        margin-bottom: 15px;
        z-index: 2;
    }

    .fp-product-item .img img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: contain;
        filter: drop-shadow(0 0 10px rgba(0, 137, 255, 0.3));
    }

    /* Glow effect background for grid items */
    .fp-product-item::before {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 80%;
        height: 60%;
        background: radial-gradient(circle, rgba(0, 137, 255, 0.1) 0%, rgba(0,0,0,0) 70%);
        z-index: 1;
        pointer-events: none;
    }

    .fp-product-item .content {
        width: 100%;
        text-align: center;
        z-index: 2;
        padding: 0 !important;
    }

    .fp-product-item .product-name {
        color: #fff !important;
        font-size: 14px !important;
        font-weight: 600 !important;
        margin-bottom: 10px !important;
        display: block;
        text-decoration: none;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .fp-product-item .price {
        background-color: #1a1a1a !important;
        border-radius: 8px !important;
        padding: 8px !important;
        width: 100%;
        text-align: center;
        color: #fff !important;
        font-size: 14px !important;
        font-weight: 700 !important;
        margin-top: auto !important;
        display: flex !important;
        justify-content: center;
        align-items: center;
        gap: 5px;
    }

    .fp-product-item .price .price-new {
        color: #fff !important;
    }
    
    .fp-product-item .price .price-old {
        color: #666 !important;
        font-size: 12px !important;
        text-decoration: line-through;
    }

    .fp-product-item .seller {
        display: none; /* Hide seller info for cleaner look, or style it if needed */
    }

    /* Hide slider fades for cleaner look */
	.top-slider .kasalar-items::before,
	.top-slider .kasalar-items:after,
    .top-slider .title-group:after {
		display: none;
	}
    
    /* Section Title */
    .section-title {
        text-align: center;
        color: #fff;
        font-family: 'Poppins', sans-serif;
        font-size: 24px;
        font-weight: 700;
        margin-bottom: 30px;
        margin-top: 50px;
        text-transform: uppercase;
        letter-spacing: 1px;
        position: relative;
        display: inline-block;
    }
    
    .section-title-wrapper {
        text-align: center;
        width: 100%;
    }

</style>
