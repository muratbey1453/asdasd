<section class="fp-section-blog-page blog-page-v2">
    <div class="container">

       <!-- Breadcrumb (Theme uyumlu + daha modern) -->
<nav class="blog-breadcrumb-v2" aria-label="breadcrumb">
    <ol class="blog-breadcrumb-list">
        <li class="blog-bc-item">
            <a href="<?= base_url() ?>" class="blog-bc-link">
                <i class="ri-home-4-line"></i> Ana Sayfa
            </a>
        </li>

        <li class="blog-bc-sep"><i class="ri-arrow-right-s-line"></i></li>

        <li class="blog-bc-item">
            <a href="<?= base_url('makale-listesi') ?>" class="blog-bc-link">Blog</a>
        </li>

        <li class="blog-bc-sep"><i class="ri-arrow-right-s-line"></i></li>

        <li class="blog-bc-item blog-bc-current" aria-current="page">
            <?= html_escape($blog->title) ?>
        </li>
    </ol>
</nav>


        <!-- HERO / HEADER KART -->
        <div class="blog-hero card-like">
            <h1 class="blog-title"><?= html_escape($blog->title) ?></h1>

            <div class="info-list blog-meta">
                <div class="text"><i class="ri-calendar-2-line"></i> <?= html_escape($blog->date) ?></div>
                <div class="text"><i class="ri-edit-line"></i> Yayınlayan: Yönetici</div>
                <div class="text"><i class="ri-time-line"></i> <span id="readTime">-</span> dk okuma</div>
            </div>

            <div class="blog-share">
                <span class="share-label">Paylaş:</span>
                <a class="share-btn" target="_blank" id="shareTwitter" href="#" rel="noopener"><i class="ri-twitter-x-line"></i></a>
                <a class="share-btn" target="_blank" id="shareWhatsApp" href="#" rel="noopener"><i class="ri-whatsapp-line"></i></a>
                <a class="share-btn" target="_blank" id="shareTelegram" href="#" rel="noopener"><i class="ri-telegram-line"></i></a>
                <button class="share-btn" type="button" id="copyLink"><i class="ri-link"></i></button>
            </div>
        </div>

        <!-- İÇERİK KART -->
        <div class="blog-body card-like">

            <?php if (!empty($blog->img)): ?>
                <div class="img-cover blog-cover">
                    <img src="<?= base_url('assets/img/blog/') . $blog->img ?>" alt="<?= html_escape($blog->title) ?>" class="img-blog">
                </div>
            <?php endif; ?>

            <div class="fp-blog-content blog-content" id="blogContent">
                <?= $blog->content ?>
            </div>

            <!-- RASTGELE YAZILAR -->
            <div class="related-wrap mt-4">
                <div class="related-head">
                    <h3 class="related-title"><i class="ri-article-line"></i> Rastgele Yazılar</h3>
                    <a href="<?= base_url('makale-listesi') ?>" class="related-link">Tüm Blog <i class="ri-arrow-right-line"></i></a>
                </div>

                <?php if (isset($relatedBlogs) && count($relatedBlogs) > 0): ?>
                    <div class="row g-3">
                        <?php foreach ($relatedBlogs as $rb): ?>
                            <div class="col-12 col-md-6 col-lg-4">
                                <a class="related-card" href="<?= base_url('makale/' . $rb->slug) ?>">
                                    <div class="related-thumb">
                                        <?php if (!empty($rb->img)): ?>
                                            <img src="<?= base_url('assets/img/blog/' . $rb->img) ?>" alt="<?= html_escape($rb->title) ?>">
                                        <?php else: ?>
                                            <img src="<?= base_url('assets/img/blog/default.jpg') ?>" alt="<?= html_escape($rb->title) ?>">
                                        <?php endif; ?>
                                    </div>
                                    <div class="related-body">
                                        <div class="related-date"><i class="ri-calendar-2-line"></i> <?= html_escape($rb->date) ?></div>
                                        <div class="related-name"><?= html_escape($rb->title) ?></div>
                                        <div class="related-cta">Oku <i class="ri-arrow-right-line"></i></div>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="related-empty">
                        Henüz gösterilecek başka makale bulunamadı.
                    </div>
                <?php endif; ?>
            </div>

        </div>

    </div>
</section>

<style>
    /* Breadcrumb v2 (dark/light uyumlu) */
.blog-breadcrumb-v2{
  margin: 10px 0 18px;
}

.blog-breadcrumb-list{
  list-style: none;
  padding: 10px 12px;
  margin: 0;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;

  border-radius: 14px;
  border: 1px solid rgba(255,255,255,.10);
  background: rgba(255,255,255,.06);
  backdrop-filter: blur(10px);
}

.blog-bc-link{
  display: inline-flex;
  align-items: center;
  gap: 6px;
  text-decoration: none;

  font-weight: 800;
  font-size: 13px;

  color: rgba(255,255,255,.78);
  transition: .18s ease;
}

.blog-bc-link:hover{
  color: rgba(255,255,255,1);
  transform: translateY(-1px);
}

.blog-bc-sep{
  color: rgba(255,255,255,.35);
  display: inline-flex;
  align-items: center;
}

.blog-bc-current{
  font-weight: 900;
  font-size: 13px;
  color: #fff;
  max-width: 520px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* LIGHT MODE */
html[data-theme="light"] .blog-breadcrumb-list{
  background: #fff;
  border: 1px solid rgba(0,0,0,.10);
  backdrop-filter: none;
}

html[data-theme="light"] .blog-bc-link{
  color: #475569; /* okunur */
}

html[data-theme="light"] .blog-bc-link:hover{
  color: #0f172a;
}

html[data-theme="light"] .blog-bc-sep{
  color: rgba(0,0,0,.35);
}

html[data-theme="light"] .blog-bc-current{
  color: #0f172a;
}

/* =========================
   BLOG PAGE – DARK BASE
   ========================= */
.blog-page-v2{ padding: 30px 0 60px; }

.blog-breadcrumb .link{ color: rgba(255,255,255,.75) !important; }
.blog-breadcrumb .link.active{ color:#fff !important; font-weight:700; }

.card-like{
    background: rgba(255,255,255,.06);
    border: 1px solid rgba(255,255,255,.10);
    border-radius: 18px;
    backdrop-filter: blur(10px);
    box-shadow: 0 18px 60px rgba(0,0,0,.35);
}

.blog-hero{
    padding: 22px;
    margin-bottom: 14px;
    position: relative;
    overflow: hidden;
}
.blog-hero::before{
    content:"";
    position:absolute;
    inset:0;
    background:
        radial-gradient(circle at 20% 0%, rgba(239,68,68,.18), transparent 45%),
        radial-gradient(circle at 85% 20%, rgba(34,197,94,.14), transparent 40%);
    pointer-events:none;
}

.blog-title{
    color:#fff;
    font-weight: 900;
    letter-spacing: -.3px;
    line-height: 1.1;
    font-size: 34px;
    margin-bottom: 10px;
    position: relative;
    z-index: 1;
}

.blog-meta{
    display:flex;
    gap: 14px;
    flex-wrap: wrap;
    position: relative;
    z-index: 1;
}
.blog-meta .text{
    color: rgba(255,255,255,.70);
    font-size: 13px;
    display:flex;
    align-items:center;
    gap: 6px;
    padding: 6px 10px;
    border-radius: 999px;
    background: rgba(0,0,0,.18);
    border: 1px solid rgba(255,255,255,.08);
}
.blog-meta i{ color: rgba(255,255,255,.85); }

/* Share */
.blog-share{
    margin-top: 14px;
    display:flex;
    align-items:center;
    gap: 10px;
    flex-wrap: wrap;
    position: relative;
    z-index: 1;
}
.share-label{
    color: rgba(255,255,255,.70);
    font-size: 13px;
    font-weight: 700;
}
.share-btn{
    width: 38px;
    height: 38px;
    border-radius: 12px;
    display:flex;
    align-items:center;
    justify-content:center;
    border: 1px solid rgba(255,255,255,.10);
    background: rgba(0,0,0,.18);
    color:#fff;
    text-decoration:none;
    transition: .2s ease;
}
.share-btn:hover{
    transform: translateY(-1px);
    border-color: rgba(255,255,255,.18);
    background: rgba(0,0,0,.30);
}

/* Content body */
.blog-body{ padding: 16px; }

.blog-cover{
    border-radius: 14px;
    overflow:hidden;
    border: 1px solid rgba(255,255,255,.10);
    box-shadow: 0 18px 50px rgba(0,0,0,.35);
    margin-bottom: 16px;
}
.blog-cover img{
    width:100%;
    height:auto;
    display:block;
    transform: scale(1.01);
}

.blog-content{
    color: rgba(255,255,255,.85);
    font-size: 16px;
    line-height: 1.85;
    padding: 4px 6px 10px;
}
.blog-content h2{ color:#fff; font-size: 24px; font-weight: 900; margin: 28px 0 12px; }
.blog-content h3{ color:#fff; font-size: 20px; font-weight: 800; margin: 22px 0 10px; }
.blog-content p{ margin-bottom: 14px; }
.blog-content a{ color:#f59e0b; text-decoration: underline; text-underline-offset: 3px; }
.blog-content img{
    max-width:100%;
    border-radius: 12px;
    border: 1px solid rgba(255,255,255,.10);
    box-shadow: 0 16px 40px rgba(0,0,0,.30);
    margin: 14px 0;
}

/* Related */
.related-wrap{
  margin-top: 28px;
  padding: 16px;
  border-radius: 18px;
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(255,255,255,.08);
  backdrop-filter: blur(10px);
}
.related-head{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap: 12px;
  margin-bottom: 12px;
}
.related-title{
  margin:0;
  color:#fff;
  font-weight: 900;
  font-size: 18px;
  display:flex;
  align-items:center;
  gap: 8px;
}
.related-title i{ color:#f59e0b; }
.related-link{
  color: rgba(255,255,255,.75);
  text-decoration:none;
  font-weight: 800;
  font-size: 13px;
  display:flex;
  align-items:center;
  gap:6px;
}
.related-link:hover{ color:#fff; }

.related-card{
  display:block;
  text-decoration:none;
  border-radius: 16px;
  overflow:hidden;
  background: rgba(0,0,0,.18);
  border: 1px solid rgba(255,255,255,.08);
  transition: .22s ease;
  height: 100%;
}
.related-card:hover{
  transform: translateY(-2px);
  border-color: rgba(255,255,255,.16);
  box-shadow: 0 18px 45px rgba(0,0,0,.35);
}
.related-thumb{ height: 150px; overflow:hidden; }
.related-thumb img{ width:100%; height:100%; object-fit: cover; display:block; }
.related-body{ padding: 12px 12px 14px; }
.related-date{ color: rgba(255,255,255,.65); font-size: 12px; display:flex; align-items:center; gap: 6px; margin-bottom: 6px; }
.related-name{ color:#fff; font-weight: 900; font-size: 14px; line-height: 1.35; min-height: 40px; }
.related-cta{ margin-top: 10px; color:#22c55e; font-weight: 900; font-size: 13px; display:flex; align-items:center; gap: 6px; }

.related-empty{
  padding: 12px 10px;
  border-radius: 12px;
  background: rgba(0,0,0,.18);
  border: 1px dashed rgba(255,255,255,.15);
  color: rgba(255,255,255,.80);
}

/* Responsive */
@media (max-width: 768px){
  .blog-title{ font-size: 26px; }
  .blog-body{ padding: 12px; }
  .blog-content{ font-size: 15px; line-height: 1.75; }
}

/* =========================
   LIGHT MODE FIX
   hem html hem body destek
   ========================= */
html[data-theme="light"] .blog-page-v2 .card-like,
body[data-theme="light"] .blog-page-v2 .card-like,
html[data-theme="light"] .blog-page-v2 .related-card,
body[data-theme="light"] .blog-page-v2 .related-card{
  background:#ffffff !important;
  border:1px solid rgba(0,0,0,.10) !important;
  box-shadow:0 18px 60px rgba(0,0,0,.10) !important;
  backdrop-filter:none !important;
}

html[data-theme="light"] .blog-page-v2 .blog-title,
body[data-theme="light"] .blog-page-v2 .blog-title,
html[data-theme="light"] .blog-page-v2 .related-title,
body[data-theme="light"] .blog-page-v2 .related-title,
html[data-theme="light"] .blog-page-v2 .related-name,
body[data-theme="light"] .blog-page-v2 .related-name,
html[data-theme="light"] .blog-page-v2 .blog-content h2,
body[data-theme="light"] .blog-page-v2 .blog-content h2,
html[data-theme="light"] .blog-page-v2 .blog-content h3,
body[data-theme="light"] .blog-page-v2 .blog-content h3{
  color:#0f172a !important;
}

html[data-theme="light"] .blog-page-v2 .blog-content,
body[data-theme="light"] .blog-page-v2 .blog-content{
  color:#111827 !important;
}
html[data-theme="light"] .blog-page-v2 .blog-content * ,
body[data-theme="light"] .blog-page-v2 .blog-content * {
  color: inherit !important;
}

html[data-theme="light"] .blog-page-v2 .blog-content a,
body[data-theme="light"] .blog-page-v2 .blog-content a{
  color:#d97706 !important;
}

html[data-theme="light"] .blog-page-v2 .blog-meta .text,
body[data-theme="light"] .blog-page-v2 .blog-meta .text{
  color:#334155 !important;
  background:rgba(0,0,0,.03) !important;
  border:1px solid rgba(0,0,0,.08) !important;
}

html[data-theme="light"] .blog-page-v2 .related-wrap,
body[data-theme="light"] .blog-page-v2 .related-wrap{
  background:rgba(0,0,0,.02) !important;
  border:1px solid rgba(0,0,0,.08) !important;
}

html[data-theme="light"] .blog-page-v2 .related-date,
body[data-theme="light"] .blog-page-v2 .related-date,
html[data-theme="light"] .blog-page-v2 .blog-meta i,
body[data-theme="light"] .blog-page-v2 .blog-meta i,
html[data-theme="light"] .blog-page-v2 .share-label,
body[data-theme="light"] .blog-page-v2 .share-label{
  color:#64748b !important;
}

html[data-theme="light"] .blog-page-v2 .share-btn,
body[data-theme="light"] .blog-page-v2 .share-btn{
  background:rgba(0,0,0,.03) !important;
  border:1px solid rgba(0,0,0,.10) !important;
  color:#111827 !important;
}

html[data-theme="light"] .blog-page-v2 .related-empty,
body[data-theme="light"] .blog-page-v2 .related-empty{
  background:rgba(0,0,0,.03) !important;
  border:1px dashed rgba(0,0,0,.15) !important;
  color:#334155 !important;
}
</style>

<script>
document.addEventListener("DOMContentLoaded", () => {
    const contentEl = document.getElementById("blogContent");
    const readTimeEl = document.getElementById("readTime");

    // Okuma süresi (ortalama 200 kelime/dk)
    if (contentEl && readTimeEl) {
        const text = (contentEl.innerText || "").trim();
        const words = text ? text.split(/\s+/).length : 0;
        const minutes = Math.max(1, Math.ceil(words / 200));
        readTimeEl.textContent = minutes;
    }

    // Paylaşım linkleri
    const url = encodeURIComponent(window.location.href);
    const title = encodeURIComponent(document.querySelector(".blog-title")?.innerText || "Blog");

    const tw = document.getElementById("shareTwitter");
    const wa = document.getElementById("shareWhatsApp");
    const tg = document.getElementById("shareTelegram");

    if (tw) tw.href = `https://twitter.com/intent/tweet?url=${url}&text=${title}`;
    if (wa) wa.href = `https://wa.me/?text=${title}%20${url}`;
    if (tg) tg.href = `https://t.me/share/url?url=${url}&text=${title}`;

    // Link kopyala
    const copyBtn = document.getElementById("copyLink");
    if (copyBtn) {
        copyBtn.addEventListener("click", async () => {
            try {
                await navigator.clipboard.writeText(window.location.href);
                copyBtn.innerHTML = '<i class="ri-check-line"></i>';
                setTimeout(() => copyBtn.innerHTML = '<i class="ri-link"></i>', 1200);
            } catch (e) {
                alert("Link kopyalanamadı.");
            }
        });
    }
});
</script>
