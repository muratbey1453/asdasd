<section class="fp-section-page wheel-page">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <!-- Başlık -->
                <div class="text-center mb-5">
                    <h1 class="wheel-title">
                        <i class="ri-gift-line"></i>
                        Şans Çarkı
                    </h1>
                    <p class="wheel-subtitle">Her gün bir kez çevirme hakkın var! Şansını dene ve ödülleri kazan!</p>
                </div>
                
                <!-- Çark Container -->
                <div class="wheel-container">
                    <div class="wheel-wrapper">
                        <!-- Ok -->
                        <div class="wheel-pointer">
                            <i class="ri-arrow-down-s-fill"></i>
                        </div>
                        
                        <!-- Canvas Çark -->
                        <canvas id="wheelCanvas" width="400" height="400"></canvas>
                        
                        <!-- Merkez Buton -->
                        <div class="wheel-center-btn" id="spinBtn">
                            <?php if (!isset($this->session->userdata('info')['id'])): ?>
                                <a href="<?= base_url('hesap') ?>" class="center-btn-inner login">
                                    <i class="ri-login-circle-line"></i>
                                    <span>Giriş Yap</span>
                                </a>
                            <?php elseif ($can_spin): ?>
                                <button type="button" class="center-btn-inner spin" onclick="spinWheel()">
                                    <i class="ri-play-fill"></i>
                                    <span>ÇEVİR!</span>
                                </button>
                            <?php else: ?>
                                <div class="center-btn-inner wait">
                                    <i class="ri-time-line"></i>
                                    <span id="countdown">--:--:--</span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Sonuç Modal -->
                <div class="wheel-result-modal" id="resultModal">
                    <div class="result-content">
                        <div class="result-icon" id="resultIcon"></div>
                        <h3 class="result-title" id="resultTitle"></h3>
                        <p class="result-message" id="resultMessage"></p>
                        <button class="btn btn-primary" onclick="closeResult()">Tamam</button>
                    </div>
                </div>
            </div>
            
            <!-- Son Kazananlar -->
            <div class="col-lg-4">
                <div class="recent-winners-card">
                    <h4 class="winners-title">
                        <i class="ri-trophy-line"></i>
                        Son Kazananlar
                    </h4>
                    <div class="winners-list">
                        <?php foreach ($recent_winners as $winner): ?>
                            <?php if ($winner->reward_type == 'balance' && $winner->reward_value > 0): ?>
                                <div class="winner-item">
                                    <div class="winner-avatar">
                                        <i class="ri-user-3-line"></i>
                                    </div>
                                    <div class="winner-info">
                                        <span class="winner-name">
                                            <?php 
                                            $masked_name = substr($winner->name, 0, 2) . str_repeat('*', max(0, strlen($winner->name) - 2));
                                            $masked_surname = substr($winner->surname, 0, 2) . str_repeat('*', max(0, strlen($winner->surname) - 2));
                                            echo $masked_name . ' ' . $masked_surname;
                                            ?>
                                        </span>
                                        <span class="winner-prize"><?= $winner->reward_label ?></span>
                                    </div>
                                    <span class="winner-time">
                                        <?= date('H:i', strtotime($winner->spin_date)) ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                        
                        <?php if (empty($recent_winners)): ?>
                            <div class="no-winners">
                                <i class="ri-emotion-sad-line"></i>
                                <p>Henüz kazanan yok. İlk sen ol!</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
/* Wheel Page Styles */
.wheel-page {
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
    min-height: 100vh;
    padding: 3rem 0;
}

.wheel-title {
    font-size: 2.5rem;
    font-weight: 700;
    color: #fff;
    margin-bottom: 0.5rem;
    text-shadow: 0 4px 20px rgba(0,0,0,0.3);
}

.wheel-title i {
    color: #f59e0b;
    margin-right: 0.5rem;
}

.wheel-subtitle {
    color: rgba(255,255,255,0.7);
    font-size: 1.1rem;
}

/* Wheel Container */
.wheel-container {
    display: flex;
    justify-content: center;
    margin-bottom: 2rem;
}

.wheel-wrapper {
    position: relative;
    width: 400px;
    height: 400px;
}

/* Pointer */
.wheel-pointer {
    position: absolute;
    top: -20px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 10;
    font-size: 48px;
    color: #ef4444;
    filter: drop-shadow(0 4px 8px rgba(0,0,0,0.3));
    animation: bounce 1s ease-in-out infinite;
}

@keyframes bounce {
    0%, 100% { transform: translateX(-50%) translateY(0); }
    50% { transform: translateX(-50%) translateY(-8px); }
}

/* Canvas */
#wheelCanvas {
    border-radius: 50%;
    box-shadow: 
        0 0 0 8px rgba(255,255,255,0.1),
        0 0 0 16px rgba(255,255,255,0.05),
        0 20px 60px rgba(0,0,0,0.5);
    transition: transform 0.1s ease-out;
}

/* Center Button */
.wheel-center-btn {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 5;
}

.center-btn-inner {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    border: none;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    font-weight: 700;
    text-transform: uppercase;
    transition: all 0.3s ease;
    text-decoration: none;
}

.center-btn-inner.spin {
    background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
    color: #fff;
    box-shadow: 0 8px 25px rgba(34, 197, 94, 0.4);
}

.center-btn-inner.spin:hover {
    transform: scale(1.1);
    box-shadow: 0 12px 35px rgba(34, 197, 94, 0.5);
}

.center-btn-inner.spin i {
    font-size: 32px;
}

.center-btn-inner.spin span {
    font-size: 14px;
    margin-top: 2px;
}

.center-btn-inner.wait {
    background: linear-gradient(135deg, #6b7280 0%, #4b5563 100%);
    color: #fff;
    cursor: not-allowed;
}

.center-btn-inner.wait i {
    font-size: 24px;
    margin-bottom: 4px;
}

.center-btn-inner.wait span {
    font-size: 12px;
}

.center-btn-inner.login {
    background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
    color: #fff;
}

.center-btn-inner.login i {
    font-size: 28px;
    margin-bottom: 4px;
}

.center-btn-inner.login span {
    font-size: 11px;
}

/* Result Modal */
.wheel-result-modal {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.8);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    backdrop-filter: blur(10px);
}

.wheel-result-modal.show {
    display: flex;
}

.result-content {
    background: linear-gradient(135deg, #1f2937 0%, #111827 100%);
    padding: 3rem;
    border-radius: 20px;
    text-align: center;
    max-width: 400px;
    border: 1px solid rgba(255,255,255,0.1);
    box-shadow: 0 25px 80px rgba(0,0,0,0.5);
}

.result-icon {
    font-size: 80px;
    margin-bottom: 1rem;
}

.result-icon.win {
    color: #22c55e;
}

.result-icon.lose {
    color: #6b7280;
}

.result-title {
    color: #fff;
    font-size: 1.8rem;
    margin-bottom: 0.5rem;
}

.result-message {
    color: rgba(255,255,255,0.7);
    margin-bottom: 1.5rem;
}

/* Recent Winners Card */
.recent-winners-card {
    background: rgba(255,255,255,0.05);
    border-radius: 16px;
    padding: 1.5rem;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.1);
}

.winners-title {
    color: #fff;
    font-size: 1.2rem;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.winners-title i {
    color: #f59e0b;
}

.winners-list {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
}

.winner-item {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.75rem;
    background: rgba(255,255,255,0.05);
    border-radius: 10px;
}

.winner-avatar {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background: linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
}

.winner-info {
    flex: 1;
    display: flex;
    flex-direction: column;
}

.winner-name {
    color: #fff;
    font-size: 0.9rem;
    font-weight: 500;
}

.winner-prize {
    color: #22c55e;
    font-size: 0.8rem;
}

.winner-time {
    color: rgba(255,255,255,0.5);
    font-size: 0.75rem;
}

.no-winners {
    text-align: center;
    padding: 2rem;
    color: rgba(255,255,255,0.5);
}

.no-winners i {
    font-size: 2rem;
    margin-bottom: 0.5rem;
    display: block;
}

/* Responsive */
@media (max-width: 768px) {
    .wheel-wrapper {
        width: 320px;
        height: 320px;
    }
    
    #wheelCanvas {
        width: 320px;
        height: 320px;
    }
    
    .center-btn-inner {
        width: 80px;
        height: 80px;
    }
    
    .wheel-title {
        font-size: 1.8rem;
    }
}

/* Spinning animation */
.wheel-spinning #wheelCanvas {
    pointer-events: none;
}

.wheel-spinning .center-btn-inner.spin {
    opacity: 0.5;
    pointer-events: none;
}

/* Confetti container */
#confetti-container {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    z-index: 9998;
}
</style>

<script>
// Çark verileri
const wheelItems = <?= json_encode($wheel_items) ?>;
const canSpin = <?= $can_spin ? 'true' : 'false' ?>;
const remainingSeconds = <?= $remaining_seconds ?>;

let isSpinning = false;
let currentRotation = 0;

// Ses efektleri
let audioContext = null;
let tickSound = null;
let winSound = null;

function initAudio() {
    if (audioContext) return;
    audioContext = new (window.AudioContext || window.webkitAudioContext)();
}

// Tık sesi oluştur (Web Audio API)
function playTickSound() {
    if (!audioContext) initAudio();
    
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.frequency.value = 800 + Math.random() * 200; // 800-1000Hz arası
    oscillator.type = 'sine';
    
    gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.05);
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.05);
}

// Kazanma sesi
function playWinSound() {
    if (!audioContext) initAudio();
    
    const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
    
    notes.forEach((freq, i) => {
        setTimeout(() => {
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.frequency.value = freq;
            oscillator.type = 'sine';
            
            gainNode.gain.setValueAtTime(0.15, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
            
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.3);
        }, i * 100);
    });
}

// Canvas çizimi
const canvas = document.getElementById('wheelCanvas');
const ctx = canvas.getContext('2d');
const centerX = canvas.width / 2;
const centerY = canvas.height / 2;
const radius = canvas.width / 2 - 10;

function drawWheel() {
    const sliceAngle = (2 * Math.PI) / wheelItems.length;
    
    wheelItems.forEach((item, i) => {
        const startAngle = i * sliceAngle - Math.PI / 2;
        const endAngle = startAngle + sliceAngle;
        
        // Dilim çiz
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.arc(centerX, centerY, radius, startAngle, endAngle);
        ctx.closePath();
        ctx.fillStyle = item.color;
        ctx.fill();
        
        // Kenarlık
        ctx.strokeStyle = 'rgba(255,255,255,0.3)';
        ctx.lineWidth = 2;
        ctx.stroke();
        
        // Metin
        ctx.save();
        ctx.translate(centerX, centerY);
        ctx.rotate(startAngle + sliceAngle / 2);
        ctx.textAlign = 'right';
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 14px Inter, sans-serif';
        ctx.shadowColor = 'rgba(0,0,0,0.5)';
        ctx.shadowBlur = 4;
        ctx.fillText(item.label, radius - 20, 5);
        ctx.restore();
    });
    
    // Merkez daire
    ctx.beginPath();
    ctx.arc(centerX, centerY, 55, 0, 2 * Math.PI);
    ctx.fillStyle = '#1f2937';
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.2)';
    ctx.lineWidth = 3;
    ctx.stroke();
}

function spinWheel() {
    if (isSpinning || !canSpin) return;
    
    isSpinning = true;
    document.querySelector('.wheel-wrapper').classList.add('wheel-spinning');
    
    // CSRF token
    const csrfName = '<?= $this->security->get_csrf_token_name() ?>';
    const csrfHash = '<?= $this->security->get_csrf_hash() ?>';
    
    // Form data oluştur
    const formData = new FormData();
    formData.append(csrfName, csrfHash);
    
    // API çağrısı
    fetch('<?= base_url("wheel/spin") ?>', {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Kazanan dilime dön
            const sliceAngle = 360 / wheelItems.length;
            const targetAngle = 360 - (data.winning_index * sliceAngle) - (sliceAngle / 2);
            const spins = 5; // 5 tam tur
            const totalRotation = (spins * 360) + targetAngle;
            
            animateWheel(totalRotation, data);
        } else {
            isSpinning = false;
            document.querySelector('.wheel-wrapper').classList.remove('wheel-spinning');
            alert(data.message);
        }
    })
    .catch(error => {
        isSpinning = false;
        document.querySelector('.wheel-wrapper').classList.remove('wheel-spinning');
        console.error('Error:', error);
    });
}

function animateWheel(targetRotation, result) {
    const duration = 5000; // 5 saniye
    const startTime = Date.now();
    const startRotation = currentRotation;
    const sliceAngle = 360 / wheelItems.length;
    let lastSlice = -1;
    
    // Audio başlat (user interaction gerekli)
    initAudio();
    
    function animate() {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Ease-out cubic
        const eased = 1 - Math.pow(1 - progress, 3);
        
        currentRotation = startRotation + (targetRotation * eased);
        canvas.style.transform = `rotate(${currentRotation}deg)`;
        
        // Hangi dilimde olduğumuzu hesapla ve ses çal
        const currentSlice = Math.floor((currentRotation % 360) / sliceAngle);
        if (currentSlice !== lastSlice) {
            lastSlice = currentSlice;
            playTickSound();
        }
        
        if (progress < 1) {
            requestAnimationFrame(animate);
        } else {
            // Animasyon bitti
            isSpinning = false;
            document.querySelector('.wheel-wrapper').classList.remove('wheel-spinning');
            
            // Kazandıysa win sesi çal
            if (result.item.type === 'balance' && result.item.value > 0) {
                playWinSound();
            }
            
            showResult(result);
        }
    }
    
    animate();
}

function showResult(result) {
    const modal = document.getElementById('resultModal');
    const icon = document.getElementById('resultIcon');
    const title = document.getElementById('resultTitle');
    const message = document.getElementById('resultMessage');
    
    if (result.item.type === 'balance' && result.item.value > 0) {
        icon.innerHTML = '<i class="ri-trophy-fill"></i>';
        icon.className = 'result-icon win';
        title.textContent = '🎉 Tebrikler!';
        message.textContent = result.item.label + ' kazandınız! Bakiyenize eklendi.';
        createConfetti();
    } else {
        icon.innerHTML = '<i class="ri-emotion-sad-line"></i>';
        icon.className = 'result-icon lose';
        title.textContent = 'Bir Dahaki Sefere!';
        message.textContent = 'Maalesef bu sefer kazanamadınız. Yarın tekrar deneyin!';
    }
    
    modal.classList.add('show');
}

function closeResult() {
    document.getElementById('resultModal').classList.remove('show');
    // Sayfayı yenile
    setTimeout(() => location.reload(), 500);
}

// Confetti efekti
function createConfetti() {
    const container = document.createElement('div');
    container.id = 'confetti-container';
    document.body.appendChild(container);
    
    const colors = ['#22c55e', '#f59e0b', '#3b82f6', '#ef4444', '#8b5cf6'];
    
    for (let i = 0; i < 100; i++) {
        const confetti = document.createElement('div');
        confetti.style.cssText = `
            position: absolute;
            width: 10px;
            height: 10px;
            background: ${colors[Math.floor(Math.random() * colors.length)]};
            left: ${Math.random() * 100}%;
            top: -20px;
            border-radius: ${Math.random() > 0.5 ? '50%' : '0'};
            animation: confetti-fall ${2 + Math.random() * 2}s ease-in-out forwards;
            animation-delay: ${Math.random() * 0.5}s;
        `;
        container.appendChild(confetti);
    }
    
    // Stil ekle
    if (!document.getElementById('confetti-style')) {
        const style = document.createElement('style');
        style.id = 'confetti-style';
        style.textContent = `
            @keyframes confetti-fall {
                0% { transform: translateY(0) rotate(0deg); opacity: 1; }
                100% { transform: translateY(100vh) rotate(720deg); opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    }
    
    setTimeout(() => container.remove(), 4000);
}

// Geri sayım
<?php if (!$can_spin && $remaining_seconds > 0): ?>
let countdown = <?= $remaining_seconds ?>;
const countdownEl = document.getElementById('countdown');

function updateCountdown() {
    if (countdown <= 0) {
        location.reload();
        return;
    }
    
    const hours = Math.floor(countdown / 3600);
    const minutes = Math.floor((countdown % 3600) / 60);
    const seconds = countdown % 60;
    
    countdownEl.textContent = 
        String(hours).padStart(2, '0') + ':' + 
        String(minutes).padStart(2, '0') + ':' + 
        String(seconds).padStart(2, '0');
    
    countdown--;
}

updateCountdown();
setInterval(updateCountdown, 1000);
<?php endif; ?>

// Sayfa yüklendiğinde çarkı çiz
drawWheel();
</script>
