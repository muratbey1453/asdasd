<section class="fp-slider-area">
    <script>
        let currentSrc = '';

        function checkActiveSlide() {
            let newSrc = $('.fp-slider-area .swiper-slide-active .img-cover').attr('src');
            if (newSrc && newSrc !== currentSrc) {
                currentSrc = newSrc;
                $('.blurred-image').attr('src', newSrc);
            }
        }

        setInterval(checkActiveSlide, 100);
        (function(){
  function applyLogos(){
    const isDark = document.body.classList.contains('dark')
      || document.body.getAttribute('data-theme') === 'dark'
      || document.documentElement.getAttribute('data-bs-theme') === 'dark'
      || document.body.getAttribute('data-bs-theme') === 'dark';

    document.querySelectorAll('img.gameLogo').forEach(img=>{
      const s = isDark ? img.dataset.dark : img.dataset.light;
      if(s) img.src = s;
    });
  }
  applyLogos();
  // tema değiştiriyorsan bir eventin varsa onu da burada çağır
})();

    </script>
<div class="gamebar-wrap">
  <div class="gamebar">
    <a class="gamebar-item" href="/kategori/league-of-legends">
      <img class="gameLogo"
           data-light="/assets/img/gameic/lol_l.svg"
           data-dark="/assets/img/gameic/lol_d.webp"
           src="/assets/img/gameic/lol_d.webp"
           alt="League of Legends">
    </a>

    <a class="gamebar-item" href="#">
      <img class="gameLogo"
           data-light="/assets/img/gameic/knight_l.svg"
           data-dark="/assets/img/gameic/knight_d.webp"
           src="/assets/img/gameic/knight_d.webp"
           alt="Knight Online">
    </a>

    <a class="gamebar-item" href="/kategori/metin-2">
      <img class="gameLogo"
           data-light="/assets/img/gameic/metin2_l.svg"
           data-dark="/assets/img/gameic/metin2_d.webp"
           src="/assets/img/gameic/metin2_d.webp"
           alt="Metin2">
    </a>

    <a class="gamebar-item" href="/kategori/valorant">
      <img class="gameLogo"
           data-light="/assets/img/gameic/valorant_l.svg"
           data-dark="/assets/img/gameic/valorant_d.webp"
           src="/assets/img/gameic/valorant_d.webp"
           alt="Valorant">
    </a>

    <a class="gamebar-item" href="/kategori/pubg-mobile">
      <img class="gameLogo"
           data-light="/assets/img/gameic/pubg_l.svg"
           data-dark="/assets/img/gameic/pubg_d.webp"
           src="/assets/img/gameic/pubg_.webp"
           alt="PUBG">
    </a>

    <a class="gamebar-item" href="#">
      <img class="gameLogo"
           data-light="/assets/img/gameic/mobile_l.svg"
           data-dark="/assets/img/gameic/mobile_d.webp"
           src="/assets/img/gameic/mlbb_d.webp"
           alt="Mobile Legends">
    </a>

    <a class="gamebar-item" href="/kategori/razer-gold">
      <img class="gameLogo"
           data-light="/assets/img/gameic/razer_l.svg"
           data-dark="/assets/img/gameic/razer_d.webp"
           src="/assets/img/gameic/razer_d.webp"
           alt="Razer Gold">
    </a>
    <a class="gamebar-item" href="#">
      <img class="gameLogo"
           data-light="/assets/img/gameic/rise_l.svg"
           data-dark="/assets/img/gameic/rise_d.webp"
           src="/assets/img/gameic/rise_d.webp"
           alt="Rise Online">
    </a>

    <a class="gamebar-item" href="#">
      <img class="gameLogo"
           data-light="/assets/img/gameic/cs2_l.svg"
           data-dark="/assets/img/gameic/cs2_d.webp"
           src="/assets/img/gameic/cs2_d.webp"
           alt="CS2">
    </a>
    <a class="gamebar-item" href="/kategori/minecraft">
      <img class="gameLogo"
           data-light="/assets/img/gameic/mc_l.svg"
           data-dark="/assets/img/gameic/mc_d.svg"
           src="/assets/img/gameic/mc_d.webp"
           alt="minecraft">
    </a>
  </div>
</div>
    <img src="" alt="" class="#blurred-image#">
    <div class="container">
        <div class="grid">

            <div class="grid-left">
                <div class="fp-swiper-home swiper">
                    <div class="swiper-wrapper">
                        <?php foreach ($slider as $s){ ?>
                        <div class="swiper-slide">
                            <a href="<?= $s->buton_2_link ?>">
                                <div class="fp-swiper-home-item">
                                    <img src="<?= base_url("assets/img/sliders/") . $s->img ?>" alt="" class="img-cover">
                                    <div class="content">
                                        <h3 class="title"><?= $s->title ?></h3>
                                        <p><?= $s->description ?></p>
                                        <?php if($s->buton_2_text != "" && $s->buton_2_link != "") { ?>
                                            <a href="<?= $s->buton_2_link ?>" class="btn btn-primary rounded-pill"><?= ($s->buton_2_text) ?> <i class="ri-arrow-right-line icon icon-right"></i></a>
                                        <?php } ?>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php } ?>
                    </div>
                    <div class="autoplay-progress">
                        <svg viewBox="0 0 48 48">
                            <circle cx="24" cy="24" r="20"></circle>
                        </svg>
                        <img src="<?= base_url() ?>assets/img/royfavicon.png">
                        <span></span>
                    </div>
                </div>
            </div>

            <?php $homeCategory2 = $this->db->order_by('home_category.id', 'DESC')->limit(2, 2)->select('home_category.*, category.name')->join('category', 'category.id = category_id', 'left')->get('home_category')->result();?>
            <div class="grid-right">
                <div class="fp-home-slider-mini-grid">
                    <?php foreach($homeCategory2 as $hc){ ?>
                        <a href="<?= $hc->link ?>">
                            <div class="fp-home-slider-mini">
                                <img src="<?= base_url('assets/img/home_category/') . $hc->img ?>" alt="" class="img-cover">
                            </div>
                        </a>
                    <?php } ?>
                </div>
            </div>

        </div>
    </div>
</section>

<?php if (!empty($featured_cards)): ?>
<section class="container mt-4">
    <div class="row">
        <?php foreach ($featured_cards as $card): ?>
        <div class="col-md-6 col-lg-3 mb-3">
            <a href="<?= $card->link ?>" class="featured-card-link">
                <div class="featured-card" style="background-image: url('<?= base_url('assets/img/home_featured/' . $card->image) ?>');">
                    <div class="featured-card-overlay">
                        <span class="featured-card-title"><?= $card->title ?></span>
                        <span class="featured-card-action"></span>
                    </div>
                </div>
            </a>
        </div>
        <?php endforeach; ?>
    </div>
     

</section>

<style>
    :root{
  /* Light */
  --gb-bg1: rgba(255,255,255,.78);
  --gb-bg2: rgba(255,255,255,.55);
  --gb-stroke: rgba(15,23,42,.10);

  --gb-item-bg: rgba(15,23,42,.06);      /* logolar beyazsa görünür olsun */
  --gb-item-stroke: rgba(15,23,42,.10);

  --gb-glow: rgba(59,130,246,.28);
  --gb-shadow: 0 16px 40px rgba(15,23,42,.12);
}

/* Dark (3 farklı sistem yakalanıyor) */
body[data-theme="dark"], body.dark, :root[data-bs-theme="dark"], body[data-bs-theme="dark"]{
  --gb-bg1: rgba(255,255,255,.06);
  --gb-bg2: rgba(255,255,255,.03);
  --gb-stroke: rgba(255,255,255,.10);

  --gb-item-bg: rgba(255,255,255,.04);
  --gb-item-stroke: rgba(255,255,255,.10);

  --gb-glow: rgba(59,130,246,.42);
  --gb-shadow: 0 18px 60px rgba(0,0,0,.45);
}

/* === Wrapper: ortalama === */
.gamebar-wrap{
  position: relative;
  z-index: 5;
  margin: 0 auto 14px auto;
  width: min(1500px, 100%);
  padding: 0 12px;
}

/* === Bar: ortalanmış içerik === */
.gamebar{
  display: flex;
  align-items: center;
  justify-content: center;  /* ORTALA */
  gap: 20px;

  padding: 10px;
  border-radius: 18px;
  

  backdrop-filter: blur(14px);;

  /* Taşarsa mobilde kaydır */
  overflow-x: auto;
  scrollbar-width: none;
}
.gamebar::-webkit-scrollbar{ display:none; }

/* İçerik çoksa kaydırırken de “ortada gibi” dursun */
.gamebar{
  scroll-snap-type: x mandatory;
}
.gamebar-item{
  scroll-snap-align: center;
}

/* === Item === */
.gamebar-item{
  flex: 0 0 auto;
  width: 120px;
  height: 90px;

  border-radius: 14px;
  


  display: flex;
  align-items: center;
  justify-content: center;

  position: relative;
  overflow: hidden;
  transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease, background .18s ease;
}

/* Logoların beyaz zemin sorununu çözmek için: */
.gamebar-item img{
  max-width: 86%;
  max-height: 62%;
  opacity: .95;
  transition: opacity .18s ease, transform .18s ease, filter .18s ease;
  filter: drop-shadow(0 6px 12px rgba(0,0,0,.25));
}

/* Hover glow + hafif yükselme */
.gamebar-item:hover{
  transform: translateY(-2px);
  border-color: color-mix(in oklab, #3b82f6 55%, var(--gb-item-stroke));
  box-shadow:
    0 0 0 3px color-mix(in oklab, var(--gb-glow) 35%, transparent),
    0 18px 40px rgba(0,0,0,.18);
}
.gamebar-item:hover img{
  opacity: 1;
  transform: scale(1.03);
}

/* Aktif seçili */
.gamebar-item.is-active{
  border-color: color-mix(in oklab, #3b82f6 55%, var(--gb-item-stroke));
  box-shadow: 0 0 0 3px color-mix(in oklab, var(--gb-glow) 30%, transparent);
}

/* Alt neon çizgi */
.gamebar-item::after{
  content:"";
  position:absolute;
  left: 12px; right: 12px; bottom: 8px;
  height: 2px;
  border-radius: 999px;
  background: linear-gradient(90deg, transparent, rgba(59,130,246,.95), transparent);
  opacity: 0;
  transform: translateY(6px);
  transition: opacity .18s ease, transform .18s ease;
}
.gamebar-item:hover::after,
.gamebar-item.is-active::after{
  opacity: 1;
  transform: translateY(0);
}

/* Mobil */
@media (max-width: 768px){
  .gamebar{ justify-content: flex-start; } /* mobilde kaydırma daha iyi */
  .gamebar-item{ width: 96px; height: 48px; }
}

.featured-card-link {
    text-decoration: none;
    display: block;
}

.featured-card {
    position: relative;
    height: 110px;
    border-radius: 10px;
    overflow: hidden;
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.featured-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    
}

.featured-card:hover {
    transform: scale(1.05);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4);
}

.featured-card-overlay {
    position: relative;
    z-index: 1;
    padding: 12px 15px 12px 25px;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.featured-card-title {
    color: #fff;
    font-size: 13px;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.3px;
    line-height: 1.2;
    margin-bottom: 3px;
    display: block;
}

.featured-card-action {
    color: #fff;
    font-size: 16px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.3px;
    display: block;
    line-height: 1.1;
}

@media (max-width: 991px) {
    .featured-card {
        height: 100px;
    }
    .featured-card-title {
        font-size: 12px;
    }
    .featured-card-action {
        font-size: 15px;
    }
}

@media (max-width: 767px) {
    .featured-card {
        height: 90px;
    }
    .featured-card-title {
        font-size: 11px;
    }
    .featured-card-action {
        font-size: 14px;
    }
}
</style>
<?php endif; ?>



<section class="fp-section">
    <div class="container">

        <div class="fp-section-head fp-section-head-keys">
            <ul class="nav nav-pills fp-nav-keys" id="tabs-section-popular">
                <li class="nav-item">
                    <a class="fp-spa-nav-link nav-link active" data-section="section-popular" data-category="id1" href="#">
                        <div class="icon-area">
                            <i class="ri-apps-fill"></i>
                        </div>
                        Popüler Ürünler
                    </a>
                </li>
                <li class="nav-item">
                    <a class="fp-spa-nav-link nav-link" data-section="section-popular" data-category="id2" href="#">
                        <div class="icon-area">
                            <i class="ri-flashlight-fill"></i>
                        </div>
                        Yeni Ürünler
                    </a>
                </li>
            </ul>
        </div>

        <div class="row row-products row-cols-2 row-cols-md-3 row-cols-lg-6 container-row-products category-products" data-section="section-popular" data-category-id="id1">
            <?php
            $specialProductIds = [285, 256, 294, 305, 306, 307];

            $specialProducts = $this->db->query("SELECT * FROM product WHERE id IN (" . implode(',', $specialProductIds) . ") AND isActive = 1")->result();

            foreach ($specialProducts as $product): ?>
                <div class="col">
                    <div class="fp-product-item">
                        <a class="img" href="<?= base_url($product->slug); ?>">
                            <img src="<?= base_url('assets/img/product/' . $product->img); ?>" alt="<?= $product->name; ?>" class="img-product img-aspect">
                        </a>
                        <div class="content">
                            <a class="product-name" href="<?= base_url($product->slug); ?>">
                                <?= $product->name; ?>
                            </a>
                            <div class="price">
                                <?php if ($product->discount > 0): ?>
                                    <div class="price-old"><?= number_format($product->price, 2); ?> TL</div>
                                    <div class="price-new"><?= number_format($product->discount, 2); ?> TL</div>
                                <?php else: ?>
                                    <div class="price-new"><?= number_format($product->price, 2); ?> TL</div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="buttons">
                    
                            <a href="<?= base_url($product->slug); ?>" class="btn btn-primary"><i class="ri-coin-line me-1 fs-16"></i> Satın Al</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="row row-products row-cols-2 row-cols-md-3 row-cols-lg-6 container-row-products category-products d-none" data-section="section-popular" data-category-id="id2">
            <?php
            $specialProducts = $this->db->query("
                SELECT * FROM product 
                ORDER BY id DESC 
                LIMIT 6
            ")->result();

            foreach ($specialProducts as $product): ?>
                <div class="col">
                    <div class="fp-product-item">
                        <a class="img" href="<?= base_url($product->slug); ?>">
                            <img src="<?= base_url('assets/img/product/' . $product->img); ?>" alt="<?= $product->name; ?>" class="img-product img-aspect">
                        </a>
                        <div class="content">
                            <a class="product-name" href="<?= base_url($product->slug); ?>">
                                <?= $product->name; ?>
                            </a>
                            <div class="price">
                                <?php if ($product->discount > 0): ?>
                                    <div class="price-old"><?= number_format($product->price, 2); ?> TL</div>
                                    <div class="price-new"><?= number_format($product->discount, 2); ?> TL</div>
                                <?php else: ?>
                                    <div class="price-new"><?= number_format($product->price, 2); ?> TL</div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="buttons">

                            <a href="<?= base_url($product->slug); ?>" class="btn btn-primary"><i class="ri-coin-line me-1 fs-16"></i> Satın Al</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>

        </div>

    </div>
</section>

<?php if (!empty($cases)): ?>
<section class="fp-section">
    <div class="container">
        <div class="fp-section-head">
            <h2 class="title">
                <i class="ri-box-3-line me-2"></i>
                Sandıklar
            </h2>
            <a href="<?= base_url('kasalar') ?>" class="link">Tümünü Gör</a>
        </div>

        <div class="row row-products row-cols-2 row-cols-md-3 row-cols-lg-6">
            <?php foreach ($cases as $case): ?>
                <div class="col">
                    <div class="fp-product-item">
                        <a class="img" href="<?= base_url('case/' . $case->slug) ?>">
                            <img src="<?= base_url('assets/img/case/' . $case->img) ?>" alt="<?= $case->name ?>" class="img-product img-aspect">
                        </a>
                        <div class="content">
                            <a class="product-name" href="<?= base_url('case/' . $case->slug) ?>">
                                <?= $case->name ?>
                            </a>
                            <div class="price">
                                <div class="price-new"><?= number_format($case->price, 2) ?> TL</div>
                            </div>
                        </div>
                        <div class="buttons">
                            <a href="<?= base_url('case/' . $case->slug) ?>" class="btn btn-primary w-100">
                                <i class="ri-box-3-line me-1"></i> Aç
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if (!empty($tasks)): ?>
<section class="fp-section">
    <div class="container">
        <div class="fp-section-head">
            <h2 class="title">
                <i class="ri-task-line me-2"></i>
                Görevler
            </h2>
            <a href="<?= base_url('tasks') ?>" class="link">Tümünü Gör</a>
        </div>

        <div class="row row-products row-cols-2 row-cols-md-3 row-cols-lg-6">
            <?php foreach ($tasks as $task): ?>
                <div class="col">
                    <div class="fp-product-item">
                        <a class="img" href="<?= base_url('tasks/detail/' . $task->id) ?>">
                            <?php if (!empty($task->image)): ?>
                                <img src="<?= base_url('assets/img/tasks/' . $task->image) ?>" class="img-product img-aspect" alt="<?= $task->title ?>">
                            <?php else: ?>
                                <img src="<?= base_url('assets/img/tasks/default-task.png') ?>" class="img-product img-aspect" alt="<?= $task->title ?>">
                            <?php endif; ?>
                            
                            <?php 
                            // Görevi oluşturan kişi
                            $taskOwner = null;
                            if (!empty($task->user_id)) {
                                $taskOwner = $this->db->where('id', $task->user_id)->get('user')->row();
                            }
                            ?>
                            <?php if ($taskOwner): ?>
                                <div class="seller-badge-overlay" style="bottom: 10px !important; cursor: pointer;" onclick="event.preventDefault(); window.location.href='<?= !empty($taskOwner->shop_slug) ? base_url('magaza/' . $taskOwner->shop_slug) : '#' ?>'">
                                    <?php if (!empty($taskOwner->shop_img)): ?>
                                        <img src="<?= base_url('assets/img/shop/' . $taskOwner->shop_img) ?>" alt="" class="shop-avatar">
                                    <?php else: ?>
                                        <i class="ri-user-3-line"></i>
                                    <?php endif; ?>
                                    <span><?php
                                        $m_name = substr($taskOwner->name, 0, 2) . str_repeat('*', max(0, strlen($taskOwner->name) - 2));
                                        $m_surname = substr($taskOwner->surname, 0, 2) . str_repeat('*', max(0, strlen($taskOwner->surname) - 2));
                                        echo $m_name . ' ' . $m_surname;
                                    ?></span>
                                </div>
                            <?php endif; ?>
                        </a>
                        <div class="content">
                            <a class="product-name" href="<?= base_url('tasks/detail/' . $task->id) ?>">
                                <?= $task->title ?>
                            </a>
                            <div class="price">
                                <div class="price-new">
                                    <i class="ri-coin-line me-1"></i><?= number_format($task->reward_amount, 2) ?> TL
                                </div>
                            </div>
                            <div class="task-meta mt-2">
                                <small class="text-muted d-block">
                                    <i class="ri-user-line"></i> Kota: <?= $task->current_count ?>/<?= $task->total_limit ?>
                                </small>
                                <?php 
                                $percentage = ($task->current_count / $task->total_limit) * 100;
                                ?>
                                <div class="progress mt-1" style="height: 4px;">
                                    <div class="progress-bar bg-success" role="progressbar" style="width: <?= $percentage ?>%"></div>
                                </div>
                            </div>
                        </div>
                        <div class="buttons">
                            <a href="<?= base_url('tasks/detail/' . $task->id) ?>" class="btn btn-primary w-100">
                                <i class="ri-eye-line me-1"></i> Detayları Gör
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php 
// Get marketplace products (products from sellers)
$marketplaceProducts = $this->db
    ->where('seller_id >', 0)
    ->where('isActive', 1)
    ->order_by('id', 'DESC')
    ->limit(18)
    ->get('product')
    ->result();
?>

<?php if (!empty($marketplaceProducts)): ?>
<section class="fp-section marketplace-home">
    <div class="container">
        <div class="fp-section-head">
            <h2 class="title">
                <i class="ri-store-line me-2"></i>
                Pazar
            </h2>
            <a href="<?= base_url('ilan-pazari') ?>" class="link">Tümünü Gör</a>
        </div>

        <div class="row row-products row-cols-2 row-cols-md-3 row-cols-lg-6">
            
            <?php foreach ($marketplaceProducts as $product): ?>
                <div class="col">
                    <div class="fp-product-item marketplace-item">
                        <div style="position: relative;">
                            <a class="img" href="<?= base_url($product->slug); ?>">
                                <img src="<?= base_url('assets/img/product/' . $product->img); ?>" alt="<?= $product->name; ?>" class="img-product img-aspect">
                            </a>
                            
                            <?php 
                            $seller = null;
                            if($product->seller_id > 0) {
                                $seller = $this->db->where('id', $product->seller_id)->get('user')->row();
                            }
                            ?>

                            <?php if($seller && !empty($seller->shop_slug)): ?>
  <a class="seller-line" href="<?= base_url('magaza/' . $seller->shop_slug) ?>">
      <span class="seller-avatar">
          <?php if(!empty($seller->shop_img)): ?>
              <img src="<?= base_url('assets/img/shop/' . $seller->shop_img) ?>" alt="Mağaza">
          <?php else: ?>
              <i class="ri-store-2-line"></i>
          <?php endif; ?>
      </span>

      <span class="seller-text">
          <span class="seller-name">
              <?= $seller->shop_name ? $seller->shop_name : ($seller->name . ' ' . $seller->surname) ?>
          </span>
      </span>
      <span class="seller-arrow" aria-hidden="true">
          <i class="ri-arrow-right-s-line"></i>
      </span>
  </a>
<?php endif; ?>
<style>/* Temaya uyum: renkleri inherit ediyoruz */
.fp-product-item .seller-line{
  margin-top: 10px;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
  border-radius: 16px;

  color: inherit;                 /* <-- dark/light otomatik */
  text-decoration: none;
  position: relative;
  overflow: hidden;

  /* Link default mavi olmasın */
  -webkit-tap-highlight-color: transparent;

  transition: transform .18s ease;
}

/* İnce çerçeve: currentColor ile otomatik tema uyumu */
.fp-product-item .seller-line::after{
  content: "";
  position: absolute;
  inset: 0;
  border-radius: 16px;
  border: 1px solid currentColor;
  opacity: .10;                  /* <-- sadece yazı rengi değişince çerçeve de uyumlanır */
  pointer-events: none;
}

/* Dikkat çekici neon accent (sol şerit) */
.fp-product-item .seller-line::before{
  content: "";
  position: absolute;
  left: 0;
  top: 10px;
  bottom: 10px;
  width: 4px;
  border-radius: 999px;
  background: linear-gradient(180deg, #ff00d6, #00ffc3);
  opacity: .85;
  pointer-events: none;
}

/* Avatar */
.fp-product-item .seller-line .seller-avatar{
  width: 40px;
  height: 40px;
  border-radius: 14px;
  overflow: hidden;

  display: inline-flex;
  align-items: center;
  justify-content: center;

  position: relative;
  flex: 0 0 40px;
}

/* Avatar çerçevesi de inherit */
.fp-product-item .seller-line .seller-avatar::after{
  content:"";
  position:absolute;
  inset:0;
  border-radius: 14px;
  border: 1px solid currentColor;
  opacity: .12;
  pointer-events:none;
}

.fp-product-item .seller-line .seller-avatar img{
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

.fp-product-item .seller-line .seller-avatar i{
  font-size: 18px;
  opacity: .9;
}

/* Yazı alanı */
.fp-product-item .seller-line .seller-text{
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
  flex: 1 1 auto;
}

.fp-product-item .seller-line .seller-name{
  font-size: 16px;
  font-weight: 750;
  line-height: 1.1;

  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.fp-product-item .seller-line .seller-sub{
  font-size: 11px;
  line-height: 1;
  opacity: .60;                  /* <-- tema uyumlu “muted” */
}

/* Sağdaki küçük chip */
.fp-product-item .seller-line .seller-chip{
  font-size: 10px;
  font-weight: 800;
  letter-spacing: .6px;
  padding: 6px 8px;
  border-radius: 999px;
  position: relative;
  flex: 0 0 auto;
  opacity: .85;
}

/* Chip çerçevesi inherit */
.fp-product-item .seller-line .seller-chip::after{
  content:"";
  position:absolute;
  inset:0;
  border-radius: 999px;
  border: 1px solid currentColor;
  opacity: .18;
  pointer-events:none;
}

/* Ok */
.fp-product-item .seller-line .seller-arrow{
  width: 34px;
  height: 34px;
  border-radius: 12px;

  display: inline-flex;
  align-items: center;
  justify-content: center;

  position: relative;
  flex: 0 0 34px;
  opacity: .85;
}

.fp-product-item .seller-line .seller-arrow::after{
  content:"";
  position:absolute;
  inset:0;
  border-radius: 12px;
  border: 1px solid currentColor;
  opacity: .12;
  pointer-events:none;
}

.fp-product-item .seller-line .seller-arrow i{
  font-size: 20px;
}

/* Hover (çok hafif, premium) */
.fp-product-item .seller-line:hover{
  transform: translateY(-1px);
}

.fp-product-item .seller-line:hover::after{
  opacity: .16;
}

.fp-product-item .seller-line:hover .seller-arrow{
  transform: translateX(2px);
  transition: transform .18s ease;
}

/* Mobil */
@media (max-width: 576px){
  .fp-product-item .seller-line{ padding: 9px 10px; }
  .fp-product-item .seller-line .seller-avatar{ width: 38px; height: 38px; flex-basis: 38px; }
}
/* mağaza satırı görsele göre içeri girsin */
.fp-product-item .seller-line{
  margin-left: 10px;
  margin-right: 10px;
}

/* büyük ekranda biraz daha içeri */
@media (min-width: 992px){
  .fp-product-item .seller-line{
    margin-left: 12px;
    margin-right: 12px;
  }
}

/* mobilde çok daralmasın */
@media (max-width: 576px){
  .fp-product-item .seller-line{
    margin-left: 8px;
    margin-right: 8px;
  }
}
/* görselin kenarlarıyla aynı his için */
.fp-product-item .product-media .img{
  display:block;
}

/* mağaza satırını resme doğru içeri al + yukarı taşı (girintili görünüm) */
.fp-product-item .product-media .seller-line{
  margin: -14px 12px 6px !important;  /* yukarı girsin + sağ-sol içeri */
  position: relative;
  z-index: 3;
}

/* çok dar ekranlarda daha az içeri */
@media (max-width: 576px){
  .fp-product-item .product-media .seller-line{
    margin: -12px 10px 6px !important;
  }
}
/* Gri çerçeveyi kaldırıp neon kayan border yap */
.fp-product-item .seller-line::after{
  content: "";
  position: absolute;
  inset: 0;
  border-radius: 16px;

  /* border kalınlığı */
  padding: 0.3px;

  /* neon gradient (kayan) */
  background: linear-gradient(90deg,
    rgba(255, 0, 214, .95),
    rgba(0, 255, 195, .85),
    rgba(0, 140, 255, .85),
    rgba(255, 0, 214, .95)
  );
  background-size: 300% 100%;
  animation: sellerBorderFlow 2.2s linear infinite;

  /* sadece çerçeveyi göstermek için maske */
  -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
  -webkit-mask-composite: xor;
  mask-composite: exclude;

  /* hafif neon glow */
  filter:
    drop-shadow(0 0 10px rgba(255, 0, 214, .18))
    drop-shadow(0 0 10px rgba(0, 255, 195, .12));

  opacity: .70;
  pointer-events: none;
}

/* Hover’da biraz daha belirgin olsun */
.fp-product-item .seller-line:hover::after{
  opacity: .95;
}

/* Kayan neon animasyonu */
@keyframes sellerBorderFlow{
  0%   { background-position:   0% 50%; }
  100% { background-position: 100% 50%; }
}

/* Hareket azaltma tercihine saygı */
@media (prefers-reduced-motion: reduce){
  .fp-product-item .seller-line::after{ animation: none; }
}
/* SECTION: hafif neon geçişli saydam arkaplan */
.marketplace-home{
  position: relative;
  overflow: hidden;      /* glow taşmasın */
  border-radius: 22px;   /* daha premium */
}

/* neon soft background katmanı */
.marketplace-home::before{
  content:"";
  position:absolute;
  inset:-120px;          /* glow geniş yayılsın */
  pointer-events:none;
  z-index:0;

  background:
    radial-gradient(900px 420px at 15% 25%,
      rgba(255, 0, 214, .12),
      transparent 60%),
    radial-gradient(900px 420px at 85% 30%,
      rgba(0, 255, 195, .10),
      transparent 60%),
    radial-gradient(900px 420px at 60% 85%,
      rgba(0, 140, 255, .10),
      transparent 60%);

  filter: blur(18px);
  opacity: .95;
}

/* çok hafif “glass” kaplama (temayı bozmaz) */
.marketplace-home::after{
  content:"";
  position:absolute;
  inset:0;
  pointer-events:none;
  z-index:0;

  background: linear-gradient(135deg,
    rgba(255,255,255,.06),
    rgba(255,255,255,.02)
  );

  /* çok hafif doku gibi */
  opacity: .9;
}

/* içerik glow’un üstünde kalsın */
.marketplace-home > *{
  position: relative;
  z-index: 1;
}

/* mobilde daha az glow */
@media (max-width: 576px){
  .marketplace-home::before{
    filter: blur(14px);
    opacity: .85;
  }
}

</style>
                        </div>
                        <div class="content">
                            <a class="product-name" href="<?= base_url($product->slug); ?>">
                                <?= $product->name; ?>
                            </a>
                           <?php 
  $price = json_decode(calculatePrice($product->id, 1), true);
  $hasDiscount = !empty($price['isDiscount']);

  $discountPercent = 0;
  if ($hasDiscount && (float)$price['normalPrice'] > 0) {
      $discountPercent = round(100 - ((float)$price['price'] / (float)$price['normalPrice']) * 100);
      if ($discountPercent < 0) $discountPercent = 0;
  }
?>

<div class="price-box <?= $hasDiscount ? 'has-discount' : 'no-discount' ?>">
    <!-- Badge HER ZAMAN var (indirim yoksa boş kalır) -->
    <span class="price-badge">
        <?= $hasDiscount ? ('-%' . $discountPercent) : '' ?>
    </span>

    <div class="price-main">
        <span class="price-now">
            <span class="price-amount"><?= number_format((float)$price['price'], 0, ',', '.') ?></span>
            <span class="price-currency">₺</span>
        </span>

        <!-- Old price HER ZAMAN var (indirim yoksa gizlenecek ama yer tutacak) -->
        <span class="price-was">
            <?= $hasDiscount ? number_format((float)$price['normalPrice'], 0, ',', '.') . ' ₺' : '&nbsp;' ?>
        </span>
    </div>
</div>


                        </div>

                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
   <style>/* ===== Price Box (modern) ===== */
.fp-product-item .price-box{
  margin-top: 8px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;

  padding: 10px 12px;
  border-radius: 16px;

  /* arkaplan verme yok: kart temasını bozmasın */
  position: relative;
  overflow: hidden;
}

/* İnce çerçeve: yazı rengine göre uyum (dark/light) */
.fp-product-item .price-box::after{
  content:"";
  position:absolute;
  inset:0;
  border-radius: 16px;
  border: 1px solid currentColor;
  opacity: .10;
  pointer-events:none;
}

/* indirim rozeti */
.fp-product-item .price-badge{
  font-size: 10px;
  font-weight: 900;
  letter-spacing: .4px;
  padding: 6px 8px;
  border-radius: 999px;
  position: relative;
  opacity: .95;
  white-space: nowrap;
}

/* rozet çerçevesi */
.fp-product-item .price-badge::after{
  content:"";
  position:absolute;
  inset:0;
  border-radius: 999px;
  border: 1px solid currentColor;
  opacity: .18;
  pointer-events:none;
}

/* fiyat satırı */
.fp-product-item .price-main{
  min-width: 0;
  display:flex;
  align-items: baseline;
  gap: 10px;
  margin-left: auto;
}

.fp-product-item .price-now{
  font-size: 16px;
  font-weight: 900;
  line-height: 1;
  white-space: nowrap;
}

.fp-product-item .price-now small{
  font-size: 11px;
  font-weight: 800;
  opacity: .65;
}

.fp-product-item .price-was{
  font-size: 12px;
  opacity: .55;
  text-decoration: line-through;
  white-space: nowrap;
}

/* ===== Single Buy Button (modern) ===== */
.fp-product-item .buttons{
  margin-top: 10px;
}

.fp-product-item .btn-buy{
  width: 100%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;

  padding: 11px 12px;
  border-radius: 16px;

  text-decoration: none;
  color: #fff;

  background: linear-gradient(135deg, #0004ff69, #b9e0faff);
  box-shadow: 0 14px 30px rgba(0,0,0,.22);

  font-weight: 900;
  letter-spacing: .2px;

  transition: transform .18s ease, box-shadow .18s ease, filter .18s ease;
}

.fp-product-item .btn-buy:hover{
  transform: translateY(-1px);
  box-shadow: 0 18px 38px rgba(0,0,0,.28);
  filter: saturate(1.1);
}

.fp-product-item .btn-buy .btn-arrow{
  display:inline-flex;
  align-items:center;
  justify-content:center;
  width: 30px;
  height: 30px;
  border-radius: 12px;
  background: rgba(255,255,255,.18);
}

.fp-product-item .btn-buy:hover .btn-arrow{
  transform: translateX(2px);
  transition: transform .18s ease;
}
/* PRICE BOX: neon kayan çerçeve + hafif glow */
.fp-product-item .price-box{
  position: relative;
  isolation: isolate; /* glow düzgün dursun */
}

/* eski gri çerçeveyi iptal et */
.fp-product-item .price-box::after{
  border: none !important;
}

/* neon kayan border */
.fp-product-item .price-box::after{
  content: "";
  position: absolute;
  inset: 0;
  padding: 1px;               /* border kalınlığı */
  border-radius: 16px;

  background: linear-gradient(90deg,
    rgba(255, 0, 214, .95),
    rgba(0, 255, 195, .85),
    rgba(0, 140, 255, .85),
    rgba(255, 0, 214, .95)
  );
  background-size: 300% 100%;
  animation: sellerBorderFlow 2.2s linear infinite;

  -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
  -webkit-mask-composite: xor;
  mask-composite: exclude;

  filter:
    drop-shadow(0 0 10px rgba(255, 0, 214, .16))
    drop-shadow(0 0 10px rgba(0, 255, 195, .10));

  opacity: .85;
  pointer-events: none;
  z-index: 1;
}

/* glow katmanı (çok abartmadan) */
.fp-product-item .price-box::before{
  content: "";
  position: absolute;
  inset: -6px;
  border-radius: 18px;
  background: linear-gradient(135deg,
    rgba(255, 0, 214, .22),
    rgba(0, 255, 195, .16),
    rgba(0, 140, 255, .14)
  );
  filter: blur(14px);
  opacity: .35;
  pointer-events: none;
  z-index: 0;
}

/* içerik üstte kalsın */
.fp-product-item .price-box > *{
  position: relative;
  z-index: 2;
}

/* hover'da biraz daha parlak */
.fp-product-item .price-box:hover::after{ opacity: .98; }
.fp-product-item .price-box:hover::before{ opacity: .50; }

/* Animasyon (seller-line ile aynı kullanılıyor) */
@keyframes sellerBorderFlow{
  0%   { background-position:   0% 50%; }
  100% { background-position: 100% 50%; }
}

/* Hareket azaltma */
@media (prefers-reduced-motion: reduce){
  .fp-product-item .price-box::after{ animation: none; }
}
/* Tüm ürünlerde fiyat kutusu aynı yükseklik */
.fp-product-item .price-box{
  min-height: 15px;       /* hepsini eşitler */
  align-items: center;
}



/* Eski fiyat satırı her zaman aynı yükseklik tutsun */
.fp-product-item .price-was{
  display: block;
  line-height: 1;
  min-height: 22px;     /* yer sabitle */
}

/* İndirim yoksa badge ve eski fiyat görünmesin ama yer tutsun */
.fp-product-item .price-box.no-discount .price-badge{
  visibility: hidden;
}

.fp-product-item .price-box.no-discount .price-was{
  visibility: hidden;
}

</style> 
</section>
<?php endif; ?>



<div class="fp-section">
    <div class="container">

        <div class="fp-trend-categories-head">
            <div class="title">
                <div class="icon-area"><i class="ri-fire-fill"></i></div> Öne Çıkan Kategoriler
            </div>
            <div class="buttons">
                <div class="button fp-swiper-trend-prev"><i class="ri-arrow-left-line"></i></div>
                <div class="button fp-swiper-trend-next"><i class="ri-arrow-right-line"></i></div>
            </div>
        </div>

        <div class="swiper fp-swiper-trend-categories">
            <div class="swiper-wrapper">

                <?php foreach($editor_choice as $ec){ ?>
                    <div class="swiper-slide">
                        <a href="<?= $ec->link ?>">
                            <div class="fp-sc-item">
                                <img src="<?= base_url("assets/img/home_choice/") . $ec->img ?>" alt="Editörün Seçimi Ürün Linki" class="img">
                            </div>
                        </a>
                    </div>
                <?php } ?>

            </div>
        </div>

    </div>
</div>



<?php
$section1_ids = [62, 63, 65, 67];
$section2_ids = [89, 90, 74];
$section3_ids = [75, 76];
$section4_ids = [88];
$section5_ids = [91, 86, 92];

$sections = [
    'section1' => $section1_ids,
    'section2' => $section2_ids,
    'section5' => $section5_ids
];

$sectionCategories = [];
$sectionProducts = [];

foreach ($sections as $sectionKey => $ids) {
    $cats = $this->db->where_in('id', $ids)->get('category')->result();
    $orderedCats = [];
    foreach ($ids as $id) {
        foreach ($cats as $c) {
            if ($c->id == $id) {
                $orderedCats[] = $c;
                break;
            }
        }
    }
    $sectionCategories[$sectionKey] = $orderedCats;

    foreach ($ids as $cid) {
        $sectionProducts[$sectionKey][$cid] = $this->db
            ->where('category_id', $cid)
            ->where('isActive', 1)
            ->order_by('price', 'ASC')
            ->limit(6)
            ->get('product')
            ->result();
    }
}
?>

<?php foreach ($sections as $sectionKey => $ids): ?>
    <section class="fp-section fp-section-keys" id="<?= $sectionKey ?>">
        <div class="container">
            <div class="fp-section-head fp-section-head-keys">
                <ul class="nav nav-pills fp-nav-keys" id="tabs-<?= $sectionKey ?>">
                    <?php foreach ($sectionCategories[$sectionKey] as $index => $cat): ?>
                        <li class="nav-item">
                            <a class="fp-spa-nav-link nav-link <?= $index === 0 ? 'active' : '' ?> <?= stripos($cat->name, 'Valorant') !== false ? 'valorant' : (stripos($cat->name, 'PUBG') !== false ? 'pubg-mobile' : (stripos($cat->name, 'Steam') !== false ? 'steam' : '')) ?>" data-section="<?= $sectionKey ?>" data-category="<?= $cat->id ?>" href="#">
                                <?php if (stripos($cat->name, 'Valorant') !== false): ?>
                                    <div class="icon-area link-valorant">
                                        <img src="<?= base_url('assets/future/img/menu-icons/valorant.png') ?>" alt="Valorant">
                                    </div>
                                <?php elseif (stripos($cat->name, 'PUBG') !== false): ?>
                                    <div class="icon-area link-pubg-mobile">
                                        <img src="<?= base_url('assets/future/img/menu-icons/pubg-mobile.png') ?>" alt="PUBG Mobile">
                                    </div>
                                <?php elseif (stripos($cat->name, 'Brawl Stars') !== false): ?>
                                    <div class="icon-area link-brawl-stars">
                                        <img src="<?= base_url('assets/future/img/menu-icons/brawl-stars.png') ?>" alt="Steam">
                                    </div>
                                <?php elseif (stripos($cat->name, 'Fortnite') !== false): ?>
                                    <div class="icon-area link-fortnite">
                                        <img src="<?= base_url('assets/future/img/menu-icons/fortnite-2.png') ?>" alt="Steam">
                                    </div>
                                <?php elseif (stripos($cat->name, 'Steam') !== false): ?>
                                    <div class="icon-area link-fortnite">
                                        <img src="<?= base_url('assets/future/img/menu-icons/steams.png') ?>" alt="Steam">
                                    </div>
                                <?php endif; ?>
                                <?= $cat->name ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
                <?php if ($sectionKey == 'section1'): ?>
                    <a href="<?= base_url('kategori/valorant') ?>" class="btn btn-opacity-primary">Tümü <i class="ri-arrow-right-s-line icon icon-right"></i></a>
                <?php elseif ($sectionKey == 'section2'): ?>
                    <a href="<?= base_url('kategori/pubg-mobile') ?>" class="btn btn-opacity-primary">Tümü <i class="ri-arrow-right-s-line icon icon-right"></i></a>
                <?php elseif ($sectionKey == 'section3'): ?>
                    <a href="<?= base_url('kategori/steam') ?>" class="btn btn-opacity-primary">Tümü <i class="ri-arrow-right-s-line icon icon-right"></i></a>
                <?php endif; ?>
            </div>

            <?php foreach ($sectionCategories[$sectionKey] as $index => $cat): ?>
                <div class="row row-products container-row-products category-products <?= $index === 0 ? '' : 'd-none' ?>" data-section="<?= $sectionKey ?>" data-category-id="<?= $cat->id ?>">
                    <?php foreach ($sectionProducts[$sectionKey][$cat->id] as $p): ?>
                        <div class="col-6 col-md-4 col-lg-3 col-xl-2">
                            <div class="fp-product-item">
                                <a class="img" href="<?= base_url($p->slug) ?>">
                                    <img src="<?= base_url('assets/img/product/') . $p->img ?>" class="img-product img-aspect">
                                </a>
                                <div class="content">
                                    <a class="product-name" href="<?= base_url($p->slug) ?>"><?= $p->name ?></a>
                                    <div class="price">
                                        <?php
                                        $price = json_decode(calculatePrice($p->id, 1), true);
                                        $total = ($price['price'] - $price['normalPrice']) / $price['normalPrice'] * 100;
                                        ?>
                                        <?php if ($price['isDiscount'] == 1) { ?>
                                            <div class="price-new"><?= $price['price'] ?> TL</div>
                                            <div class="price-old"><?= $price['normalPrice'] ?> TL</div>
                                        <?php }else{ ?>
                                            <div class="price-new"><?= $price['price'] ?> TL</div>
                                        <?php } ?>
                                    </div>
                                </div>
                                <div class="buttons">
                                 
                                    <a href="<?= base_url($p->slug); ?>" class="btn btn-primary"><i class="ri-coin-line me-1 fs-16"></i> Satın Al</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <?php if ($sectionKey == 'section1'): ?>

        <section class="fp-section">
            <div class="container">
                <div class="row">

                    <div class="col-lg-3">
                        <a href="" class="fp-roy-grid-image">
                            <img src="<?= base_url('assets/future/img/grid-images/enalt3.png') ?>" alt="">
                        </a>
                        <a href="" class="fp-roy-grid-image">
                            <img src="<?= base_url('assets/future/img/grid-images/enalt2.png') ?>" alt="">
                        </a>
                    </div>

                    <div class="col-lg-6">
                        <a href="" class="fp-roy-grid-image large">
                            <img src="<?= base_url('assets/future/img/grid-images/enalt1.png') ?>" alt="">
                        </a>
                    </div>

                    <div class="col-lg-3">
                        <a href="" class="fp-roy-grid-image">
                            <img src="<?= base_url('assets/future/img/grid-images/enalt4.png') ?>" alt="">
                        </a>
                        <a href="" class="fp-roy-grid-image">
                            <img src="<?= base_url('assets/future/img/grid-images/enalt5.png') ?>" alt="">
                        </a>
                    </div>

                </div>
            </div>
        </section>

        <div class="container">
            <div class="fp-instagram-area">
                <img src="<?= base_url('assets/future/img/insta.jpeg') ?>" alt="" class="img">
                <a href="https://www.instagram.com/roypincom/" target="_blank" class="btn btn-primary"><i class="ri-instagram-line me-2"></i> Takip Et</a>
            </div>
        </div>
    <?php endif; ?>
<?php endforeach; ?>


<script>
    $('.fp-spa-nav-link').on('click', function(e) {
        e.preventDefault();
        var section = $(this).data('section');
        var categoryId = $(this).data('category');

        $('#tabs-' + section + ' .fp-spa-nav-link').removeClass('active');
        $(this).addClass('active');

        $('.category-products[data-section="' + section + '"]').addClass('d-none');
        $('.category-products[data-section="' + section + '"][data-category-id="' + categoryId + '"]').removeClass('d-none');
    });
</script>



<section class="fp-testimonials">
    <div class="container">

        <div class="head-area">
            <div class="left">
                <img src="<?= base_url("assets/future/img/roy-logo-dark.png"); ?>" alt="" class="logo dark">
                <img src="<?= base_url("assets/future/img/roy-logo-light.png"); ?>" alt="" class="logo white">
            </div>
            <div class="right">
                <div class="content">
                    <div class="stars"><i class="ri-star-fill"></i><i class="ri-star-fill"></i><i class="ri-star-fill"></i><i class="ri-star-fill"></i><i class="ri-star-fill"></i></div>
                    <p>Roypin, müşteri deneyimine ve müşteri değerlendirmelerine oldukça önem verir. Siz de aldığınız ürünü değerlendirerek burada yer alabilirsiniz. İşte bazı değerlendirmelerimiz:</p>
                </div>
            </div>
        </div>


        <?php
        $testimonials = $this->db->query("
            SELECT pc.*, 
                   p.name AS product_name, 
                   p.slug AS product_slug, 
                   p.img AS product_image, 
                   c.name AS category_name, 
                   c.slug AS category_slug
            FROM product_comments pc
            LEFT JOIN product p ON pc.product_id = p.id
            LEFT JOIN category c ON p.category_id = c.id
            WHERE pc.isActive = 1
            ORDER BY RAND() 
            LIMIT 16
        ")->result();
        ?>


        <div class="swiper fp-swiper-testimonials">
            <div class="swiper-wrapper">
                <?php foreach ($testimonials as $testimonial): ?>
                    <div class="swiper-slide">
                        <div class="fp-testimonials-item">
                            <div class="user">
                                <img src="<?= base_url('assets/img/profile-testimonials.png') ?>" alt="" class="img-profile">
                                <div class="info">
                                    <div class="stars">
                                        <?php for ($i = 0; $i < $testimonial->star; $i++): ?>
                                            <i class="ri-star-fill"></i>
                                        <?php endfor; ?>
                                    </div>
                                    <a href="<?= base_url('kategori/' . $testimonial->category_slug) ?>" class="product-link">
                                        <?= htmlspecialchars($testimonial->category_name) ?>
                                    </a>
                                </div>
                            </div>
                            <div class="desc"><?= htmlspecialchars($testimonial->comment) ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="fp-swiper-testimonials-prev fp-swiper-prev"><i class="ri-arrow-left-s-line"></i></div>
            <div class="fp-swiper-testimonials-next fp-swiper-next"><i class="ri-arrow-right-s-line"></i></div>
            <div class="swiper-pagination"></div>
        </div>

    </div>
</section>


<div class="fp-section pb-5">
    <div class="container">

        <div class="fp-trend-categories-head">
            <div class="title">
                <div class="icon-area"><i class="ri-article-line"></i></div> Blog
            </div>
        </div>

        <?php
        function dateFormat($originalDate) {
            $dateObject = DateTime::createFromFormat('d.m.Y', $originalDate);
            $turkishMonths = ['01' => 'OCA', '02' => 'ŞUB', '03' => 'MAR', '04' => 'NİS', '05' => 'MAY', '06' => 'HAZ','07' => 'TEM', '08' => 'AĞU', '09' => 'EYL', '10' => 'EKM', '11' => 'KAS', '12' => 'ARA'];
            $monthNumber = $dateObject->format('m');
            $newFormat = $turkishMonths[$monthNumber];
            return $newFormat;
        }
        ?>
        <div class="row">
            <?php foreach ($footerBlog as $b) { ?>
                <div class="col-md-6 col-lg-4">
                    <div class="fp-blog-item">
                        <img src="<?= base_url('assets/img/blog/' . $b->img) ?>" alt="" class="img-cover img-aspect">
                        <div class="date">
                            <?php $dateObject = DateTime::createFromFormat('d.m.Y', $b->date); ?>
                            <div class="day"><?= $dateObject->format('d'); ?></div>
                            <div class="month"><?= dateFormat($b->date); ?></div>
                        </div>
                        <div class="content">
                            <a href="<?= base_url('makale/') . $b->slug ?>" class="title"><?= $b->title ?></a>
                            <a href="<?= base_url('makale/') . $b->slug ?>" class="btn btn-link text-white rounded-pill btn-sm">Tümünü Oku <i class="ri-arrow-right-line icon icon-right"></i></a>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>

    </div>
</div>
<script>
(function () {
  function isDarkTheme() {
    const html = document.documentElement;
    const body = document.body;

    // data-theme / data-bs-theme
    const htmlTheme = (html.getAttribute('data-theme') || '').toLowerCase();
    const bodyTheme = (body.getAttribute('data-theme') || '').toLowerCase();
    const bsHtml = (html.getAttribute('data-bs-theme') || '').toLowerCase();
    const bsBody = (body.getAttribute('data-bs-theme') || '').toLowerCase();

    // class tabanli
    const classDark = html.classList.contains('dark') || body.classList.contains('dark')
      || html.classList.contains('theme-dark') || body.classList.contains('theme-dark')
      || html.classList.contains('dark-mode') || body.classList.contains('dark-mode');

    return classDark || htmlTheme === 'dark' || bodyTheme === 'dark' || bsHtml === 'dark' || bsBody === 'dark';
  }

  function applyLogos() {
    const dark = isDarkTheme();
    document.querySelectorAll('img.gameLogo').forEach(img => {
      const lightSrc = img.getAttribute('data-light');
      const darkSrc  = img.getAttribute('data-dark');
      const nextSrc = dark ? darkSrc : lightSrc;

      if (nextSrc && img.src !== location.origin + nextSrc && !img.src.endsWith(nextSrc)) {
        img.src = nextSrc;
      }
    });
  }

  // ilk yükleme
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applyLogos);
  } else {
    applyLogos();
  }

  // tema değişimini otomatik yakala
  const mo = new MutationObserver(applyLogos);
  mo.observe(document.documentElement, { attributes: true, attributeFilter: ['class','data-theme','data-bs-theme'] });
  mo.observe(document.body, { attributes: true, attributeFilter: ['class','data-theme','data-bs-theme'] });

  // sistem tema değişirse (manual toggle yoksa bile)
  if (window.matchMedia) {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    if (mq.addEventListener) mq.addEventListener('change', applyLogos);
    else if (mq.addListener) mq.addListener(applyLogos);
  }
})();
</script>
