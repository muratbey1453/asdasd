<section class="fp-section-page">
    <div class="container">

        <div class="fp-section-page-head">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="<?= base_url() ?>">Ana Sayfa</a></li>
                    <li class="breadcrumb-item"><a href="<?= base_url('makale-listesi') ?>">Blog</a></li>
                    <li class="breadcrumb-item active"><?= $blog->title ?></li>
                </ol>
            </nav>
        </div>

        <div class="row">
            <div class="col-lg-8">
                <div class="fp-card">
                    <div class="fp-blog-detail">
                        <?php if(!empty($blog->img)): ?>
                            <div class="blog-image mb-4">
                                <img src="<?= base_url('assets/img/blog/' . $blog->img) ?>" alt="<?= $blog->title ?>" class="img-fluid rounded">
                            </div>
                        <?php endif; ?>
                        
                        <h1 class="blog-title mb-3"><?= $blog->title ?></h1>
                        
                        <div class="blog-meta mb-4">
                            <span class="date"><i class="ri-calendar-2-line"></i> <?= $blog->date ?></span>
                        </div>
                        
                        <div class="blog-content">
                            <?= $blog->content ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="fp-card">
                    <div class="fp-card-head">
                        <h3 class="title">Diğer Makaleler</h3>
                    </div>
                    <div class="fp-card-body p-0">
                        <?php if(!empty($relatedBlogs)): ?>
                            <?php foreach($relatedBlogs as $rb): ?>
                                <a href="<?= base_url('makale/' . $rb->slug) ?>" class="d-flex align-items-center p-3 border-bottom text-decoration-none">
                                    <?php if(!empty($rb->img)): ?>
                                        <img src="<?= base_url('assets/img/blog/' . $rb->img) ?>" alt="<?= $rb->title ?>" style="width: 60px; height: 60px; object-fit: cover; border-radius: 8px;" class="me-3">
                                    <?php endif; ?>
                                    <div>
                                        <h6 class="mb-1"><?= $rb->title ?></h6>
                                        <small class="text-muted"><?= $rb->date ?></small>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="p-3 text-muted mb-0">Henüz başka makale yok.</p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="mt-4">
                    <a href="<?= base_url('makale-listesi') ?>" class="btn btn-outline-primary w-100">
                        <i class="ri-arrow-left-line"></i> Tüm Makaleler
                    </a>
                </div>
            </div>
        </div>

    </div>
</section>

<style>
.fp-blog-detail .blog-title {
    font-size: 1.75rem;
    font-weight: 600;
}

.fp-blog-detail .blog-meta {
    color: var(--text-secondary);
    font-size: 0.9rem;
}

.fp-blog-detail .blog-meta i {
    margin-right: 5px;
}

.fp-blog-detail .blog-content {
    line-height: 1.8;
}

.fp-blog-detail .blog-content img {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
}

.fp-blog-detail .blog-content p {
    margin-bottom: 1rem;
}
</style>
