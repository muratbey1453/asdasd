<?php
$games   = isset($games) && is_array($games) ? $games : [];
$groups  = isset($groups) && is_array($groups) ? $groups : [];

$gameKeys = array_values(array_unique(array_merge(array_keys($games), array_keys($groups))));
$active = !empty(array_keys($groups)) ? array_keys($groups)[0] : (array_key_first($games) ?: 'all');
if (!empty($gameKeys) && !in_array($active, $gameKeys, true)) $active = $gameKeys[0];

$counts = [];
foreach ($gameKeys as $slug) {
  $counts[$slug] = isset($groups[$slug]) && is_array($groups[$slug]) ? count($groups[$slug]) : 0;
}

/**
 * slug -> logo key map (senin dosya adların)
 * /assets/img/gameic/{key}_l.svg
 * /assets/img/gameic/{key}_d.webp
 */
$logoMap = [
  'league-of-legends' => 'lol',
  'knight-online'     => 'knight',
  'metin-2'           => 'metin2',
  'metin2'            => 'metin2',
  'valorant'          => 'valorant',
  'pubg-mobile'       => 'pubg',
  'mobile-legends'    => 'mobile',   // sende mobile_l.svg var, dark tarafı mlbb_d.webp kullanıyorsun (aşağıda override var)
  'mlbb'              => 'mobile',
  'razer-gold'        => 'razer',
  'rise-online'       => 'rise',
  'cs2'               => 'cs2',
  'minecraft'         => 'mc',
];

/**
 * Bazı oyunlarda dark dosya adı farklı olabilir:
 * Mobile Legends: dark'ta mlbb_d.webp kullanıyorsun
 * PUBG: örneğinde src yanlışlıkla pubg_.webp yazılmış, düzeltelim -> pubg_d.webp
 */
function game_logo_paths($slug, $label, $logoMap){
  $key = $logoMap[$slug] ?? $slug;

  $light = "/assets/img/gameic/{$key}_l.svg";
  $dark  = "/assets/img/gameic/{$key}_d.webp";

  // Special cases
  if ($key === 'mobile') {
    $dark = "/assets/img/gameic/mlbb_d.webp";
  }
  if ($key === 'pubg') {
    $dark = "/assets/img/gameic/pubg_d.webp";
  }

  return [
    'light' => $light,
    'dark'  => $dark,
    'alt'   => $label
  ];
}
?>

<div class="fp-container serverhub" style="padding:24px 0;">
  <div class="servers-page">

    <div class="servers-head">
      <div>
        <h1 class="servers-title"><?= isset($title) ? html_escape($title) : 'Sunucular' ?></h1>
        <p class="servers-sub">Oyun seç, sunucuları incele. Kullanıcı eklemeleri admin onayından sonra görünür.</p>
      </div>

      <a class="btn-add-server" href="<?= base_url('client/sunucu-ekle') ?>">
        <i class="ri-add-line"></i><span>Sunucu Ekle</span>
      </a>
    </div>

    <!-- GAME TABS -->
    <?php if (!empty($gameKeys)): ?>
      <div class="game-tabs" role="tablist" aria-label="Oyun Sekmeleri">
        <?php foreach ($gameKeys as $slug): ?>
          <?php
            $label = $games[$slug] ?? ucfirst($slug);
            $count = (int)($counts[$slug] ?? 0);
            $lp = game_logo_paths($slug, $label, $logoMap);
          ?>

          <button type="button"
                  class="game-tab <?= ($slug === $active) ? 'is-active' : '' ?>"
                  data-game="<?= html_escape($slug) ?>"
                  role="tab"
                  aria-selected="<?= ($slug === $active) ? 'true' : 'false' ?>">

            <div class="gt-logoWrap">
              <img class="gameLogo"
                   data-light="<?= html_escape($lp['light']) ?>"
                   data-dark="<?= html_escape($lp['dark']) ?>"
                   src="<?= html_escape($lp['dark']) ?>"
                   alt="<?= html_escape($lp['alt']) ?>">
            </div>

            <div class="gt-text">
              <div class="gt-label"><?= html_escape($label) ?></div>
              <div class="gt-sub">Onaylı Sunucu</div>
            </div>

            <div class="gt-count" title="Onaylı sunucu sayısı"><?= $count ?></div>
          </button>

        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <!-- LIST -->
    <div class="servers-grid">

      <?php if (empty($groups)): ?>
        <div class="servers-empty">
          <i class="ri-server-line"></i>
          <div>
            <div class="t">Henüz onaylı sunucu yok</div>
            <div class="d">İlk sunucuyu ekleyerek listeyi başlat.</div>
          </div>
        </div>
      <?php else: ?>

        <?php foreach ($groups as $gameSlug => $items): ?>
          <?php $label = $games[$gameSlug] ?? ucfirst($gameSlug); ?>

          <section class="servers-section"
                   data-game-section="<?= html_escape($gameSlug) ?>"
                   style="<?= ($gameSlug === $active) ? '' : 'display:none' ?>">

            <div class="servers-section-head">
              <h2 class="servers-section-title">
                <i class="ri-gamepad-line"></i>
                <span><?= html_escape($label) ?></span>
              </h2>
            </div>

            <div class="servers-cards servers-cards-1col">
              <?php foreach ($items as $s): ?>

                <?php
                  $bannerUrl = !empty($s->banner)
                    ? base_url('assets/img/servers/' . $s->banner)
                    : base_url('assets/img/server_banners/default.webp');
                ?>

                <?php $detailUrl = base_url('sunucular/detay/' . $s->id); ?>

<div class="server-card server-card-row">
  <a class="server-banner" href="<?= $detailUrl ?>">
    <img src="<?= html_escape($bannerUrl) ?>" alt="<?= html_escape($s->title) ?>">
  </a>

  <div class="server-body">
    <div class="server-top">
      <div class="server-title">
        <a class="name" href="<?= $detailUrl ?>"><?= html_escape($s->title) ?></a>
        <span class="badge ok">Onaylı</span>
      </div>

                      <?php if (!empty($s->short_desc)): ?>
                        <div class="server-short"><?= nl2br(html_escape($s->short_desc)) ?></div>
                      <?php endif; ?>
                    </div>

                    <div class="server-ip">
                      <i class="ri-navigation-line"></i>
                      <span><?= html_escape($s->ip) ?></span>

                      <button class="copy-btn" type="button" data-copy="<?= html_escape($s->ip) ?>" aria-label="IP kopyala">
                        <i class="ri-file-copy-line"></i>
                      </button>
                    </div>

                    <?php if (!empty($s->description) && empty($s->short_desc)): ?>
                      <div class="server-desc"><?= nl2br(html_escape($s->description)) ?></div>
                    <?php endif; ?>

                    <div class="server-actions">
  <?php if (!empty($s->website)): ?>
    <a class="server-link-mini" target="_blank" rel="nofollow" href="<?= html_escape($s->website) ?>">
      <i class="ri-global-line"></i><span>Website</span>
    </a>
  <?php endif; ?>

  <?php if (!empty($s->discord)): ?>
    <a class="server-link-mini" target="_blank" rel="nofollow" href="<?= html_escape($s->discord) ?>">
      <i class="ri-discord-line"></i><span>Discord</span>
    </a>
  <?php endif; ?>
  <a class="server-link-mini" href="<?= $detailUrl ?>">
  <i class="ri-article-line"></i><span>Detay</span>
</a>

</div>

                  </div>
                </div>

              <?php endforeach; ?>
            </div>

          </section>
        <?php endforeach; ?>

        <!-- Boş tab placeholder -->
        <div class="servers-empty" id="serversEmptyTab" style="display:none; margin-top:12px;">
          <i class="ri-server-line"></i>
          <div>
            <div class="t">Bu oyunda henüz onaylı sunucu yok</div>
            <div class="d">Sunucu ekleyerek listeyi başlatabilirsin.</div>
          </div>
        </div>

      <?php endif; ?>
    </div>

  </div>
</div>

<style>
.serverhub{
  --sh-card: rgba(255,255,255,.65);
  --sh-card2: rgba(255,255,255,.52);
  --sh-text: var(--text-color);
  --sh-muted: var(--text-gray);
  --sh-bd: var(--border);
  --sh-glow: rgba(0,255,209,.20);
}
html[data-theme="dark"] .serverhub{
  --sh-card: rgba(20,24,33,.66);
  --sh-card2: rgba(20,24,33,.48);
  --sh-glow: rgba(0,255,209,.14);
}

/* ✅ Sayfayı sağa-sola genişlet */
.servers-page{
  width:100%;
  max-width: 1400px;
  margin:0 auto;
  padding: 0 14px;
}
@media (min-width: 14s00px){
  .servers-page{ max-width: 1620px; }
}

.servers-head{display:flex;align-items:flex-end;justify-content:space-between;gap:16px;margin-bottom:14px;}
.servers-title{margin:0;font-size:28px;letter-spacing:-.2px;color:var(--sh-text);}
.servers-sub{margin:6px 0 0;color:var(--sh-muted);}

.btn-add-server{
  display:inline-flex;align-items:center;gap:8px;text-decoration:none;
  padding:10px 14px;border-radius:12px;
  background:linear-gradient(135deg, rgba(59,130,246,.25), rgba(16,185,129,.18));
  border:1px solid var(--sh-bd);color:var(--sh-text);
  transition:transform .15s ease, filter .15s ease;
}
.btn-add-server:hover{transform:translateY(-1px);filter:brightness(1.02);}

/* ✅ Sekmeler: logo üstte, yazı altta, sağda adet */
.game-tabs{
  display:grid;
  grid-template-columns: repeat(auto-fill, minmax(170px, 1fr));
  gap:10px;
  padding:10px;
  border:1px solid var(--sh-bd);
  border-radius:18px;
  background:linear-gradient(135deg, var(--sh-card), var(--sh-card2));
  position:relative;
  overflow:hidden;
  margin-bottom:14px;
  backdrop-filter: blur(8px);
}
.game-tabs:before{
  content:"";
  position:absolute;inset:-2px;pointer-events:none;opacity:.35;
  background:
    radial-gradient(650px 250px at 18% 0%, var(--sh-glow), transparent 60%),
    radial-gradient(520px 220px at 92% 15%, rgba(255,56,255,.12), transparent 60%);
}
.game-tabs > *{position:relative}

.game-tab{
  border:1px solid var(--sh-bd);
  background:rgba(0,0,0,.02);
  color:var(--sh-text);
  padding:12px 12px 10px;
  border-radius:16px;
  cursor:pointer;
  display:grid;
  grid-template-columns: 1fr auto;
  grid-template-rows: auto auto;
  gap:10px;
  align-items:center;
  transition:transform .15s, border-color .15s, background .15s;
  text-align:left;
}
html[data-theme="dark"] .game-tab{background:rgba(255,255,255,.04);}
.game-tab:hover{transform:translateY(-1px); border-color:rgba(59,130,246,.45);}
.game-tab.is-active{
  background:linear-gradient(135deg, rgba(59,130,246,.22), rgba(16,185,129,.16));
  border-color:rgba(59,130,246,.55);
}

/* logo üstte büyük */
.gt-logoWrap{
  grid-column:1 / 2;
  grid-row:1 / 2;
  display:flex;
  align-items:center;
}
.gameLogo{
  height:34px;
  width:auto;
  display:block;
  filter: drop-shadow(0 10px 16px rgba(0,0,0,.12));
}

/* yazılar altta */
.gt-text{
  grid-column:1 / 2;
  grid-row:2 / 3;
  display:flex;
  flex-direction:column;
  gap:2px;
  min-width:0;
}
.gt-label{
  font-weight:800;
  font-size:13px;
  white-space:nowrap;
  overflow:hidden;
  text-overflow:ellipsis;
}
.gt-sub{font-size:12px;color:var(--sh-muted);}

/* adet sağ üstte */
.gt-count{
  grid-column:2 / 3;
  grid-row:1 / 2;
  justify-self:end;
  align-self:start;
  font-weight:800;
  font-size:12px;
  padding:4px 9px;
  border-radius:999px;
  border:1px solid rgba(59,130,246,.22);
  background:rgba(59,130,246,.10);
  color:var(--sh-text);
}

.servers-section{margin-top:16px;}
.servers-section-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;}
.servers-section-title{display:flex;align-items:center;gap:10px;margin:0;font-size:18px;color:var(--sh-text);}

.servers-cards-1col{display:flex;flex-direction:column;gap:12px;}

/* Cards */
.server-card{
  border:1px solid var(--sh-bd);
  border-radius:18px;
  background:linear-gradient(135deg, var(--sh-card), var(--sh-card2));
  position:relative;
  overflow:hidden;
  backdrop-filter: blur(10px);
}
.server-card:before{
  content:"";position:absolute;inset:-2px;opacity:.22;pointer-events:none;
  background:
    radial-gradient(600px 120px at 10% 0%, rgba(59,130,246,.45), transparent 60%),
    radial-gradient(600px 120px at 90% 100%, rgba(16,185,129,.35), transparent 60%);
}
.server-card-row{
  display:grid;
  grid-template-columns: clamp(460px, 46vw, 620px) 1fr;
  gap:0;
  overflow:hidden;
}
.server-banner{
  position:relative;
  height:220px;
  min-height:220px;
  overflow:hidden;
  background:rgba(0,0,0,.04);
}
.server-banner img{
  width:100%;
  height:100%;
  object-fit:cover;
  display:block;
  cursor: zoom-in;
  transition: transform .35s ease;
}
.server-card-row:hover .server-banner img{ transform: scale(1.04); }
.server-banner::after{
  content:""; position:absolute; inset:0;
  background: linear-gradient(to right, rgba(0,0,0,.18), rgba(0,0,0,.05));
  pointer-events:none;
}
.server-body{display:flex;flex-direction:column;gap:10px;padding:14px;}

.server-title{display:flex;align-items:center;justify-content:space-between;gap:10px;}
.server-title .name{font-weight:800;color:var(--sh-text);font-size:16px;}
.badge{font-size:12px;padding:4px 8px;border-radius:999px;border:1px solid rgba(16,185,129,.25);background:rgba(16,185,129,.12);color:var(--sh-text);}
.badge.ok{color:#10b981}
.server-short,.server-desc{color:var(--sh-muted);font-size:13px;line-height:1.55;}

.server-ip{display:flex;align-items:center;gap:8px;font-size:14px;color:var(--sh-text);}
.copy-btn{margin-left:auto;border:1px solid transparent;background:transparent;color:var(--sh-muted);cursor:pointer;border-radius:10px;padding:6px 8px;transition:background .15s,color .15s,border-color .15s,transform .15s;}
.copy-btn:hover{color:var(--sh-text);background:rgba(0,0,0,.04);border-color:rgba(59,130,246,.22);transform:translateY(-1px);}
html[data-theme="dark"] .copy-btn:hover{background:rgba(255,255,255,.05);}

.server-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:2px;}
.chip{display:inline-flex;align-items:center;gap:7px;padding:8px 10px;border-radius:999px;border:1px solid var(--sh-bd);background:rgba(0,0,0,.03);color:var(--sh-text);text-decoration:none;font-size:13px;transition:transform .15s,border-color .15s;}
html[data-theme="dark"] .chip{background:rgba(255,255,255,.04);}
.chip:hover{transform:translateY(-1px);border-color:rgba(59,130,246,.35);}

.servers-empty{display:flex;gap:12px;align-items:center;padding:18px;border:1px dashed var(--sh-bd);border-radius:16px;color:var(--sh-muted);}
.servers-empty i{font-size:26px;opacity:.7;}
.servers-empty .t{font-weight:700;color:var(--sh-text);}

@media (max-width: 900px){
  .server-card-row{grid-template-columns:1fr;}
  .server-banner{height:200px;min-height:200px;}
}
/* === PREMIUM CARD OVERRIDES (HTML DOKUNMADAN) === */

/* Kart yüzeyi + gölge */
.server-card{
  border-radius:20px;
  border:1px solid rgba(255,255,255,.10);
  background: linear-gradient(135deg, rgba(255,255,255,.55), rgba(255,255,255,.38));
  box-shadow:
    0 18px 60px rgba(0,0,0,.08),
    0 1px 0 rgba(255,255,255,.35) inset;
  transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease;
}
html[data-theme="dark"] .server-card{
  background: linear-gradient(135deg, rgba(20,24,33,.72), rgba(20,24,33,.52));
  border-color: rgba(255,255,255,.08);
  box-shadow:
    0 18px 65px rgba(0,0,0,.32),
    0 1px 0 rgba(255,255,255,.06) inset;
}

/* Gradient border efekti (çok hafif) */
.server-card::after{
  content:"";
  position:absolute;
  inset:0;
  border-radius:20px;
  padding:1px;
  background: linear-gradient(135deg,
    rgba(59,130,246,.45),
    rgba(16,185,129,.35),
    rgba(255,56,255,.18)
  );
  -webkit-mask:
    linear-gradient(#000 0 0) content-box,
    linear-gradient(#000 0 0);
  -webkit-mask-composite: xor;
  mask-composite: exclude;
  pointer-events:none;
  opacity:.55;
}
html[data-theme="dark"] .server-card::after{opacity:.42;}

.server-card:hover{
  transform: translateY(-2px);
  box-shadow:
    0 24px 75px rgba(0,0,0,.12),
    0 1px 0 rgba(255,255,255,.42) inset;
}
html[data-theme="dark"] .server-card:hover{
  box-shadow:
    0 26px 80px rgba(0,0,0,.38),
    0 1px 0 rgba(255,255,255,.07) inset;
}

/* Grid satırında “iç boşluk” hissi (banner tam yapışmasın) */
.server-card-row{
  gap:14px;
  padding:14px;
}
@media (max-width: 900px){
  .server-card-row{ padding:12px; gap:12px; }
}

/* Banner: kartın içinde duran premium blok */
.server-banner{
  border-radius:16px;
  border:1px solid rgba(255,255,255,.10);
  overflow:hidden;
  background: rgba(0,0,0,.03);
}
html[data-theme="dark"] .server-banner{
  border-color: rgba(255,255,255,.08);
  background: rgba(255,255,255,.03);
}
.server-banner::after{
  background: linear-gradient(to right, rgba(0,0,0,.20), rgba(0,0,0,.06));
}

/* Sağ taraf body padding’ini azalt (zaten card-row padding var) */
.server-body{ padding:0; }

/* Başlık satırı daha temiz */
.server-title .name{letter-spacing:-.1px;}
.badge{
  border-color: rgba(16,185,129,.22);
  background: rgba(16,185,129,.10);
}

/* IP satırı “pill” */
.server-ip{
  background: rgba(0,0,0,.03);
  border:1px solid rgba(59,130,246,.16);
  border-radius:14px;
  padding:9px 10px;
}
html[data-theme="dark"] .server-ip{
  background: rgba(255,255,255,.04);
  border-color: rgba(59,130,246,.18);
}

/* Copy butonunu pill’in içine yakıştır */
.copy-btn{
  background: rgba(0,0,0,.02);
  border:1px solid rgba(255,255,255,.0);
}
.copy-btn:hover{
  background: rgba(59,130,246,.10);
  border-color: rgba(59,130,246,.22);
}

/* Chip’ler daha “button” hissi */
.chip{
  border-radius:14px;
  background: rgba(0,0,0,.02);
}
html[data-theme="dark"] .chip{background: rgba(255,255,255,.03);}
.chip:hover{
  border-color: rgba(16,185,129,.28);
  transform: translateY(-1px);
}
/* Mini linkler (ikon + yazı) */
.server-actions{
  display:flex;
  flex-wrap:wrap;
  gap:8px;
  margin-top:4px;
  justify-content:flex-start; /* istersen flex-end yap */
}

.server-link-mini{
  display:inline-flex;
  align-items:center;
  gap:6px;
  padding:6px 10px;
  border-radius:12px;
  text-decoration:none;
  font-size:12px;
  color:var(--sh-text);
  border:1px solid rgba(59,130,246,.18);
  background:rgba(0,0,0,.02);
  transition:transform .15s ease, border-color .15s ease, background .15s ease;
}

html[data-theme="dark"] .server-link-mini{
  background:rgba(255,255,255,.03);
  border-color:rgba(59,130,246,.20);
}

.server-link-mini i{
  font-size:14px; /* küçük ikon */
  opacity:.95;
}

.server-link-mini:hover{
  transform:translateY(-1px);
  border-color:rgba(16,185,129,.28);
  background:rgba(16,185,129,.06);
}
body{
  font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial,
               "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji", sans-serif;
}

</style>

<!-- Banner modal -->
<div class="modal fade" id="serverBannerModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-xl">
    <div class="modal-content" style="background:transparent;border:none;">
      <button type="button" class="btn-close ms-auto me-2 mt-2" data-bs-dismiss="modal" aria-label="Close" style="filter: invert(1);"></button>
      <img id="serverBannerModalImg" src="" alt="Banner" style="width:100%;height:auto;border-radius:18px;box-shadow:0 25px 80px rgba(0,0,0,.45);">
    </div>
  </div>
</div>

<script>
(function(){
  // Tabs filter
  var tabs = document.querySelectorAll('.game-tab');
  var sections = document.querySelectorAll('[data-game-section]');
  var emptyTab = document.getElementById('serversEmptyTab');

  function setActive(slug){
    tabs.forEach(function(t){
      var on = (t.getAttribute('data-game') === slug);
      t.classList.toggle('is-active', on);
      t.setAttribute('aria-selected', on ? 'true' : 'false');
    });

    var found = false;
    sections.forEach(function(s){
      var show = (s.getAttribute('data-game-section') === slug);
      s.style.display = show ? '' : 'none';
      if(show) found = true;
    });

    if(emptyTab) emptyTab.style.display = found ? 'none' : '';
  }

  tabs.forEach(function(btn){
    btn.addEventListener('click', function(){
      setActive(this.getAttribute('data-game'));
    });
  });

  // Copy IP
  document.querySelectorAll('.copy-btn').forEach(function(btn){
    btn.addEventListener('click', function(){
      var text = this.getAttribute('data-copy') || '';
      if(!text) return;
      var self = this;
      navigator.clipboard.writeText(text).then(function(){
        self.innerHTML = '<i class="ri-check-line"></i>';
        setTimeout(function(){ self.innerHTML = '<i class="ri-file-copy-line"></i>'; }, 900);
      }).catch(function(){});
    });
  });

  // banner img'lerine tıklayınca modal aç
  document.querySelectorAll('.server-card-row .server-banner img').forEach(function(img){
    img.addEventListener('click', function(){
      var src = this.getAttribute('src');
      if(!src) return;
      document.getElementById('serverBannerModalImg').src = src;
      var m = new bootstrap.Modal(document.getElementById('serverBannerModal'));
      m.show();
    });
  });

  // ✅ Dark/Light tema: senin ana sayfadaki gameLogo mantığı
  function applyGameLogoTheme(){
    var dark = (document.documentElement.getAttribute('data-theme') === 'dark');
    document.querySelectorAll('.gameLogo').forEach(function(img){
      var s = dark ? img.getAttribute('data-dark') : img.getAttribute('data-light');
      if(s) img.setAttribute('src', s);
    });
  }
  applyGameLogoTheme();

  // Tema değişimini yakala (attribute değişirse otomatik günceller)
  var obs = new MutationObserver(function(muts){
    for (var i=0;i<muts.length;i++){
      if(muts[i].attributeName === 'data-theme'){ applyGameLogoTheme(); break; }
    }
  });
  obs.observe(document.documentElement, { attributes:true });

})();
</script>
