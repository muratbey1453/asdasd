<section class="fp-section">
  <div class="container">
    <div class="card-like" style="padding:16px;">
      <h1 style="margin:0;font-weight:950;">Sunucuya Yeni Ürün Oluştur</h1>
      <div style="opacity:.75;font-weight:800;margin-top:6px;">
        Sunucu: <strong><?= html_escape($server->title) ?></strong>
      </div>

      <hr style="opacity:.15">

      <form action="<?= base_url('sunucular/urun-ekle/'.(int)$server->id.'/kaydet') ?>"
            method="post" enctype="multipart/form-data">
        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>"
               value="<?= $this->security->get_csrf_hash(); ?>">

        <div class="mb-3">
          <label class="form-label" style="font-weight:900;">Başlık</label>
          <input type="text" name="name" class="form-control" required maxlength="120" placeholder="Örn: Metin2 2000 EP">
        </div>

        <div class="mb-3">
          <label class="form-label" style="font-weight:900;">Fiyat (TL)</label>
          <input type="number" name="price" class="form-control" required step="0.01" min="0" placeholder="Örn: 199.90">
        </div>

        <div class="mb-3 sp-upload">
          <label class="form-label" style="font-weight:900;">Ürün Görselleri</label>
          <input type="file" name="imgs[]" class="form-control" required multiple accept=".jpg,.jpeg,.png,.webp">
          <small class="text-muted">En az 1, en fazla 8 görsel. Öneri: 800x800 / webp</small>

          <div id="spPreview" class="sp-preview" style="margin-top:10px;"></div>
        </div>

        <style>
          .sp-preview{ display:flex; gap:10px; flex-wrap:wrap; }
          .sp-preview .sp-thumb{
            width: 86px; height: 66px;
            border-radius: 12px;
            overflow:hidden;
            border: 1px solid rgba(0,0,0,.10);
            background: rgba(0,0,0,.04);
          }
          html[data-theme="dark"] .sp-preview .sp-thumb{
            border-color: rgba(255,255,255,.12);
            background: rgba(0,0,0,.18);
          }
          .sp-preview img{ width:100%; height:100%; object-fit:cover; display:block; }
        </style>

        <script>
          (function(){
            const input = document.querySelector('input[name="imgs[]"]');
            const wrap = document.getElementById('spPreview');
            if(!input || !wrap) return;

            input.addEventListener('change', function(){
              wrap.innerHTML = '';
              const files = Array.from(input.files || []);
              files.slice(0, 8).forEach(f=>{
                if(!f.type || !f.type.startsWith('image/')) return;
                const url = URL.createObjectURL(f);
                const div = document.createElement('div');
                div.className = 'sp-thumb';
                div.innerHTML = '<img alt="preview">';
                div.querySelector('img').src = url;
                wrap.appendChild(div);
              });
            });
          })();
        </script>

        <div class="mb-3">
          <label class="form-label" style="font-weight:900;">Açıklama (opsiyonel)</label>
          <textarea name="description" class="form-control" rows="4" maxlength="2000"
                    placeholder="Ürün detayları..."></textarea>
        </div>

        <button type="submit" class="btn btn-primary">
          <i class="ri-add-line"></i> Ürünü Oluştur
        </button>

        <a href="<?= base_url('sunucular/detay/'.(int)$server->id).'#sunucu-urunleri' ?>"
           class="btn btn-light ms-2">Geri</a>
      </form>
    </div>
  </div>
</section>
