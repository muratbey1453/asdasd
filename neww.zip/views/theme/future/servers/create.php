<?php
$game_options = isset($game_options) && is_array($game_options) ? $game_options : [];
?>

<div class="fp-container" style="padding: 24px 0;">
  <div class="server-add-wrap">
    <div class="server-add-card">
      <div class="head">
        <h1>Sunucu Ekle</h1>
        <p>Bilgileri doldur, admin onayından sonra listede yayınlanır.</p>
      </div>

      <form action="<?= base_url('client/sunucu-ekle/kaydet') ?>" method="post" enctype="multipart/form-data">

  <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">


        <div class="row">
          <label>Oyun</label>
          <select name="game" required>
            <option value="">Seçiniz</option>
            <?php foreach($game_options as $slug => $label): ?>
              <option value="<?= htmlspecialchars($slug) ?>"><?= htmlspecialchars($label) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="row">
          <label>Sunucu Adı</label>
          <input type="text" name="title" required minlength="3" maxlength="80" placeholder="Örn: Orion2 PVP" />
        </div>

        <div class="row">
          <label>IP / Host</label>
          <input type="text" name="ip" required minlength="3" maxlength="120" placeholder="Örn: play.server.com" />
        </div>

        <div class="grid">
          <div class="row">
            <label>Website (opsiyonel)</label>
            <input type="url" name="website" placeholder="https://..." />
          </div>
          <div class="row">
            <label>Discord (opsiyonel)</label>
            <input type="text" name="discord" placeholder="discord.gg/..." />
          </div>
        </div>
<div class="col-lg-6">
    <label class="form-label">Sunucu Banner (opsiyonel)</label>
    <input type="file" name="banner" class="form-control" accept=".jpg,.jpeg,.png,.webp">
    <small class="text-muted">Öneri: 600x300 / webp-jpg-png</small>
  </div>

        <div class="row">
          <label>Açıklama (opsiyonel)</label>
          <textarea name="description" rows="4" maxlength="800" placeholder="Kısa bilgi, oranlar, özellikler..."></textarea>
        </div>

        <button class="btn-submit" type="submit">
          <i class="ri-send-plane-line"></i>
          <span>Gönder</span>
        </button>
      </form>
    </div>
  </div>
</div>

<style>
.server-add-wrap{max-width:760px;margin:0 auto;}
.server-add-card{border:1px solid var(--border);background:var(--bg-white);border-radius:18px;padding:18px;}
html[data-theme="dark"] .server-add-card{background:rgba(255,255,255,.03);} 
.server-add-card .head h1{margin:0;font-size:24px;}
.server-add-card .head p{margin:8px 0 0;color:var(--text-gray);} 

.form{margin-top:16px;display:flex;flex-direction:column;gap:12px;}
.row{display:flex;flex-direction:column;gap:8px;}
label{font-size:13px;color:var(--text-gray);} 
input,select,textarea{border:1px solid var(--border);border-radius:12px;padding:12px 12px;background:var(--background);color:var(--text-color);outline:none;}
input:focus,select:focus,textarea:focus{border-color:rgba(59,130,246,.65);box-shadow:0 0 0 3px rgba(59,130,246,.12);} 
.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
@media (max-width:720px){.grid{grid-template-columns:1fr;}}

.btn-submit{border:none;border-radius:14px;padding:12px 14px;display:flex;align-items:center;justify-content:center;gap:8px;
  background:linear-gradient(135deg, rgba(59,130,246,.32), rgba(16,185,129,.22));
  color:var(--text-color);border:1px solid var(--border);cursor:pointer;
}
.btn-submit:hover{transform:translateY(-1px);} 
</style>
