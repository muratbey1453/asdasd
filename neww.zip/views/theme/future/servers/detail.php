<section class="fp-section-blog-page blog-page-v2">
  <div class="container">

    <!-- Breadcrumb -->
    <nav class="blog-breadcrumb-v2" aria-label="breadcrumb">
      <ol class="blog-breadcrumb-list">
        <li class="blog-bc-item">
          <a href="<?= base_url() ?>" class="blog-bc-link"><i class="ri-home-4-line"></i> Ana Sayfa</a>
        </li>

        <li class="blog-bc-sep"><i class="ri-arrow-right-s-line"></i></li>

        <li class="blog-bc-item">
          <a href="<?= base_url('sunucular') ?>" class="blog-bc-link">Sunucular</a>
        </li>

        <li class="blog-bc-sep"><i class="ri-arrow-right-s-line"></i></li>

        <li class="blog-bc-item blog-bc-current" aria-current="page">
          <?= html_escape($server->title) ?>
        </li>
      </ol>
    </nav>

    <!-- HERO (blog gibi) -->
    <?php
// Albüm görselleri (şimdilik banner + ileride gallery ekleyebilirsin)
$bannerUrl = !empty($server->banner)
  ? base_url('assets/img/servers/' . $server->banner)
  : base_url('assets/img/server_banners/default.webp');

$images = [$bannerUrl];

// opsiyonel: DB'ye gallery (json) eklersen otomatik alır
if (!empty($server->gallery)) {
  $g = json_decode($server->gallery, true);
  if (is_array($g)) {
    foreach ($g as $img) {
      $images[] = base_url('assets/img/servers/' . ltrim($img, '/'));
    }
  }
}

$images = array_values(array_unique(array_filter($images)));
$likesCount = (int)($server->likes_count ?? 0);
?>

<div class="server-hero-v3 card-like">
  <div class="hero-grid">

    <!-- LEFT: Album -->
    <div class="hero-media">
      <a class="hero-main" href="<?= html_escape($images[0]) ?>" target="_blank" rel="noopener">
        <img id="heroMainImg" src="<?= html_escape($images[0]) ?>" alt="<?= html_escape($server->title) ?>">
        <span class="hero-zoom"><i class="ri-zoom-in-line"></i></span>
      </a>

      <div class="hero-thumbs" role="list">
        <?php foreach ($images as $i => $img): ?>
          <button type="button"
                  class="thumb <?= $i === 0 ? 'active' : '' ?>"
                  data-src="<?= html_escape($img) ?>"
                  aria-label="Görsel <?= $i+1 ?>">
            <img src="<?= html_escape($img) ?>" alt="thumb <?= $i+1 ?>">
          </button>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- RIGHT: Info -->
    <div class="hero-info">
      <div class="hero-head">
        <h1 class="hero-title"><?= html_escape($server->title) ?></h1>

        <div class="hero-chips">
          <span class="chip"><i class="ri-gamepad-line"></i> <?= html_escape($games[$server->game] ?? $server->game) ?></span>
          <span class="chip chip-ok"><i class="ri-verified-badge-line"></i> Onaylı</span>
        </div>
      </div>

      <!-- IP / Website / Discord: ip gibi uzun satırlar -->
      <div class="hero-rows">
        <div class="hero-row">
          <div class="row-label"><i class="ri-navigation-line"></i> IP Adresi</div>
          <div class="row-value"><?= html_escape($server->ip) ?></div>
          <button class="row-btn" type="button" data-copy="<?= html_escape($server->ip) ?>">
            <i class="ri-file-copy-line"></i> Kopyala
          </button>
        </div>

        <?php if (!empty($server->website)): ?>
          <div class="hero-row">
            <div class="row-label"><i class="ri-global-line"></i> Website</div>
            <div class="row-value">
              <a href="<?= html_escape($server->website) ?>" target="_blank" rel="nofollow">
                <?= html_escape($server->website) ?>
              </a>
            </div>
            <div class="row-actions">
              <a class="row-btn" href="<?= html_escape($server->website) ?>" target="_blank" rel="nofollow">
                <i class="ri-external-link-line"></i> Aç
              </a>
              <button class="row-btn" type="button" data-copy="<?= html_escape($server->website) ?>">
                <i class="ri-file-copy-line"></i> Kopyala
              </button>
            </div>
          </div>
        <?php endif; ?>

        <?php if (!empty($server->discord)): ?>
          <div class="hero-row">
            <div class="row-label"><i class="ri-discord-line"></i> Discord</div>
            <div class="row-value">
              <a href="<?= html_escape($server->discord) ?>" target="_blank" rel="nofollow">
                <?= html_escape($server->discord) ?>
              </a>
            </div>
            <div class="row-actions">
              <a class="row-btn row-btn-primary" href="<?= html_escape($server->discord) ?>" target="_blank" rel="nofollow">
                <i class="ri-discord-line"></i> Katıl
              </a>
              <button class="row-btn" type="button" data-copy="<?= html_escape($server->discord) ?>">
                <i class="ri-file-copy-line"></i> Kopyala
              </button>
            </div>
          </div>
        <?php endif; ?>
      </div>

      <!-- Like -->
      <div class="hero-foot">
        <button class="like-btn"
                type="button"
                data-like-url="<?= site_url('sunucular/begen/' . (int)$server->id) ?>"
                data-like-key="server_like_<?= (int)$server->id ?>">
          <i class="ri-heart-3-line"></i>
          <span>Beğen</span>
          <span class="like-count" id="likeCount"><?= $likesCount ?></span>
        </button>

        <div class="hero-hint">
          <i class="ri-information-line"></i> IP’yi kopyalayıp oyunda hızlıca bağlanabilirsin.
        </div>
      </div>

    </div>
  </div>
</div>

    <!-- CONTENT (blog body gibi) -->
    <div class="blog-body card-like">

      

      <div class="fp-blog-content blog-content" id="serverContent">
        <?php if (!empty($server->short_desc)): ?>
          <div class="server-lead">
            <?= nl2br(html_escape($server->short_desc)) ?>
          </div>
        <?php endif; ?>

        <?php if (!empty($server->description)): ?>
          <div class="server-desc-long">
            <?= nl2br(html_escape($server->description)) ?>
          </div>
        <?php else: ?>
          <div class="server-desc-long" style="opacity:.8">
            Bu sunucu için henüz detaylı açıklama eklenmemiş.
          </div>
        <?php endif; ?>
      </div>

    </div>

  </div>
  
</section>
<section class="fp-section" id="sunucu-urunleri">
  <div class="container">
    <div class="card-like" style="padding:16px;">
      <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
        <h2 style="margin:0;font-weight:950;">Sunucu Ürünleri</h2>

      <?php $isLogged = !empty($this->session->userdata('info')); ?>

<?php if ($isLogged): ?>
  <a class="btn btn-primary" href="<?= base_url('sunucular/urun-ekle/'.(int)$server->id) ?>">
    <i class="ri-add-line"></i> Ürün Ekle
  </a>
<?php else: ?>
  <a class="btn btn-light" href="<?= base_url('hesap') ?>">
    <i class="ri-login-circle-line"></i> Giriş Yap
  </a>
<?php endif; ?>

      </div>

      <div style="opacity:.75;font-weight:800;margin-top:6px;">
        Sadece admin onaylı ürünler burada görünür.
      </div>

      <hr style="opacity:.15">

      <div class="row g-3 server-products-grid">
        <?php if (empty($serverProducts)): ?>
          <div class="col-12">
            <div class="alert alert-info text-center">
              <i class="ri-information-line fs-1"></i>
              <h4 class="mt-2">Ürün Bulunamadı</h4>
              <p>Bu sunucu için onaylı ürün bulunamadı.</p>
            </div>
          </div>
        <?php else: ?>
          <?php foreach ($serverProducts as $p): ?>
            <div class="col-6 col-md-4 col-lg-3">
              <div class="fp-product-item marketplace-item">
                <div style="position: relative;">
                  <a class="img-container" href="<?= base_url($p->slug) ?>">
                    <img src="<?= base_url('assets/img/product/') . $p->img ?>" class="img-product img-aspect" alt="">
                  </a>

                  <?php
                    $seller = null;
                    if ((int)$p->seller_id > 0) {
                      $seller = $this->db->where('id', (int)$p->seller_id)->get('user')->row();
                    }
                  ?>

                  <?php if ($seller && !empty($seller->name)): ?>
                    <div onclick="window.location.href='<?= base_url('magaza/') . $seller->shop_slug ?>'"
                         class="seller-badge-overlay" style="bottom: 10px !important; cursor: pointer;">
                      <?php if (!empty($seller->shop_img)): ?>
                        <img src="<?= base_url('assets/img/shop/') . $seller->shop_img ?>" class="shop-avatar" alt="">
                      <?php else: ?>
                        <i class="ri-user-3-line"></i>
                      <?php endif; ?>
                      <span><?= $seller->shop_name ? $seller->shop_name : ($seller->name . ' ' . $seller->surname) ?></span>
                    </div>
                  <?php else: ?>
                    <div class="seller-badge-overlay official" style="bottom: 10px !important;">
                      <i class="ri-shield-check-line"></i>
                      <span>Resmi</span>
                    </div>
                  <?php endif; ?>
                </div>

                <div class="content">
                  <a class="product-name" href="<?= base_url($p->slug) ?>"><?= html_escape($p->name) ?></a>
                  <div class="price">
                    <?php $price = json_decode(calculatePrice($p->id, 1), true); ?>
                    <?php if (!empty($price['isDiscount'])): ?>
                      <div class="price-new"><?= $price['price'] ?> TL</div>
                      <div class="price-old"><?= $price['normalPrice'] ?> TL</div>
                    <?php else: ?>
                      <div class="price-new"><?= $price['price'] ?> TL</div>
                    <?php endif; ?>
                  </div>
                </div>

              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>

      <?php if (!empty($serverProducts) && !empty($serverProductsTotal) && $serverProductsTotal > 8): ?>
        <div class="mt-4">
          <?= $this->pagination->create_links(); ?>
        </div>
      <?php endif; ?>

    </div>
  </div>
</section>


<style>
  /* ===== Similar Servers Marketplace Slider ===== */
.rel-market{ margin: 14px 0 14px; }
.rel-head{
  display:flex; align-items:flex-end; justify-content:space-between;
  gap:12px; margin-bottom: 12px; flex-wrap:wrap;
}
.rel-title{
  margin:0; font-weight: 950; color:#fff;
  display:flex; align-items:center; gap:10px; font-size: 18px;
}
.rel-sub{ color: rgba(255,255,255,.65); font-weight: 800; margin-top: 6px; }

.rel-nav{ display:flex; align-items:center; gap:10px; }
.rel-btn{
  width: 40px; height: 40px; border-radius: 14px;
  border: 1px solid rgba(255,255,255,.12);
  background: rgba(0,0,0,.18);
  color:#fff;
  display:flex; align-items:center; justify-content:center;
  transition:.18s ease;
}
.rel-btn:hover{ transform: translateY(-1px); filter: brightness(1.06); }

.rel-all{
  text-decoration:none; color: rgba(255,255,255,.75);
  font-weight: 950; font-size: 13px;
  display:inline-flex; align-items:center; gap:6px;
  padding: 10px 12px; border-radius: 14px;
  border: 1px solid rgba(255,255,255,.12);
  background: rgba(255,255,255,.06);
}
.rel-all:hover{ color:#fff; transform: translateY(-1px); }

.rel-swiper{ padding: 4px 2px 10px; }
.rel-card2{ overflow:hidden; border-radius: 18px; height: 100%; }

.rel-thumb2{
  display:block; position:relative;
  height: 170px; overflow:hidden;
  border-bottom: 1px solid rgba(255,255,255,.10);
}
.rel-thumb2 img{ width:100%; height:100%; object-fit: cover; display:block; transform: scale(1.01); }

.rel-badges{
  position:absolute; left: 10px; right: 10px; bottom: 10px;
  display:flex; justify-content:space-between; gap:10px;
}
.rel-pill{
  display:inline-flex; align-items:center; gap:8px;
  padding: 7px 10px; border-radius: 999px;
  border: 1px solid rgba(255,255,255,.12);
  background: rgba(0,0,0,.35);
  color:#fff; font-weight: 950; font-size: 12.5px;
  backdrop-filter: blur(10px);
}
.rel-pill-like{ border-color: rgba(239,68,68,.25); }

.rel-body2{ padding: 12px; }
.rel-name2{
  display:block; text-decoration:none;
  color:#fff; font-weight: 950; font-size: 14px;
  line-height: 1.25;
  margin-bottom: 8px;
}
.rel-ip2{
  display:flex; align-items:center; gap:8px;
  color: rgba(255,255,255,.75);
  font-weight: 900; font-size: 13px;
  margin-bottom: 8px;
  word-break: break-word;
}
.rel-desc2{ color: rgba(255,255,255,.72); font-weight: 800; font-size: 13px; line-height: 1.45; min-height: 38px; }

.rel-actions2{
  margin-top: 10px;
  display:flex; gap:10px; flex-wrap:wrap;
}
.rel-act{
  display:inline-flex; align-items:center; gap:8px;
  padding: 10px 12px; border-radius: 14px;
  border: 1px solid rgba(255,255,255,.12);
  background: rgba(255,255,255,.06);
  color:#fff; font-weight: 950; font-size: 13px;
  text-decoration:none;
  transition:.18s ease;
}
.rel-act:hover{ transform: translateY(-1px); filter: brightness(1.06); }
.rel-copy{ background: rgba(0,0,0,.18); }
.rel-detail{ background: rgba(34,197,94,.12); border-color: rgba(34,197,94,.22); }

.rel-mini{
  margin-top: 10px;
  display:flex; gap:10px;
}
.mini-ic{
  width: 40px; height: 40px;
  border-radius: 14px;
  display:flex; align-items:center; justify-content:center;
  border: 1px solid rgba(255,255,255,.12);
  background: rgba(0,0,0,.18);
  color:#fff; text-decoration:none;
  transition:.18s ease;
}
.mini-ic:hover{ transform: translateY(-1px); filter: brightness(1.06); }

/* Light mode */
html[data-theme="light"] .rel-title{ color:#0f172a; }
html[data-theme="light"] .rel-sub{ color:#475569; }
html[data-theme="light"] .rel-btn,
html[data-theme="light"] .rel-all,
html[data-theme="light"] .rel-act,
html[data-theme="light"] .mini-ic{
  background:#fff;
  border:1px solid rgba(0,0,0,.10);
  color:#0f172a;
}
html[data-theme="light"] .rel-ip2,
html[data-theme="light"] .rel-desc2{ color:#475569; }

/* Blog görünümünü aynen kullanıyoruz (blog.php’deki CSS zaten güzel).
   Ek olarak hero butonları + cover zoom */
.server-hero-actions{
  margin-top: 14px;
  display:flex;
  gap:10px;
  flex-wrap:wrap;
  position: relative;
  z-index: 1;
}
.hero-btn{
  display:inline-flex;
  align-items:center;
  gap:8px;
  text-decoration:none;
  padding:10px 12px;
  border-radius:12px;
  border:1px solid rgba(255,255,255,.10);
  background: rgba(0,0,0,.18);
  color:#fff;
  font-weight:800;
  font-size:13px;
  transition:.18s ease;
}
html[data-theme="light"] .hero-btn{
  background:#fff;
  border:1px solid rgba(0,0,0,.10);
  color:#0f172a;
}
.hero-btn:hover{ transform: translateY(-1px); filter: brightness(1.05); }

.server-lead{
  padding: 12px 14px;
  border-radius: 14px;
  background: rgba(255,255,255,.06);
  border: 1px solid rgba(255,255,255,.10);
  margin-bottom: 12px;
  font-weight: 800;
}
html[data-theme="light"] .server-lead{
  background:#fff;
  border:1px solid rgba(0,0,0,.10);
}

.cover-zoom{ display:block; }
.cover-zoom img{ transition: transform .25s ease; }
.cover-zoom:hover img{ transform: scale(1.02); }
  /* Breadcrumb v2 (dark/light uyumlu) */
.blog-breadcrumb-v2{
  margin: 10px 0 18px;
}

.blog-breadcrumb-list{
  list-style: none;
  padding: 10px 12px;
  margin: 0;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;

  border-radius: 14px;
  border: 1px solid rgba(255,255,255,.10);
  background: rgba(255,255,255,.06);
  backdrop-filter: blur(10px);
}

.blog-bc-link{
  display: inline-flex;
  align-items: center;
  gap: 6px;
  text-decoration: none;

  font-weight: 800;
  font-size: 13px;

  color: rgba(255,255,255,.78);
  transition: .18s ease;
}

.blog-bc-link:hover{
  color: rgba(255,255,255,1);
  transform: translateY(-1px);
}

.blog-bc-sep{
  color: rgba(255,255,255,.35);
  display: inline-flex;
  align-items: center;
}

.blog-bc-current{
  font-weight: 900;
  font-size: 13px;
  color: #fff;
  max-width: 520px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* LIGHT MODE */
html[data-theme="light"] .blog-breadcrumb-list{
  background: #fff;
  border: 1px solid rgba(0,0,0,.10);
  backdrop-filter: none;
}

html[data-theme="light"] .blog-bc-link{
  color: #475569; /* okunur */
}

html[data-theme="light"] .blog-bc-link:hover{
  color: #0f172a;
}

html[data-theme="light"] .blog-bc-sep{
  color: rgba(0,0,0,.35);
}

html[data-theme="light"] .blog-bc-current{
  color: #0f172a;
}

/* =========================
   BLOG PAGE – DARK BASE
   ========================= */
.blog-page-v2{ padding: 30px 0 60px; }

.blog-breadcrumb .link{ color: rgba(255,255,255,.75) !important; }
.blog-breadcrumb .link.active{ color:#fff !important; font-weight:700; }

.card-like{
    background: rgba(255,255,255,.06);
    border: 1px solid rgba(255,255,255,.10);
    border-radius: 18px;
    backdrop-filter: blur(10px);
    box-shadow: 0 18px 60px rgba(0,0,0,.35);
}

.blog-hero{
    padding: 22px;
    margin-bottom: 14px;
    position: relative;
    overflow: hidden;
}
.blog-hero::before{
    content:"";
    position:absolute;
    inset:0;
    background:
        radial-gradient(circle at 20% 0%, rgba(239,68,68,.18), transparent 45%),
        radial-gradient(circle at 85% 20%, rgba(34,197,94,.14), transparent 40%);
    pointer-events:none;
}

.blog-title{
    color:#fff;
    font-weight: 900;
    letter-spacing: -.3px;
    line-height: 1.1;
    font-size: 34px;
    margin-bottom: 10px;
    position: relative;
    z-index: 1;
}

.blog-meta{
    display:flex;
    gap: 14px;
    flex-wrap: wrap;
    position: relative;
    z-index: 1;
}
.blog-meta .text{
    color: rgba(255,255,255,.70);
    font-size: 13px;
    display:flex;
    align-items:center;
    gap: 6px;
    padding: 6px 10px;
    border-radius: 999px;
    background: rgba(0,0,0,.18);
    border: 1px solid rgba(255,255,255,.08);
}
.blog-meta i{ color: rgba(255,255,255,.85); }

/* Share */
.blog-share{
    margin-top: 14px;
    display:flex;
    align-items:center;
    gap: 10px;
    flex-wrap: wrap;
    position: relative;
    z-index: 1;
}
.share-label{
    color: rgba(255,255,255,.70);
    font-size: 13px;
    font-weight: 700;
}
.share-btn{
    width: 38px;
    height: 38px;
    border-radius: 12px;
    display:flex;
    align-items:center;
    justify-content:center;
    border: 1px solid rgba(255,255,255,.10);
    background: rgba(0,0,0,.18);
    color:#fff;
    text-decoration:none;
    transition: .2s ease;
}
.share-btn:hover{
    transform: translateY(-1px);
    border-color: rgba(255,255,255,.18);
    background: rgba(0,0,0,.30);
}

/* Content body */
.blog-body{ padding: 16px; }

.blog-cover{
    border-radius: 14px;
    overflow:hidden;
    border: 1px solid rgba(255,255,255,.10);
    box-shadow: 0 18px 50px rgba(0,0,0,.35);
    margin-bottom: 16px;
}
.blog-cover img{
    width:100%;
    height:auto;
    display:block;
    transform: scale(1.01);
}

.blog-content{
    color: rgba(255,255,255,.85);
    font-size: 16px;
    line-height: 1.85;
    padding: 4px 6px 10px;
}
.blog-content h2{ color:#fff; font-size: 24px; font-weight: 900; margin: 28px 0 12px; }
.blog-content h3{ color:#fff; font-size: 20px; font-weight: 800; margin: 22px 0 10px; }
.blog-content p{ margin-bottom: 14px; }
.blog-content a{ color:#f59e0b; text-decoration: underline; text-underline-offset: 3px; }
.blog-content img{
    max-width:100%;
    border-radius: 12px;
    border: 1px solid rgba(255,255,255,.10);
    box-shadow: 0 16px 40px rgba(0,0,0,.30);
    margin: 14px 0;
}

/* Related */
.related-wrap{
  margin-top: 28px;
  padding: 16px;
  border-radius: 18px;
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(255,255,255,.08);
  backdrop-filter: blur(10px);
}
.related-head{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap: 12px;
  margin-bottom: 12px;
}
.related-title{
  margin:0;
  color:#fff;
  font-weight: 900;
  font-size: 18px;
  display:flex;
  align-items:center;
  gap: 8px;
}
.related-title i{ color:#f59e0b; }
.related-link{
  color: rgba(255,255,255,.75);
  text-decoration:none;
  font-weight: 800;
  font-size: 13px;
  display:flex;
  align-items:center;
  gap:6px;
}
.related-link:hover{ color:#fff; }

.related-card{
  display:block;
  text-decoration:none;
  border-radius: 16px;
  overflow:hidden;
  background: rgba(0,0,0,.18);
  border: 1px solid rgba(255,255,255,.08);
  transition: .22s ease;
  height: 100%;
}
.related-card:hover{
  transform: translateY(-2px);
  border-color: rgba(255,255,255,.16);
  box-shadow: 0 18px 45px rgba(0,0,0,.35);
}
.related-thumb{ height: 150px; overflow:hidden; }
.related-thumb img{ width:100%; height:100%; object-fit: cover; display:block; }
.related-body{ padding: 12px 12px 14px; }
.related-date{ color: rgba(255,255,255,.65); font-size: 12px; display:flex; align-items:center; gap: 6px; margin-bottom: 6px; }
.related-name{ color:#fff; font-weight: 900; font-size: 14px; line-height: 1.35; min-height: 40px; }
.related-cta{ margin-top: 10px; color:#22c55e; font-weight: 900; font-size: 13px; display:flex; align-items:center; gap: 6px; }

.related-empty{
  padding: 12px 10px;
  border-radius: 12px;
  background: rgba(0,0,0,.18);
  border: 1px dashed rgba(255,255,255,.15);
  color: rgba(255,255,255,.80);
}

/* Responsive */
@media (max-width: 768px){
  .blog-title{ font-size: 26px; }
  .blog-body{ padding: 12px; }
  .blog-content{ font-size: 15px; line-height: 1.75; }
}

/* =========================
   LIGHT MODE FIX
   hem html hem body destek
   ========================= */
html[data-theme="light"] .blog-page-v2 .card-like,
body[data-theme="light"] .blog-page-v2 .card-like,
html[data-theme="light"] .blog-page-v2 .related-card,
body[data-theme="light"] .blog-page-v2 .related-card{
  background:#ffffff !important;
  border:1px solid rgba(0,0,0,.10) !important;
  box-shadow:0 18px 60px rgba(0,0,0,.10) !important;
  backdrop-filter:none !important;
}

html[data-theme="light"] .blog-page-v2 .blog-title,
body[data-theme="light"] .blog-page-v2 .blog-title,
html[data-theme="light"] .blog-page-v2 .related-title,
body[data-theme="light"] .blog-page-v2 .related-title,
html[data-theme="light"] .blog-page-v2 .related-name,
body[data-theme="light"] .blog-page-v2 .related-name,
html[data-theme="light"] .blog-page-v2 .blog-content h2,
body[data-theme="light"] .blog-page-v2 .blog-content h2,
html[data-theme="light"] .blog-page-v2 .blog-content h3,
body[data-theme="light"] .blog-page-v2 .blog-content h3{
  color:#0f172a !important;
}

html[data-theme="light"] .blog-page-v2 .blog-content,
body[data-theme="light"] .blog-page-v2 .blog-content{
  color:#111827 !important;
}
html[data-theme="light"] .blog-page-v2 .blog-content * ,
body[data-theme="light"] .blog-page-v2 .blog-content * {
  color: inherit !important;
}

html[data-theme="light"] .blog-page-v2 .blog-content a,
body[data-theme="light"] .blog-page-v2 .blog-content a{
  color:#d97706 !important;
}

html[data-theme="light"] .blog-page-v2 .blog-meta .text,
body[data-theme="light"] .blog-page-v2 .blog-meta .text{
  color:#334155 !important;
  background:rgba(0,0,0,.03) !important;
  border:1px solid rgba(0,0,0,.08) !important;
}

html[data-theme="light"] .blog-page-v2 .related-wrap,
body[data-theme="light"] .blog-page-v2 .related-wrap{
  background:rgba(0,0,0,.02) !important;
  border:1px solid rgba(0,0,0,.08) !important;
}

html[data-theme="light"] .blog-page-v2 .related-date,
body[data-theme="light"] .blog-page-v2 .related-date,
html[data-theme="light"] .blog-page-v2 .blog-meta i,
body[data-theme="light"] .blog-page-v2 .blog-meta i,
html[data-theme="light"] .blog-page-v2 .share-label,
body[data-theme="light"] .blog-page-v2 .share-label{
  color:#64748b !important;
}

html[data-theme="light"] .blog-page-v2 .share-btn,
body[data-theme="light"] .blog-page-v2 .share-btn{
  background:rgba(0,0,0,.03) !important;
  border:1px solid rgba(0,0,0,.10) !important;
  color:#111827 !important;
}

html[data-theme="light"] .blog-page-v2 .related-empty,
body[data-theme="light"] .blog-page-v2 .related-empty{
  background:rgba(0,0,0,.03) !important;
  border:1px dashed rgba(0,0,0,.15) !important;
  color:#334155 !important;
}
.server-hero-v3{ padding: 16px; margin-bottom: 14px; }
.hero-grid{
  display: grid;
  grid-template-columns: 1.05fr 1fr;
  gap: 14px;
  position: relative;
  z-index: 1;
}
@media(max-width: 992px){
  .hero-grid{ grid-template-columns: 1fr; }
}

.hero-media{ display:flex; flex-direction:column; gap:10px; }
.hero-main{
  position: relative;
  display:block;
  border-radius: 16px;
  overflow:hidden;
  border: 1px solid rgba(255,255,255,.10);
  background: rgba(0,0,0,.18);
  min-height: 240px;
}
.hero-main img{
  width:100%;
  height: 320px;
  object-fit: cover;
  display:block;
  transform: scale(1.01);
}
@media(max-width: 992px){ .hero-main img{ height: 260px; } }

.hero-zoom{
  position:absolute;
  right: 10px;
  bottom: 10px;
  display:inline-flex;
  align-items:center;
  gap:8px;
  padding: 8px 10px;
  border-radius: 12px;
  border:1px solid rgba(255,255,255,.12);
  background: rgba(0,0,0,.35);
  color:#fff;
  font-weight: 900;
  font-size: 13px;
  backdrop-filter: blur(10px);
}

.hero-thumbs{
  display:flex;
  gap: 10px;
  overflow:auto;
  padding-bottom: 4px;
}
.hero-thumbs .thumb{
  flex: 0 0 auto;
  width: 74px;
  height: 54px;
  border-radius: 12px;
  overflow:hidden;
  border: 1px solid rgba(255,255,255,.10);
  background: rgba(0,0,0,.18);
  padding:0;
  cursor:pointer;
  transition: .18s ease;
}
.hero-thumbs .thumb img{ width:100%; height:100%; object-fit: cover; display:block; }
.hero-thumbs .thumb.active{
  transform: translateY(-1px);
  border-color: rgba(245,158,11,.55);
  box-shadow: 0 14px 35px rgba(0,0,0,.35);
}

.hero-info{ display:flex; flex-direction:column; gap: 12px; }
.hero-title{
  margin: 0;
  font-size: 30px;
  font-weight: 950;
  color:#fff;
  letter-spacing: -.3px;
  line-height: 1.1;
}
@media(max-width: 768px){ .hero-title{ font-size: 24px; } }

.hero-chips{ display:flex; gap: 10px; flex-wrap: wrap; margin-top: 10px; }
.chip{
  display:inline-flex;
  align-items:center;
  gap: 8px;
  padding: 7px 10px;
  border-radius: 999px;
  background: rgba(0,0,0,.18);
  border: 1px solid rgba(255,255,255,.10);
  color: rgba(255,255,255,.80);
  font-weight: 900;
  font-size: 12.5px;
}
.chip-ok{ color: rgba(34,197,94,1); border-color: rgba(34,197,94,.25); background: rgba(34,197,94,.10); }

.hero-rows{ display:flex; flex-direction:column; gap: 10px; }
.hero-row{
  border-radius: 16px;
  border: 1px solid rgba(255,255,255,.10);
  background: rgba(0,0,0,.18);
  padding: 10px 12px;
}
.row-label{
  font-size: 12px;
  font-weight: 900;
  color: rgba(255,255,255,.70);
  display:flex;
  align-items:center;
  gap: 8px;
  margin-bottom: 6px;
}
.row-value{
  font-weight: 950;
  color: rgba(255,255,255,.92);
  word-break: break-word;
  line-height: 1.35;
  margin-bottom: 10px;
}
.row-value a{ color: inherit; text-decoration: none; }
.row-actions{ display:flex; gap: 10px; flex-wrap:wrap; }

.row-btn{
  display:inline-flex;
  align-items:center;
  gap:8px;
  padding: 10px 12px;
  border-radius: 14px;
  border: 1px solid rgba(255,255,255,.12);
  background: rgba(255,255,255,.06);
  color:#fff;
  text-decoration:none;
  font-weight: 950;
  font-size: 13px;
  transition: .18s ease;
}
.row-btn:hover{ transform: translateY(-1px); filter: brightness(1.06); }
.row-btn-primary{
  background: rgba(88,101,242,.18); /* discord vibe */
  border-color: rgba(88,101,242,.25);
}

.hero-foot{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap: 12px;
  flex-wrap: wrap;
  margin-top: 2px;
}
.like-btn{
  display:inline-flex;
  align-items:center;
  gap: 10px;
  padding: 10px 12px;
  border-radius: 14px;
  border: 1px solid rgba(255,255,255,.12);
  background: rgba(0,0,0,.18);
  color:#fff;
  font-weight: 950;
  transition: .18s ease;
}
.like-btn .like-count{
  padding: 4px 10px;
  border-radius: 999px;
  border: 1px solid rgba(255,255,255,.12);
  background: rgba(255,255,255,.06);
  font-weight: 950;
}
.like-btn.liked{
  border-color: rgba(239,68,68,.35);
  background: rgba(239,68,68,.14);
}
.like-btn.liked i{ color: rgba(239,68,68,1); }

.hero-hint{
  display:flex;
  align-items:center;
  gap: 8px;
  color: rgba(255,255,255,.70);
  font-weight: 800;
  font-size: 13px;
}

/* LIGHT MODE */
html[data-theme="light"] .server-hero-v3 .hero-title{ color:#0f172a; }
html[data-theme="light"] .server-hero-v3 .chip,
html[data-theme="light"] .server-hero-v3 .hero-row,
html[data-theme="light"] .server-hero-v3 .like-btn{
  background:#fff;
  color:#0f172a;
  border:1px solid rgba(0,0,0,.10);
}
html[data-theme="light"] .server-hero-v3 .row-label,
html[data-theme="light"] .server-hero-v3 .hero-hint{ color:#475569; }
html[data-theme="light"] .server-hero-v3 .row-btn{
  background: rgba(0,0,0,.03);
  color:#0f172a;
  border:1px solid rgba(0,0,0,.10);
}
html[data-theme="light"] .server-hero-v3 .row-value{ color:#111827; }



/* =========================
   SERVER PRODUCTS - equal card heights
   ========================= */
.server-products-grid > [class*="col-"]{
  display: flex;
}
.server-products-grid .fp-product-item.marketplace-item{
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
}
.server-products-grid .fp-product-item.marketplace-item .content{
  display: flex;
  flex-direction: column;
  flex: 1;
}
.server-products-grid .fp-product-item.marketplace-item .product-name{
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  min-height: 44px;
}
.server-products-grid .fp-product-item.marketplace-item .price{
  margin-top: auto;
}
.server-products-grid .fp-product-item.marketplace-item .img-container{
  display:block;
}
.server-products-grid .fp-product-item.marketplace-item .img-aspect{
  width:100%;
  aspect-ratio: 1 / 1;
  object-fit: cover;
}
</style>
<script>
window.CSRF = {
  name: "<?= $this->security->get_csrf_token_name(); ?>",
  hash: "<?= $this->security->get_csrf_hash(); ?>"
};
</script>

<script>
document.addEventListener('click', async function(e){
  const likeBtn = e.target.closest('.like-btn');
  if(!likeBtn) return;

  const key = likeBtn.getAttribute('data-like-key');
  const url = likeBtn.getAttribute('data-like-url');
  if(!url) return;

  if(key && localStorage.getItem(key) === '1'){
    likeBtn.classList.add('liked');
    return;
  }

  likeBtn.disabled = true;

  try{
    const body = new URLSearchParams();
    body.set(window.CSRF.name, window.CSRF.hash);

    const res = await fetch(url, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'X-Requested-With': 'XMLHttpRequest',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
      },
      body: body.toString()
    });

    const data = await res.json();

    // csrf_regenerate açıksa token her postta değişir; yenisini sakla
    if (data && data.csrfHash) {
      window.CSRF.hash = data.csrfHash;
    }

    if(data && data.ok){
      const el = document.getElementById('likeCount');
      if(el) el.textContent = data.count;

      likeBtn.classList.add('liked');
      if(key) localStorage.setItem(key, '1');
    }
  }catch(err){
    // sessiz geç
  }finally{
    likeBtn.disabled = false;
  }
});
</script>

<script>
/* Albüm thumbnail -> main değiştir */
document.addEventListener('click', function(e){
  const t = e.target.closest('.hero-thumbs .thumb');
  if(!t) return;

  const src = t.getAttribute('data-src');
  const img = document.getElementById('heroMainImg');
  if(!src || !img) return;

  document.querySelectorAll('.hero-thumbs .thumb').forEach(x=>x.classList.remove('active'));
  t.classList.add('active');
  img.src = src;
});

/* Like (guest dahil) */
document.addEventListener('click', async function(e){
  const btn = e.target.closest('.like-btn');
  if(!btn) return;

  const likeKey = btn.getAttribute('data-like-key');
  const url = btn.getAttribute('data-like-url');
  if(!url) return;

  // UI: tek cihazda tekrar basmayı engelle (backend de engelleyecek)
  if(likeKey && localStorage.getItem(likeKey) === '1'){
    btn.classList.add('liked');
    return;
  }

  btn.disabled = true;
  try{
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'X-Requested-With': 'XMLHttpRequest' }
    });
    const data = await res.json();

    if(data && data.ok){
      const countEl = document.getElementById('likeCount');
      if(countEl) countEl.textContent = data.count;

      btn.classList.add('liked');
      btn.querySelector('i')?.classList.remove('ri-heart-3-line');
      btn.querySelector('i')?.classList.add('ri-heart-3-fill');

      if(likeKey) localStorage.setItem(likeKey, '1');
    }
  }catch(err){
    // sessiz geç
  }finally{
    btn.disabled = false;
  }
});
</script>
