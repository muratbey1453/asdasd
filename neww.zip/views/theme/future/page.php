<section class="fp-section-page">
    <div class="container">

        <div class="fp-section-page-head">
            <h1 class="title mb-0"><?= $page->title ?></h1>
        </div>

        <div class="fp-card">
            <div class="fp-card-body">
                <?= $page->content ?>
            </div>
        </div>
    </div>
</section>