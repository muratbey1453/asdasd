<section class="fp-section-page">
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="fp-card fp-client-menu">
                <div class="user-info user-info-v2">
    <div class="avatar-box">
    <span class="shine"></span>
    <img src="<?= base_url('assets/future/img/character-blue.png') ?>" alt="Avatar">
</div>

    <div class="content">
        <?php if ($this->session->userdata('info')): ?>
            <?php $user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row(); ?>

            <div class="name"><?= htmlspecialchars($user->name ?? 'Kullanıcı') ?></div>
            <div class="mail"><?= htmlspecialchars($user->email) ?></div>

            <div class="balance-row">
    <div class="balance-left">
        <span class="label">Bakiye</span>
    </div>
    <div class="balance-right">
        <span class="money"><?= number_format((float)$user->balance, 2, ',', '.') ?></span>
          <span class="tl-chip">TL</span>
    </div>
</div>

            <div class="balance-actions">
                <a href="<?= base_url('client/balance/') ?>" class="btn btn-sm btn-balance btn-load">
                    <i class="ri-add-line me-1"></i> Bakiye Yükle
                </a>
                <a href="<?= base_url('client/balance/') ?>" class="btn btn-sm btn-balance btn-withdraw">
                    <i class="ri-bank-card-line me-1"></i> Bakiye Çek
                </a>
            </div>
        <?php endif ?>
    </div>
</div>

                    <div class="content-menu">
                        <ul class="list-unstyled mb-0 list-menu client-menu">
                            <li>
                                <a href="#" class="link toggle-client-menu">
                                    <div class="icon"><i class="ri-menu-line"></i></div>
                                    <div class="text">Menü</div>
                                </a>
                            </li>
                            <li>
                                <a href="<?= base_url('client/product') ?>" class="link mobile-none">
                                    <div class="icon"><i class="ri-shopping-bag-line"></i></div>
                                    <div class="text">Siparişlerim</div>
                                </a>
                            </li>
                            <li>
                                <a href="<?= base_url('client/balance') ?>" class="link mobile-none">
                                    <div class="icon"><i class="ri-wallet-3-line"></i></div>
                                    <div class="text">Cüzdanım</div>
                                </a>
                            </li>
                            <li>
                                <a href="<?= base_url('tasks/my-tasks') ?>" class="link mobile-none">
                                    <div class="icon"><i class="ri-task-line"></i></div>
                                    <div class="text">Görevlerim</div>
                                </a>
                            </li>
                            <li>
                                <a href="<?= base_url('tasks/my-proofs') ?>" class="link mobile-none">
                                    <div class="icon"><i class="ri-file-list-3-line"></i></div>
                                    <div class="text">Kanıtlarım</div>
                                </a>
                            </li>
                            <?php if ($properties->isSubscription == 1) { ?>
                            <li>
                                <a href="<?= base_url('client/my_subscription') ?>" class="link mobile-none">
                                    <div class="icon"><i class="ri-vip-crown-line"></i></div>
                                    <div class="text">Aboneliklerim</div>
                                </a>
                            </li>
                            <?php } ?>
                            <li>
                                <a href="<?= base_url('client/my_dealer') ?>" class="link mobile-none">
                                    <div class="icon"><i class="ri-store-2-line"></i></div>
                                    <div class="text">Bayilik Bilgilerim</div>
                                </a>
                            </li>
                            <?php if ($properties->shop_active == 1) { ?>
                                <li>
                                    <a href="<?= base_url('client/orders') ?>" class="link mobile-none">
                                        <div class="icon"><i class="ri-store-line"></i></div>
                                        <div class="text">Pazaryeri</div>
                                    </a>
                                </li>
                            <?php } ?>
                            <li>
                                <a href="<?= base_url('client/streamer') ?>" class="link mobile-none">
                                    <div class="icon"><i class="ri-base-station-line"></i></div>
                                    <div class="text">Yayıncı Paneli</div>
                                </a>
                            </li>
                            <li>
                                <a href="<?= base_url('client/my_donations') ?>" class="link mobile-none">
                                    <div class="icon"><i class="ri-chat-history-line"></i></div>
                                    <div class="text">Yaptığım Bağışlar</div>
                                </a>
                            </li>
                            <li>
                                <a href="<?= base_url('client/reference') ?>" class="link mobile-none">
                                    <div class="icon"><i class="ri-user-smile-line"></i></div>
                                    <div class="text">Referanslarım</div>
                                </a>
                            </li>
                            <li>
                                <a href="<?= base_url('client/settings') ?>" class="link mobile-none">
                                    <div class="icon"><i class="ri-user-settings-line"></i></div>
                                    <div class="text">Hesap Ayarları</div>
                                </a>
                            </li>
                            <?php if ($properties->api_is_active == 1) { ?>
                            <li>
                                <a href="<?= base_url('client/api_settings') ?>" class="link mobile-none">
                                    <div class="icon"><i class="ri-code-line"></i></div>
                                    <div class="text">API Ayarları</div>
                                </a>
                            </li>
                            <?php } ?>
                            <li>
                                <a href="<?= base_url('client/ticket') ?>" class="link mobile-none">
                                    <div class="icon"><i class="ri-question-answer-line"></i></div>
                                    <div class="text">Destek</div>
                                </a>
                            </li>
                            <li>
                                <a href="<?= base_url('client/logout') ?>" class="link mobile-none text-danger">
                                    <div class="icon"><i class="ri-logout-box-r-line"></i></div>
                                    <div class="text">Çıkış Yap</div>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <style>.user-info-v2{
  display:flex;
  gap:12px;
  align-items:center;
  padding:14px 14px 12px;
  border-radius:16px;
  background: rgba(255,255,255,.03);
  border: 1px solid rgba(255,255,255,.06);
  box-shadow: 0 12px 30px rgba(0,0,0,.25);
}

.user-info-v2 .avatar-box{
  width:56px;
  height:56px;
  border-radius:16px;
  padding:6px;
  display:grid;
  place-items:center;
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(255,255,255,.12);
  box-shadow:
    0 10px 22px rgba(0,0,0,.28),
    inset 0 0 0 1px rgba(124,58,237,.25);
  position:relative;
  overflow:hidden;
}

.user-info-v2 .avatar-box::after{
  content:"";
  position:absolute;
  inset:-40%;
  background: radial-gradient(circle, rgba(124,58,237,.25), transparent 60%);
  transform: rotate(20deg);
}

.user-info-v2 .avatar-box img{
  width:100%;
  height:100%;
  object-fit:contain;
  position:relative;
  z-index:1;
  filter: drop-shadow(0 10px 16px rgba(0,0,0,.35));
}

.user-info-v2 .content{
  flex:1;
  min-width:0;
}

.user-info-v2 .name{
  font-weight:700;
  font-size:18px;
  line-height:1.2;
  white-space:nowrap;
  overflow:hidden;
  text-overflow:ellipsis;
}

.user-info-v2 .mail{
  font-size:12px;
  opacity:.85;
  margin-top:2px;
  white-space:nowrap;
  overflow:hidden;
  text-overflow:ellipsis;
}

.user-info-v2 .balance-row{
  display:flex;
  justify-content:space-between;
  align-items:center;
  margin-top:10px;
  padding-top:10px;
  border-top: 1px solid rgba(255,255,255,.08);
  font-size:14px;
}

.user-info-v2 .balance-row .label{
  opacity:.75;
}

.user-info-v2 .balance-row .money{
  font-weight:800;
  letter-spacing:.2px;
}

.user-info-v2 .balance-actions{
  display:flex;
  gap:8px;
  margin-top:10px;
}

.user-info-v2 .btn-balance{
  flex:1;
  border-radius:12px;
  padding:8px 10px;
  border: 1px solid rgba(255,255,255,.12);
  background: rgba(255,255,255,.05);
  color: inherit;
  box-shadow: 0 10px 18px rgba(0,0,0,.18);
  transition: transform .15s ease, background .15s ease, border-color .15s ease;
}

.user-info-v2 .btn-balance:hover{
  transform: translateY(-1px);
  background: rgba(255,255,255,.07);
  border-color: rgba(124,58,237,.35);
}

/* Mobil sıkışınca alt alta */
@media (max-width: 576px){
  .user-info-v2{ align-items:flex-start; }
  .user-info-v2 .balance-actions{ flex-direction:column; }
}
/* ========== TL CHIP / BADGE ========== */
.user-info-v2 .balance-left{
  display:flex;
  align-items:center;
  gap:8px;
}

.user-info-v2 .tl-chip{
  font-size:14px;
  font-weight:800;
  padding:3px 8px;
  border-radius:999px;
  border:1px solid rgba(255,255,255,.14);
  background: linear-gradient(135deg, rgba(124,58,237,.25), rgba(34,211,238,.18));
  box-shadow:
    0 10px 18px rgba(0,0,0,.18),
    inset 0 0 0 1px rgba(255,255,255,.08);
  letter-spacing:.4px;
  text-transform:uppercase;
}

.user-info-v2 .balance-right .money{
  font-weight:900;
  letter-spacing:.2px;
}


/* ========== BUTTON NEON / GRADIENT GLOW ========== */
.user-info-v2 .btn-balance{
  position:relative;
  overflow:hidden;
  isolation:isolate;
}

/* butonun arkasına soft glow katmanı */
.user-info-v2 .btn-balance::before{
  content:"";
  position:absolute;
  inset:-2px;
  border-radius:14px;
  background: radial-gradient(circle at 30% 30%, rgba(124,58,237,.35), transparent 55%),
              radial-gradient(circle at 70% 70%, rgba(34,211,238,.25), transparent 55%);
  opacity:0;
  transition: opacity .18s ease;
  z-index:-1;
}

/* buton üzerinde “shine” süpürme efekti */
.user-info-v2 .btn-balance::after{
  content:"";
  position:absolute;
  top:-60%;
  left:-60%;
  width:60%;
  height:220%;
  transform: rotate(25deg);
  background: linear-gradient(90deg, transparent, rgba(255,255,255,.18), transparent);
  opacity:0;
  transition: opacity .18s ease;
}

.user-info-v2 .btn-balance:hover::before{
  opacity:1;
}

.user-info-v2 .btn-balance:hover::after{
  opacity:1;
  animation: btnShine .9s ease forwards;
}

@keyframes btnShine{
  from{ transform: translateX(0) rotate(25deg); }
  to{ transform: translateX(260%) rotate(25deg); }
}

.user-info-v2 .btn-balance:focus-visible{
  outline:none;
  border-color: rgba(34,211,238,.45);
  box-shadow:
    0 0 0 3px rgba(34,211,238,.15),
    0 12px 22px rgba(0,0,0,.22);
}

/* İstersen iki butonu farklı “accent” yapalım */
.user-info-v2 .btn-load{
  border-color: rgba(124,58,237,.22);
}
.user-info-v2 .btn-withdraw{
  border-color: rgba(34,211,238,.20);
}


/* ========== AVATAR SHINE ANIMATION ========== */
.user-info-v2 .avatar-box{
  position:relative;
}

.user-info-v2 .avatar-box::before{
  content:"";
  position:absolute;
  inset:-2px;
  border-radius:18px;
  background: linear-gradient(135deg, rgba(124,58,237,.35), rgba(34,211,238,.20));
  filter: blur(10px);
  opacity:.35;
  z-index:0;
}

/* kutu üstünden geçen ince parlak çizgi */
.user-info-v2 .avatar-box .shine{
  position:absolute;
  inset:-40%;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,.18), transparent);
  transform: rotate(25deg);
  animation: avatarShine 3.2s ease-in-out infinite;
  opacity:.6;
  z-index:1;
  pointer-events:none;
}

@keyframes avatarShine{
  0%   { transform: translateX(-40%) rotate(25deg); opacity:.0; }
  20%  { opacity:.6; }
  50%  { transform: translateX(40%) rotate(25deg); opacity:.2; }
  100% { transform: translateX(80%) rotate(25deg); opacity:0; }
}

/* img üstte kalsın */
.user-info-v2 .avatar-box img{
  position:relative;
  z-index:2;
}

/* Hareket azaltma tercihine saygı */
@media (prefers-reduced-motion: reduce){
  .user-info-v2 .avatar-box .shine,
  .user-info-v2 .btn-balance:hover::after{
    animation:none !important;
  }
}
/* Sadece çerçeve + hafif gölge (arka planı bozmaz) */
.fp-card.fp-client-menu{
  border: 1px solid rgba(0,0,0,.12);          /* beyaz temada görünen ince çizgi */
  border-radius: 18px;
  box-shadow: 0 10px 24px rgba(0,0,0,.06);    /* çok hafif gölgelendirme */
}

/* İçerideki menü linklerinin de çerçeveye uyumlu görünmesi (opsiyonel ama iyi durur) */
.fp-card.fp-client-menu .content-menu .client-menu .link{
  border-radius: 12px;
}

/* Eğer mevcut temada border zaten var ve görünmüyorsa baskılamak için */
.fp-card.fp-client-menu{
  border-color: rgba(0,0,0,.12) !important;
  box-shadow: 0 10px 24px rgba(0,0,0,.06) !important;
}

</style>