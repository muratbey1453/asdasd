<div class="col-lg-9">
    <div class="fp-card fp-card-client">
        <div class="fp-cc-head d-flex justify-content-between align-items-center">
            <h1 class="title mb-0">Yeni İlan Ekle</h1>
            <a href="<?= base_url('client/orders') ?>" class="btn btn-outline-secondary btn-sm">
                <i class="ri-arrow-left-line me-1"></i>Geri
            </a>
        </div>
        <div class="fp-cc-body">
            <form action="<?= base_url('client/addProduct') ?>" method="POST" enctype="multipart/form-data">
                
                <div class="row g-3">
                    <div class="col-md-8">
                        <label class="form-label">Ürün Adı <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="product_name" placeholder="Ürün adını girin" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Fiyat (TL) <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" name="product_price" placeholder="0.00" step="0.01" required>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Kategori <span class="text-danger">*</span></label>
                        <select class="form-select" name="category_id" required>
                            <option value="">Kategori Seçin</option>
                            <?php foreach($categories as $cat): ?>
                                <option value="<?= $cat->id ?>"><?= $cat->name ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Ürün Açıklaması <span class="text-danger">*</span></label>
                        <textarea class="form-control" name="product_desc" rows="4" placeholder="Ürün açıklamasını girin..." required></textarea>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Ürün Görseli (Ana Görsel)</label>
                        <input class="form-control" type="file" id="formFile" name="img">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Ek Görseller (Galeri - Max 5 adet)</label>
                        <input class="form-control" type="file" name="gallery[]" multiple accept="image/*">
                        <small class="text-muted">Birden fazla resim seçebilirsiniz</small>
                    </div>
                    <div class="col-12">
                        <div class="alert alert-light border mb-0 py-2">
                            <i class="ri-information-line me-1"></i>
                            <small>İlanınız yönetici onayından sonra yayınlanacaktır.</small>
                        </div>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">
                            <i class="ri-add-line me-1"></i>İlan Oluştur
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
        </div>
    </div>
</section>
