<section class="fp-section">
    <div class="container">
        
        <?php
        // Aktif görevlerin toplam kazancı (status=1)
        $sumRow = $this->db->query("
            SELECT COUNT(*) AS task_count, SUM(reward_amount) AS total_earning
            FROM tasks
            WHERE status = 1
        ")->row();

        $taskCount = (int)($sumRow->task_count ?? 0);
        $totalEarning = (float)($sumRow->total_earning ?? 0);
        ?>
<!-- HERO KART -->
<div class="total-earning-box mb-4">
    <i class="ri-coins-line total-earning-icon"></i>

    <div class="total-earning-title">
        Maksimum Kazanç
    </div>

    <div class="total-earning-amount big-red">
        <span id="earningCounter"
              data-target="<?= number_format($totalEarning, 2, '.', '') ?>">
            0.00
        </span>
        <span class="currency">TL</span>
    </div>

    <div class="total-earning-sub">
        Sitedeki tüm aktif görevleri tamamladığınızda kazanabileceğiniz maksimum tutar.
    </div>
</div>


<!-- /HERO KART -->


        <div class="fp-section-head d-flex justify-content-between align-items-center mb-4">
            <h2 class="m-0"><i class="ri-task-line me-2"></i> Görevler</h2>
            <div class="d-flex gap-2">
                <?php if(isset($this->session->userdata('info')['id'])): ?>
                    <a href="<?= base_url('tasks/my-proofs') ?>" class="btn btn-info">
                        <i class="ri-file-list-3-line me-1"></i> Kanıtlarım
                    </a>
                    <a href="<?= base_url('tasks/create') ?>" class="btn btn-primary">
                        <i class="ri-add-line me-1"></i> Görev Oluştur
                    </a>
                <?php else: ?>
                    <a href="<?= base_url('hesap') ?>" class="btn btn-info">
                        <i class="ri-file-list-3-line me-1"></i> Kanıtlarım
                    </a>
                    <a href="<?= base_url('hesap') ?>" class="btn btn-primary">
                        <i class="ri-add-line me-1"></i> Görev Oluştur
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <?php if(empty($tasks)): ?>
            <div class="alert alert-info text-center">
                <i class="ri-information-line fs-1"></i>
                <h4 class="mt-2">Henüz Aktif Görev Yok</h4>
                <p>Şu anda gösterecek bir görev bulunmuyor. İlk görev siz oluşturun!</p>
                <?php if(isset($this->session->userdata('info')['id'])): ?>
                    <a href="<?= base_url('tasks/create') ?>" class="btn btn-primary mt-2">
                        <i class="ri-add-line me-1"></i> Görev Oluştur
                    </a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="row row-products">
                <?php foreach($tasks as $task): ?>
                    <div class="col-6 col-md-4 col-lg-3 col-xl-2">
                        <div class="fp-product-item">
                            <a class="img" href="<?= base_url('tasks/detail/' . $task->id) ?>" style="position: relative;">
                                <?php if(!empty($task->image)): ?>
                                    <img src="<?= base_url('assets/img/tasks/' . $task->image) ?>" class="img-product img-aspect" alt="<?= $task->title ?>">
                                <?php else: ?>
                                    <img src="<?= base_url('assets/img/tasks/default-task.png') ?>" class="img-product img-aspect" alt="<?= $task->title ?>">
                                <?php endif; ?>
                                
                                <?php 
                                // Görevi oluşturan kişi
                                $taskOwner = null;
                                if (!empty($task->user_id)) {
                                    $taskOwner = $this->db->where('id', $task->user_id)->get('user')->row();
                                }
                                ?>
                                <?php if ($taskOwner): ?>
                                    <div class="seller-badge-overlay" style="bottom: 10px !important; cursor: pointer;" onclick="event.preventDefault(); window.location.href='<?= !empty($taskOwner->shop_slug) ? base_url('magaza/' . $taskOwner->shop_slug) : '#' ?>'">
                                        <?php if (!empty($taskOwner->shop_img)): ?>
                                            <img src="<?= base_url('assets/img/shop/' . $taskOwner->shop_img) ?>" alt="" class="shop-avatar">
                                        <?php else: ?>
                                            <i class="ri-user-3-line"></i>
                                        <?php endif; ?>
                                        <span><?php
                                            $m_name = substr($taskOwner->name, 0, 2) . str_repeat('*', max(0, strlen($taskOwner->name) - 2));
                                            $m_surname = substr($taskOwner->surname, 0, 2) . str_repeat('*', max(0, strlen($taskOwner->surname) - 2));
                                            echo $m_name . ' ' . $m_surname;
                                        ?></span>
                                    </div>
                                <?php endif; ?>
                            </a>
                            <div class="content">
                                <a class="product-name" href="<?= base_url('tasks/detail/' . $task->id) ?>">
                                    <?= $task->title ?>
                                </a>
                                <div class="price">
                                    <div class="price-new">
                                        <i class="ri-coin-line me-1"></i><?= number_format($task->reward_amount, 2) ?> TL
                                    </div>
                                </div>
                                <div class="task-meta mt-2">
                                    <small class="text-muted d-block mt-1">
        <i class="ri-time-line"></i>
        <?= date('d.m.Y', strtotime($task->created_at)) ?>
    </small>
                                    <small class="text-muted d-block">
                                        <i class="ri-user-line"></i> Kota: <?= $task->current_count ?>/<?= $task->total_limit ?>
                                    </small>
                                    <?php 
                                    $percentage = ($task->current_count / $task->total_limit) * 100;
                                    ?>
                                    <div class="progress mt-1" style="height: 4px;">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: <?= $percentage ?>%"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="buttons">
                                <a href="<?= base_url('tasks/detail/' . $task->id) ?>" class="btn btn-primary w-100">
                                    <i class="ri-eye-line me-1"></i> Detayları Gör
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
  <style>
    .total-earning-amount.big-red{
    display: flex;
    align-items: baseline;
    gap: 10px;
    font-size: 44px;
    font-weight: 900;
    color: #ef4444;
    letter-spacing: .5px;
    line-height: 1;
    text-shadow:
        0 0 10px rgba(239,68,68,.35),
        0 0 25px rgba(239,68,68,.15);
}

.total-earning-amount.big-red .currency{
    font-size: 16px;
    font-weight: 800;
    color: rgba(255,255,255,.75);
    letter-spacing: .3px;
}

@media (max-width: 768px){
    .total-earning-amount.big-red{
        font-size: 34px;
    }
}
.total-earning-box{
    position: relative;
    background: linear-gradient(135deg, #0f172a, #020617);
    border-radius: 16px;
    padding: 28px 32px;
    border: 1px solid rgba(255,255,255,.08);
    box-shadow: 
        0 10px 30px rgba(0,0,0,.6),
        inset 0 0 0 1px rgba(255,255,255,.04);
    overflow: hidden;
}

.total-earning-box::before{
    content:"";
    position:absolute;
    inset:0;
    background: linear-gradient(
        120deg,
        transparent 40%,
        rgba(239,68,68,.15),
        transparent 60%
    );
    pointer-events:none;
}

.total-earning-title{
    color: rgba(255,255,255,.75);
    font-size: 13px;
    letter-spacing: .5px;
    text-transform: uppercase;
    margin-bottom: 8px;
}

.total-earning-amount{
    font-size: 36px;
    font-weight: 900;
    color: #ef4444;
    letter-spacing: .3px;
    display: flex;
    align-items: baseline;
    gap: 8px;
}

.total-earning-amount span{
    font-size: 36px;
    font-weight: 700;
    color: rgba(230, 14, 14, 0.91);
}

.total-earning-sub{
    margin-top: 10px;
    font-size: 13px;
    color: rgba(255,255,255,.55);
}

.total-earning-icon{
    position: absolute;
    top: 16px;
    right: 18px;
    font-size: 48px;
    color: rgba(239,68,68,.15);
}
</style>
<script>
document.addEventListener("DOMContentLoaded", () => {
    const counter = document.getElementById("earningCounter");
    if (!counter) return;

    const target = parseFloat(counter.dataset.target);
    const duration = 1600; // ms (1.6 saniye)
    const startTime = performance.now();

    function animate(now) {
        const progress = Math.min((now - startTime) / duration, 1);

        // Ease-out (yumuşak bitiş)
        const eased = 1 - Math.pow(1 - progress, 3);

        const current = target * eased;

        counter.textContent = current.toLocaleString('tr-TR', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });

        if (progress < 1) {
            requestAnimationFrame(animate);
        } else {
            // Final değeri garantiye al
            counter.textContent = target.toLocaleString('tr-TR', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }
    }

    requestAnimationFrame(animate);
});
</script>

</section>
