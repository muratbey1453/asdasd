<div class="col-lg-9">
    <div class="fp-card fp-card-client">
        <div class="fp-cc-head">
            <h1 class="title">Gönderdiğim Kanıtlar</h1>
            <a href="<?= base_url('tasks') ?>" class="btn btn-primary btn-sm">
                <i class="ri-arrow-left-line me-1"></i> Geri Dön
            </a>
        </div>
        <div class="fp-cc-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Görev ID</th>
                            <th>Kanıt</th>
                            <th>Durum</th>
                            <th>Red Nedeni</th>
                            <th>Tarih</th>
                            <th>İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($proofs)): ?>
                            <tr>
                                <td colspan="7" class="text-center">Henüz kanıt göndermediniz.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach($proofs as $proof): ?>
                                <tr>
                                    <td>#<?= $proof->id ?></td>
                                    <td><a href="<?= base_url('tasks/detail/'.$proof->task_id) ?>">#<?= $proof->task_id ?></a></td>
                                    <td><?= mb_substr($proof->proof_text, 0, 30) ?>...</td>
                                    <td>
                                        <?php 
                                            if($proof->status == 0) echo '<span class="badge bg-warning">Bekliyor</span>';
                                            elseif($proof->status == 1) echo '<span class="badge bg-success">Onaylandı</span>';
                                            elseif($proof->status == 2) echo '<span class="badge bg-danger">Reddedildi</span>';
                                        ?>
                                    </td>
                                    <td><?= $proof->rejection_reason ?></td>
                                    <td><?= date('d.m.Y H:i', strtotime($proof->created_at)) ?></td>
                                    <td>
                                        <a href="<?= base_url('tasks/detail/'.$proof->task_id) ?>" class="btn btn-sm btn-primary">Görüntüle</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</section>
