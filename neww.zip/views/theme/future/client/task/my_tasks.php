<div class="col-lg-9">
    <div class="fp-card fp-card-client">
        <div class="fp-cc-head">
            <h1 class="title">Oluşturduğum Görevler</h1>
            <a href="<?= base_url('tasks') ?>" class="btn btn-primary btn-sm">
                <i class="ri-arrow-left-line me-1"></i> Geri Dön
            </a>
        </div>
        <div class="fp-cc-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Başlık</th>
                            <th>Ücret</th>
                            <th>İlerleme</th>
                            <th>Durum</th>
                            <th>Tarih</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($tasks)): ?>
                            <tr>
                                <td colspan="6" class="text-center">Henüz görev oluşturmadınız.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach($tasks as $task): ?>
                                <tr>
                                    <td>#<?= $task->id ?></td>
                                    <td><?= $task->title ?></td>
                                    <td><?= $task->reward_amount ?> TL</td>
                                    <td>
                                        <div class="progress" style="height: 20px;">
                                            <div class="progress-bar" role="progressbar" style="width: <?= ($task->current_count / $task->total_limit) * 100 ?>%;" aria-valuenow="<?= $task->current_count ?>" aria-valuemin="0" aria-valuemax="<?= $task->total_limit ?>">
                                                <?= $task->current_count ?>/<?= $task->total_limit ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <?php 
                                            if($task->status == 0) echo '<span class="badge bg-warning">Onay Bekliyor</span>';
                                            elseif($task->status == 1) echo '<span class="badge bg-success">Aktif</span>';
                                            elseif($task->status == 2) echo '<span class="badge bg-secondary">Pasif</span>';
                                            elseif($task->status == 3) echo '<span class="badge bg-danger">Reddedildi/İptal</span>';
                                            elseif($task->status == 4) echo '<span class="badge bg-info">Tamamlandı</span>';
                                        ?>
                                    </td>
                                    <td><?= date('d.m.Y H:i', strtotime($task->created_at)) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</section>
