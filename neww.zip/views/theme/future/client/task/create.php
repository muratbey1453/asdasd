<div class="col-lg-9">
    <div class="fp-card fp-card-client">
        <div class="fp-cc-head">
            <h1 class="title">Yeni Görev Oluştur</h1>
            <a href="<?= base_url('tasks') ?>" class="btn btn-primary btn-sm">
                <i class="ri-arrow-left-line me-1"></i> Geri Dön
            </a>
        </div>
        <div class="fp-cc-body">
            <div class="alert alert-info">
                <i class="ri-information-line"></i> Görev oluşturma ücreti bakiyenizden tahsil edilecektir. Görev iptal edilirse kalan tutar iade edilir.
            </div>
            <form action="<?= base_url('tasks/do_create') ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>" />
                <div class="mb-3">
                    <label for="title" class="form-label">Görev Başlığı</label>
                    <input type="text" class="form-control" id="title" name="title" required>
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Görev Açıklaması ve Talimatlar</label>
                    <textarea class="form-control" id="description" name="description" rows="5" required></textarea>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="reward_amount" class="form-label">Kişi Başı Ücret (TL)</label>
                        <input type="number" step="0.01" class="form-control" id="reward_amount" name="reward_amount" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="total_limit" class="form-label">Kaç Kişi İstiyorsunuz?</label>
                        <input type="number" class="form-control" id="total_limit" name="total_limit" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="image" class="form-label">Görev Görseli (Opsiyonel)</label>
                    <input class="form-control" type="file" id="image" name="image">
                </div>
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="is_repeatable" name="is_repeatable">
                    <label class="form-check-label" for="is_repeatable">Bu görev aynı kullanıcı tarafından tekrar yapılabilir mi?</label>
                </div>
                
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary btn-lg">Görevi Oluştur ve Ödeme Yap</button>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
</div>
</section>
