<section class="fp-section-page">
    <div class="container">
        <!-- Geri Dön Butonu -->
        <div class="mb-3">
            <a href="<?= base_url('tasks') ?>" class="btn btn-outline-primary">
                <i class="ri-arrow-left-line me-2"></i>Tüm Görevler
            </a>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="fp-card p-4">
                    <div class="row g-4">
                        <!-- Sol Taraf - Görsel -->
                        <div class="col-lg-5">
                            <div class="task-image-container">
                                <?php if(!empty($task->image)): ?>
                                    <img src="<?= base_url('assets/img/tasks/' . $task->image) ?>" class="img-fluid rounded" alt="<?= $task->title ?>" style="width: 100%; height: auto; max-height: 500px; object-fit: cover;">
                                <?php else: ?>
                                    <div class="no-image-placeholder d-flex align-items-center justify-content-center rounded" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); height: 400px;">
                                        <i class="ri-task-line" style="font-size: 120px; color: rgba(255,255,255,0.3);"></i>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Sağ Taraf - Bilgiler -->
                        <div class="col-lg-7">
                            <div class="task-details">
                                <!-- Başlık -->
                                <h1 class="h3 mb-3"><?= $task->title ?></h1>

                                <!-- Durum ve Tekrarlanabilirlik Badge'leri -->
                                <div class="mb-4">
                                    <?php 
                                        $status_class = '';
                                        $status_text = '';
                                        if($task->status == 0) { 
                                            $status_class = 'bg-warning text-dark'; 
                                            $status_text = 'Onay Bekliyor';
                                        } elseif($task->status == 1) { 
                                            $status_class = 'bg-success'; 
                                            $status_text = 'Aktif';
                                        } elseif($task->status == 2) { 
                                            $status_class = 'bg-secondary'; 
                                            $status_text = 'Pasif';
                                        } elseif($task->status == 3) { 
                                            $status_class = 'bg-danger'; 
                                            $status_text = 'Reddedildi/İptal';
                                        } elseif($task->status == 4) { 
                                            $status_class = 'bg-info'; 
                                            $status_text = 'Tamamlandı';
                                        }
                                    ?>
                                    <span class="badge <?= $status_class ?> fs-6 me-2">
                                        <i class="ri-checkbox-circle-line me-1"></i><?= $status_text ?>
                                    </span>
                                    <span class="badge <?= $task->is_repeatable ? 'bg-info' : 'bg-secondary' ?> fs-6">
                                        <i class="ri-repeat-line me-1"></i>
                                        <?= $task->is_repeatable ? 'Tekrarlanabilir' : 'Tek Seferlik' ?>
                                    </span>
                                </div>

                                <!-- Ödül Miktarı -->
                                <div class="task-price mb-4 p-3 rounded border border-primary">
                                    <div class="d-flex align-items-center">
                                        <i class="ri-money-dollar-circle-fill text-primary me-3" style="font-size: 2.5rem;"></i>
                                        <div>
                                            <h2 class="h4 text-primary mb-0"><?= $task->reward_amount ?> TL</h2>
                                            <small class="text-muted">Görev Başına Ödül</small>
                                        </div>
                                    </div>
                                </div>

                                <!-- İlerleme Çubuğu -->
                                <div class="mb-4">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <span class="fw-bold"><i class="ri-bar-chart-fill me-2"></i>İlerleme</span>
                                        <span class="badge bg-primary d-flex align-items-center justify-content-center" style="min-width: 60px;"><?= $task->current_count ?> / <?= $task->total_limit ?></span>
                                    </div>
                                    <div class="progress" style="height: 25px;">
                                        <div class="progress-bar bg-success" role="progressbar" 
                                             style="width: <?= ($task->current_count / $task->total_limit) * 100 ?>%;" 
                                             aria-valuenow="<?= $task->current_count ?>" 
                                             aria-valuemin="0" 
                                             aria-valuemax="<?= $task->total_limit ?>">
                                            <?= round(($task->current_count / $task->total_limit) * 100, 1) ?>%
                                        </div>
                                    </div>
                                </div>

                                <!-- Açıklama -->
                                <div class="mb-4">
                                    <h5 class="mb-3"><i class="ri-file-text-line me-2"></i>Görev Açıklaması</h5>
                                    <div class="task-description p-3 rounded border-start border-primary border-4">
                                        <?= nl2br(htmlspecialchars($task->description)) ?>
                                    </div>
                                </div>

                                <!-- Görevi Oluşturan Kişi Bilgisi -->
                                <?php 
                                $taskCreator = null;
                                if (!empty($task->user_id)) {
                                    $taskCreator = $this->db->where('id', $task->user_id)->get('user')->row();
                                }
                                ?>
                                <?php if (!empty($taskCreator)): ?>
                                <div class="mb-4">
                                    <h5 class="mb-3"><i class="ri-user-star-line me-2"></i>Görevi Oluşturan</h5>
                                    <div class="task-creator-panel p-3 rounded border" style="background: var(--bg-white-2);">
                                        <div class="d-flex align-items-center gap-3">
                                            <?php if (!empty($taskCreator->shop_img)): ?>
                                                <img src="<?= base_url('assets/img/shop/' . $taskCreator->shop_img) ?>" class="rounded-circle" style="width: 56px; height: 56px; object-fit: cover; border: 2px solid var(--border);" alt="">
                                            <?php else: ?>
                                                <div class="rounded-circle d-flex align-items-center justify-content-center" style="width: 56px; height: 56px; background: linear-gradient(135deg, #667eea, #764ba2);">
                                                    <i class="ri-user-3-line text-white" style="font-size: 24px;"></i>
                                                </div>
                                            <?php endif; ?>
                                            <div class="flex-grow-1">
                                                <h6 class="mb-1">
                                                    <?php if (!empty($taskCreator->shop_name)): ?>
                                                        <?= $taskCreator->shop_name ?>
                                                        <span class="badge bg-success ms-1" style="font-size: 10px;"><i class="ri-verified-badge-fill"></i> Mağaza</span>
                                                    <?php else: ?>
                                                        <?= $taskCreator->name . ' ' . $taskCreator->surname ?>
                                                    <?php endif; ?>
                                                </h6>
                                                <div class="d-flex gap-3 text-muted" style="font-size: 13px;">
                                                    <?php 
                                                    $creatorTotalTasks = $this->db->where('user_id', $taskCreator->id)->where('status', 1)->count_all_results('tasks');
                                                    ?>
                                                    <span><i class="ri-task-line me-1"></i><?= $creatorTotalTasks ?> Görev</span>
                                                </div>
                                            </div>
                                            <?php if (!empty($taskCreator->shop_slug)): ?>
                                                <a href="<?= base_url('magaza/' . $taskCreator->shop_slug) ?>" class="btn btn-outline-primary btn-sm">
                                                    <i class="ri-store-2-line me-1"></i>Mağaza
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <!-- Kanıt Gönderme Formu veya Durum -->
                                <?php if(isset($this->session->userdata('info')['id'])): ?>
                                    <?php if(isset($user_proof) && $user_proof): ?>
                                        <div class="alert alert-<?= $user_proof->status == 1 ? 'success' : ($user_proof->status == 2 ? 'danger' : 'warning') ?>">
                                            <h5 class="alert-heading">
                                                <i class="<?= $user_proof->status == 1 ? 'ri-checkbox-circle-line' : ($user_proof->status == 2 ? 'ri-close-circle-line' : 'ri-time-line') ?> me-2"></i>
                                                Kanıt Durumu
                                            </h5>
                                            <p class="mb-0">
                                                <?php if($user_proof->status == 0): ?>
                                                    <strong>Onay Bekliyor:</strong> Kanıtınız inceleniyor.
                                                <?php elseif($user_proof->status == 1): ?>
                                                    <strong>Onaylandı:</strong> Kanıtınız onaylandı ve ödül hesabınıza eklendi!
                                                <?php elseif($user_proof->status == 2): ?>
                                                    <strong>Reddedildi</strong>
                                                    <?php if($user_proof->rejection_reason): ?>
                                                        <br><small>Sebep: <?= $user_proof->rejection_reason ?></small>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </p>
                                        </div>
                                    <?php elseif($task->status == 1 && $task->current_count < $task->total_limit): ?>
                                        <div class="card border-primary shadow-sm bg-transparent">
                                            <div class="card-header border-bottom border-primary">
                                                <h5 class="mb-0 text-primary"><i class="ri-upload-cloud-line me-2"></i>Kanıt Gönder</h5>
                                            </div>
                                            <div class="card-body p-4">
                                                <form action="<?= base_url('tasks/do_proof/' . $task->id) ?>" method="post" enctype="multipart/form-data">
                                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>" />
                                                    <div class="mb-3">
                                                        <label for="proof_text" class="form-label fw-bold">Kanıt Açıklaması / Linkler</label>
                                                        <textarea class="form-control" id="proof_text" name="proof_text" rows="4" required placeholder="Görev kanıtınızı buraya yazın veya link ekleyin..."></textarea>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="proof_image" class="form-label fw-bold">Kanıt Görseli (Opsiyonel)</label>
                                                        <input type="file" class="form-control" id="proof_image" name="proof_image" accept="image/*">
                                                    </div>
                                                    <button type="submit" class="btn btn-primary btn-lg w-100">
                                                        <i class="ri-send-plane-fill me-2"></i>Kanıt Gönder
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div class="alert alert-warning">
                                            <i class="ri-error-warning-line me-2"></i>
                                            <?php if($task->status != 1): ?>
                                                Bu görev şu anda aktif değil.
                                            <?php else: ?>
                                                Bu görevin kotası dolmuştur.
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div class="alert alert-info shadow-sm">
                                        <h5 class="alert-heading"><i class="ri-login-box-line me-2"></i>Giriş Yapın</h5>
                                        <p class="mb-3">Bu göreve katılmak için giriş yapmanız gerekmektedir.</p>
                                        <a href="<?= base_url('hesap') ?>" class="btn btn-primary me-2">
                                            <i class="ri-login-circle-line me-2"></i>Giriş Yap / Kayıt Ol
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
