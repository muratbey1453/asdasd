<div class="col-lg-9">
    <div class="fp-card fp-card-client">
        <div class="fp-cc-head">
            <h1 class="title">Kontrol Paneli</h1>
        </div>
        <div class="fp-cc-body">
            <a class="fp-client-shortcut fp-card" href="<?= base_url('client/product') ?>">
                <div class="left">
                    <i class="ri-shopping-bag-line"></i>
                    <div class="title">Siparişlerimi Görüntüle</div>
                </div>
                <i class="ri-arrow-right-line icon-right"></i>
            </a>
            <a class="fp-client-shortcut fp-card" href="<?= base_url('client/balance') ?>">
                <div class="left">
                    <i class="ri-wallet-3-line"></i>
                    <div class="title">Cüzdanım</div>
                </div>
                <i class="ri-arrow-right-line icon-right"></i>
            </a>
            <a class="fp-client-shortcut fp-card mb-0" href="<?= base_url('client/settings') ?>">
                <div class="left">
                    <i class="ri-user-settings-line"></i>
                    <div class="title">Hesap Ayarlarım</div>
                </div>
                <i class="ri-arrow-right-line icon-right"></i>
            </a>
        </div>
    </div>
</div>
</div>
</div>
</section>