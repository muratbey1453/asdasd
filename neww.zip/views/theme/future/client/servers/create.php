<?php
// application/views/servers/create.php
// Variables expected: $title, $games
?>

<section class="fp-section-page serverhub" style="padding:2.25rem 0">
  <div class="container">
    <div class="serverhub-head" style="margin-bottom:1.25rem">
      <div>
        <h1 class="serverhub-title"><?= html_escape($title) ?></h1>
        <p class="serverhub-sub">Sunucun onaylandıktan sonra listede görünecek. Lütfen bilgileri doğru gir.</p>
      </div>
      <a href="<?= base_url('sunucular') ?>" class="btn btn-outline-primary">
        <i class="ri-arrow-left-line me-1"></i> Sunuculara Dön
      </a>
    </div>

    <?php if ($this->session->flashdata('message')): ?>
      <div class="alert alert-info"><?= $this->session->flashdata('message') ?></div>
    <?php endif; ?>

    <div class="server-form">
       <?php echo form_open('client/sunucu-ekle/kaydet'); ?>

        <div class="row g-3">
          <div class="col-lg-6">
            <label class="form-label">Oyun</label>
            <select name="game" class="form-select" required>
              <option value="" disabled selected>Seçiniz</option>
              <?php foreach($games as $k => $label): ?>
                <option value="<?= html_escape($k) ?>"><?= html_escape($label) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-lg-6">
            <label class="form-label">Sunucu Adı</label>
            <input type="text" name="title" class="form-control" maxlength="80" placeholder="Örn: Metin2 Orion" required>
          </div>
          <div class="col-lg-6">
            <label class="form-label">IP / Domain</label>
            <input type="text" name="ip" class="form-control" maxlength="100" placeholder="orion2.com / 123.123.123.123" required>
          </div>
          <div class="col-lg-6">
            <label class="form-label">Website (opsiyonel)</label>
            <input type="url" name="website" class="form-control" maxlength="255" placeholder="https://...">
          </div>
          <div class="col-lg-6">
            <label class="form-label">Discord (opsiyonel)</label>
            <input type="url" name="discord" class="form-control" maxlength="255" placeholder="https://discord.gg/...">
          </div>
          <div class="col-lg-6">
            <label class="form-label">Tanıtım (kısa)</label>
            <input type="text" name="short_desc" class="form-control" maxlength="140" placeholder="Örn: 24/7 aktif, hızlı başlangıç, etkinlikler...">
          </div>
          <div class="col-12">
            <label class="form-label">Açıklama</label>
            <textarea name="description" class="form-control" rows="5" placeholder="Sunucu özellikleri, rate, event, açılış tarihi vb." required></textarea>
          </div>
          <div class="col-12">
            <button class="btn btn-primary">
              <i class="ri-send-plane-2-line me-1"></i> Onaya Gönder
            </button>
          </div>
        </div>
    </div>
  </div>
</section>
<?php echo form_close(); ?>

<style>
/* Aynı temayı index sayfasıyla paylaşır */
.serverhub{ --sh-bg: var(--fp-body-bg, transparent); --sh-card: rgba(255,255,255,.65); --sh-card2: rgba(255,255,255,.52); --sh-text: var(--fp-text, #0f172a); --sh-muted: rgba(15,23,42,.65); --sh-bd: rgba(15,23,42,.12); --sh-glow: rgba(0,255,209,.22); }
html[data-theme="dark"] .serverhub, body.dark .serverhub{ --sh-card: rgba(20,24,33,.66); --sh-card2: rgba(20,24,33,.48); --sh-text: rgba(255,255,255,.92); --sh-muted: rgba(255,255,255,.62); --sh-bd: rgba(255,255,255,.10); --sh-glow: rgba(0,255,209,.16); }

.serverhub-title{font-size:1.35rem;margin:0;color:var(--sh-text)}
.serverhub-sub{margin:.35rem 0 0;color:var(--sh-muted)}
.server-form{border:1px solid var(--sh-bd);border-radius:18px;background:linear-gradient(135deg,var(--sh-card),var(--sh-card2));box-shadow:0 18px 55px rgba(0,0,0,.18);padding:1.25rem;position:relative;overflow:hidden}
.server-form:before{content:"";position:absolute;inset:-2px;background:radial-gradient(650px 250px at 25% 0%, var(--sh-glow), transparent 60%),radial-gradient(520px 220px at 90% 15%, rgba(255,56,255,.14), transparent 60%);pointer-events:none}
.server-form>*{position:relative}
</style>
