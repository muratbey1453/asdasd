<section class="fp-section-page fp-products-page">
    <div class="container">
        <div class="fp-breadcrumb">
            <ul class="list-inline list-unstyled mb-0 list">
                <li><a href="#" class="link">Tüm Kategoriler</a></li>
                <li><a href="#" class="link active"><?= $categories->name ?></a></li>
            </ul>
        </div>
        <div class="row">
            <div class="col-lg-3">
                <div class="fp-products-category-info">
                    <img src="<?= base_url('assets/img/category/') . $categories->img ?>" alt="" class="img-products">
                    <div class="content">
                        <h1 class="title"><?= $categories->name ?></h1>
                        <p><?= $categories->description ?></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-9">
                <div class="row row-products">
                    <?php
                    $category_id = $categories->id;

                    $this->db->select('*');
                    $this->db->from('category');
                    $this->db->where('mother_category_id', $category_id);
                    $subCategories = $this->db->get()->result();
                    ?>

                        <?php foreach ($subCategories as $subCategory) { ?>
                            <div class="col-6 col-md-4 col-lg-3 col-xl-3">
                                <a href="<?= base_url('kategori/' . $subCategory->slug) ?>" class="fp-categories-item">
                                    <div class="img">
                                        <?php if (!empty($subCategory->img)) { ?>
                                            <img src="<?= base_url('assets/img/category/' . $subCategory->img) ?>" alt="<?= $subCategory->name ?>">
                                        <?php } ?>
                                    </div>
                                    <div class="name"><?= $subCategory->name ?></div>
                                </a>
                            </div>
                        <?php } ?>

                <?php foreach($products as $product) { ?>
                    <div class="col-6 col-md-4 col-lg-3 col-xl-3">
                        <div class="fp-product-item">
                            <a class="img" href="<?= base_url($product->slug); ?>">
                                <img src="<?= base_url('assets/img/product/' . $product->img); ?>" alt="<?= $product->name; ?>" class="img-product img-aspect">
                            </a>
                            <div class="content">
                                <a class="product-name" href="<?= base_url($product->slug); ?>">
                                    <?= $product->name; ?>
                                </a>
                                <div class="price">
                                    <?php if ($product->discount > 0): ?>
                                        <div class="price-old"><?= number_format($product->price, 2); ?> TL</div>
                                        <div class="price-new"><?= number_format($product->discount, 2); ?> TL</div>
                                    <?php else: ?>
                                        <div class="price-new"><?= number_format($product->price, 2); ?> TL</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="buttons">
                                <?php if ($product->isStock == 1 && $properties->isStock == 1){ ?>
                                    <a href="#" class="btn btn-success" id="addItem<?=$product->id?>" onclick="addItem(<?=$product->id?>)"><i class="ri-shopping-cart-2-line me-1 fs-16"></i> Sepete Ekle</a>
                                <?php }else{ ?>
                                    <a href="<?=base_url($product->slug)?>" class="btn btn-success"> Ürünü İncele</a>
                                <?php } ?>
                                <a href="<?= base_url($product->slug); ?>" class="btn btn-primary"><i class="ri-coin-line me-1 fs-16"></i> Satın Al</a>
                            </div>
                            <input type="number" class="form-control d-none" min="1" value="1" name="amount" id="amount<?=$product->id?>">
                        </div>
                    </div>
                <?php } ?>
                <?php $comments = $this->db->where('isActive', 1)->limit(10)->get('product_comments')->result(); ?>
                <div class="fp-card fp-card-comments">
                    <div class="fp-card-body">
                        <h4 class="title">Yorumlar <span class="fw-normal">(<?= $this->db->where('isActive', 1)->count_all_results('product_comments'); ?>)</span></h4>
                        <?php if (!empty($history)) { ?>
                            <div class="fp-comments-total">
                                <div class="text">Toplam Puan <span class="fw-medium">(<?= calculateAverageRating($comments); ?>)</span></div>
                                <div class="fp-stars">
                                    <?php
                                    $averageStars = calculateAverageRating($comments);
                                    $filledStars = floor($averageStars);
                                    $emptyStars = 5 - $filledStars;
                                    for ($i = 0; $i < $filledStars; $i++) {
                                        echo '<i class="ri-star-fill"></i>';
                                    }
                                    for ($i = 0; $i < $emptyStars; $i++) {
                                        echo '<i class="ri-star-line"></i>';
                                    }
                                    ?>
                                </div>
                            </div>
                            <?php foreach ($history as $comment) { ?>
                                <?php $user = $this->db->where('id', $comment->user_id)->get('user')->row(); ?>
                                <div class="fp-comment-item">
                                    <div class="user">
                                        <div class="name"><?= $user->name . " " . $user->surname ?></div>
                                        <div class="fp-stars">
                                            <?php
                                            $filledStars = $comment->star;
                                            $emptyStars = 5 - $filledStars;
                                            for ($i = 0; $i < $filledStars; $i++) {
                                                echo '<i class="ri-star-fill"></i>';
                                            }
                                            for ($i = 0; $i < $emptyStars; $i++) {
                                                echo '<i class="ri-star-line"></i>';
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <p class="text"><?= $comment->comment ?></p>
                                        <div class="date"><?= $comment->date ?></div>
                                    </div>
                                </div>
                            <?php } ?>
                        <?php } else { ?>
                            <p>Henüz yorum bulunmamaktadır.</p>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script>
    function addItem(productId) {
        var extras = {};
        extras.name1 = $("#extras1").attr("name");
        extras.number1 = $("#extras1").val();
        extras.name2 = $("#extras2").attr("name");
        extras.number2 = $("#extras2").val();
        extras.name3 = $("#extras3").attr("name");
        extras.number3 = $("#extras3").val();
        var amount = $("#amount"+productId).val();
        $.post({
            url: "<?= base_url('home/addToCartItem'); ?>",
            type: "POST",
            data: {"id": productId, "extras": extras, "amount": amount},
            success:function(e){
                $("#cart").html(e);
                $('#addItem' + productId).html('Sepete Eklendi');
                setTimeout(function() {
                    $('#addItem' + productId).html('Sepete Ekle');
                }, 500);
            }
        });
        $.ajax({
            url: "<?= base_url('API/getCartAmount'); ?>",
            type: "POST",
            data: {},
            success:function(amount){
                $('#MobileNavbarCart').html('Sepet (' + amount + ')');
            }
        });
    }
</script>