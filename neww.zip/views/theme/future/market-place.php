<section class="fp-section-page" style="padding-top: 2.5rem; padding-bottom: 2.5rem;">
    <div class="container">
        <div class="d-flex align-items-center justify-content-between mb-4">
            <h1 class="title mb-0" style="font-size:26px">İlan Pazarı</h1>
                  <!-- Ürün Ekle (sağ üst) -->
        <a href="/client/urun-ekle" class="btn btn-success">
            <i class="ri-add-line me-2"></i> Ürün Ekle
        </a>
            <button class="btn btn-primary d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#filterSidebar">
                <i class="ri-filter-3-line me-2"></i> Filtreler
            </button>
        </div>

        <div class="row g-4">
            <!-- Filter Sidebar -->
            <div class="col-lg-3">
                <div class="offcanvas-lg offcanvas-start" tabindex="-1" id="filterSidebar">
                    <div class="offcanvas-header d-lg-none border-bottom">
                        <h5 class="offcanvas-title fw-bold">Filtreler</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
                    </div>
                    <div class="offcanvas-body p-lg-0">
                        <!-- Filter Card -->
                        <div class="marketplace-filter-card">
                            <form method="get" action="<?= base_url('ilan-pazari') ?>" id="filterForm">
                                <!-- Search -->
                                <div class="filter-section">
                                    <label class="filter-label">
                                        <i class="ri-search-line me-2"></i>Ürün Ara
                                    </label>
                                    <div class="input-group">
                                        <input type="text" class="form-control" name="search" placeholder="Ürün adı yazın..." value="<?= $this->input->get('search') ?>">
                                        <button class="btn btn-outline-secondary" type="submit">
                                            <i class="ri-search-line"></i>
                                        </button>
                                    </div>
                                </div>

                                <!-- Category Filter -->
                                <div class="filter-section">
                                    <label class="filter-label">
                                        <i class="ri-folder-line me-2"></i>Kategori
                                    </label>
                                    <div class="category-badges">
                                        <?php 
                                        $selectedCategory = $this->input->get('category');
                                        ?>
                                        <label class="category-badge <?= empty($selectedCategory) ? 'active' : '' ?>">
                                            <input type="radio" name="category" value="" <?= empty($selectedCategory) ? 'checked' : '' ?> hidden>
                                            <span>Tümü</span>
                                        </label>
                                        <?php foreach($categories as $cat): ?>
                                            <label class="category-badge <?= $selectedCategory == $cat->id ? 'active' : '' ?>">
                                                <input type="radio" name="category" value="<?= $cat->id ?>" <?= $selectedCategory == $cat->id ? 'checked' : '' ?> hidden>
                                                <span><?= $cat->name ?></span>
                                            </label>
                                        <?php endforeach; ?>
                                    </div>
                                </div>

                                <!-- Price Range -->
                                <div class="filter-section">
                                    <label class="filter-label">
                                        <i class="ri-price-tag-3-line me-2"></i>Fiyat Aralığı
                                    </label>
                                    <div class="row g-2">
                                        <div class="col-6">
                                            <input type="number" class="form-control" name="min_price" placeholder="Min ₺" value="<?= $this->input->get('min_price') ?>" step="0.01">
                                        </div>
                                        <div class="col-6">
                                            <input type="number" class="form-control" name="max_price" placeholder="Max ₺" value="<?= $this->input->get('max_price') ?>" step="0.01">
                                        </div>
                                    </div>
                                </div>

                                <!-- Seller Type -->
                                <div class="filter-section">
                                    <label class="filter-label">
                                        <i class="ri-store-line me-2"></i>Satıcı Tipi
                                    </label>
                                    <div class="filter-checkbox-group">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="seller_type[]" value="user" id="sellerUser" <?= in_array('user', (array)$this->input->get('seller_type')) ? 'checked' : '' ?>>
                                            <label class="form-check-label" for="sellerUser">
                                                Kullanıcı Satıcılar
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="seller_type[]" value="official" id="sellerOfficial" <?= in_array('official', (array)$this->input->get('seller_type')) ? 'checked' : '' ?>>
                                            <label class="form-check-label" for="sellerOfficial">
                                                Resmi Mağaza
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <!-- Sort -->
                                <div class="filter-section">
                                    <label class="filter-label">
                                        <i class="ri-sort-desc me-2"></i>Sıralama
                                    </label>
                                    <select class="form-select" name="sort">
                                        <option value="">Varsayılan</option>
                                        <option value="price_asc" <?= $this->input->get('sort') == 'price_asc' ? 'selected' : '' ?>>Fiyat: Düşükten Yükseğe</option>
                                        <option value="price_desc" <?= $this->input->get('sort') == 'price_desc' ? 'selected' : '' ?>>Fiyat: Yüksekten Düşüğe</option>
                                        <option value="newest" <?= $this->input->get('sort') == 'newest' ? 'selected' : '' ?>>En Yeni</option>
                                    </select>
                                </div>

                                <!-- Action Buttons -->
                                <div class="filter-actions">
                                    <button type="submit" class="btn btn-primary w-100 mb-2">
                                        <i class="ri-checkbox-circle-line me-2"></i>Filtrele
                                    </button>
                                    <a href="<?= base_url('ilan-pazari') ?>" class="btn btn-outline-secondary w-100">
                                        <i class="ri-refresh-line me-2"></i>Filtreleri Temizle
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Products Grid -->
            <div class="col-lg-9">
                <div class="row row-products">
                    <?php if(empty($products)): ?>
                        <div class="col-12">
                            <div class="alert alert-info text-center">
                                <i class="ri-information-line fs-1"></i>
                                <h4 class="mt-2">Ürün Bulunamadı</h4>
                                <p>Aradığınız kriterlere uygun ürün bulunamadı.</p>
                            </div>
                        </div>
                    <?php else: ?>
                        <?php foreach ($products as $p) { ?>
                            <div class="col-6 col-md-4 col-lg-3">
                                <div class="fp-product-item marketplace-item">
                                    <div style="position: relative;">
                                        <?php if (!empty($p->server_id) && (int)$p->server_id > 0): ?>
                                            <a href="<?= base_url('sunucular/detay/') . (int)$p->server_id ?>" class="server-product-badge" title="Sunucu ürünü">
                                                <i class="ri-server-line"></i> Sunucu
                                            </a>
                                        <?php endif; ?>
                                        <a class="img-container" href="<?= base_url($p->slug) ?>">
                                            <img src="<?= base_url('assets/img/product/') . $p->img ?>" alt="Ürün Resmi" class="img-product img-aspect">
                                        </a>
                                        
                                        <?php 
                                        $seller = null;
                                        if($p->seller_id > 0) {
                                            $seller = $this->db->where('id', $p->seller_id)->get('user')->row();
                                        }
                                        ?>

                                        <?php if($seller && !empty($seller->name)): ?>
                                            <div onclick="window.location.href='<?= base_url('magaza/') . $seller->shop_slug ?>'" class="seller-badge-overlay" style="bottom: 10px !important; cursor: pointer;">
                                                <?php if($seller->shop_img): ?>
                                                    <img src="<?= base_url('assets/img/shop/') . $seller->shop_img ?>" alt="Shop" class="shop-avatar">
                                                <?php else: ?>
                                                    <i class="ri-user-3-line"></i>
                                                <?php endif; ?>
                                                <span><?= $seller->shop_name ? $seller->shop_name : ($seller->name . ' ' . $seller->surname) ?></span>
                                            </div>
                                        <?php else: ?>
                                            <div class="seller-badge-overlay official" style="bottom: 10px !important;">
                                                <i class="ri-shield-check-line"></i>
                                                <span>Resmi</span>
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    <div class="content">
                                        <a class="product-name" href="<?= base_url($p->slug) ?>"><?= $p->name ?></a>

                                        <div class="price">
                                            <?php 
                                                $price = json_decode(calculatePrice($p->id, 1), true);
                                            ?>
                                            <?php if ($price['isDiscount'] == 1) { ?>
                                                <div class="price-new"><?= $price['price'] ?> TL</div>
                                                <div class="price-old"><?= $price['normalPrice'] ?> TL</div>
                                            <?php } else { ?>
                                                <div class="price-new"><?= $price['price'] ?> TL</div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    <?php endif; ?>
                </div>

                <div class="pagination mt-4">
                    <?= $this->pagination->create_links(); ?>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
/* Marketplace Filter Card */
.marketplace-filter-card {
    background: var(--card-bg, #ffffff);
    border: 1px solid var(--border, #e5e7eb);
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease;
}

.marketplace-filter-card:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
}

/* Filter Sections */
.filter-section {
    margin-bottom: 1.5rem;
    padding-bottom: 1.5rem;
    border-bottom: 1px solid var(--border, #e5e7eb);
}

.filter-section:last-of-type {
    border-bottom: none;
    margin-bottom: 0;
    padding-bottom: 0;
}

/* Filter Labels */
.filter-label {
    display: flex;
    align-items: center;
    font-weight: 600;
    font-size: 0.9rem;
    color: var(--text-primary, #1f2937);
    margin-bottom: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.filter-label i {
    color: var(--primary, #3b82f6);
    font-size: 1.1rem;
}

/* Checkbox Group */
.filter-checkbox-group {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
}

.filter-checkbox-group .form-check {
    padding-left: 1.75rem;
    margin-bottom: 0;
}

.filter-checkbox-group .form-check-label {
    font-size: 0.9rem;
    color: var(--text-secondary, #6b7280);
    cursor: pointer;
    user-select: none;
}

.filter-checkbox-group .form-check-input:checked ~ .form-check-label {
    color: var(--text-primary, #1f2937);
    font-weight: 500;
}

/* Filter Actions */
.filter-actions {
    margin-top: 1.75rem;
    padding-top: 1.5rem;
    border-top: 1px solid var(--border, #e5e7eb);
}

/* Form Controls Enhancement */
.marketplace-filter-card .form-control,
.marketplace-filter-card .form-select {
    border: 1px solid var(--input-border, #d1d5db);
    border-radius: 8px;
    padding: 0.625rem 0.875rem;
    font-size: 0.9rem;
    transition: all 0.2s ease;
}

.marketplace-filter-card .form-control:focus,
.marketplace-filter-card .form-select:focus {
    border-color: var(--primary, #3b82f6);
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

.marketplace-filter-card .form-control::placeholder {
    color: var(--placeholder, #9ca3af);
}

/* Input Group Enhancement */
.marketplace-filter-card .input-group .btn {
    border-radius: 0 8px 8px 0;
    border-left: none;
}

.marketplace-filter-card .input-group .form-control {
    border-radius: 8px 0 0 8px;
}

/* Button Enhancements */
.marketplace-filter-card .btn {
    border-radius: 8px;
    padding: 0.625rem 1.25rem;
    font-weight: 500;
    font-size: 0.9rem;
    transition: all 0.2s ease;
}

.marketplace-filter-card .btn-primary {
    background: linear-gradient(135deg, var(--primary, #3b82f6) 0%, var(--primary-dark, #2563eb) 100%);
    border: none;
}

.marketplace-filter-card .btn-primary:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
}

.marketplace-filter-card .btn-outline-secondary {
    border: 1px solid var(--border, #d1d5db);
    color: var(--text-secondary, #6b7280);
}

.marketplace-filter-card .btn-outline-secondary:hover {
    background: var(--hover-bg, #f3f4f6);
    border-color: var(--border-hover, #9ca3af);
    color: var(--text-primary, #1f2937);
}

/* Dark Theme Support */
html[data-theme="dark"] .marketplace-filter-card {
    background: var(--card-bg, #1f2937);
    border-color: var(--border, #374151);
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
}

html[data-theme="dark"] .marketplace-filter-card:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
}

html[data-theme="dark"] .filter-section {
    border-color: var(--border, #374151);
}

html[data-theme="dark"] .filter-label {
    color: var(--text-primary, #f9fafb);
}

html[data-theme="dark"] .filter-checkbox-group .form-check-label {
    color: var(--text-secondary, #d1d5db);
}

html[data-theme="dark"] .filter-checkbox-group .form-check-input:checked ~ .form-check-label {
    color: var(--text-primary, #f9fafb);
}

html[data-theme="dark"] .filter-actions {
    border-color: var(--border, #374151);
}

html[data-theme="dark"] .marketplace-filter-card .form-control,
html[data-theme="dark"] .marketplace-filter-card .form-select {
    background: var(--input-bg, #374151);
    border-color: var(--input-border, #4b5563);
    color: var(--text-primary, #f9fafb);
}

html[data-theme="dark"] .marketplace-filter-card .form-control::placeholder {
    color: var(--placeholder, #6b7280);
}

html[data-theme="dark"] .marketplace-filter-card .btn-outline-secondary {
    border-color: var(--border, #4b5563);
    color: var(--text-secondary, #d1d5db);
}

html[data-theme="dark"] .marketplace-filter-card .btn-outline-secondary:hover {
    background: var(--hover-bg, #374151);
    border-color: var(--border-hover, #6b7280);
    color: var(--text-primary, #f9fafb);
}

/* Mobile Responsiveness */
@media (max-width: 991.98px) {
    .marketplace-filter-card {
        padding: 1.25rem;
    }
    
    .filter-section {
        margin-bottom: 1.25rem;
        padding-bottom: 1.25rem;
    }
}

.marketplace-item {
    position: relative;
}

.marketplace-item .img-container {
    position: relative;
    display: block;
}

.seller-badge-overlay {
    position: absolute;
    bottom: 40px !important;
    left: 8px;
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 6px 10px;
    background: rgba(255, 140, 0, 0.85);
    backdrop-filter: blur(10px);
    border-radius: 5px;
    font-size: 12px;
    color: #fff;
    font-weight: 500;
    z-index: 2;
    transition: all 0.2s ease;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
}

.seller-badge-overlay i {
    font-size: 16px;
}

.seller-badge-overlay .shop-avatar {
    width: 18px;
    height: 18px;
    border-radius: 50%;
    object-fit: cover;
}

.seller-badge-overlay span {
    max-width: 100px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.seller-badge-overlay.official {
    background: linear-gradient(135deg, rgba(102, 126, 234, 0.95) 0%, rgba(118, 75, 162, 0.95) 100%);
}

.marketplace-item:hover .seller-badge-overlay {
    transform: scale(1.05);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
}

html[data-theme="dark"] .seller-badge-overlay {
    background: rgba(255, 140, 0, 0.95);
    backdrop-filter: blur(10px);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.5);
}

html[data-theme="dark"] .seller-badge-overlay.official {
    background: linear-gradient(135deg, rgba(102, 126, 234, 0.98) 0%, rgba(118, 75, 162, 0.98) 100%);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.5);
}

/* Eşit yükseklikli kartlar için */
.row-products {
    display: flex;
    flex-wrap: wrap;
}

.row-products > [class*="col-"] {
    display: flex;
}

.row-products .fp-product-item {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
}

.row-products .fp-product-item .content {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

/* Görsel oranı sabit tut */
.row-products .img-container {
    aspect-ratio: 3 / 4;
    overflow: hidden;
    display: block;
}

.row-products .img-container .img-product {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

/* Kategori Badge Stilleri */
.category-badges {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.category-badge {
    display: inline-flex;
    align-items: center;
    padding: 6px 12px;
    background: var(--bg-secondary, #f3f4f6);
    border: 1px solid var(--border, #e5e7eb);
    border-radius: 20px;
    font-size: 0.85rem;
    color: var(--text-secondary, #6b7280);
    cursor: pointer;
    transition: all 0.2s ease;
    user-select: none;
}

.category-badge:hover {
    background: var(--primary-light, #dbeafe);
    border-color: var(--primary, #3b82f6);
    color: var(--primary, #3b82f6);
}

.category-badge.active {
    background: var(--primary, #3b82f6);
    border-color: var(--primary, #3b82f6);
    color: #fff;
}

.category-badge.active:hover {
    background: var(--primary-dark, #2563eb);
}

/* Dark theme */
html[data-theme="dark"] .category-badge {
    background: var(--bg-secondary, #374151);
    border-color: var(--border, #4b5563);
    color: var(--text-secondary, #d1d5db);
}

html[data-theme="dark"] .category-badge:hover {
    background: var(--primary-light, rgba(59, 130, 246, 0.2));
    border-color: var(--primary, #3b82f6);
    color: var(--primary, #60a5fa);
}

html[data-theme="dark"] .category-badge.active {
    background: var(--primary, #3b82f6);
    border-color: var(--primary, #3b82f6);
    color: #fff;
}
/* ===== Price Box (modern) ===== */
.fp-product-item .price-box{
  margin-top: 8px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;

  padding: 10px 12px;
  border-radius: 16px;

  /* arkaplan verme yok: kart temasını bozmasın */
  position: relative;
  overflow: hidden;
}

/* İnce çerçeve: yazı rengine göre uyum (dark/light) */
.fp-product-item .price-box::after{
  content:"";
  position:absolute;
  inset:0;
  border-radius: 16px;
  border: 1px solid currentColor;
  opacity: .10;
  pointer-events:none;
}

/* indirim rozeti */
.fp-product-item .price-badge{
  font-size: 10px;
  font-weight: 900;
  letter-spacing: .4px;
  padding: 6px 8px;
  border-radius: 999px;
  position: relative;
  opacity: .95;
  white-space: nowrap;
}

/* rozet çerçevesi */
.fp-product-item .price-badge::after{
  content:"";
  position:absolute;
  inset:0;
  border-radius: 999px;
  border: 1px solid currentColor;
  opacity: .18;
  pointer-events:none;
}

/* fiyat satırı */
.fp-product-item .price-main{
  min-width: 0;
  display:flex;
  align-items: baseline;
  gap: 10px;
  margin-left: auto;
}

.fp-product-item .price-now{
  font-size: 16px;
  font-weight: 900;
  line-height: 1;
  white-space: nowrap;
}

.fp-product-item .price-now small{
  font-size: 11px;
  font-weight: 800;
  opacity: .65;
}

.fp-product-item .price-was{
  font-size: 12px;
  opacity: .55;
  text-decoration: line-through;
  white-space: nowrap;
}

/* ===== Single Buy Button (modern) ===== */
.fp-product-item .buttons{
  margin-top: 10px;
}

.fp-product-item .btn-buy{
  width: 100%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;

  padding: 11px 12px;
  border-radius: 16px;

  text-decoration: none;
  color: #fff;

  background: linear-gradient(135deg, #0004ff69, #b9e0faff);
  box-shadow: 0 14px 30px rgba(0,0,0,.22);

  font-weight: 900;
  letter-spacing: .2px;

  transition: transform .18s ease, box-shadow .18s ease, filter .18s ease;
}

.fp-product-item .btn-buy:hover{
  transform: translateY(-1px);
  box-shadow: 0 18px 38px rgba(0,0,0,.28);
  filter: saturate(1.1);
}

.fp-product-item .btn-buy .btn-arrow{
  display:inline-flex;
  align-items:center;
  justify-content:center;
  width: 30px;
  height: 30px;
  border-radius: 12px;
  background: rgba(255,255,255,.18);
}

.fp-product-item .btn-buy:hover .btn-arrow{
  transform: translateX(2px);
  transition: transform .18s ease;
}
/* PRICE BOX: neon kayan çerçeve + hafif glow */
.fp-product-item .price-box{
  position: relative;
  isolation: isolate; /* glow düzgün dursun */
}

/* eski gri çerçeveyi iptal et */
.fp-product-item .price-box::after{
  border: none !important;
}

/* neon kayan border */
.fp-product-item .price-box::after{
  content: "";
  position: absolute;
  inset: 0;
  padding: 1px;               /* border kalınlığı */
  border-radius: 16px;

  background: linear-gradient(90deg,
    rgba(255, 0, 214, .95),
    rgba(0, 255, 195, .85),
    rgba(0, 140, 255, .85),
    rgba(255, 0, 214, .95)
  );
  background-size: 300% 100%;
  animation: sellerBorderFlow 2.2s linear infinite;

  -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
  -webkit-mask-composite: xor;
  mask-composite: exclude;

  filter:
    drop-shadow(0 0 10px rgba(255, 0, 214, .16))
    drop-shadow(0 0 10px rgba(0, 255, 195, .10));

  opacity: .85;
  pointer-events: none;
  z-index: 1;
}

/* glow katmanı (çok abartmadan) */
.fp-product-item .price-box::before{
  content: "";
  position: absolute;
  inset: -6px;
  border-radius: 18px;
  background: linear-gradient(135deg,
    rgba(255, 0, 214, .22),
    rgba(0, 255, 195, .16),
    rgba(0, 140, 255, .14)
  );
  filter: blur(14px);
  opacity: .35;
  pointer-events: none;
  z-index: 0;
}

/* içerik üstte kalsın */
.fp-product-item .price-box > *{
  position: relative;
  z-index: 2;
}

/* hover'da biraz daha parlak */
.fp-product-item .price-box:hover::after{ opacity: .98; }
.fp-product-item .price-box:hover::before{ opacity: .50; }

/* Animasyon (seller-line ile aynı kullanılıyor) */
@keyframes sellerBorderFlow{
  0%   { background-position:   0% 50%; }
  100% { background-position: 100% 50%; }
}

/* Hareket azaltma */
@media (prefers-reduced-motion: reduce){
  .fp-product-item .price-box::after{ animation: none; }
}
/* Tüm ürünlerde fiyat kutusu aynı yükseklik */
.fp-product-item .price-box{
  min-height: 15px;       /* hepsini eşitler */
  align-items: center;
}



/* Eski fiyat satırı her zaman aynı yükseklik tutsun */
.fp-product-item .price-was{
  display: block;
  line-height: 1;
  min-height: 22px;     /* yer sabitle */
}

/* İndirim yoksa badge ve eski fiyat görünmesin ama yer tutsun */
.fp-product-item .price-box.no-discount .price-badge{
  visibility: hidden;
}

.fp-product-item .price-box.no-discount .price-was{
  visibility: hidden;
}


</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Kategori badge'lerine tıklama olayı ekle
    document.querySelectorAll('.category-badge').forEach(function(badge) {
        badge.addEventListener('click', function() {
            // Radio'yu seç
            var radio = this.querySelector('input[type="radio"]');
            if (radio) {
                radio.checked = true;
                // Formu bul ve submit et
                var form = this.closest('form');
                if (form) {
                    form.submit();
                }
            }
        });
    });
});
</script>