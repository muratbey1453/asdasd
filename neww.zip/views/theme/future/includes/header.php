<?php $properties = $this->db->where('id', 1)->get('properties')->row(); ?>
<?php $amount = 0; ?>
<?php foreach ($this->advanced_cart->contents() as $items){
    $amount = $amount + $items['price'] * $items['qty'];
}

if (!empty($this->session->userdata('info')['id'])){
    $notifications = getNotification($this->session->userdata('info')['id']);
}else{
    $notifications = [];
}

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="title" content="<?= $properties->title ?>">
    <meta name="description" content="<?= (!empty($meta)) ? $meta->meta : $properties->description ?>">
    <meta name="robots" content="index, follow">
    <meta http-equiv="Content-Type" content="text/html; charset=utf8">
    <meta name="language" content="Turkish">
    <title><?= (!empty($title)) ? $title : $properties->title  ?></title>
    <script src="<?= base_url('assets/' . $properties->theme) ?>/js/jquery.min.js"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/38.1.0/classic/ckeditor.js"></script>
    <link rel="stylesheet" href="<?= base_url('assets/' . $properties->theme) ?>/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/' . $properties->theme) ?>/css/swiper-bundle.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/' . $properties->theme) ?>/css/style.css?v=<?= time() ?>">
    <link rel="stylesheet" href="<?= base_url('assets/' . $properties->theme) ?>/css/sweetalert2.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/' . $properties->theme) ?>/fonts/gilroy/stylesheet.css?v=64">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.6.0/fonts/remixicon.css" rel="stylesheet">
    <script type="text/javascript">
        var baseURL = "<?= base_url() ?>";
    </script>
    <script src="<?= base_url('assets/' . $properties->theme) ?>/js/shop.js"></script>
    <?= $properties->google_analytics ?>

<style>
/* =========================
   SUNUCU ÜRÜNÜ ETİKETİ (kartlarda sol üst)
   ========================= */
.server-product-badge{
  position:absolute;
  top: 10px;
  left: 10px;
  z-index: 6;
  display:inline-flex;
  align-items:center;
  gap: 6px;
  padding: 6px 10px;
  border-radius: 999px;
  border: 1px solid rgba(255,255,255,.16);
  background: rgba(0,0,0,.45);
  color:#fff;
  font-weight: 950;
  font-size: 12px;
  text-decoration:none;
  backdrop-filter: blur(10px);
  transition: .18s ease;
}
.server-product-badge:hover{
  transform: translateY(-1px);
  filter: brightness(1.08);
}
.server-product-badge i{ font-size: 14px; opacity:.95; }

html[data-theme="light"] .server-product-badge,
body[data-theme="light"] .server-product-badge{
  background:#fff;
  color:#0f172a;
  border: 1px solid rgba(0,0,0,.10);
  backdrop-filter:none;
}

/* =========================
   ÜRÜN KARTI BAŞLIK SABİTLEME (SADECE BAŞLIK)
   (height:100% vermiyoruz; fiyat/buton kaybolmasın)
   ========================= */
.fp-product-item .product-name{
  display:-webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow:hidden;
  min-height: 44px; /* 2 satır */
}
</style>

</head>
<body>

<?php $alertMessage = alert(); ?>
<?php if (!empty($alertMessage)): ?>
<div class="bs-example" id="toastArea">
    <div style="position: fixed; z-index: 9999; top: 80px; right: 20px;">
        <div class="alert alert-primary alert-dismissible fade show" role="alert" style="min-width: 300px;">
            <?= $alertMessage ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Kapat"></button>
        </div>
    </div>
</div>
<?php endif; ?>
<div class="top-note glow">
  🚀 Ocak 2026 itibarıyla Roypin’in yönetimi devredilmiştir. Güncel stoklarla satışlarımız başlamıştır.
</div>


<div class="fp-topnav-ry">
    <div class="container">
        <div class="flex">

            <div class="flex-item left">
                <a href="https://instagram.com/roypincom" class="instagram">
                    <div class="icon"><i class="ri-instagram-line"></i></div>
                    <div class="text">Bizi Takip Edin!</div>
                </a>
            </div>

            <script>
                document.addEventListener("DOMContentLoaded", function() {
                    fetch('https://api.exchangerate-api.com/v4/latest/USD')
                        .then(response => {
                            if (!response.ok) {
                                throw new Error('Network response was not ok');
                            }
                            return response.json();
                        })
                        .then(data => {
                            const usdTryRate = data.rates.TRY;
                            const formattedRate = usdTryRate.toFixed(4);
                            document.getElementById('usdtry').textContent = formattedRate;
                        })
                        .catch(error => {
                            console.error('There has been a problem with your fetch operation:', error);
                            document.getElementById('usdtry').textContent = '...';
                        });
                });
            </script>

            <div class="flex-item">
                <ul class="list-unstyled mb-0 list right">
                    <li><a href="<?= base_url('sayfa/yardim') ?>"><i class="ri-questionnaire-line"></i> Yardım</a></li>
                    <li><a href="<?= base_url('sayfa/iletisim') ?>"><i class="ri-phone-line"></i> İletişim</a></li>
                    <li><a href="<?= base_url('client/balance') ?>"><i class="ri-add-line"></i> Bakiye Yükle</a></li>
                    <li>
                        <div class="fp-color-selector">
                            <a href="#" class="link link-light-theme"><i class="ri-sun-line"></i></a>
                            <a href="#" class="link link-dark-theme"><i class="ri-moon-line"></i></a>
                        </div>
                    </li>
                </ul>
            </div>

        </div>
    </div>
</div>


<header class="fp-header">
    <div class="container">
        <div class="grid">
            <div class="logo-area">
                <a href="<?= base_url(); ?>" class="logo dark"><img src="<?= base_url('assets/future/img/roy-logo-dark.png'); ?>" alt=""></a>
                <a href="<?= base_url(); ?>" class="logo white"><img src="<?= base_url('assets/future/img/roy-logo-light.png'); ?>" alt=""></a>
            </div>
            <div class="search">
                <div class="search-box">
                    <input type="text" class="form-control rounded-pill" placeholder="Valorant hesap, Lol RP veya çeşitli ürün ara..." id="searchInput" onfocusout="disable_form()" oninput="search_form()" autocomplete="off">
                    <i class="ri-search-line icon"></i>
                </div>
                <div class="search-results d-none" id="serch-results"></div>
            </div>
            <a href="#" class="btn btn-primary btn-all-categories"><i class="ri-menu-line"></i></a>
            <div class="right-area" id="cart">

                <div class="position-relative">
                    <a href="#" class="right-link notification square primary">
                        <div class="icon"><i class="ri-chat-unread-line"></i></div>
                        <div class="number"><?=count($notifications)?></div>
                    </a>
                    <div class="fp-nav-notification-menu">
                        <div class="fp-nnm-title">Bildirimler</div>
                        <?php foreach ($notifications as $notification){ ?>
                            <?php $notificationManagement = $this->db->where('id', $notification->notification_id)->get('notification_management')->row(); ?>
                            <a class="fp-nnm-item <?= ($notification->seen_at == 1 ? "new" : NULL); ?> notification_link" data-notification-id="<?= $notification->id ?>" href="<?=($notificationManagement ? $notificationManagement->link : $notification->link)?>">
                                <div class="fp-nnm-item-img"><img src="<?=base_url('assets/img/notifications/') . ($notificationManagement ? $notificationManagement->img : 'notification.png');?>" alt=""></div>
                                <div class="fp-nnm-item-content">
                                    <div class="fp-nnm-item-title"><?=($notificationManagement ? $notificationManagement->title : $notification->title)?></div>
                                    <p class="fp-nnm-item-text"><?=($notificationManagement ? $notificationManagement->contents : $notification->contents)?></p>
                                    <div class="fp-nnm-item-date"><?=($notificationManagement ? $notificationManagement->created_at : $notification->created_at)?></div>
                                </div>
                            </a>
                        <?php } ?>
                        <a href="#" class="fp-nnm-link allSetSeen">Tümünü Okundu Olarak İşaretle</a>
                    </div>
                </div>

                <?php $cartCount = count($this->advanced_cart->contents()); ?>
<a href="<?= base_url('sepet') ?>" class="right-link cart-pill success position-relative">
    <div class="icon"><i class="ri-shopping-cart-2-fill"></i></div>
    <div class="label">Sepet</div>
    <span class="badge-count"><?= $cartCount ?></span>
</a>

                </a>

                <?php if (!empty($this->session->userdata('info'))){ ?>
                    <?php $user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row(); ?>
                    <div class="position-relative">
                        <a href="#" class="right-link user fp-dma-toggle">
                            <div class="icon"><i class="ri-user-line"></i></div>
                            <div class="content">
                                <div class="key"><?= $user->name ?></div>
                                <div class="value">Bakiye: <?= $user->balance ?> TL</div>
                            </div>
                            <i class="ri-arrow-down-s-line icon-right"></i>
                        </a>
                        <div class="fp-dropdown-menu-account">
                            <div class="balance-area">
                                <div class="flex">
                                    <div class="key">Güncel Bakiyem</div>
                                    <div class="value">
                                        <?= $user->balance ?> TL
                                    </div>
                                </div>
                                <a href="<?= base_url('client/balance') ?>" class="btn btn-primary btn-sm w-100 m-0">Bakiye Ekle</a>
                            </div>
                            <ul class="list-unstyled mb-0 list-dma">
                                <li><a href="<?= base_url('client') ?>" class="fp-dma-link"><div class="icon"><i class="ri-user-line"></i></div> Hesabım</a></li>
                                <li><a href="<?= base_url('client/product') ?>" class="fp-dma-link"><div class="icon"><i class="ri-shopping-bag-line"></i></div> Siparişlerim</a></li>
                                <li><a href="<?= base_url('client/ticket') ?>" class="fp-dma-link"><div class="icon"><i class="ri-customer-service-2-line"></i></div> Destek</a></li>
                                <li><a href="<?= base_url('client/settings') ?>" class="fp-dma-link"><div class="icon"><i class="ri-settings-3-line"></i></div> Hesap Ayarları</a></li>
                                <li><a href="<?= base_url('client/logout') ?>" class="fp-dma-link"><div class="icon"><i class="ri-logout-box-r-line"></i></div> Güvenli Çıkış</a></li>
                            </ul>
                        </div>
                    </div>
  <?php } else { ?>
  <div class="auth-actions">
    <a href="<?= base_url('hesap') ?>" class="right-link auth-pill position-relative">
      <div class="icon"><i class="ri-login-circle-line"></i></div>
      <div class="label">Giriş Yap</div>
    </a>

    <a href="<?= base_url('hesap?=kayit-ol') ?>" class="right-link auth-pill primary position-relative">
      <div class="icon"><i class="ri-user-add-line"></i></div>
      <div class="label">Kayıt Ol</div>
    </a>
  </div>
<?php } ?>




            </div>
        </div>
    </div>
    
</header>

<nav class="fp-navbar">
    <div class="container">
        <div class="flex-justify">

            <ul class="list-unstyled mb-0 list">
                <li><a href="<?= base_url('tum-kategoriler') ?>" class="link"><i class="ri-apps-2-fill fs-24"></i> Kategoriler</a></li>
                <?php if ($this->db->where('seller_id >', 2)->count_all_results('product') > 0): ?>
                    <li><a href="<?= base_url('ilan-pazari') ?>" class="link animated animated-red"><span class="icon-area"><i class="ri-store-2-line"></i></span>İlan Pazarı</a></li>
                <?php endif ?>
                <?php foreach ($category as $c) { ?>
                    <?php
                    $icons = [
                        'Valorant' => 'valorant.png',
                        'Steam' => 'steams.png',
                        'Brawl Stars' => 'brawl-stars.png',
                        'League of Legends' => 'lol-tr.png',
                        'PUBG Mobile' => 'pubg-mobile.png',
                        'Growtopia' => 'growtopia.png',
                        'Minecraft' => 'mc.png',
                        'Pazar' => 'royfavicon.png'
                    ];

                    $linkClass = 'link-' . strtolower(str_replace(' ', '-', $c->name));
                    ?>
                    <?php if ($this->db->where('isActive', 1)->where('isMenu', 1)->where('mother_category_id', $c->id)->count_all_results('category') > 0){ ?>
                        <li class="fp-navbar-dropdown-item">
                            <a href="#" class="link">
                            <span class="icon-area <?= $linkClass ?>">
                                <?php if (isset($icons[$c->name])): ?>
                                    <img src="<?= base_url('assets/future/img/menu-icons/' . $icons[$c->name]) ?>">
                                <?php endif; ?>
                            </span>
                                <?= $c->name == 'Hediye Kartı' ? 'Pazar' : $c->name ?>
                                <i class="ri-arrow-down-s-line icon-dropdown-down"></i>
                            </a>
                            <div class="fp-navbar-dropdown-menu">
                                <div class="container">
                                    <div class="grid-dropdown">
                                        <?php $subCategory = $this->db->where('isActive', 1)->where('isMenu', 1)->where('mother_category_id', $c->id)->get('category')->result(); ?>
                                        <?php foreach ($subCategory as $sc) { ?>
                                            <a class="fp-navbar-dropdown-link" href="<?= base_url('kategori/') . $sc->slug ?>">
                                                <img src="<?= base_url('assets/img/category/') . $sc->img ?>" alt="">
                                                <div class="name"><?= $sc->name ?></div>
                                            </a>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </li>
                    <?php }else{ ?>
                        <li>
                        </li>
                    <?php } }?>
            </ul>

            <ul class="list-unstyled mb-0 list">
                <li><a href="<?= base_url('sunucular') ?>" class="link animated animated-blue"><span class="icon-area"><i class="ri-server-line"></i></span> Sunucular</a></li>
                <li><a href="<?= base_url('tasks') ?>" class="link animated animated-green"><span class="icon-area"><i class="ri-task-line"></i></span> Görevler</a></li>
                <li><a href="<?= base_url('kasalar') ?>" class="link animated animated-red"><span class="icon-area"><i class="ri-gift-fill"></i></span> Kasalar</a></li>
               
            </ul>

        </div>
    </div>
</nav>

<div class="fp-mobile-bar">
    <div class="grid h-100">
        <a href="<?= base_url() ?>" class="link">
            <div class="icon"><i class="ri-home-5-line"></i></div>
            <div class="text">Ana Sayfa</div>
        </a>
        <a href="<?= base_url('tum-kategoriler') ?>" class="link">
            <div class="icon"><i class="ri-menu-line"></i></div>
            <div class="text">Kategoriler</div>
        </a>
        <a href="<?= base_url('sepet') ?>" class="link">
            <div class="icon"><i class="ri-shopping-cart-2-line"></i></div>
            <div class="text" id="MobileNavbarCart">Sepet (<?= count($this->advanced_cart->contents()); ?>)</div>
        </a>
        <a href="<?= base_url('ilan-pazari') ?>" class="link">
            <div class="icon"><i class="ri-store-line"></i></div>
            <div class="text">İlan Pazarı</div>
        </a>
        <a href="<?= !empty($this->session->userdata('info')) ? base_url('client') : base_url('hesap'); ?>" class="link">
            <div class="icon"><i class="ri-user-3-line"></i></div>
            <div class="text">Hesap</div>
        </a>
    </div>
</div>

<script>
    // Tüm .notification_link sınıfına sahip öğeleri seç
    var notificationLinks = document.querySelectorAll('.notification_link');

    // Her bir bildirim linki için tıklama olayını dinle ve .ajax isteği oluştur
    notificationLinks.forEach(function(link) {
        $(link).on('click', function(event) {
            event.preventDefault(); // Varsayılan tıklama davranışını engelle

            var redirectUrl = $(this).attr('href');

            // Tıklanan bildirimin ID'sini al
            var notificationId = $(this).data('notification-id');
            console.log('Tıklanan bildirimin ID\'si: ' + notificationId);

            // AJAX isteği oluştur
            $.ajax({
                type: "POST",
                url: '<?=base_url("API/setSeen")?>',
                data: {notification_id: notificationId},
                success: function(response) {
                    window.location.href = redirectUrl;
                },
                error: function(xhr, status, error) {
                    // Hata
                }
            });
        });
    });

    //tümünü okundu olarak işaretle
    $('.allSetSeen').on('click', function(event) {
        event.preventDefault(); // Varsayılan tıklama davranışını engelle

        // AJAX isteği oluştur
        $.ajax({
            type: "POST",
            url: '<?=base_url("API/setAllSeen")?>',
            success: function(response) {
                console.log(response);
                window.location.href = window.location.href;
                // İşlem başarılı olduysa burada yapılacak işlemleri gerçekleştirin
                console.log('Tüm bildirimler başarıyla okundu.');
            },
            error: function(xhr, status, error) {
                // Hata durumunda burada işlem yapabilirsiniz
                console.error('Bir hata oluştu: ' + error);
            }
        });
    });

</script>
<style>.top-note{
  width:100%;
  min-height:34px;
  padding:8px 12px;

  display:flex;
  align-items:center;
  justify-content:center;

  font-size:13px;
  font-weight:600;
  letter-spacing:.2px;
  text-align:center;
  line-height:1.2;

  color:rgba(255,255,255,.92);

  /* Şık arkaplan */
  background: linear-gradient(90deg,
    rgba(13,110,253,.35),
    rgba(102,16,242,.25),
    rgba(13,110,253,.35)
  );
  border-bottom:1px solid rgba(255,255,255,.10);

  /* Cam efekti */
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
}
.glow{
  animation: glowPulse 2.4s ease-in-out infinite;
}

@keyframes glowPulse{
  0%,100% { text-shadow: 0 0 0 rgba(255,255,255,0); opacity:.92; }
  50%     { text-shadow: 0 0 14px rgba(255,255,255,.25); opacity:1; }
}

@media (prefers-reduced-motion: reduce){
  .glow{ animation:none; }
}
/* Header auth buttons */
.auth-actions{
  display:flex;
  align-items:center;
  gap:10px;
}

.auth-btn{
  display:inline-flex;
  align-items:center;
  gap:8px;
  padding:10px 12px;
  border-radius:14px;
  text-decoration:none;
  font-weight:700;
  font-size:13px;
  border:1px solid var(--border);
  transition: transform .15s ease, border-color .15s ease, background .15s ease, filter .15s ease;
  white-space:nowrap;
}

.auth-btn i{font-size:16px;}

/* Primary-ish (Giriş Yap) */
.auth-login{
  background: linear-gradient(135deg, rgba(59,130,246,.18), rgba(59,130,246,.10));
  color: var(--text-color);
  border-color: rgba(59,130,246,.25);
}
.auth-login:hover{
  transform: translateY(-1px);
  filter: brightness(1.03);
  border-color: rgba(59,130,246,.40);
}

/* Secondary (Kayıt Ol) */
.auth-register{
  background: rgba(0,0,0,.03);
  color: var(--text-color);
}
html[data-theme="dark"] .auth-register{ background: rgba(255,255,255,.04); }

.auth-register:hover{
  transform: translateY(-1px);
  border-color: rgba(16,185,129,.28);
  background: rgba(16,185,129,.06);
}

/* Mobile: çok dar alanda ikon-only yapmak istersen */
@media (max-width: 520px){
  .auth-btn span{display:none;}
  .auth-btn{padding:10px 11px;}
}
/* Header auth buttons */
.auth-actions{
  display:flex;
  align-items:center;
  gap:10px;
}

/* Base button */
.auth-btn{
  display:inline-flex;
  align-items:center;
  gap:8px;
  padding:10px 12px;
  border-radius:14px;
  text-decoration:none;
  font-weight:800;
  font-size:13px;
  border:1px solid var(--border);
  transition: transform .15s ease, border-color .15s ease, background .15s ease, filter .15s ease;
  white-space:nowrap;
}
.auth-btn i{font-size:16px;}

/* Secondary: Giriş Yap (sade) */
.auth-login{
  background: rgba(0,0,0,.03);
  color: var(--text-color);
  border-color: rgba(255,255,255,.0);
}
html[data-theme="dark"] .auth-login{
  background: rgba(255,255,255,.05);
  border-color: rgba(255,255,255,.06);
}
.auth-login:hover{
  transform: translateY(-1px);
  border-color: rgba(59,130,246,.26);
  background: rgba(59,130,246,.06);
}

/* Primary: Kayıt Ol (dikkat çeken) */
.auth-register{
  background: linear-gradient(135deg, rgba(59,130,246,.28), rgba(16,185,129,.20));
  color: var(--text-color);
  border-color: rgba(59,130,246,.28);
  box-shadow: 0 12px 28px rgba(0,0,0,.08);
}
html[data-theme="dark"] .auth-register{
  box-shadow: 0 18px 45px rgba(0,0,0,.28);
}
.auth-register:hover{
  transform: translateY(-1px);
  filter: brightness(1.03);
  border-color: rgba(16,185,129,.30);
}

/* Mobile: çok dar alanda ikon-only */
@media (max-width: 520px){
  .auth-btn span{display:none;}
  .auth-btn{padding:10px 11px;}
}
/* Right-area hizalama (gerekirse) */
.fp-header .right-area{
  display:flex;
  align-items:center;
  gap:10px;
}

/* Hepsini aynı yükseklik/radius */
.fp-header .right-area .right-link,
.fp-header .right-area .auth-pill{
  height:44px;
  border-radius:14px;
}

/* Auth butonları: right-link gibi */
.auth-actions{
  display:flex;
  align-items:center;
  gap:10px;
}

.auth-pill{
  display:inline-flex;
  align-items:center;
  gap:8px;
  padding:0 12px;
  text-decoration:none;
  border:1px solid var(--border);
  background: rgba(0,0,0,.03);
}
html[data-theme="dark"] .auth-pill{
  background: rgba(255,255,255,.05);
}

/* İkon & yazı */
.auth-pill .icon i,
.cart-pill .icon i{
  font-size:18px;
}
.auth-pill .label,
.cart-pill .label{
  font-weight:800;
  font-size:13px;
  color: var(--text-color);
  line-height:1;
}

/* Sepet: ikon + yazı aynı modül */
.cart-pill{
  display:inline-flex;
  align-items:center;
  gap:8px;
  padding:0 12px;
}

/* Sağ üst sayaç (Sepet) */
.badge-count{
  position:absolute;
  top:-6px;
  right:-6px;
  height:18px;
  min-width:18px;
  padding:0 6px;
  border-radius:999px;
  display:inline-flex;
  align-items:center;
  justify-content:center;
  font-size:11px;
  font-weight:900;
  color:#fff;
  background: rgba(59,130,246,.90);
  border:2px solid rgba(255,255,255,.85);
}
html[data-theme="dark"] .badge-count{
  border-color: rgba(20,24,33,.85);
}

/* Bildirim sayacı da aynı stile gelsin (istersen) */
.right-link.notification .number{
  position:absolute;
  top:-6px;
  right:-6px;
  height:18px;
  min-width:18px;
  padding:0 6px;
  border-radius:999px;
  display:inline-flex;
  align-items:center;
  justify-content:center;
  font-size:11px;
  font-weight:900;
  color:#fff;
  background: rgba(59,130,246,.90);
  border:2px solid rgba(255,255,255,.85);
}
html[data-theme="dark"] .right-link.notification .number{
  border-color: rgba(20,24,33,.85);
}

/* Mobilde yer daralırsa yazıları sakla (ikonlar kalsın) */
@media (max-width: 520px){
  .auth-pill .label,
  .cart-pill .label{ display:none; }
  .auth-pill, .cart-pill{ padding:0 11px; }
}

</style>
