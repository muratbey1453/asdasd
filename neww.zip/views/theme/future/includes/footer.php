<footer class="fpn-footer">

    <div class="container">
        <div class="top-area">
            <div class="logo-area">
                <a href="<?= base_url() ?>" class="logo dark"><img src="<?= base_url() ?>assets/future/img/roy-logo-dark.png" alt="" class="img-logo"></a>
                <a href="<?= base_url() ?>" class="logo white"><img src="<?= base_url() ?>assets/future/img/roy-logo-light.png" alt="" class="img-logo"></a>
            </div>
            <div class="right">
                <a href="mailto:destek@roypin.com" class="link-contact"><i class="ri-mail-line"></i> destek@roypin.com</a>
                <a href="https://wa.me/+905458118463" target="_blank" class="link-contact"><i class="ri-whatsapp-line"></i> Destek Hattı!</a>
            </div>
        </div>
    </div>

    <div class="h-links-area">
        <div class="container">
            <ul class="list-unstyled mb-0">
                <li><a href="#">İlan Pazarı</a></li>
                <li><a href="#">Çekilişler</a></li>
                <li><a href="#">Mağazalar</a></li>
                <li><a href="#">Valorant</a></li>
                <li><a href="#">Ürünler</a></li>
                <li><a href="#">Blog</a></li>
                <li><a href="#">Yayıncılar</a></li>
            </ul>
        </div>
    </div>

    <div class="alt-links-area">
        <div class="container">
            <div class="row">

                <div class="col-lg-3">
                    <div class="footer-title">Roypin</div>
                    <ul class="mb-0">
                        <?php foreach ($footerPage as $p) { ?>
                            <li><a href="<?= base_url('sayfa/' . $p->slug); ?>"><?= $p->title ?></a></li>
                        <?php } ?>
                    </ul>
                </div>

                <div class="col-lg-9">
                    <div class="footer-title">Kategoriler</div>
                    <ul class="mb-0 grid-4">
                        <?php
                        $categories = $this->db->where('isActive', 1)->limit(20)->get('category')->result();
                        foreach ($categories as $c): ?>
                            <li><a href="<?= base_url('kategori/') . $c->slug; ?>"><?= $c->name; ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>


            </div>
        </div>
    </div>

    <div class="bottom-area">
        <div class="container">
            <div class="flex">
                <div class="text-copyright"><?= date("Y"); ?> © Roypin tüm hakları saklıdır.</div>
                <img src="<?= base_url('assets/future/img/payments.png') ?>" alt="Ödeme Yöntemleri" class="d-block">
            </div>
        </div>
    </div>

</footer>



<a href="https://wa.me/+905458118463" class="wp-destek" target="_blank">
    <img src="<?= base_url('assets/future/img/roypin-qa-2.png') ?>" alt="Roypin Destek Hattı" style="height:40px">
</a>

<!-- Şans Çarkı Mini Widget -->
<a href="<?= base_url('cark') ?>" class="wheel-widget" id="wheelWidget">
    <div class="wheel-widget-inner">
        <div class="wheel-widget-icon">
            <i class="ri-gift-fill"></i>
        </div>
        <div class="wheel-widget-text">
            <span class="wheel-widget-title">Şans Çarkı</span>
            <span class="wheel-widget-sub" id="wheelWidgetStatus">Çevir & Kazan!</span>
        </div>
    </div>
    <div class="wheel-widget-shine"></div>
</a>

<style>
    .wp-destek {
        position: fixed;
        bottom: 25px;
        right: 25px;
        z-index: 99;
    }
    @media (max-width: 1200px) {
        .wp-destek {
            bottom: 100px;
        }
    }
    
    /* Wheel Widget Styles */
    .wheel-widget {
        position: fixed;
        bottom: 25px;
        left: 25px;
        z-index: 99;
        text-decoration: none;
        display: inline-flex !important;
        align-items: center;
        background: linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%);
        padding: 10px 16px;
        border-radius: 50px;
        box-shadow: 0 8px 25px rgba(139, 92, 246, 0.4);
        transition: all 0.3s ease;
        overflow: hidden;
        max-width: 200px !important;
        width: auto !important;
        flex-shrink: 0 !important;
    }
    
    .wheel-widget:hover {
        transform: translateY(-3px);
        box-shadow: 0 12px 35px rgba(139, 92, 246, 0.5);
    }
    
    .wheel-widget-inner {
        display: flex;
        align-items: center;
        gap: 10px;
        position: relative;
        z-index: 1;
    }
    
    .wheel-widget-icon {
        width: 36px;
        height: 36px;
        background: rgba(255,255,255,0.2);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        animation: pulse-icon 2s ease-in-out infinite;
    }
    
    .wheel-widget-icon i {
        color: #fff;
        font-size: 20px;
    }
    
    @keyframes pulse-icon {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.1); }
    }
    
    .wheel-widget-text {
        display: flex;
        flex-direction: column;
    }
    
    .wheel-widget-title {
        color: #fff;
        font-weight: 700;
        font-size: 13px;
    }
    
    .wheel-widget-sub {
        color: rgba(255,255,255,0.8);
        font-size: 11px;
    }
    
    .wheel-widget-shine {
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
        animation: shine 3s ease-in-out infinite;
    }
    
    @keyframes shine {
        0% { left: -100%; }
        50%, 100% { left: 100%; }
    }
    
    @media (max-width: 768px) {
        .wheel-widget {
            bottom: 80px;
            left: 15px;
            padding: 8px 12px;
        }
        
        .wheel-widget-icon {
            width: 30px;
            height: 30px;
        }
        
        .wheel-widget-icon i {
            font-size: 16px;
        }
        
        .wheel-widget-title {
            font-size: 11px;
        }
        
        .wheel-widget-sub {
            font-size: 10px;
        }
    }
</style>

<script src="<?= base_url('assets/' . $properties->theme) ?>/js/bootstrap.min.js"></script>
<script src="<?= base_url('assets/' . $properties->theme) ?>/js/swiper-bundle.min.js"></script>
<script src="<?= base_url('assets/' . $properties->theme) ?>/js/main.js?v=<?= time() ?>"></script>
<script src="<?= base_url('assets/' . $properties->theme) ?>/js/balance.js"></script>
<script src="<?= base_url('assets/case/') ?>case.js"></script>
<?= $properties->online_support ?>
<script>
    Tawk_API.customStyle = {
        visibility : {
            mobile : {
                position : 'br',
                xOffset : '20px',
                yOffset : '80px'
            },
        }
    };
</script>
<script type="text/javascript">
    function search_form() {
        var value = $('#searchInput').val();
        if (value.length > 0) {
            $.ajax({
                url: "<?= base_url('home/getSearchFormProducts'); ?>",
                type: "POST",
                data: {words: $('#searchInput').val()},
                success: function(data) {
                    $("#serch-results").html(data);
                    $('#serch-results').removeClass('d-none');
                    $('#serch-results').slideDown('slow');
                }
            });
        }else{
            $('#serch-results').addClass('d-none');
        }
    }
    function disable_form()
    {
        $('#serch-results').slideUp(800, function(){
            $('#serch-results').addClass('d-none');
        }).delay(800).fadeIn(400);
    }
</script>
<script src="https://twemoji.maxcdn.com/v/latest/twemoji.min.js" crossorigin="anonymous"></script>
<script>
  twemoji.parse(document.body, {folder: 'svg', ext: '.svg'});
</script>


</body>
</html>