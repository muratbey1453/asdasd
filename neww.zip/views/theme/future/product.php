<?php $category = $this->db->where('id', $product->category_id)->get('category')->row(); ?>

<section class="modern-product-page" style="padding: 2rem 0; min-height: 100vh;">
    <div class="container">
      <!-- Breadcrumb -->
        <nav class="product-breadcrumb mb-4">
            <ol class="breadcrumb-list">
                <?php if (!empty($serverForProduct)): ?>
                    <li><a href="<?= base_url('sunucular'); ?>">Sunucular</a></li>
                    <li><span>/</span></li>
                    <li><a href="<?= base_url('sunucular/detay/' . (int)$serverForProduct->id); ?>"><?= html_escape($serverForProduct->title) ?></a></li>
                    <li><span>/</span></li>
                    <li class="active"><?= html_escape($product->name) ?></li>
                <?php elseif (!empty($category)): ?>
                    <li><a href="<?= base_url('tum-kategoriler'); ?>">Tüm Kategoriler</a></li>
                    <li><span>/</span></li>
                    <li><a href="<?= base_url('kategori/') . $category->slug ?>"><?= html_escape($category->name) ?></a></li>
                    <li><span>/</span></li>
                    <li class="active"><?= html_escape($product->name) ?></li>
                <?php else: ?>
                    <li><a href="<?= base_url('tum-kategoriler'); ?>">Tüm Kategoriler</a></li>
                    <li><span>/</span></li>
                    <li class="active"><?= html_escape($product->name) ?></li>
                <?php endif; ?>
            </ol>
        </nav>

        <!-- Product Details Grid -->
        <div class="product-details-grid">
            <!-- Left: Product Image -->
            <div class="product-image-section" id="productImageSection">
                <div class="product-image-wrapper">
                    <img src="<?= base_url('assets/img/product/') . $product->img; ?>" alt="<?=$product->name?>" class="main-product-image rp-zoomable" id="mainProductImage" data-original="<?= base_url('assets/img/product/') . $product->img; ?>">
                    <button type="button" class="rp-img-zoom" aria-label="Görseli büyüt" title="Büyüt">
                        <i class="ri-zoom-in-line"></i>
                    </button>
                    <?php $price = json_decode(calculatePrice($product->id, 1), true); ?>
                    <?php if ($price['isDiscount'] == 1) { 
                        $discountPercent = round((($price['normalPrice'] - $price['price']) / $price['normalPrice']) * 100);
                    ?>
                        <div class="discount-badge">-<?=$discountPercent?>%</div>
                    <?php } ?>
                </div>
                
                <?php 
                // Galeri resimleri
                $gallery = [];
                if (!empty($product->gallery)) {
                    $gallery = json_decode($product->gallery, true);
                    if (!is_array($gallery)) $gallery = [];
                }
                
                // Ana resim + galeri resimleri varsa göster
                if (!empty($gallery) && count($gallery) > 0): 
                ?>
                <div class="product-gallery-thumbnails">
                    <div class="gallery-thumb active" onclick="changeMainImage(event,'<?= base_url('assets/img/product/') . $product->img ?>')">
                        <img src="<?= base_url('assets/img/product/') . $product->img ?>" alt="">
                    </div>
                    <?php foreach($gallery as $gImg): ?>
                    <div class="gallery-thumb" onclick="changeMainImage(event,'<?= base_url('assets/img/product/') . $gImg ?>')">
                        <img src="<?= base_url('assets/img/product/') . $gImg ?>" alt="">
                    </div>
                    <?php endforeach; ?>
                </div>
                <script>
                function changeMainImage(e, src) {
                    document.getElementById('mainProductImage').src = src;
                    document.querySelectorAll('.gallery-thumb').forEach(el => el.classList.remove('active'));
                    const thumb = e?.target?.closest('.gallery-thumb');
                    if (thumb) thumb.classList.add('active');
                }
                </script>
                <?php endif; ?>
            </div>

               <!-- Center: Product Info -->
            <div class="product-info-section">
                <div class="product-header">
                    <div class="product-category-badge">
  <?php if (!empty($category) && !empty($category->name)): ?>
    <i class="ri-folder-line"></i>
    <a href="<?= base_url('kategori/' . html_escape($category->slug ?? '')) ?>" style="color:inherit;text-decoration:none;">
      <span><?= html_escape($category->name) ?></span>
    </a>

  <?php elseif (!empty($serverForProduct) && !empty($serverForProduct->title)): ?>
    <i class="ri-server-line"></i>
    <a href="<?= base_url('sunucular/detay/' . (int)$serverForProduct->id) ?>" style="color:inherit;text-decoration:none;">
      <span><?= html_escape($serverForProduct->title) ?></span>
    </a>

  <?php else: ?>
    <i class="ri-price-tag-3-line"></i>
    <span>Ürün</span>
  <?php endif; ?>
</div>
                    <h1 class="product-title"><?= $product->name ?></h1>
                <?php if (!empty($serverForProduct)): ?>
                    <a href="<?= base_url('sunucular/detay/' . (int)$serverForProduct->id) ?>" class="server-product-chip" style="display:inline-flex;align-items:center;gap:8px;margin-top:10px;text-decoration:none;font-weight:900;">
                        <i class="ri-server-line"></i>
                        <span>Sunucu: <?= html_escape($serverForProduct->title) ?></span>
                    </a>
                <?php endif; ?>
                </div>

                <!-- Product Features -->
                <?php 
                // Parse product features from description or custom fields if available
                ?>
                <div class="product-features">
                    <div class="feature-premium">
                        <i class="ri-checkbox-circle-fill"></i>
                        <span>Ürün Tipi: E-Pin</span>
                    </div>
                    <div class="feature-premium">
                        <i class="ri-shield-check-fill"></i>
                        <span>Teslimat: Anında</span>
                    </div>
                    <div class="feature-premium">
                        <i class="ri-check-double-line"></i>
                        <span>Destek: 7/24</span>
                    </div>
                    <div class="feature-premium">
                        <i class="ri-verified-badge-fill"></i>
                        <span>Otomatik Teslimat</span>
                    </div>
                </div>

                <!-- Price Section -->
                <div class="price-section">
                    <div class="price-wrapper">
                        <div class="price-compare-icon">
                            <i class="ri-shopping-bag-line"></i>
                        </div>
                        <div class="price-content">
                            <div class="price-display">
                                <span class="current-price"><?= $price['price'] ?> TL</span>
                                <?php if ($price['isDiscount'] == 1) { ?>
                                    <span class="old-price"><?= $price['normalPrice'] ?> TL</span>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Custom Fields -->
                <?php $inf = json_decode($product->text); ?>
                <?php if (!empty($inf) && is_array($inf)) { ?>
                    <div class="product-custom-fields">
                        <?php $a = 1; ?>
                        <?php foreach ($inf as $i) {
                            if (!empty($i)) { ?>
                                <div class="custom-field-group">
                                    <label for="extras<?=$a?>"><?= $i ?></label>
                                    <input type="text" class="custom-field-input" id="extras<?=$a?>" name="<?= $i ?>" placeholder="<?= $i ?>" required>
                                    <div id="extras<?=$a?>Feedback" class="field-error"><?= $i ?> alanını boş bırakamazsınız!</div>
                                </div>
                                <?php $a++; 
                            } 
                        } ?>
                    </div>
                <?php } ?>

                <!-- Purchase Actions -->
                <div class="purchase-actions">
                    <div class="quantity-selector">
                        <button type="button" class="qty-btn minus" onclick="decreaseQty()">
                            <i class="ri-subtract-line"></i>
                        </button>
                        <input type="number" class="qty-input" min="1" name="amount" id="amount" value="1">
                        <button type="button" class="qty-btn plus" onclick="increaseQty()">
                            <i class="ri-add-line"></i>
                        </button>
                    </div>

                    <?php if (!empty($this->session->userdata('info')) || $properties->isGuest == 1) { ?>
                        <?php if ($product->isStock == 0 || $stock > 0 || $properties->isStock == 1){ ?>
                            <button id="addItem" onclick="addItem();" class="btn-add-to-cart">
                                <i class="ri-shopping-cart-2-line"></i>
                                <span>Satın Al</span>
                            </button>
                        <?php }else{ ?>
                            <button class="btn-out-of-stock" disabled>
                                <i class="ri-close-circle-line"></i>
                                <span>Stok Bulunamadı</span>
                            </button>
                        <?php } ?>
                    <?php }else{ ?>
                        <a href="<?= base_url('hesap') ?>" class="btn-login-required">
                            <i class="ri-login-box-line"></i>
                            <span>Giriş Yapmalısın</span>
                        </a>
                    <?php } ?>
                </div>

                <!-- Seller Info (if exists) -->
                <?php
                $seller = null;
                if ($product->seller_id > 0) {
                    $seller = $this->db->where('id', $product->seller_id)->get('user')->row();
                }
                ?>

                <?php if (!empty($seller)): ?>
                    <div class="seller-info-compact">
                        <img src="<?= base_url('assets/img/shop/') . $seller->shop_img ?>" alt="Shop" class="seller-avatar">
                        <div class="seller-details">
                            <span class="seller-label">Satıcı</span>
                            <span class="seller-name">
                                <?=$seller->shop_name?>
                                </span>
                            </span>
                            <?php if(!empty($sellerLastSeenText)): ?>
                                <span class="seller-lastseen"><?=$sellerLastSeenText?></span>
                            <?php endif; ?>
                        </div>
                        <a href="#modal-seller-message" data-bs-target="#modal-seller-message" data-bs-toggle="modal" class="btn-message-seller">
                            <i class="ri-message-3-line"></i>
                        </a>
                    </div>

                    <!-- Seller Message Modal -->
                    <div class="modal fade" id="modal-seller-message" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Satıcıya Mesaj Gönder</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form action="<?= base_url('client/addSupport')."?shop=".$seller->shop_slug; ?>" method="POST">
                                        <div class="mb-3">
                                            <label for="">Konu</label>
                                            <input type="text" class="form-control" name="title" required="">
                                        </div>
                                        <div class="mb-3">
                                            <label for="">Mesaj</label>
                                            <textarea rows="3" class="form-control" name="message"></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-primary w-100 d-block">Gönder</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Right: Seller Info Panel + Similar Products -->
            <div class="similar-products-section">
                <!-- Seller Info Panel (Extended) -->
                <?php if (!empty($seller)): ?>
                    <div class="seller-info-panel mb-4">
                        <div class="seller-panel-header">
                            <img src="<?= base_url('assets/img/shop/') . $seller->shop_img ?>" class="seller-panel-logo" alt="<?= $seller->shop_name ?>">
                            <div class="seller-panel-info">
                                <h4 class="seller-panel-name">
                                <?= $seller->shop_name ?>
                              
                            
                              </h4>
                                <span class="seller-verified-badge">
                                    <i class="ri-verified-badge-fill"></i> Onaylı Satıcı
                                </span>
                            </div>
                        </div>
                        
                        <div class="seller-panel-stats">
                            <?php 
                            $totalSales = $this->db->where('seller_id', $seller->id)->count_all_results('invoice');
                            $totalProducts = $this->db->where('seller_id', $seller->id)->where('isActive', 1)->count_all_results('product');
                            $refundedSales = $this->db->where('seller_id', $seller->id)->where('isActive', 2)->count_all_results('invoice');
                            $satisfactionRate = ($totalSales == 0) ? 100 : round((($totalSales - $refundedSales) / $totalSales) * 100);
                            ?>
                            <div class="seller-stat-item">
                                <i class="ri-shopping-bag-3-line"></i>
                                <div class="stat-content">
                                    <span class="stat-value"><?= $totalSales ?></span>
                                    <span class="stat-label">Satış</span>
                                </div>
                            </div>
                            <div class="seller-stat-item">
                                <i class="ri-store-2-line"></i>
                                <div class="stat-content">
                                    <span class="stat-value"><?= $totalProducts ?></span>
                                    <span class="stat-label">Ürün</span>
                                </div>
                            </div>
                            <div class="seller-stat-item">
                                <i class="ri-star-line"></i>
                                <div class="stat-content">
                                    <span class="stat-value">%<?= $satisfactionRate ?></span>
                                    <span class="stat-label">Memnuniyet</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="seller-panel-actions">
                            <a href="<?= base_url('magaza/' . $seller->shop_slug) ?>" class="btn btn-outline-primary w-100 mb-2">
                                <i class="ri-store-2-line me-1"></i> Mağazayı Ziyaret Et
                            </a>
                            <a href="#modal-seller-message" data-bs-target="#modal-seller-message" data-bs-toggle="modal" class="btn btn-primary w-100">
                                <i class="ri-message-3-line me-1"></i> Mesaj Gönder
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
                
                <!-- Similar Products -->
                <h3 class="section-title">
                    <i class="ri-layouts-line"></i>
                    <span>Benzer Ürünler</span>
                </h3>
                <div class="similar-products-list">
                    <?php 
                    $similarProducts = $this->db->limit(4)->where('category_id', $category->id)->where('id !=', $product->id)->where('isActive', 1)->get('product')->result(); 
                    if (!empty($similarProducts)) {
                        foreach($similarProducts as $sp) { 
                            $spPrice = json_decode(calculatePrice($sp->id, 1), true);
                    ?>
                        <a href="<?= base_url($sp->slug) ?>" class="similar-product-item">
                            <img src="<?= base_url('assets/img/product/') . $sp->img ?>" alt="<?=$sp->name?>" class="similar-product-img">
                            <div class="similar-product-info">
                                <h4 class="similar-product-name"><?= $sp->name ?></h4>
                                <div class="similar-product-price">
                                    <span class="price"><?= $spPrice['price'] ?> TL</span>
                                    <?php if ($spPrice['isDiscount'] == 1) { ?>
                                        <span class="old"><?= $spPrice['normalPrice'] ?> TL</span>
                                    <?php } ?>
                                </div>
                            </div>
                        </a>
                    <?php 
                        }
                    } else {
                        echo '<p class="no-similar-products">Benzer ürün bulunamadı</p>';
                    }
                    ?>
                </div>
            </div>
        </div>

        <!-- Product Tabs Section -->
        <div class="product-tabs-section" id="urun-hakkinda">
            <div class="tabs-header">
                <button class="tab-btn active" data-tab="description">Ürün Hakkında</button>
                <button class="tab-btn" data-tab="reviews">Değerlendirmeler</button>
            </div>

            <div class="tabs-content">
                <!-- Description Tab -->
                <div class="tab-pane active" id="description-tab">
                    <div class="product-description">
                        <?= $product->desc; ?>
                    </div>
                </div>

                <!-- Reviews Tab -->
                <div class="tab-pane" id="reviews-tab">
                    <?php if (!empty($history)) { ?>
                        <div class="reviews-summary">
                            <div class="average-rating">
                                <span class="rating-number"><?= calculateAverageRating($comments); ?></span>
                                <div class="stars">
                                    <?php
                                    $averageStars = calculateAverageRating($comments);
                                    $filledStars = floor($averageStars);
                                    $emptyStars = 5 - $filledStars;
                                    for ($i = 0; $i < $filledStars; $i++) {
                                        echo '<i class="ri-star-fill"></i>';
                                    }
                                    for ($i = 0; $i < $emptyStars; $i++) {
                                        echo '<i class="ri-star-line"></i>';
                                    }
                                    ?>
                                </div>
                                <span class="review-count"><?= count($comments) ?> Değerlendirme</span>
                            </div>
                        </div>
                        
                        <div class="reviews-list">
                            <?php foreach ($history as $comment) { ?>
                                <?php $user = $this->db->where('id', $comment->user_id)->get('user')->row(); ?>
                                <div class="review-item">
                                    <div class="review-header">
                                        <div class="reviewer-info">
                                            <span class="reviewer-name"><?= $user->name . " " . $user->surname ?></span>
                                            <span class="review-date"><?= $comment->date ?></span>
                                        </div>
                                        <div class="review-stars">
                                            <?php
                                            $filledStars = $comment->star;
                                            $emptyStars = 5 - $filledStars;
                                            for ($i = 0; $i < $filledStars; $i++) {
                                                echo '<i class="ri-star-fill"></i>';
                                            }
                                            for ($i = 0; $i < $emptyStars; $i++) {
                                                echo '<i class="ri-star-line"></i>';
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <p class="review-text"><?= $comment->comment ?></p>
                                </div>
                            <?php } ?>
                        </div>
                    <?php } else { ?>
                        <div class="no-reviews">
                            <i class="ri-chat-3-line"></i>
                            <p>Henüz değerlendirme bulunmamaktadır.</p>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Image Lightbox (Popup) -->
<div class="rp-lightbox" id="rpLightbox" aria-hidden="true">
  <div class="rp-lb-backdrop" data-rp-close></div>
  <div class="rp-lb-dialog" role="dialog" aria-modal="true" aria-label="Görsel Önizleme">
    <button type="button" class="rp-lb-close" data-rp-close aria-label="Kapat"><i class="ri-close-line"></i></button>
    <button type="button" class="rp-lb-nav rp-lb-prev" data-rp-prev aria-label="Önceki"><i class="ri-arrow-left-s-line"></i></button>
    <img class="rp-lb-img" alt="Görsel">
    <button type="button" class="rp-lb-nav rp-lb-next" data-rp-next aria-label="Sonraki"><i class="ri-arrow-right-s-line"></i></button>
    <div class="rp-lb-count" id="rpLbCount"></div>
  </div>
</div>


<style>
    .server-product-chip{color: rgba(255,255,255,.85); padding:6px 10px; border-radius:999px; border:1px solid rgba(255,255,255,.12); background: rgba(0,0,0,.18);} html[data-theme="light"] .server-product-chip{background:#fff; border:1px solid rgba(0,0,0,.10); color:#0f172a;} 
/* Modern Product Page Styles */
.modern-product-page {
    background: var(--background);
    color: var(--text-color);
}

/* Breadcrumb */
.product-breadcrumb {
    padding: 0;
}

.breadcrumb-list {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    list-style: none;
    padding: 0;
    margin: 0;
    flex-wrap: wrap;
}

.breadcrumb-list li {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 14px;
}

.breadcrumb-list li a {
    color: var(--text-gray);
    text-decoration: none;
    transition: color 0.2s;
}

.breadcrumb-list li a:hover {
    color: var(--text-color);
}

.breadcrumb-list li.active {
    color: var(--text-color);
    font-weight: 500;
}

.breadcrumb-list li span {
    color: var(--text-gray);
}

/* Product Details Grid */
.product-details-grid {
    display: grid;
    grid-template-columns: 280px 1fr 320px;
    gap: 2rem;
    margin-bottom: 2rem;
}

@media (max-width: 1200px) {
    .product-details-grid {
        grid-template-columns: 1fr 1fr;
    }
    
    .similar-products-section {
        grid-column: 1 / -1;
    }
}

@media (max-width: 768px) {
    .product-details-grid {
        grid-template-columns: 1fr;
    }
}

/* Product Image Section */
.product-image-section {
    position: sticky;
    top: 100px;
    height: fit-content;
}

/* Mobilde sticky kaldır */
@media screen and (max-width: 991px) {
    .product-image-section {
        position: static !important;
        top: auto !important;
    }
}

.product-image-wrapper {
    background: var(--bg-white);
    border-radius: 12px;
    overflow: hidden;
    position: relative;
    border: 1px solid var(--border);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    padding: 1rem;
}

.main-product-image {
    width: 100%;
    height: auto;
    display: block;
    aspect-ratio: 1;
    object-fit: contain;
}

.discount-badge {
    position: absolute;
    top: 12px;
    right: 12px;
    background: linear-gradient(135deg, #ff6b6b, #ee5a6f);
    color: white;
    padding: 6px 12px;
    border-radius: 8px;
    font-weight: 600;
    font-size: 14px;
    box-shadow: 0 4px 12px rgba(255, 107, 107, 0.4);
}

/* Gallery Thumbnails */
.product-gallery-thumbnails {
    display: flex;
    gap: 8px;
    margin-top: 12px;
    flex-wrap: wrap;
}

.gallery-thumb {
    width: 56px;
    height: 56px;
    border-radius: 8px;
    overflow: hidden;
    cursor: pointer;
    border: 2px solid transparent;
    transition: all 0.2s ease;
}

.gallery-thumb:hover {
    border-color: #3b82f6;
}

.gallery-thumb.active {
    border-color: #3b82f6;
    box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
}

.gallery-thumb img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

/* Product Info Section */
.product-info-section {
    background: var(--bg-white);
    border-radius: 12px;
    padding: 2rem;
    border: 1px solid var(--border);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.product-header {
    margin-bottom: 1.5rem;
}

.product-category-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(59, 130, 246, 0.1);
    color: #3b82f6;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 500;
    margin-bottom: 1rem;
}

.product-title {
    font-size: 28px;
    font-weight: 700;
    color: var(--text-color);
    margin: 0;
    line-height: 1.3;
}

/* Product Features */
.product-features {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 0.75rem;
    margin-bottom: 1.5rem;
}

.feature-item {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 12px;
    background: var(--bg-white-2);
    border-radius: 8px;
    font-size: 13px;
    color: var(--text-color);
    border: 1px solid rgba(0, 0, 0, 0.05);
}

.feature-item i {
    color: #10b981;
    font-size: 18px;
}

/* Price Section */
.price-section {
    margin-bottom: 1.5rem;
}

.price-wrapper {
    display: flex;
    align-items: center;
    gap: 1rem;
    background: var(--bg-white-2);
    padding: 1.25rem;
    border-radius: 10px;
    border: 1px solid rgba(0, 0, 0, 0.08);
}

.price-compare-icon {
    width: 48px;
    height: 48px;
    background: linear-gradient(135deg, #3b82f6, #2563eb);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.price-compare-icon i {
    font-size: 24px;
    color: white;
}

.price-content {
    flex: 1;
}

.price-display {
    display: flex;
    align-items: center;
    gap: 12px;
}

.current-price {
    font-size: 24px;
    font-weight: 700;
    color: var(--text-color);
}

.old-price {
    font-size: 16px;
    color: #999;
    text-decoration: line-through;
}

/* Custom Fields */
.product-custom-fields {
    margin-bottom: 1.5rem;
}

.custom-field-group {
    margin-bottom: 1rem;
}

.custom-field-group label {
    display: block;
    font-size: 14px;
    font-weight: 500;
    color: var(--text-color);
    margin-bottom: 0.5rem;
}

.custom-field-input {
    width: 100%;
    padding: 12px 16px;
    border: 1px solid var(--border);
    border-radius: 8px;
    font-size: 14px;
    background: var(--background);
    color: var(--text-color);
    transition: all 0.2s;
}

.custom-field-input:focus {
    outline: none;
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

.custom-field-input.is-invalid {
    border-color: #ef4444;
}

.field-error {
    display: none;
    color: #ef4444;
    font-size: 13px;
    margin-top: 0.25rem;
}

.custom-field-input.is-invalid ~ .field-error {
    display: block;
}

/* Purchase Actions */
.purchase-actions {
    display: grid;
    grid-template-columns: 140px 1fr;
    gap: 1rem;
    margin-bottom: 1.5rem;
}

.quantity-selector {
    display: flex;
    align-items: center;
    border: 1px solid var(--border);
    border-radius: 8px;
    background: var(--background);
    overflow: hidden;
}

.qty-btn {
    width: 40px;
    height: 48px;
    border: none;
    background: transparent;
    color: var(--text-color);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background 0.2s;
}

.qty-btn:hover {
    background: var(--bg-white-2);
}

.qty-btn i {
    font-size: 18px;
}

.qty-input {
    flex: 1;
    border: none;
    text-align: center;
    font-size: 16px;
    font-weight: 600;
    background: transparent;
    color: var(--text-color);
    outline: none;
    -moz-appearance: textfield;
}

.qty-input::-webkit-outer-spin-button,
.qty-input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

.btn-add-to-cart,
.btn-login-required,
.btn-out-of-stock {
    height: 48px;
    border: none;
    border-radius: 8px;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: all 0.2s;
}

.btn-add-to-cart {
    background: linear-gradient(135deg, #10b981, #059669);
    color: white;
    box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
}

.btn-add-to-cart:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(16, 185, 129, 0.4);
}

.btn-login-required {
    background: linear-gradient(135deg, #f59e0b, #d97706);
    color: white;
    text-decoration: none;
    box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3);
}

.btn-login-required:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(245, 158, 11, 0.4);
}

.btn-out-of-stock {
    background: var(--bg-white-2);
    color: var(--text-gray);
    cursor: not-allowed;
}

/* Seller Info Compact */
.seller-info-compact {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    background: var(--bg-white-2);
    border-radius: 10px;
    border: 1px solid rgba(0, 0, 0, 0.05);
}

.seller-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    object-fit: cover;
}

.seller-details {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.seller-label {
    font-size: 12px;
    color: var(--text-gray);
}

.seller-name {
    font-size: 14px;
    font-weight: 600;
    color: var(--text-color);
}

.btn-message-seller {
    width: 36px;
    height: 36px;
    border-radius: 8px;
    background: #3b82f6;
    color: white;
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.2s;
    text-decoration: none;
}

.btn-message-seller:hover {
    background: #2563eb;
    transform: scale(1.05);
}

/* Similar Products Section */
.similar-products-section {
    position: sticky;
    top: 100px;
    height: fit-content;
}

.section-title {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 18px;
    font-weight: 600;
    color: var(--text-color);
    margin-bottom: 1rem;
}

.section-title i {
    color: #3b82f6;
    font-size: 20px;
}

.similar-products-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.similar-product-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    background: var(--bg-white);
    border: 1px solid var(--border);
    border-radius: 10px;
    text-decoration: none;
    transition: all 0.2s;
}

.similar-product-item:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    border-color: #3b82f6;
}

.similar-product-img {
    width: 60px;
    height: 60px;
    border-radius: 8px;
    object-fit: cover;
    flex-shrink: 0;
}

.similar-product-info {
    flex: 1;
    min-width: 0;
}

.similar-product-name {
    font-size: 14px;
    font-weight: 500;
    color: var(--text-color);
    margin: 0 0 4px 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.similar-product-price {
    display: flex;
    align-items: center;
    gap: 6px;
}

.similar-product-price .price {
    font-size: 14px;
    font-weight: 700;
    color: #10b981;
}

.similar-product-price .old {
    font-size: 12px;
    color: #999;
    text-decoration: line-through;
}

.no-similar-products {
    text-align: center;
    color: var(--text-gray);
    padding: 2rem;
    font-size: 14px;
}

/* Seller Info Panel Styles */
.seller-info-panel {
    background: var(--bg-white);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.seller-panel-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 1.25rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid var(--border);
}

.seller-panel-logo {
    width: 56px;
    height: 56px;
    border-radius: 12px;
    object-fit: cover;
    border: 2px solid var(--border);
}

.seller-panel-info {
    flex: 1;
}

.seller-panel-name {
    font-size: 16px;
    font-weight: 600;
    color: var(--text-color);
    margin: 0 0 4px 0;
}

.seller-verified-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-size: 12px;
    color: #10b981;
    font-weight: 500;
}

.seller-verified-badge i {
    font-size: 14px;
}

.seller-panel-stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 8px;
    margin-bottom: 1.25rem;
}

.seller-stat-item {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px;
    background: var(--bg-white-2);
    border-radius: 8px;
    border: 1px solid rgba(0, 0, 0, 0.05);
}

.seller-stat-item i {
    font-size: 20px;
    color: #3b82f6;
}

.stat-content {
    display: flex;
    flex-direction: column;
}

.stat-value {
    font-size: 14px;
    font-weight: 700;
    color: var(--text-color);
}

.stat-label {
    font-size: 11px;
    color: var(--text-gray);
}

.seller-panel-actions {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.seller-panel-actions .btn {
    font-size: 14px;
    padding: 10px 16px;
    border-radius: 8px;
}

@media (max-width: 1200px) {
    .seller-panel-stats {
        grid-template-columns: 1fr;
    }
    
    .seller-stat-item {
        justify-content: center;
    }
}

/* Product Tabs Section */
.product-tabs-section {
    background: var(--bg-white);
    border-radius: 12px;
    padding: 2rem;
    border: 1px solid var(--border);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.tabs-header {
    display: flex;
    gap: 1rem;
    border-bottom: 2px solid var(--border);
    margin-bottom: 2rem;
}

.tab-btn {
    padding: 12px 24px;
    background: transparent;
    border: none;
    font-size: 16px;
    font-weight: 500;
    color: var(--text-gray);
    cursor: pointer;
    position: relative;
    transition: color 0.2s;
}

.tab-btn:hover {
    color: var(--text-color);
}

.tab-btn.active {
    color: #3b82f6;
}

.tab-btn.active::after {
    content: '';
    position: absolute;
    bottom: -2px;
    left: 0;
    right: 0;
    height: 2px;
    background: #3b82f6;
}

.tab-pane {
    display: none;
}

.tab-pane.active {
    display: block;
}

/* Product Description */
.product-description {
    font-size: 15px;
    line-height: 1.8;
    color: var(--text-color);
}

/* Reviews */
.reviews-summary {
    margin-bottom: 2rem;
    padding: 1.5rem;
    background: var(--bg-white-2);
    border-radius: 10px;
    text-align: center;
}

.average-rating {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
}

.rating-number {
    font-size: 48px;
    font-weight: 700;
    color: var(--text-color);
}

.stars {
    display: flex;
    gap: 4px;
}

.stars i {
    font-size: 20px;
    color: #fbbf24;
}

.review-count {
    font-size: 14px;
    color: var(--text-gray);
}

.reviews-list {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}

.review-item {
    padding-bottom: 1.5rem;
    border-bottom: 1px solid var(--border);
}

.review-item:last-child {
    border-bottom: none;
    padding-bottom: 0;
}

.review-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 0.75rem;
}

.reviewer-info {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.reviewer-name {
    font-size: 15px;
    font-weight: 600;
    color: var(--text-color);
}

.review-date {
    font-size: 13px;
    color: var(--text-gray);
}

.review-stars {
    display: flex;
    gap: 2px;
}

.review-stars i {
    font-size: 16px;
    color: #fbbf24;
}

.review-text {
    font-size: 14px;
    line-height: 1.6;
    color: var(--text-color);
    margin: 0;
}

.no-reviews {
    text-align: center;
    padding: 3rem 1rem;
    color: var(--text-gray);
}

.no-reviews i {
    font-size: 48px;
    margin-bottom: 1rem;
    opacity: 0.5;
}

.no-reviews p {
    font-size: 15px;
    margin: 0;
}

/* Dark Mode Adjustments */
html[data-theme="dark"] .product-image-wrapper,
html[data-theme="dark"] .product-info-section,
html[data-theme="dark"] .product-tabs-section {
    border-color: #2a2a2a;
}

html[data-theme="dark"] .similar-product-item {
    border-color: #2a2a2a;
}

html[data-theme="dark"] .similar-product-item:hover {
    border-color: #3b82f6;
}

/* =========================
   PREMIUM NEON + STATUS + FEATURES (Light/Dark)
   ========================= */

/* Neon arkaplan (temayı bozmaz, hafif) */
.modern-product-page{
    background:
        radial-gradient(1100px 520px at 18% 0%, rgba(59,130,246,.16), transparent 55%),
        radial-gradient(900px 520px at 85% 10%, rgba(34,197,94,.12), transparent 55%),
        radial-gradient(900px 520px at 55% 85%, rgba(168,85,247,.10), transparent 60%),
        var(--background);
}

/* Dark temada neon biraz güçlensin + beyazlıklar kapansın */
html[data-theme="dark"] .modern-product-page{
    background:
        radial-gradient(1100px 520px at 18% 0%, rgba(59,130,246,.22), transparent 55%),
        radial-gradient(900px 520px at 85% 10%, rgba(34,197,94,.18), transparent 55%),
        radial-gradient(900px 520px at 55% 85%, rgba(168,85,247,.16), transparent 60%),
        var(--background);
}

/* Online/Offline rozet */
.online-pill{
    display:inline-flex;
    align-items:center;
    gap:6px;
    padding: 5px 10px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 700;
    margin-left: 10px;
    border: 1px solid rgba(0,0,0,.08);
    background: rgba(0,0,0,.04);
    color: var(--text-color);
    vertical-align: middle;
    white-space: nowrap;
}
.online-pill .dot{
    width: 8px;
    height: 8px;
    border-radius: 99px;
    background: #94a3b8;
    box-shadow: 0 0 0 0 rgba(148,163,184,.0);
}
.online-pill.is-online{
    background: rgba(16,185,129,.12);
    border-color: rgba(16,185,129,.22);
}
.online-pill.is-online .dot{
    background: #22c55e;
    box-shadow: 0 0 12px rgba(34,197,94,.55);
}
.online-pill.is-offline{
    background: rgba(148,163,184,.10);
    border-color: rgba(148,163,184,.18);
}
.seller-lastseen{
    display:block;
    margin-top: 4px;
    font-size: 12px;
    color: var(--text-gray);
}

/* Dark tema: rozet border/zemin */
html[data-theme="dark"] .online-pill{
    border-color: rgba(255,255,255,.12);
    background: rgba(255,255,255,.06);
}

/* PREMIUM FEATURES (attığın görsel tarzı) */
.product-features{
    gap: 12px !important;
}
.feature-premium{
    display:flex;
    align-items:center;
    gap: 10px;
    padding: 12px 14px;
    border-radius: 14px;
    background: linear-gradient(180deg, rgba(255,255,255,.75), rgba(255,255,255,.55));
    border: 1px solid rgba(0,0,0,.06);
    box-shadow: 0 10px 26px rgba(0,0,0,.06);
    position: relative;
    overflow: hidden;
}
.feature-premium::before{
    content:"";
    position:absolute;
    inset:-2px;
    background: radial-gradient(500px 120px at 20% 0%, rgba(59,130,246,.18), transparent 55%);
    pointer-events:none;
    opacity:.9;
}
.feature-premium i{
    width: 36px;
    height: 36px;
    border-radius: 12px;
    display:flex;
    align-items:center;
    justify-content:center;
    background: rgba(59,130,246,.12);
    color: #3b82f6;
    font-size: 18px;
    flex-shrink:0;
}
.feature-premium span{
    font-size: 13.5px;
    font-weight: 700;
    color: var(--text-color);
}
.feature-premium:hover{
    transform: translateY(-1px);
    box-shadow: 0 16px 34px rgba(59,130,246,.14);
    border-color: rgba(59,130,246,.22);
}

/* Dark tema feature */
html[data-theme="dark"] .feature-premium{
    background: linear-gradient(180deg, rgba(255,255,255,.07), rgba(255,255,255,.04));
    border-color: rgba(255,255,255,.10);
    box-shadow: 0 14px 44px rgba(0,0,0,.40);
}
html[data-theme="dark"] .feature-premium::before{
    background: radial-gradient(500px 120px at 20% 0%, rgba(59,130,246,.26), transparent 55%);
}
html[data-theme="dark"] .feature-premium i{
    background: rgba(59,130,246,.18);
    color: #86b6ff;
}

/* RESİM ALANI: bozulmadan vitrin + contain */
.product-image-wrapper{
    padding: 12px !important;
}
.main-product-image{
    height: 340px !important;
    object-fit: contain !important;
}
@media (max-width:768px){
    .main-product-image{ height: 280px !important; }
}

/* Thumb taşma düzeltme */
.product-gallery-thumbnails{
    flex-wrap: nowrap !important;
    overflow-x: auto !important;
}

/* Seller panel header satırı hizalama */
.seller-panel-name{
    display:flex;
    align-items:center;
    gap: 10px;
    flex-wrap: wrap;
}


/* ====== Product Image Lightbox (Popup) ====== */
.rp-zoomable{ cursor: zoom-in; }
.product-image-wrapper{ position: relative; }
.rp-img-zoom{
  position:absolute; right:12px; bottom:12px; z-index:3;
  width:42px; height:42px; border-radius:14px;
  border:1px solid rgba(255,255,255,.12);
  background: rgba(0,0,0,.35);
  color:#fff;
  display:flex; align-items:center; justify-content:center;
  backdrop-filter: blur(10px);
  transition:.18s ease;
}
.rp-img-zoom:hover{ transform: translateY(-1px); filter: brightness(1.06); }
html[data-theme="light"] .rp-img-zoom{ background: rgba(255,255,255,.92); color:#0f172a; border:1px solid rgba(0,0,0,.10); }

.rp-lightbox{ position:fixed; inset:0; z-index:99999; display:none; }
.rp-lightbox.is-open{ display:block; }
.rp-lb-backdrop{ position:absolute; inset:0; background: rgba(0,0,0,.70); backdrop-filter: blur(6px); }
.rp-lb-dialog{ position:absolute; inset:0; display:flex; align-items:center; justify-content:center; padding:20px; }
.rp-lb-img{
  max-width: min(1100px, 92vw);
  max-height: 84vh;
  border-radius: 18px;
  border: 1px solid rgba(255,255,255,.16);
  box-shadow: 0 30px 90px rgba(0,0,0,.55);
  background: rgba(0,0,0,.25);
}
.rp-lb-close{
  position:absolute; top:18px; right:18px;
  width:44px; height:44px; border-radius:14px;
  border:1px solid rgba(255,255,255,.14);
  background: rgba(0,0,0,.35);
  color:#fff; display:flex; align-items:center; justify-content:center;
  transition:.18s ease;
}
.rp-lb-close:hover{ transform: translateY(-1px); filter: brightness(1.06); }
.rp-lb-nav{
  position:absolute; top:50%; transform: translateY(-50%);
  width:46px; height:46px; border-radius:16px;
  border:1px solid rgba(255,255,255,.14);
  background: rgba(0,0,0,.35);
  color:#fff; display:flex; align-items:center; justify-content:center;
  transition:.18s ease;
}
.rp-lb-nav:hover{ transform: translateY(-50%) translateY(-1px); filter: brightness(1.06); }
.rp-lb-prev{ left:18px; }
.rp-lb-next{ right:18px; }
.rp-lb-count{
  position:absolute; bottom:18px; left:50%; transform: translateX(-50%);
  padding:8px 12px; border-radius: 999px;
  border:1px solid rgba(255,255,255,.14);
  background: rgba(0,0,0,.35);
  color: rgba(255,255,255,.92);
  font-weight: 900; font-size: 13px;
}
html[data-theme="light"] .rp-lb-img{ border:1px solid rgba(0,0,0,.10); box-shadow: 0 30px 90px rgba(0,0,0,.18); background:#fff; }
html[data-theme="light"] .rp-lb-close,
html[data-theme="light"] .rp-lb-nav,
html[data-theme="light"] .rp-lb-count{ background: rgba(255,255,255,.92); border:1px solid rgba(0,0,0,.10); color:#0f172a; }

</style>

<script>
// Quantity controls
function increaseQty() {
    const input = document.getElementById('amount');
    input.value = parseInt(input.value) + 1;
}

function decreaseQty() {
    const input = document.getElementById('amount');
    if (parseInt(input.value) > 1) {
        input.value = parseInt(input.value) - 1;
    }
}

// Tab switching
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const tabName = this.getAttribute('data-tab');
        
        // Remove active class from all tabs and buttons
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
        
        // Add active class to clicked button and corresponding pane
        this.classList.add('active');
        document.getElementById(tabName + '-tab').classList.add('active');
    });
});

// Add to cart function
function addItem() {
    var extras = {
        name1: $("#extras1").attr("name"),
        number1: $("#extras1").val(),
        name2: $("#extras2").attr("name"),
        number2: $("#extras2").val(),
        name3: $("#extras3").attr("name"),
        number3: $("#extras3").val()
    };
    
    var is_valid = true;
    
    // Validate extras1
    if ($("#extras1").prop("required") && extras.number1.length === 0) {
        $("#extras1").addClass("is-invalid");
        is_valid = false;
    } else {
        $("#extras1").removeClass("is-invalid").addClass("is-valid");
        setTimeout(function() {
            $("#extras1").removeClass("is-valid");
        }, 1000);
    }
    
    // Validate extras2
    if ($("#extras2").prop("required") && extras.number2.length === 0) {
        $("#extras2").addClass("is-invalid");
        is_valid = false;
    } else {
        $("#extras2").removeClass("is-invalid").addClass("is-valid");
        setTimeout(function() {
            $("#extras2").removeClass("is-valid");
        }, 1000);
    }
    
    // Validate extras3
    if ($("#extras3").prop("required") && extras.number3.length === 0) {
        $("#extras3").addClass("is-invalid");
        is_valid = false;
    } else {
        $("#extras3").removeClass("is-invalid").addClass("is-valid");
        setTimeout(function() {
            $("#extras3").removeClass("is-valid");
        }, 1000);
    }
    
    if (!is_valid) return;
    
    var amount = $("#amount").val();
    var dataToSend = {
        id: <?= $product->id ?>,
        extras: extras,
        amount: amount
    };
    
    $.post({
        url: "<?= base_url(); ?>/home/addToCartItem",
        type: "POST",
        data: dataToSend,
        success: function (response) {
            console.log(response);
            $("#cart").html(response);
            $('#addItem').html('<i class="ri-check-line"></i><span>Sepete Eklendi</span>');
            setTimeout(function () {
                $('#addItem').html('<i class="ri-shopping-cart-2-line"></i><span>Satın Al</span>');
            }, 1500);
        }
    });
    
    $.ajax({
        url: "<?= base_url('API/getCartAmount'); ?>",
        type: "POST",
        data: {},
        success: function (amount) {
            $('#MobileNavbarCart').html('Sepet (' + amount + ')');
        }
    });
}

// Mobilde sticky kaldır
(function() {
    function fixMobileSticky() {
        var el = document.getElementById('productImageSection');
        if (el && window.innerWidth <= 991) {
            el.style.position = 'static';
            el.style.top = 'auto';
        }
    }
    fixMobileSticky();
    window.addEventListener('resize', fixMobileSticky);
})();
</script>

<script>
(function(){
  const lb = document.getElementById("rpLightbox");
  const main = document.getElementById("mainProductImage");
  if(!lb || !main) return;

  const imgEl = lb.querySelector(".rp-lb-img");
  const countEl = document.getElementById("rpLbCount");
  const prevBtn = lb.querySelector("[data-rp-prev]");
  const nextBtn = lb.querySelector("[data-rp-next]");

  function orderedUnique(arr){
    const seen = new Set();
    const out = [];
    for(const s of arr){
      if(!s) continue;
      if(seen.has(s)) continue;
      seen.add(s);
      out.push(s);
    }
    return out;
  }

  function getSources(){
    const srcs = [];
    const orig = main.getAttribute("data-original") || main.src;
    if(orig) srcs.push(orig);
    document.querySelectorAll(".product-gallery-thumbnails .gallery-thumb img").forEach(im => {
      if(im && im.src) srcs.push(im.src);
    });
    return orderedUnique(srcs);
  }

  let sources = [];
  let index = 0;

  function render(){
    sources = getSources();
    if(!sources.length) return;
    if(index < 0) index = 0;
    if(index > sources.length - 1) index = sources.length - 1;
    imgEl.src = sources[index];
    if(countEl){
      countEl.textContent = (sources.length > 1) ? ((index+1) + " / " + sources.length) : "";
    }
    if(prevBtn) prevBtn.style.display = (sources.length > 1) ? "" : "none";
    if(nextBtn) nextBtn.style.display = (sources.length > 1) ? "" : "none";
  }

  function openAt(i){
    sources = getSources();
    if(!sources.length) return;
    index = i;
    lb.classList.add("is-open");
    lb.setAttribute("aria-hidden","false");
    document.body.style.overflow = "hidden";
    render();
  }

  function close(){
    lb.classList.remove("is-open");
    lb.setAttribute("aria-hidden","true");
    document.body.style.overflow = "";
  }

  function currentIndexFromMain(){
    const arr = getSources();
    const cur = main.src;
    const i = arr.indexOf(cur);
    return (i >= 0) ? i : 0;
  }

  function next(){
    if(!sources.length) return;
    index = (index + 1) % sources.length;
    render();
  }
  function prev(){
    if(!sources.length) return;
    index = (index - 1 + sources.length) % sources.length;
    render();
  }

  document.addEventListener("click", function(e){
    const zoom = e.target.closest(".rp-img-zoom") || e.target.closest("#mainProductImage");
    if(zoom){
      e.preventDefault();
      openAt(currentIndexFromMain());
      return;
    }

    if(!lb.classList.contains("is-open")) return;

    if(e.target.closest("[data-rp-close]")){ e.preventDefault(); close(); return; }
    if(e.target.closest("[data-rp-next]")){ e.preventDefault(); next(); return; }
    if(e.target.closest("[data-rp-prev]")){ e.preventDefault(); prev(); return; }
  });

  document.addEventListener("keydown", function(e){
    if(!lb.classList.contains("is-open")) return;
    if(e.key === "Escape") close();
    if(e.key === "ArrowRight") next();
    if(e.key === "ArrowLeft") prev();
  });

})();
</script>
