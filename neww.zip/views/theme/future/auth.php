<section class="fp-section-page fp-auth-page">
  <div class="container">
    <div class="fp-auth-layout">

      <!-- SOL: HERO / INFO -->
      <div class="fp-auth-hero">
        <div class="hero-inner">
          <div class="brand">
           <a href="<?= base_url(); ?>" class="hero-logo">
  <img src="<?= base_url('assets/future/img/logo-dark.png'); ?>" class="hero-logo-dark" alt="Roypin">
  <img src="<?= base_url('assets/future/img/logo-white.png'); ?>" class="hero-logo-light" alt="Roypin">
</a>

            
          </div>

          <h2 class="hero-title">Görev Yaparak Para Kazanabileceğin Dijital Platform</h2>
          <p class="hero-sub">
            Roypin’de görev yaparak gelir elde et; E-Pin satın al, %0 komisyon ilepazar sisteminde satış yap. Günlük ücretsiz çark, kasa açma sistemi ve blog içerikleriyle hem kazan hem eğlen.
          </p>

          <div class="hero-badges">
            <div class="badge-item"><i class="ri-shield-check-line"></i> Güvenli Altyapı</div>
            <div class="badge-item"><i class="ri-flashlight-line"></i> Anında Teslimat</div>
            <div class="badge-item"><i class="ri-customer-service-2-line"></i> 7/24 Destek</div>
          </div>

          <div class="hero-mini">
            <div class="mini-card">
              <div class="mini-icon"><i class="ri-percent-line"></i></div>
              <div class="mini-text">
                <div class="mini-title">%0 Komisyon</div>
                <div class="mini-subtitle">Satışlarda avantaj</div>
              </div>
            </div>
            <div class="mini-card">
              <div class="mini-icon"><i class="ri-user-add-line"></i></div>
              <div class="mini-text">
                <div class="mini-title">Hızlı Üyelik</div>
                <div class="mini-subtitle">1 dakikada kayıt</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- SAĞ: FORM KART -->
      <div class="fp-card fp-auth-card fp-auth-card-v2">
        <div class="fp-card-body">

          <div class="logo-area">
            <a href="<?= base_url(); ?>" class="logo dark">
              <img src="<?= base_url('assets/future/img/logo-dark.png'); ?>" alt="">
            </a>
            <a href="<?= base_url(); ?>" class="logo white">
              <img src="<?= base_url('assets/future/img/logo-white.png'); ?>" alt="">
            </a>
          </div>

          <div class="fp-auth-tabs fp-auth-tabs-v2">
            <a href="#" class="link-tab active show-login-form">Giriş Yap</a>
            <a href="#" class="link-tab show-register-form">Kayıt Ol</a>
          </div>

          <!-- Sosyal giriş (opsiyonel UI) -->
          <div class="auth-social">
            <button type="button" class="btn-social">
              <i class="ri-google-fill"></i> Google ile devam et
            </button>
            <div class="divider"><span>veya</span></div>
          </div>

          <!-- LOGIN -->
          <div class="auth-login-form">
            <?php echo form_open(base_url('login/loginClient'));?>

            <label>E-Posta <span class="text-danger">*</span></label>
            <div class="fp-input mb-3 fp-input-v2">
              <div class="icon"><i class="ri-mail-line"></i></div>
              <input type="email" class="form-control" placeholder="E-Posta Adresi" id="loginemail" name="mail" required>
            </div>

            <label>Şifre <span class="text-danger">*</span></label>
            <div class="fp-input mb-3 fp-input-v2">
              <div class="icon"><i class="ri-lock-line"></i></div>
              <input type="password" class="form-control" placeholder="Şifre" id="loginpassword" name="password" required>
              <button type="button" class="toggle-pass" data-target="#loginpassword" aria-label="Şifreyi göster">
                <i class="ri-eye-line"></i>
              </button>
            </div>

            <div class="d-flex justify-content-between align-items-center my-2">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" id="rememberMe">
                <label class="form-check-label" for="rememberMe">Beni hatırla</label>
              </div>
              <a href="<?= base_url('sifremi-unuttum') ?>" class="link">Şifremi Unuttum</a>
            </div>

            <?php echo form_submit('btn btn-primary w-100', 'Giriş Yap', ['class'=>'btn btn-primary w-100 btn-auth']); ?>
            <?php echo form_close();?>

            <div class="auth-bottom-note">
              Hesabın yok mu? <a href="#" class="show-register-form-inline">Kayıt Ol</a>
            </div>
          </div>

          <!-- REGISTER -->
          <div class="auth-register-form" style="display:none">
            <?php echo form_open(base_url('login/regUser'));?>

            <div class="row">
              <div class="col-lg-6">
                <label>Ad <span class="text-danger">*</span></label>
                <div class="fp-input mb-3 fp-input-v2">
                  <div class="icon"><i class="ri-user-line"></i></div>
                  <input type="text" class="form-control" placeholder="Ad" name="name" id="name" required>
                </div>
              </div>
              <div class="col-lg-6">
                <label>Soyad <span class="text-danger">*</span></label>
                <div class="fp-input mb-3 fp-input-v2">
                  <div class="icon"><i class="ri-user-star-line"></i></div>
                  <input type="text" class="form-control" placeholder="Soyad" name="surname" id="surname" required>
                </div>
              </div>
            </div>

            <label>E-Posta Adresi <span class="text-danger">*</span></label>
            <div class="fp-input mb-3 fp-input-v2">
              <div class="icon"><i class="ri-mail-line"></i></div>
              <input type="email" class="form-control" id="email" name="email" placeholder="E-Posta Adresi" required>
            </div>

            <?php if ($properties->isConfirmTc == 1): ?>
              <label>TC Kimlik Numarası <span class="text-danger">*</span></label>
              <div class="fp-input mb-3 fp-input-v2">
                <div class="icon"><i class="ri-shield-user-line"></i></div>
                <input type="text" id="tc" name="tc" class="form-control" placeholder="TC Kimlik Numarası" minlength="11" maxlength="11" required>
              </div>

              <label>Doğum Yılı <span class="text-danger">*</span></label>
              <div class="fp-input mb-3 fp-input-v2">
                <div class="icon"><i class="ri-calendar-2-line"></i></div>
                <input type="text" id="birthday" name="birthday" class="form-control" placeholder="Doğum Yılı" minlength="4" maxlength="4" required>
              </div>
            <?php endif ?>

            <label>Telefon Numarası <span class="text-danger">*</span></label>
            <div class="fp-input mb-3 fp-input-v2">
              <div class="icon"><i class="ri-phone-line"></i></div>
              <input type="text" class="form-control" id="phone" name="phone" placeholder="Telefon Numarası" required>
            </div>

            <label>Şifre <span class="text-danger">*</span></label>
            <div class="fp-input mb-3 fp-input-v2">
              <div class="icon"><i class="ri-lock-line"></i></div>
              <input type="password" class="form-control" id="password" name="password" placeholder="Şifre" required>
              <button type="button" class="toggle-pass" data-target="#password" aria-label="Şifreyi göster">
                <i class="ri-eye-line"></i>
              </button>
            </div>

            <label>Referans Kodu</label>
            <div class="fp-input mb-3 fp-input-v2">
              <div class="icon"><i class="ri-link"></i></div>
              <input type="text" class="form-control" id="ref_code" name="ref_code"
                     placeholder='Referans Kodu "BRONZ"'
                     <?php if (!empty($ref_code)) { ?>value="<?= $ref_code ?>" readonly<?php } ?>>
            </div>

            <div class="my-3">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" id="confirm" name="confirm" required checked>
                <label class="form-check-label fs-15" for="confirm">
                  <a href="#modalContract" data-bs-toggle="modal" data-bs-target="#modalContract">Sözleşmeyi</a> okudum ve onaylıyorum.
                </label>
              </div>
            </div>

            <div class="modal fade" id="modalContract" tabindex="-1" role="dialog" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title">Şartlar ve Gizlilik Sözleşmesi</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                    <?= $properties->contract ?>
                  </div>
                </div>
              </div>
            </div>

            <?php echo form_submit('btn btn-primary w-100', 'Kayıt Ol', ['class'=>'btn btn-primary w-100 btn-auth']); ?>
            <?php echo form_close();?>

            <div class="auth-bottom-note">
              Zaten hesabın var mı? <a href="#" class="show-login-form-inline">Giriş Yap</a>
            </div>
          </div>

        </div>
      </div>

    </div>
  </div>
  <style>
/* Layout */
.fp-auth-page { padding: 40px 0; }
.fp-auth-layout{
  display:grid;
  grid-template-columns: 1.1fr .9fr;
  gap: 24px;
  align-items: stretch;
}
@media (max-width: 992px){
  .fp-auth-layout{ grid-template-columns: 1fr; }
  .fp-auth-hero{ display:none; } /* istersen mobilde de gösteririz */
}

/* HERO */
.fp-auth-hero{
  border-radius: 18px;
  overflow:hidden;
  position: relative;
  border: 1px solid rgba(255,255,255,.10);
  background: radial-gradient(circle at 20% 0%, rgba(59,130,246,.25), transparent 45%),
              radial-gradient(circle at 90% 20%, rgba(16,185,129,.18), transparent 40%),
              rgba(255,255,255,.06);
  box-shadow: 0 18px 60px rgba(0,0,0,.35);
  backdrop-filter: blur(10px);
}
.fp-auth-hero .hero-inner{ padding: 28px; }
.hero-title{ font-size: 28px; font-weight: 900; margin: 10px 0 8px; color: #fff; }
.hero-sub{ color: rgba(255,255,255,.75); margin: 0 0 18px; line-height: 1.6; }
.hero-badges{ display:flex; flex-wrap: wrap; gap: 10px; margin-bottom: 16px; }
.badge-item{
  display:flex; align-items:center; gap:8px;
  padding: 8px 12px; border-radius: 999px;
  background: rgba(0,0,0,.18);
  border: 1px solid rgba(255,255,255,.10);
  color: rgba(255,255,255,.80);
  font-weight: 700; font-size: 13px;
}
.badge-item i{ color: rgba(255,255,255,.9); }
.hero-mini{ display:grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 14px; }
.mini-card{
  display:flex; gap: 12px; align-items:center;
  background: rgba(0,0,0,.18);
  border: 1px solid rgba(255,255,255,.10);
  border-radius: 14px;
  padding: 12px;
}
.mini-icon{
  width: 42px; height: 42px; border-radius: 12px;
  display:flex; align-items:center; justify-content:center;
  background: rgba(255,255,255,.08);
  border: 1px solid rgba(255,255,255,.10);
  color:#fff;
}
.mini-title{ color:#fff; font-weight:900; font-size: 14px; }
.mini-subtitle{ color: rgba(255,255,255,.65); font-size: 12px; }

/* CARD */
.fp-auth-card-v2{
  border-radius: 18px;
  border: 1px solid rgba(255,255,255,.10);
  box-shadow: 0 18px 60px rgba(0,0,0,.25);
}

/* Tabs */
.fp-auth-tabs-v2{
  display:flex; gap: 8px;
  background: rgba(0,0,0,.14);
  border: 1px solid rgba(255,255,255,.10);
  border-radius: 12px;
  padding: 6px;
  margin: 18px 0 14px;
}
.fp-auth-tabs-v2 .link-tab{
  flex:1;
  text-align:center;
  padding: 10px 12px;
  border-radius: 10px;
  font-weight: 900;
  text-decoration:none;
  color: rgba(255,255,255,.70);
  transition: .18s ease;
}
.fp-auth-tabs-v2 .link-tab.active{
  background: rgba(255,255,255,.12);
  color:#fff;
}

/* Social */
.auth-social{ margin: 6px 0 14px; }
.btn-social{
  width:100%;
  display:flex; align-items:center; justify-content:center; gap:10px;
  border-radius: 12px;
  padding: 12px 14px;
  background: rgba(0,0,0,.14);
  border: 1px solid rgba(255,255,255,.12);
  color:#fff;
  font-weight: 900;
}
.btn-social:hover{ background: rgba(0,0,0,.22); }
.divider{ position:relative; text-align:center; margin: 12px 0 4px; }
.divider span{
  display:inline-block; padding: 0 10px;
  color: rgba(255,255,255,.55);
  background: transparent;
  font-weight: 700; font-size: 12px;
}
.divider:before{
  content:""; position:absolute; left:0; right:0; top:50%;
  height:1px; background: rgba(255,255,255,.10);
  transform: translateY(-50%);
  z-index:-1;
}

/* Inputs */
.fp-input-v2{ position: relative; }
.fp-input-v2 .form-control{
  border-radius: 12px;
  padding-right: 44px;
  transition: .2s ease;
}
.fp-input-v2 .form-control:focus{
  box-shadow: 0 0 0 4px rgba(59,130,246,.18);
}
.toggle-pass{
  position:absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  width: 34px; height: 34px;
  border-radius: 10px;
  border: 1px solid rgba(255,255,255,.12);
  background: rgba(0,0,0,.12);
  color:#fff;
  display:flex; align-items:center; justify-content:center;
}

/* Buttons */
.btn-auth{
  border-radius: 12px;
  padding: 12px 14px;
  font-weight: 900;
}

/* Bottom note */
.auth-bottom-note{
  margin-top: 12px;
  text-align:center;
  color: rgba(255,255,255,.65);
  font-weight: 700;
}
.auth-bottom-note a{ color:#fff; text-decoration: underline; }
.fp-auth-layout{
  display: grid;
  grid-template-columns: 1.1fr .9fr;
  gap: 24px;
  align-items: stretch; /* doğru */
}

/* 🔥 ASIL DÜZELTME */
.fp-auth-card,
.fp-auth-card-v2{
  height: 100%;
  display: flex;
}

.fp-auth-card-v2 .fp-card-body{
  display: flex;
  flex-direction: column;
  justify-content: center; /* ortalı ve eşit */
  height: 100%;
}

/* LIGHT MODE */
html[data-theme="light"] .fp-auth-hero{
  background: radial-gradient(circle at 20% 0%, rgba(59,130,246,.18), transparent 45%),
              radial-gradient(circle at 90% 20%, rgba(16,185,129,.12), transparent 40%),
              #fff;
  border: 1px solid rgba(0,0,0,.10);
  box-shadow: 0 18px 60px rgba(0,0,0,.10);
  backdrop-filter:none;
}
html[data-theme="light"] .hero-title{ color:#0f172a; }
html[data-theme="light"] .hero-sub,
html[data-theme="light"] .badge-item,
html[data-theme="light"] .mini-subtitle{
  color:#334155;
}
html[data-theme="light"] .badge-item,
html[data-theme="light"] .mini-card{
  background: rgba(0,0,0,.03);
  border: 1px solid rgba(0,0,0,.08);
}
html[data-theme="light"] .mini-icon{ color:#0f172a; background: rgba(0,0,0,.03); border-color: rgba(0,0,0,.08); }

html[data-theme="light"] .fp-auth-tabs-v2{
  background: rgba(0,0,0,.03);
  border-color: rgba(0,0,0,.08);
}
html[data-theme="light"] .fp-auth-tabs-v2 .link-tab{ color:#64748b; }
html[data-theme="light"] .fp-auth-tabs-v2 .link-tab.active{ background: rgba(0,0,0,.04); color:#0f172a; }

html[data-theme="light"] .btn-social{
  background: rgba(0,0,0,.03);
  border-color: rgba(0,0,0,.10);
  color:#0f172a;
}

html[data-theme="light"] .divider span{ color:#64748b; }
html[data-theme="light"] .divider:before{ background: rgba(0,0,0,.10); }

html[data-theme="light"] .toggle-pass{
  background: rgba(0,0,0,.03);
  border-color: rgba(0,0,0,.10);
  color:#0f172a;
}
html[data-theme="light"] .auth-bottom-note{ color:#64748b; }
html[data-theme="light"] .auth-bottom-note a{ color:#0f172a; }
/* HERO LOGO - büyük + stabil */
.hero-logo{
  display:inline-flex;
  align-items:center;
  justify-content:flex-start;
  height: 64px;              /* logo alanı */
  width: 100%;
  position: relative;
}

.hero-logo img{
  height: 56px;              /* logo boyutu (büyüt) */
  width: auto;
  max-width: 260px;          /* taşmasın */
  object-fit: contain;
  display:block;             /* asla display:none yapma */
}

/* İki logo üst üste dursun, tema ile opacity değişsin */
.hero-logo .hero-logo-dark,
.hero-logo .hero-logo-light{
  position:absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
  transition: opacity .2s ease;
}

html[data-theme="light"] .hero-logo .hero-logo-dark{ opacity: 1; }
html[data-theme="light"] .hero-logo .hero-logo-light{ opacity: 0; }

html[data-theme="dark"]  .hero-logo .hero-logo-dark{ opacity: 0; }
html[data-theme="dark"]  .hero-logo .hero-logo-light{ opacity: 1; }

/* ------------------------------------ */
/* KONUM / BOŞLUK DÜZELTME (daha düzgün) */
/* ------------------------------------ */
/* =========================
   HERO BADGE + MINI CARD
   THEME FIX (icons + text)
   ========================= */

/* DARK (default) */
.fp-auth-hero .badge-item,
.fp-auth-hero .mini-title,
.fp-auth-hero .mini-subtitle{
  color: rgba(255,255,255,.80);
}

.fp-auth-hero .badge-item i,
.fp-auth-hero .mini-icon i{
  color: rgba(255,255,255,.92);
}

/* LIGHT MODE */
html[data-theme="light"] .fp-auth-hero .badge-item{
  color:#334155 !important;
  background: rgba(0,0,0,.03) !important;
  border-color: rgba(0,0,0,.08) !important;
}

html[data-theme="light"] .fp-auth-hero .badge-item i{
  color:#0f172a !important;          /* ikonlar koyu olsun */
  opacity: .95;
}

/* Mini cards: %0 Komisyon / Hızlı Üyelik */
html[data-theme="light"] .fp-auth-hero .mini-title{
  color:#0f172a !important;
}

html[data-theme="light"] .fp-auth-hero .mini-subtitle{
  color:#475569 !important;
}

html[data-theme="light"] .fp-auth-hero .mini-icon{
  background: rgba(0,0,0,.03) !important;
  border-color: rgba(0,0,0,.08) !important;
}

html[data-theme="light"] .fp-auth-hero .mini-icon i{
  color:#0f172a !important;          /* mini ikon koyu */
}

.fp-auth-layout{ align-items: stretch; }

.fp-auth-hero,
.fp-auth-card-v2{ height: 100%; }

.fp-auth-hero .hero-inner{
  height: 100%;
  display: flex;
  flex-direction: column;
  gap: 14px;                 /* elemanlar arası düzenli boşluk */
  padding: 32px;             /* biraz daha ferah */
}

/* Eski margin-top:auto konumu bozabiliyordu: kaldırıyoruz */
.fp-auth-hero .hero-mini{
  margin-top: 10px;          /* sabit ve kontrollü */
}

/* Hero başlık/alt yazı daha iyi otursun */
.hero-title{ margin-top: 6px; }

/* Sağ kartın içeriği de daha dengeli */
.fp-auth-card-v2 .fp-card-body{
  height: 100%;
  display: flex;
  flex-direction: column;
}

.fp-auth-tabs-v2{ margin-top: 14px; }
.auth-bottom-note{ margin-top: 14px; }

</style>
<script>
$(document).ready(function() {

  function showLogin(){
    $(".show-register-form").removeClass("active");
    $(".show-login-form").addClass("active");
    $(".auth-register-form").hide();
    $(".auth-login-form").show();
  }

  function showRegister(){
    $(".show-login-form").removeClass("active");
    $(".show-register-form").addClass("active");
    $(".auth-register-form").show();
    $(".auth-login-form").hide();
  }

  $(".show-login-form").on("click", function(e){ e.preventDefault(); showLogin(); });
  $(".show-register-form").on("click", function(e){ e.preventDefault(); showRegister(); });

  $(".show-register-form-inline").on("click", function(e){ e.preventDefault(); showRegister(); });
  $(".show-login-form-inline").on("click", function(e){ e.preventDefault(); showLogin(); });

  if (window.location.search.includes("kayit-ol")) {
    showRegister();
  }

  // Şifre göster/gizle
  document.querySelectorAll(".toggle-pass").forEach(btn => {
    btn.addEventListener("click", () => {
      const target = document.querySelector(btn.getAttribute("data-target"));
      if (!target) return;
      const isPass = target.type === "password";
      target.type = isPass ? "text" : "password";
      btn.innerHTML = isPass ? '<i class="ri-eye-off-line"></i>' : '<i class="ri-eye-line"></i>';
    });
  });

});
</script>

</section>
