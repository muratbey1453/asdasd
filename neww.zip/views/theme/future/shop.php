<section class="fp-section-page shop-page">
  <div class="container">

    <?php
      // Kapak görseli: varsa cover alanını kullan, yoksa shop_img
      $coverUrl   = base_url('assets/img/shop/') . $seller->shop_img;
      $profileUrl = base_url('assets/img/shop/') . $seller->shop_img;

      // İstatistikler
      $salesCount   = $this->db->where('seller_id', $seller->id)->count_all_results('invoice');
      $refundCount  = $this->db->where('seller_id', $seller->id)->where('isActive', 2)->count_all_results('invoice');
      $productCount = $this->db->where('seller_id', $seller->id)->where('isActive', 1)->count_all_results('product');
      $successRate  = ($salesCount == 0) ? 100 : round((($salesCount - $refundCount) / $salesCount) * 100, 2);

      // Ürünler
      $products = $this->db
        ->where('isActive', 1)
        ->where('seller_id', $seller->id)
        ->order_by('id', 'DESC')
        ->get('product')->result();

      // =========================
      // Değerlendirmeler (product + product_comments + user)
      // product_comments: id, comment, star, date, isActive, user_id, product_id
      // user: id, name
      // =========================
      $reviewSummary = $this->db
        ->select('COUNT(pc.id) AS cnt, COALESCE(AVG(pc.star),0) AS avg_star', false)
        ->from('product_comments pc')
        ->join('product p', 'p.id = pc.product_id', 'inner')
        ->where('p.seller_id', $seller->id)
        ->where('pc.isActive', 1)
        ->get()->row();

      $reviewCount = (int)($reviewSummary->cnt ?? 0);
      $avgStar     = (float)($reviewSummary->avg_star ?? 0);

      $reviews = $this->db
        ->select('pc.id, pc.comment, pc.star, pc.date, pc.user_id, u.name AS user_name, p.name AS product_name, p.slug', false)
        ->from('product_comments pc')
        ->join('product p', 'p.id = pc.product_id', 'inner')
        ->join('user u', 'u.id = pc.user_id', 'left')
        ->where('p.seller_id', $seller->id)
        ->where('pc.isActive', 1)
        ->order_by('pc.id', 'DESC')
        ->limit(30)
        ->get()->result();

      function renderStars($star){
        $star = (int)$star;
        $out = '';
        for($i=1; $i<=5; $i++){
          $out .= ($i <= $star) ? '<i class="ri-star-fill"></i>' : '<i class="ri-star-line"></i>';
        }
        return $out;
      }
    ?>

    <!-- HERO / KAPAK -->
    <div class="fp-card shop-hero">
      <div class="shop-cover" style="background-image:url('<?= $coverUrl ?>');"></div>

      <div class="shop-hero-body">
        <div class="shop-avatar">
          <img src="<?= $profileUrl ?>" alt="<?= htmlspecialchars($seller->shop_name) ?>">
        </div>

        <div class="shop-meta">
          <h1 class="shop-title" data-text="<?= htmlspecialchars($seller->shop_name) ?>"><?= $seller->shop_name ?></h1>


          <!-- yıldızlar: ALT SATIR + SAĞ -->
          
        </div>
      </div>
    </div>

    <!-- İSTATİSTİKLER -->
    <div class="row g-3 shop-stats-row">
      <div class="col-6 col-md-3">
        <div class="fp-card shop-stat-card">
          <div class="shop-stat-left">
            <div class="shop-stat-key">Başarılı Satış</div>
            <div class="shop-stat-val"><?= $salesCount ?></div>
          </div>
          <div class="shop-stat-ico"><i class="ri-shield-check-line"></i></div>
        </div>
      </div>

      <div class="col-6 col-md-3">
        <div class="fp-card shop-stat-card">
          <div class="shop-stat-left">
            <div class="shop-stat-key">Ürün Sayısı</div>
            <div class="shop-stat-val"><?= $productCount ?></div>
          </div>
          <div class="shop-stat-ico"><i class="ri-box-3-line"></i></div>
        </div>
      </div>

      <div class="col-6 col-md-3">
        <div class="fp-card shop-stat-card">
          <div class="shop-stat-left">
            <div class="shop-stat-key">İade Sayısı</div>
            <div class="shop-stat-val"><?= $refundCount ?></div>
          </div>
          <div class="shop-stat-ico text-danger"><i class="ri-refund-2-line"></i></div>
        </div>
      </div>

      <div class="col-6 col-md-3">
        <div class="fp-card shop-stat-card">
          <div class="shop-stat-left">
            <div class="shop-stat-key">Başarı Oranı</div>
            <div class="shop-stat-val">%<?= $successRate ?></div>
          </div>
          <div class="shop-stat-ico text-success"><i class="ri-checkbox-circle-line"></i></div>
        </div>
      </div>
    </div>

    <!-- DEĞERLENDİRMELER (Slider) -->
    <div class="fp-card shop-reviews-card mt-4">
      <div class="shop-reviews-head">
        <div class="shop-reviews-title">
          Değerlendirmeler
          <span class="shop-reviews-badge"><?= $reviewCount ?> yorum</span>
        </div>

        <div class="shop-reviews-avg">
          <div class="shop-reviews-avg-num"><?= number_format($avgStar, 1) ?></div>
          <div class="shop-reviews-avg-stars"><?= renderStars((int)round($avgStar)) ?></div>
        </div>
      </div>

      <div class="shop-reviews-slider">
        <button class="shop-reviews-nav prev" type="button" aria-label="Önceki yorumlar">
          <i class="ri-arrow-left-s-line"></i>
        </button>

        <div class="shop-reviews-track" id="shopReviewsTrack" tabindex="0">
          <?php if (empty($reviews)) { ?>
            <div class="shop-review-empty">Henüz değerlendirme yok.</div>
          <?php } else { ?>
            <?php foreach($reviews as $r){
              $uname = !empty($r->user_name) ? $r->user_name : 'Kullanıcı';
              $initial = mb_strtoupper(mb_substr($uname, 0, 1, 'UTF-8'), 'UTF-8');
            ?>
              <div class="shop-review-card">
                <div class="shop-review-card-top">
                  <div class="shop-review-avatar"><?= htmlspecialchars($initial) ?></div>

                  <div class="shop-review-who">
                    <div class="shop-review-user"><?= htmlspecialchars($uname) ?></div>
                    <div class="shop-review-stars"><?= renderStars($r->star) ?></div>
                  </div>
                </div>

                <div class="shop-review-meta">
                  <a class="shop-review-product" href="<?= base_url($r->slug) ?>">
                    <?= htmlspecialchars($r->product_name) ?>
                  </a>
                  <span class="shop-review-date">
                    <?= !empty($r->date) ? date('d.m.Y', strtotime($r->date)) : '' ?>
                  </span>
                </div>

                <?php if (!empty($r->comment)) { ?>
                  <div class="shop-review-text"><?= nl2br(htmlspecialchars($r->comment)) ?></div>
                <?php } else { ?>
                  <div class="shop-review-text shop-review-text--empty">Yorum yok.</div>
                <?php } ?>
              </div>
            <?php } ?>
          <?php } ?>
        </div>

        <button class="shop-reviews-nav next" type="button" aria-label="Sonraki yorumlar">
          <i class="ri-arrow-right-s-line"></i>
        </button>
      </div>
    </div>

    <!-- İLANLAR BAŞLIK -->
    <div class="fp-card fp-card-client mb-16 mt-4">
      <div class="fp-cc-head border-bottom-0 shop-listing-head">
        <h1 class="title mb-0">İlanlar</h1>
        <span class="shop-count-badge"><?= count($products) ?> ürün</span>
      </div>
    </div>

    <!-- ÜRÜNLER -->
    <div class="row row-products">
      <?php foreach ($products as $p) { ?>
        <?php $price = json_decode(calculatePrice($p->id, 1), true); ?>
        <div class="col-6 col-md-6 col-lg-4 col-xl-3">
          <div class="fp-product-item">
            <a class="img" href="<?= base_url($p->slug) ?>">
              <img src="<?= base_url('assets/img/product/') . $p->img ?>" alt="" class="img-product img-aspect">
            </a>
            <div class="content">
              <a class="product-name" href="<?= base_url($p->slug) ?>"><?= $p->name ?></a>
              <div class="price shop-price">
                <?php if ($price['isDiscount'] == 1) { ?>
                  <div class="price-new"><?= $price['normalPrice'] ?> TL</div>
                  <div class="price-old"><?= $price['price'] ?> TL</div>
                <?php } else { ?>
                  <div class="price-new"><?= $price['price'] ?> TL</div>
                <?php } ?>
              </div>
              <div class="shop-buy-row">
  <a class="btn btn-primary shop-buy-btn" href="<?= base_url($p->slug) ?>">
    Satın Al
  </a>
</div>

            </div>
          </div>
        </div>
      <?php } ?>
    </div>

  </div>
</section>

<style>
    .shop-page .fp-product-item{
  display: flex;
  flex-direction: column;
}

.shop-page .fp-product-item .content{
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.shop-page .shop-buy-row{
  margin-top: 8px;
}

.shop-page .shop-buy-btn{
  width: 100%;
  border-radius: 14px;
  padding: 10px 12px;
  font-weight: 900;
  letter-spacing: .2px;
}

/* =========================
   HERO / BAŞLIK OKUNABİLİRLİK
   ========================= */
.shop-page .shop-hero{
  border-radius: 18px;
  overflow: hidden;
  position: relative;
}

.shop-page .shop-cover{
  height: 220px;
  background-size: cover;
  background-position: center;
  position: relative;
}
.shop-page .shop-cover::after{
  content:"";
  position:absolute;
  inset:0;
  background: linear-gradient(to bottom, rgba(0,0,0,0.12) 0%, rgba(0,0,0,0.78) 100%);
}

.shop-page .shop-hero-body{
  position: relative;
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 0 18px 18px 18px;
  margin-top: -52px;
}

.shop-page .shop-avatar{
  width: 104px;
  height: 104px;
  border-radius: 22px;
  overflow: hidden;
  flex: 0 0 auto;
  border: 3px solid rgba(255,255,255,0.92);
  box-shadow: 0 10px 25px rgba(0,0,0,0.25);
  background: #fff;
}
.shop-page .shop-avatar img{
  width:100%;
  height:100%;
  object-fit: cover;
}

/* Meta alanı */
.shop-page .shop-meta{
  min-width: 0;
  padding: 10px 12px;
  border-radius: 14px;
}

/* Title (dark/light fix) */
.shop-page .shop-title{
  margin: 0;
  font-size: 28px;
  font-weight: 900;
  line-height: 1.1;
  letter-spacing: .2px;
}

html[data-theme="dark"] .shop-page .shop-title{
  color: #fff;
  text-shadow: 0 8px 18px rgba(0,0,0,0.45);
}
html[data-theme="dark"] .shop-page .shop-meta{
  background: rgba(0,0,0,0.32);
}

html[data-theme="light"] .shop-page .shop-title{
  color: #111;
  text-shadow: none;
}
html[data-theme="light"] .shop-page .shop-meta{
  background: rgba(255,255,255,0.92);
  box-shadow: 0 10px 25px rgba(0,0,0,0.10);
}

/* Yıldızlar: alt satır + sağ */
.shop-page .shop-meta{
  display: flex !important;
  flex-direction: column !important;
  align-items: flex-start !important;
  gap: 8px;
}
.shop-page .shop-meta .fp-stars{
  align-self: flex-end !important;
  display: flex !important;
  justify-content: flex-end !important;
  white-space: nowrap;
}
.shop-page .shop-hero .fp-stars i{ font-size: 18px; }

/* =========================
   PREMIUM STAT KUTULARI
   ========================= */
.shop-page .shop-stats-row{ margin-top: 14px; }

.shop-page .shop-stats-row > div:nth-child(1) { --accent: 122,213,255; }
.shop-page .shop-stats-row > div:nth-child(2) { --accent: 255,128,52;  }
.shop-page .shop-stats-row > div:nth-child(3) { --accent: 255,52,52;   }
.shop-page .shop-stats-row > div:nth-child(4) { --accent: 0,255,170;   }

.shop-page .shop-stat-card{
  position: relative;
  overflow: hidden;
  border-radius: 18px;
  padding: 14px 14px;
  display:flex;
  align-items:center;
  justify-content: space-between;
  gap: 12px;
  height: 100%;

  background: rgba(255,255,255,0.04);
  border: 1px solid rgba(255,255,255,0.08);
  backdrop-filter: blur(10px) saturate(115%);
  -webkit-backdrop-filter: blur(10px) saturate(115%);
  box-shadow: 0 10px 26px rgba(0,0,0,0.22), inset 0 1px 0 rgba(255,255,255,0.06);
  transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease;
}
html[data-theme="light"] .shop-page .shop-stat-card{
  background: rgba(255,255,255,0.86);
  border: 1px solid rgba(0,0,0,0.06);
  box-shadow: 0 10px 26px rgba(0,0,0,0.08), inset 0 1px 0 rgba(255,255,255,0.78);
}

/* ince premium gradient border */
.shop-page .shop-stat-card::after{
  content:"";
  position:absolute;
  inset:0;
  border-radius: 18px;
  padding: 1px;
  background: linear-gradient(135deg,
    rgba(var(--accent),0.30),
    rgba(255,255,255,0.05),
    rgba(var(--accent),0.12)
  );
  pointer-events:none;

  -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
  -webkit-mask-composite: xor;
          mask-composite: exclude;
  opacity: .95;
}
html[data-theme="light"] .shop-page .shop-stat-card::after{
  background: linear-gradient(135deg,
    rgba(var(--accent),0.18),
    rgba(0,0,0,0.03),
    rgba(var(--accent),0.10)
  );
  opacity: 1;
}

/* hover */
.shop-page .shop-stat-card:hover{
  transform: translateY(-2px);
  border-color: rgba(255,255,255,0.12);
  box-shadow: 0 16px 40px rgba(0,0,0,0.26), inset 0 1px 0 rgba(255,255,255,0.08);
}
html[data-theme="light"] .shop-page .shop-stat-card:hover{
  border-color: rgba(0,0,0,0.08);
  box-shadow: 0 16px 40px rgba(0,0,0,0.12), inset 0 1px 0 rgba(255,255,255,0.85);
}

.shop-page .shop-stat-key{
  font-size: 12px;
  font-weight: 800;
  letter-spacing: .2px;
  opacity: .78;
  margin-bottom: 3px;
}
.shop-page .shop-stat-val{
  font-size: 20px;
  font-weight: 900;
  letter-spacing: .2px;
  line-height: 1.1;
}

.shop-page .shop-stat-ico{
  width: 42px;
  height: 42px;
  border-radius: 16px;
  display:flex;
  align-items:center;
  justify-content:center;
  background: rgba(255,255,255,0.05);
  border: 1px solid rgba(255,255,255,0.08);
}
html[data-theme="light"] .shop-page .shop-stat-ico{
  background: rgba(0,0,0,0.02);
  border: 1px solid rgba(0,0,0,0.06);
}
.shop-page .shop-stat-ico i{
  font-size: 20px;
  color: rgba(var(--accent),0.95);
  opacity: .95;
}
/* ===== SHOP TITLE: görünür (dark+light) + hafif yıldız ışıltısı ===== */
.shop-page .shop-title{
  position: relative;
  display: inline-block;

  font-family: "Poppins","Plus Jakarta Sans","Inter",system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;
  font-size: 30px;
  font-weight: 900;
  letter-spacing: .3px;
  line-height: 1.1;

  /* FALLBACK: her durumda görünür */
  color: #111 !important;                 /* light default */
  text-shadow: 0 8px 18px rgba(0,0,0,0.10);
}

/* Dark mod: beyaz + güçlü okunurluk */
html[data-theme="dark"] .shop-page .shop-title{
  color: #fff !important;
  text-shadow: 0 10px 22px rgba(0,0,0,0.55);
}

/* Gradient sadece destek varsa (ama okunurluk bozulmasın) */
@supports ((-webkit-background-clip: text) or (background-clip: text)){
  html[data-theme="dark"] .shop-page .shop-title{
    background: linear-gradient(90deg,
      rgba(255,255,255,0.98),
      rgba(122,213,255,1),
      rgba(255,41,130,1),
      rgba(255,255,255,0.98)
    );
    background-size: 220% 100%;
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
    color: transparent !important;

    animation: shopTitleGradient 4.2s ease-in-out infinite;
  }

  /* Light modda gradienti daha koyu yapıyoruz ki kaybolmasın */
  html[data-theme="light"] .shop-page .shop-title{
    background: linear-gradient(90deg,
      rgba(17,17,17,0.98),
      rgba(0,137,255,0.92),
      rgba(255,41,130,0.85),
      rgba(17,17,17,0.98)
    );
    background-size: 220% 100%;
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
    color: transparent !important;

    /* light modda text-shadow kapat */
    text-shadow: none;
    animation: shopTitleGradient 4.8s ease-in-out infinite;
  }
}

/* ===== YILDIZ IŞILTISI (sweep yok) ===== */
/* Başlığın arkasında çok hafif, küçük "sparkle" noktaları */
.shop-page .shop-title::before{
  content:"";
  position: absolute;
  inset: -10px -14px;
  pointer-events: none;
  border-radius: 14px;

  /* minik yıldız/nokta hissi: birkaç radial gradient */
  background:
    radial-gradient(circle at 12% 35%, rgba(255,255,255,0.45) 0 1px, rgba(255,255,255,0) 2px),
    radial-gradient(circle at 28% 70%, rgba(122,213,255,0.45) 0 1px, rgba(122,213,255,0) 3px),
    radial-gradient(circle at 55% 25%, rgba(255,41,130,0.40) 0 1px, rgba(255,41,130,0) 3px),
    radial-gradient(circle at 78% 62%, rgba(255,255,255,0.35) 0 1px, rgba(255,255,255,0) 3px),
    radial-gradient(circle at 92% 30%, rgba(122,213,255,0.35) 0 1px, rgba(122,213,255,0) 3px);

  opacity: .35;
  filter: blur(.2px);
  mix-blend-mode: screen;

  animation: shopTitleSparkle 2.8s ease-in-out infinite;
}

/* Light modda sparkle daha az görünür (çok parlamasın) */
html[data-theme="light"] .shop-page .shop-title::before{
  opacity: .16;
  mix-blend-mode: normal;
}

/* Gradient anim */
@keyframes shopTitleGradient{
  0%   { background-position: 0% 50%; }
  50%  { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

/* Sparkle "titreşim" gibi hafif hareket */
@keyframes shopTitleSparkle{
  0%   { transform: translate3d(0,0,0); opacity: .25; }
  50%  { transform: translate3d(1px,-1px,0); opacity: .45; }
  100% { transform: translate3d(0,0,0); opacity: .25; }
}

/* Hareket azaltma */
@media (prefers-reduced-motion: reduce){
  .shop-page .shop-title{ animation: none !important; }
  .shop-page .shop-title::before{ animation: none !important; }
}

/* =========================
   DEĞERLENDİRMELER (Slider - küçük kartlar + oklar)
   ========================= */
.shop-page .shop-reviews-card{
  border-radius: 18px;
  overflow: hidden;
}

.shop-page .shop-reviews-head{
  padding: 14px 16px;
  display:flex;
  align-items:center;
  justify-content: space-between;
  gap: 14px;
  background: rgba(255,255,255,0.04);
  border-bottom: 1px solid rgba(255,255,255,0.08);
  backdrop-filter: blur(10px) saturate(115%);
  -webkit-backdrop-filter: blur(10px) saturate(115%);
}
html[data-theme="light"] .shop-page .shop-reviews-head{
  background: rgba(255,255,255,0.90);
  border-bottom: 1px solid rgba(0,0,0,0.06);
}

.shop-page .shop-reviews-title{
  font-weight: 900;
  letter-spacing: .2px;
  display:flex;
  align-items:center;
  gap: 10px;
}
.shop-page .shop-reviews-badge{
  font-size: 12px;
  font-weight: 900;
  padding: 6px 10px;
  border-radius: 999px;
  background: rgba(255,255,255,0.06);
  border: 1px solid rgba(255,255,255,0.10);
}
html[data-theme="light"] .shop-page .shop-reviews-badge{
  background: rgba(0,0,0,0.03);
  border: 1px solid rgba(0,0,0,0.06);
}

.shop-page .shop-reviews-avg{
  display:flex;
  align-items:center;
  gap: 10px;
  white-space: nowrap;
}
.shop-page .shop-reviews-avg-num{
  font-weight: 900;
  font-size: 18px;
}
.shop-page .shop-reviews-avg-stars i{ font-size: 16px; }

/* slider wrapper */
.shop-page .shop-reviews-slider{
  position: relative;
  padding: 14px 44px;
}
.shop-page .shop-reviews-track{
  display: flex;
  gap: 12px;
  overflow-x: auto;
  padding: 2px;
  scroll-snap-type: x mandatory;
  scroll-behavior: smooth;
  -webkit-overflow-scrolling: touch;
  scrollbar-width: none;
}
.shop-page .shop-reviews-track::-webkit-scrollbar{ height: 0; }

.shop-page .shop-review-empty{
  padding: 18px 16px;
  opacity: .7;
}

/* review card */
.shop-page .shop-review-card{
  scroll-snap-align: start;
  flex: 0 0 auto;
  width: 280px;
  border-radius: 16px;
  padding: 12px 12px;
  background: rgba(255,255,255,0.04);
  border: 1px solid rgba(255,255,255,0.10);
  backdrop-filter: blur(10px) saturate(115%);
  -webkit-backdrop-filter: blur(10px) saturate(115%);
  box-shadow: 0 10px 24px rgba(0,0,0,0.18), inset 0 1px 0 rgba(255,255,255,0.05);
}
html[data-theme="light"] .shop-page .shop-review-card{
  background: rgba(255,255,255,0.92);
  border: 1px solid rgba(0,0,0,0.06);
  box-shadow: 0 10px 24px rgba(0,0,0,0.08), inset 0 1px 0 rgba(255,255,255,0.65);
}

.shop-page .shop-review-card-top{
  display:flex;
  align-items:center;
  gap: 10px;
}
.shop-page .shop-review-avatar{
  width: 38px;
  height: 38px;
  border-radius: 14px;
  display:flex;
  align-items:center;
  justify-content:center;
  font-weight: 900;
  background: rgba(255,255,255,0.06);
  border: 1px solid rgba(255,255,255,0.10);
}
html[data-theme="light"] .shop-page .shop-review-avatar{
  background: rgba(0,0,0,0.03);
  border: 1px solid rgba(0,0,0,0.06);
}

.shop-page .shop-review-who{ min-width:0; flex:1; }
.shop-page .shop-review-user{
  font-weight: 900;
  font-size: 13px;
  overflow:hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.shop-page .shop-review-stars{
  margin-top: 2px;
  display:flex;
  gap: 2px;
  opacity: .95;
}
.shop-page .shop-review-stars i{ font-size: 13px; }

.shop-page .shop-review-meta{
  margin-top: 10px;
  display:flex;
  align-items:center;
  justify-content: space-between;
  gap: 10px;
  font-size: 12px;
  opacity: .75;
}
.shop-page .shop-review-product{
  text-decoration: none;
  font-weight: 900;
  opacity: .9;
  overflow:hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.shop-page .shop-review-date{ white-space: nowrap; }

.shop-page .shop-review-text{
  margin-top: 10px;
  font-size: 13px;
  line-height: 1.35;
  opacity: .92;
  max-height: 76px;
  overflow: hidden;
}
.shop-page .shop-review-text--empty{ opacity: .65; }

/* oklar */
.shop-page .shop-reviews-nav{
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  width: 34px;
  height: 34px;
  border-radius: 12px;
  border: 1px solid rgba(255,255,255,0.12);
  background: rgba(0,0,0,0.25);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  display:flex;
  align-items:center;
  justify-content:center;
  cursor: pointer;
  z-index: 5;
}
html[data-theme="light"] .shop-page .shop-reviews-nav{
  background: rgba(255,255,255,0.85);
  border: 1px solid rgba(0,0,0,0.08);
}
.shop-page .shop-reviews-nav i{ font-size: 20px; }
.shop-page .shop-reviews-nav.prev{ left: 10px; }
.shop-page .shop-reviews-nav.next{ right: 10px; }
.shop-page .shop-reviews-nav:disabled{
  opacity: .35;
  cursor: not-allowed;
}

/* =========================
   İLANLAR başlık satırı
   ========================= */
.shop-page .shop-listing-head{
  display:flex;
  align-items:center;
  justify-content: space-between;
  gap: 12px;
}
.shop-page .shop-count-badge{
  padding: 6px 10px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 900;
  background: rgba(255,255,255,0.08);
  color: var(--text-color, #fff);
}
html[data-theme="light"] .shop-page .shop-count-badge{
  background: rgba(0,0,0,0.03);
  color: #111;
}

/* =========================
   ÜRÜNLER: 5'li grid + görsel alanı küçült
   ========================= */
.shop-page .row-products{
  margin-left: 0 !important;
  margin-right: 0 !important;

  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 14px;
}

.shop-page .row-products > [class*="col-"]{
  padding: 0 !important;
  margin: 0 !important;
  max-width: none !important;
  flex: none !important;
  width: auto !important;
}

@media (min-width: 768px){
  .shop-page .row-products{ grid-template-columns: repeat(3, minmax(0, 1fr)); }
}
@media (min-width: 992px){
  .shop-page .row-products{ grid-template-columns: repeat(4, minmax(0, 1fr)); }
}
@media (min-width: 1200px){
  .shop-page .row-products{ grid-template-columns: repeat(5, minmax(0, 1fr)); }
}

/* Görsel alanı: kartın yarısını kaplamasın */
.shop-page .fp-product-item{
  border-radius: 16px !important;
  padding: 0px !important;
}
.shop-page .fp-product-item .img{
  padding-bottom: 0 !important;
  height: 130px;
  width: 100%;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 8px !important;
}
.shop-page .fp-product-item .img{
  overflow: hidden;         /* taşanı kes */
  border-radius: 0px;      /* istersen */
}

.shop-page .fp-product-item .img img{
  width: 100% !important;
  height: 100% !important;
  object-fit: cover !important;   /* FULL KAPLAR */
  object-position: center;        /* ortala */
}

@media (min-width: 1200px){
  .shop-page .fp-product-item .img{ height: 380px; }
}

.shop-page .fp-product-item .product-name{
  font-size: 13px !important;
  font-weight: 800 !important;
  line-height: 1.15;
}
.shop-page .fp-product-item .price .price-new{
  font-size: 13px ;
  font-weight: 900 ;
}
.shop-page .fp-product-item .price .price-old{
  font-size: 12px ;
}

/* Mobil düzen: ortala */
@media (max-width: 576px){
  .shop-page .shop-cover{ height: 180px; }
  .shop-page .shop-hero-body{
    flex-direction: column;
    align-items: center;
    text-align: center;
    margin-top: -60px;
  }
  .shop-page .shop-title{ font-size: 22px; }
  .shop-page .shop-meta .fp-stars{ align-self: center !important; }
  .shop-page .shop-reviews-slider{ padding: 14px 38px; }
  .shop-page .shop-review-card{ width: 240px; }
}
.shop-page .fp-product-item .price.shop-price{
  width: 100% !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  gap: 8px !important;

  padding: 10px 12px !important;
  border-radius: 14px !important;
  margin-top: 8px !important;

  background: rgba(255,255,255,0.06) !important;
  border: 1px solid rgba(255,255,255,0.12) !important;

  backdrop-filter: blur(10px) saturate(120%) !important;
  -webkit-backdrop-filter: blur(10px) saturate(120%) !important;

  box-shadow: inset 0 1px 0 rgba(255,255,255,0.06) !important;
}

html[data-theme="light"] .shop-page .fp-product-item .price.shop-price{
  background: rgba(0,0,0,0.03) !important;
  border: 1px solid rgba(0,0,0,0.10) !important;
  box-shadow: inset 0 1px 0 rgba(255,255,255,0.85) !important;
}

/* Senin yazdığın font ayarlarını da shop-price ile güçlendirelim */
.shop-page .fp-product-item .price.shop-price .price-new{
  font-size: 14px !important;
  font-weight: 900 !important;
  letter-spacing: .2px !important;
}

.shop-page .fp-product-item .price.shop-price .price-old{
  font-size: 12px !important;
  font-weight: 800 !important;
  opacity: .55 !important;
  text-decoration: line-through !important;
}

</style>

<script>
document.addEventListener('DOMContentLoaded', function () {
  const track = document.getElementById('shopReviewsTrack');
  if (!track) return;

  const prevBtn = document.querySelector('.shop-reviews-nav.prev');
  const nextBtn = document.querySelector('.shop-reviews-nav.next');

  function updateButtons(){
    if (!prevBtn || !nextBtn) return;
    const maxScrollLeft = track.scrollWidth - track.clientWidth - 2;
    prevBtn.disabled = track.scrollLeft <= 2;
    nextBtn.disabled = track.scrollLeft >= maxScrollLeft;
  }

  function scrollByAmount(dir){
    const amount = Math.max(220, Math.floor(track.clientWidth * 0.8));
    track.scrollBy({ left: dir * amount, behavior: 'smooth' });
  }

  if (prevBtn) prevBtn.addEventListener('click', () => scrollByAmount(-1));
  if (nextBtn) nextBtn.addEventListener('click', () => scrollByAmount(1));

  track.addEventListener('scroll', updateButtons);
  window.addEventListener('resize', updateButtons);

  updateButtons();
});
</script>
