<?php
usort($categories, function($a, $b) {
    setlocale(LC_COLLATE, 'tr_TR.UTF-8'); // Türkçe sıralama için
    return strcoll($a->name, $b->name);
});

// Alfabetik sıraya göre kategorileri gruplayacak bir dizi oluşturun
$grupluKategoriler = [];
foreach ($categories as $kategori) {
    $harf = strtoupper(substr($kategori->name, 0, 1));
    $grupluKategoriler[$harf][] = $kategori;
}
?>
<section class="fp-section-page">
    <div class="container">
        <div class="fp-section-page-head">
            <h1 class="title mb-0">Tüm Kategoriler</h1>
        </div>
        <div class="fp-categories-search position-relative">
            <i class="ri-search-line icon"></i>
            <input type="text" class="form-control" placeholder="Kategorileri filtreleyin..." id="category-filter">
        </div>
        <div class="row row-products">
            <?php foreach ($grupluKategoriler as $harf => $kategoriler): ?>
                <?php foreach ($kategoriler as $cat): ?>
                    <div class="col-6 col-md-4 col-lg-3 col-xl-2">
                        <a href="<?= base_url('kategori/' . $cat->slug) ?>" class="fp-categories-item">
                            <div class="img">
                                <img src="<?= base_url('assets/img/category/' . $cat->img) ?>" alt="Kategori Resmi">
                            </div>
                            <div class="name"><?= htmlspecialchars($cat->name, ENT_QUOTES, 'UTF-8') ?></div>
                        </a>
                    </div>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </div>
    </div>
</section>