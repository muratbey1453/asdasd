<ul class="float-right">
    <?php if (!empty($this->session->userdata('info'))) { ?>
        <?php $user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row(); ?>
        <li><a href="<?= base_url('client'); ?>"><i class="fa fa-coins"></i> Bakiye: <?=$user->balance?>₺</a></li>
        <li><a href="<?= base_url('sepet'); ?>"><div class="animate__animated animate__headShake"><i class="fa fa-shopping-basket"></i> Sepet (<?= count($this->advanced_cart->contents()); ?>)</a></div></li>
        <li><a href="<?= base_url('client'); ?>" class="text-success"><i class="fa fa-user-circle"></i> <?=$user->name?></a></li>
        <li><a href="<?= base_url('client/logOut'); ?>" class="text-danger"><i class="fa fa-sign-out-alt"></i> Çıkış</a></li>
   <?php }else{ ?>
        <li><a href="<?= base_url('sepet'); ?>"><div class="animate__animated animate__headShake"><i class="fa fa-shopping-basket"></i> Sepet (<?= count($this->advanced_cart->contents()); ?>)</a></div></li>
        <li><a href="<?= base_url('hesap'); ?>">Kayıt Ol</a></li>
        <li><a href="<?= base_url('hesap'); ?>" class="text-success">Giriş Yap</a></li>
<?php } ?>
</ul>
