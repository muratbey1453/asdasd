<?php  
if (!empty($this->session->userdata('info'))) {
  $user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row();
  $userDiscount = $user->discount;
}else{
  $userDiscount = 0;
}
?>   
<div class="page-cart">
  <div class="container">
    <div class="row">
      <div class="col-lg-9" id="cart">
        <div class="cart-products">

          <?php if (empty($this->session->userdata('info'))) { ?>
            <h2>Son Bir Adım Kaldı</h2>
            <?php echo form_open(base_url('login/regGuest'));?>
            <div class="form-group">
              <label for="email">E-Posta Adresi</label>
              <input type="email" id="email" name="email" class="form-control" placeholder="Mail adresinizi girin." required="">
            </div>
            <small>E-Posta adresini doğru girdiğinden emin ol. Yoksa ürünlerini teslim alamazsın.</small>
            <div class="form-row">
              <div class="form-group col-12 col-lg-6">
                <label for="name">Ad</label>
                <input type="text" id="name" class="form-control" name="name" required="" placeholder="Adınızı girin.">
              </div>
              <div class="form-group col-12 col-lg-6">
                <label for="surname">Soyad</label>
                <input type="text" id="surname" class="form-control" name="surname" required=""  placeholder="Soy Adınızı girin.">
              </div>
            </div>
            <div class="form-group">
              <label for="phone">Telefon Numarası</label>
              <input type="text" id="phone" name="phone" class="form-control" required=""  placeholder="Telefon Numaranızı girin.">
            </div>
            <?php if ($properties->isConfirmTc == 1): ?>
              <div class="form-group">
                  <label for="tc">TC Kimlik NO</label>
                  <input type="text" id="tc" name="tc" class="form-control" minlength="11" maxlength="11" required="">
              </div>
              <div class="form-group">
                  <label for="birthday">Doğum Yılı</label>
                  <input type="text" id="birthday" name="birthday" class="form-control" minlength="4" maxlength="4" required="">
              </div>
              <?php endif ?>
            <!--<div class="form-check form-switch">
              <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked">
              <label class="form-check-label" for="flexSwitchCheckChecked">Şifre Girmek İstiyorum</label>
            </div>-->
            <small id="passwordNote">Not: Bilgilerinizi doldurduğunuzda size bir şifre göndereceğiz. Bundan sonraki siparişlerinizde mail adresinizi ve şifrenizi kullanabilirsiniz.</small>
            <hr>
          <?php } ?>
          <h3>Sepet</h3>

          <?php $amount = $this->advanced_cart->total(); ?>
          <?php foreach ($this->advanced_cart->contents() as $items){ ?>
            <div class="cart-product">
              <div class="row">
                <div class="col-3 col-md-3">
                  <div class="cart-img">
                    <?php $product = $this->db->where('id', $items['product_id'])->get('product')->row(); ?>
                    <?php $path = "assets/img/product/" . $product->img; ?>
                    <img src="<?php 
                    if (file_exists($path)) {
                      echo base_url('assets/img/product/') . $product->img;
                      } else {
                        echo base_url('assets/img/unknown.png');
                      }?>" alt="<?= $product->name ?>">
                    </div>
                  </div>
                  <div class="col-9 col-md-6">
                    <h5><?= $product->name ?></h5>
                    <div class="d-flex justify-content-start align-items-center">
                      <label for="labelAdet" class="mb-0">Adet</label>
                      <input type="number" id="labelAdet" class="form-control input-adet ml-2" min="1" disabled="" value="<?= $items['qty'] ?>">
                    </div>
                  </div>
                  <div class="col-12 col-md-3 cp-price">
                    <h2><?= $items['subtotal']; ?>₺</h2>
                  <a href="<?= base_url('home/removeCart/' . $items['rowid']); ?>" class="cart-delete"><i class="fa fa-times"></i></a>
                </div>
              </div>
            </div>
          <?php } ?>
        </div>
      </div>
      <?php if ($amount > 0){ ?>
       <div class="col-lg-3">
        <div class="cart-total">
          <h3>Toplam</h3>
          <h2><?= $amount  ?>₺</h2>
			<?php if ($this->advanced_cart->has_discount() && $this->advanced_cart->has_cart_extra("coupon_code")) { ?>
				<p class="text-center mt-3">
					<b>Kazancınız:</b>
					<?= $this->advanced_cart->first_total()-$amount  ?>₺
				</p>
			<?php } ?>
			<div>
				<?php
				$coupon_code = ($this->advanced_cart->has_discount() && $this->advanced_cart->has_cart_extra("coupon_code")) ? $this->advanced_cart->get_cart_extra("coupon_code") : false;
				?>
				<div class="input-group">
					<input type="text" class="form-control" placeholder="Kupon Kodu" name="coupon" value="<?= $coupon_code ?? "" ?>" style="<?= ($coupon_code!=false) ? "border-right: 0;" : "" ?>">
					<?php if ($coupon_code!=false) { ?>
						<a href="javascript:cancelCoupon()" class="input-group-text" style="background-color: #fff;">
							<i class="far fa-times-circle" style="color:red;" data-toggle="tooltip" data-placement="top" title="Kuponu kaldır"></i>
						</a>
					<?php } ?>
					<a href="javascript:useCoupon()" class="btn btn-main input-group-text">Uygula</a>
				</div>
				<br>
			</div>
          <?php if (!empty($this->session->userdata('info'))) { ?>
            <?php if ($amount <= $user->balance){ ?>
              <a href="<?= base_url("client/buyOnBalance") ?>" class="btn btn-primary btn-block">Bakiye ile öde <i class="fa fa-long-arrow-alt-right"></i></a>
            <?php }else{ ?>
              <div class="alert alert-danger text-center">Bakiye Yetersiz</div>
              <a href="#modalBalance" data-toggle="modal" class="btn btn-primary btn-block">Bakiye Yükle <i class="fa fa-long-arrow-alt-right"></i></a>
            <?php } ?>
            <p class="text-center mt-3">veya</p>
          <?php } ?>
          <?php if (!empty($this->session->userdata('info'))) { ?>
          <a href="<?= base_url("payment/buyOnCart") ?>" class="btn btn-primary btn-block">Kart ile Öde <i class="fa fa-long-arrow-alt-right"></i></a>
          <?php }else{
            echo form_submit('btn btn-primary', 'Kart ile Öde', ['class'=>'btn btn-primary btn-block']);
          } ?>
          <?php echo form_close();?>
          <i><small>+<?= number_format(($amount * $properties->commission) / 100, 2, '.', ''); ?>₺ ödeme komisyonu</small></i>
        </div>
        <?php if ($this->session->userdata('info')): ?>
          <div class="cart-balance"><span><i class="fa fa-coins"></i> Mevcut Bakiye: <?= $user->balance; ?>₺</span></div>
        <?php endif ?>
      </div>
    <?php }else{ ?>
     <div class="col-lg-3">
      <div class="cart-total">
        <h3>Toplam</h3>
        <h2>0₺</h2>
        <button href="<?= base_url(); ?>" class="btn btn-primary btn-block">Sepetinde Hiç Ürün Yok</button>
      </div>
      <?php if (!empty($this->session->userdata('info')['id'])) { ?>
      <?php $user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row(); ?>
        <div class="cart-balance"><span><i class="fa fa-coins"></i> Mevcut Bakiye: <?= $user->balance; ?>₺</span></div>
      <?php } ?>
    </div>
  <?php } ?>
  </div>
</div>
</div>

<div class="modal fade modal-dark" id="modalBalance" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <form action="<?= base_url('payment'); ?>" method="POST">
          <div class="form-group">
            <label for="inputOG">Miktar</label>
            <input type="number" class="form-control form-control-sm" id="inputOG" required="required" name="amount">
          </div>
          <div class="float-right">
            <button type="submit" class="btn btn-primary">Yükle</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>


</div>
</div>
</div>

</div>

<script src="<?= base_url("assets/base.js") ?>"></script>
<script type="text/javascript">
	function useCoupon() {
		$.post(
			"<?= base_url('API/useCoupon'); ?>",
			{"coupon": $('[name=coupon]').val()},
			function(data){
				if (data.status == "success") {
					window.location.reload();
				} else {
					sendToast("Başarısız!", data.message);
				}
			},
			"json"
		);
	}

	function cancelCoupon() {
		$.post(
			"<?= base_url('API/cancelCoupon'); ?>",
			{},
			function(data){
				if (data.status == "success") {
					window.location.reload();
				}
			},
			"json"
		);
	}
</script>
