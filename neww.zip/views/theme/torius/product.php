<?php if ($product->discount > 0){
  $price = $product->discount;
}else{
  $price = $product->price;
} ?>

<main class="on-main">

    <div class="on-page-back" style="background-image:url(<?= base_url('assets/img/product/') . $product->img ?>)">
        <div class="on-pb-alt">
        </div>
    </div>

    <div class="container">
        <div class="on-item">
            <div class="row">
                <div class="col-md-3">
                    <img src="<?= base_url('assets/img/product/') . $product->img ?>" alt="<?= $product->name ?>">
                </div>
                <div class="col-md-6">
                    <?php
                    $stars = $this->db->where(['product_id' => $product->id, 'isActive' => 1])->get('product_comments')->result();
                    if (!empty($stars))
                    {
                        $totalStars = count($stars);
                        $amount = 0;
                        foreach ($stars as $s) {
                          $amount = $amount + $s->star;
                      }
                      $totalStars = ceil($amount / $totalStars);
                  }else{
                    $totalStars = 0;
                }
                ?>
                <h1 class="on-item-title"><?= $product->name ?></h1>
                <div class="on-item-stars">
                    <?php $i = 0; ?>
                    <?php while($i < $totalStars) { ?>
                        <i class="fa fa-star text-warning"></i>
                        <?php
                        $i++;
                    } ?>
                </div>
                <div class="on-item-content">
                    <?= $product->desc; ?>
                </div>
            </div>
            <div class="col-md-3 pl-0">
                <div class="on-item-alt">
                    <div class="on-item-price"><h2><?php $price = json_decode(calculatePrice($product->id, 1), true); echo $price['price']; ?>₺</h2></div> 
                <div class="on-item-btn">
                      <input class="form-control form-border col-8 mb-2" type="number" name="amount" id="amount" value="1" min="1">
                    <?php if (!empty($this->session->userdata('info')) || $properties->isGuest == 1) { ?>
                       <?php if ($product->isStock == 0 || $stock > 0 || $properties->isStock == 1){ ?>
                            <a class="btn btn-success" id="addItem" onclick="addItem();"><i id="cart_icon"></i> Sepete Ekle</a>
                        <?php }else{ ?>
                            <a class="btn btn-danger">Stok Bitti</a>
                        <?php }
                    }else{ ?>
                        <a href="<?= base_url('hesap') ?>" class="btn btn-success"><i id="cart_icon"></i><i class="fa fa-user"></i> Giriş Yap</a>
                    <?php } ?>
                </div>
            </div>
            <div class="on-item-select">
                <form action="">
                    <div class="form-group">
                        <?php $inf = json_decode($product->text); ?>
                        <?php $a = 1; ?>
                        <?php if (!empty($inf) && (!empty($this->session->userdata('info')) || $properties->isGuest == 1)): ?>
                        <?php foreach ($inf as $i) {
                          if (!empty($i)) { ?>
                              <input class="form-control form-border form-pubg" type="text" id="extras<?=$a?>" name="<?= $i ?>" placeholder="<?= $i ?>" required>
                              <?php $a++; }
                          } ?>
                      <?php endif ?>
                  </div>
              </form>
          </div>
      </div>
  </div>
</div>
</div>

<div class="on-item-comments">
    <div class="container">

        <div class="on-title-1">
            <h3>Yorumlar</h3>
        </div>

        <div class="row">

            <?php if ($history) {
                foreach ($history as $h) { ?>
                    <div class="col-md-6">
                        <div class="comment-box">
                            <div class="cb-alt">
                                <div class="cb-user">
                                    <img src="assets/img/icons/profile.png" alt="">
                                    <div class="left-content">
                                        <h6><?= substr($h->name, 0, 3) . "** " . substr($h->surname, 0, 5) . "***" ?></h6>
                                        <small><?= $h->date ?></small>
                                    </div>
                                </div>
                                <div class="cb-stars">
                                    <?php $i = 0; ?>
                                    <?php while ($i < $h->star) { ?>
                                      <i class="fa fa-star text-warning"></i>
                                      <?php $i++; } ?>

                                      <?php while ($i < 5) { ?>
                                        <i class="fa fa-star"></i>
                                        <?php $i++; } ?>
                                    </div>
                                </div>
                                <p><?= $h->comment ?></p>
                            </div>
                        </div>
                    <?php }
                }else{ ?>
                </div>
                <div class="alert alert-warning mb-5">Henüz hiç yorum yapılmamış.</div>
            <?php } ?>

        </div>
    </div>

    <div class="on-products mb-5">
        <div class="container">

            <div class="on-title-1">
                <h3>Diğer Ürünlere Göz At</h3>
            </div>

            <div class="row">

                <?php foreach ($likeProducts as $lp) { ?>
                    <?php if ($lp->id != $product->id): ?>
                        <div class="col-6 col-md-3">
                            <div class="on-product" onclick="window.location='<?= base_url($lp->slug); ?>'">
                                <?php $path = "assets/img/product/" . $lp->img; ?>
                                <img src="<?php 
                                if (file_exists($path)) {
                                    echo base_url('assets/img/product/') . $lp->img;
                                    } else {
                                        echo base_url('assets/img/unknown.png');
                                    }?>" ?>
                                    <div class="on-product-content">
                                        <h6><?= $lp->name ?></h6>
                                        <div class="on-pc-alt">
                                            <h3><?php if (!empty($this->session->userdata('info'))) {
                                              $user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row();?> <?php $discount = ($lp->price / 100) * $user->discount; echo $lp->price - $discount ?>₺
                                              <?php }else{ ?><?= $lp->price ?>₺
                                              <?php } ?></h3>
                                              <a href="<?= base_url($lp->slug); ?>" class="btn btn-success"><i class="fa fa-shopping-basket"></i></a>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          <?php endif ?>
                      <?php } ?>


                  </div>

              </div>
          </div>

      </main>

      <script type="text/javascript">
          function addItem() {
            var extras = {};
            extras.name1 = $("#extras1").attr("name"); 
            extras.number1 = $("#extras1").val();
            extras.name2 = $("#extras2").attr("name"); 
            extras.number2 = $("#extras2").val(); 
            extras.name3 = $("#extras3").attr("name"); 
            extras.number3 = $("#extras3").val(); 
            
            var amount = $("#amount").val(); 

            $.post({
              url: "<?= base_url('home/addToCartItem'); ?>",
              type: "POST",
              data: {"id": <?= $product->id ?>, "extras": extras, "amount": amount},          
              success:function(e){
                  $("#cart").html(e); 
                  $('#addItem').html("").addClass('fa fa-check');
                  setTimeout(function() {
                    $('#addItem').html("Sepete Ekle").removeClass('fa fa-check');
                }, 500);
              }
          });
        }
    </script>