    <main class="on-main">

        <div class="on-products mt-5 mb-5">
            <div class="container">

                <div class="on-title-1">
                    <h3><?= $categories->name ?></h3>
                </div>

                <div class="row">

                   <?php foreach ($products as $p) { ?>
                     <div class="col-6 col-md-3">
                        <div class="on-product" onclick="window.location='<?= base_url($p->slug); ?>'">
                            <?php $path = "assets/img/product/" . $p->img; ?>
                                <img src="<?php 
                                if (file_exists($path)) {
                                    echo base_url('assets/img/product/') . $p->img;
                                } else {
                                    echo base_url('assets/img/unknown.png');
                                }?>" alt="<?= $p->name ?>">
                            <div class="on-product-content">
                                <h6><?= $p->name ?></h6>
                                <?= ($p->discount > 0) ? '<s>'.$p->price.'₺</s>' : NULL; ?>
                                <div class="on-pc-alt">
                                    <h3><?php $price = json_decode(calculatePrice($p->id, 1), true); ?><?= $price['price']; ?>₺</h3>
                                    <a href="<?= base_url($p->slug); ?>" class="btn btn-success"><i class="fa fa-shopping-basket"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>

                </div>

            </div>
        </div>

    </main>