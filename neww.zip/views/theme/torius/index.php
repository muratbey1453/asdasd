<main class="on-main">

  <div class="oi-story">
    <div class="container">
      <div class="oi-slider-story owl-carousel">

        <?php foreach ($stories as $story) { ?>
          <div class="item">
            <div class="box">
              <img src="<?= base_url('assets/img/story/') . $story->img ?>" alt="Story Image" data-toggle="modal" data-target="#story<?=$story->id?>">
            </div>
          </div>
        <?php } ?>

      </div>
    </div>
  </div>

  <?php foreach ($stories as $story) { ?>
    <div class="modal fade oi-story-modal" id="story<?=$story->id?>" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-body">
            <img src="<?= base_url('assets/img/story/') . $story->img ?>" alt="Story">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  <?php } ?>

  <div class="on-home-1">
    <div class="container">
      <div class="row">

        <div class="col-md-9">
          <div class="owl-carousel owl-theme slider-main">
            <?php foreach ($slider as $s){ ?>
              <div class="on-banner" style="background-image:url('assets/img/sliders/<?= $s->img ?>')">
                <div class="on-banner-content">
                  <h3><?= $s->title ?></h3>
                  <?= ($s->buton_2_text != NULL) ? '<a href="'. $s->buton_2_link .'" class="btn btn-success btn-success-opacity">' . $s->buton_2_text . '</a>' : NULL; ?>
                </div>
              </div>
            <?php } ?>
          </div>
        </div>

        <div class="col-md-3">
          <div class="on-category">
            <div class="row">
              <?php foreach ($home_category as $hc) { ?>
                <div class="col-6 col-md-12">
                  <div class="box" style="background-image:url('assets/img/home_category/<?=$hc->img?>')" onclick="window.location='<?= $hc->link ?>'">
                    <div class="content"><?= $hc->name ?></div>
                  </div>
                </div>
              <?php } ?>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <div class="on-choice">
    <div class="container">
      <div class="row">

        <?php foreach ($editor_choice as $ec) { ?>
          <div class="col-6 col-md-2">
            <div class="on-choice-box" onclick="window.location='<?= $ec->link  ?>'">
              <img src="<?= base_url("assets/img/home_choice/") . $ec->img ?>" alt="Editörün Seçimi Ürün Linki">
              <h6><?= $ec->text ?></h6>
            </div>
          </div>
        <?php } ?>

      </div>
    </div>
  </div>

<?php
      foreach ($products as $product) { ?>
        <div class="on-products">
          <div class="container">

            <div class="on-title-1"><h3><?= $product['title'] ?></h3></div>

            <div class="row">
              <?php foreach ($product['products'] as $lp) { ?>
                <?php if (!empty($lp->product_id)) {
                  $lp = $this->db->where('id', $lp->product_id)->get('product')->row();
                } ?>
                <div class="col-6 col-md-3">
                  <div class="on-product">
                    <?php $path = "assets/img/product/" . $lp->img; ?>
                    <img class="lazyload" data-src="<?php 
                    if (file_exists($path)) {
                      echo base_url('assets/img/product/') . $lp->img;
                      } else {
                        echo base_url('assets/img/unknown.png');
                      }?>" onclick="window.location='<?= base_url($lp->slug); ?>'" alt="<?= $lp->name ?>">
                      <div class="on-product-content">
                        <h6><?= $lp->name ?></h6>
                        <div class="on-pc-alt">
                          <div class="on-pc-price">
                            <?php $price = json_decode(calculatePrice($lp->id, 1), true); ?>
                              <?php if ($price['isDiscount'] == 1): ?>
                              <span><?= $price['normalPrice']?>₺</span>
                              <?php endif ?>
                              <h3>
                                <?= $price['price']; ?>₺
                              </h3>
                          </div>
                          <a href="<?= base_url($lp->slug); ?>" class="btn btn-success"><i class="fa fa-shopping-basket"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
                <?php } ?>
              </div>

            </div>
          </div>
        <?php }  ?>

        <div class="on-why">
          <div class="container">

            <div class="on-title-2">
              <h3>Neden Biz?</h3>
            </div>

            <div class="row">
              <div class="col-md-12 col-lg-12">
                <div class="row">
                  <?php foreach ($why as $w) { ?>
                    <div class="col-md-6">
                      <div class="box">
                        <img class="lazyload" data-src="<?= base_url('assets/img/why/') . $w->img ?>" alt="<?= $w->title ?>">
                        <h6><?= $w->title ?></h6>
                        <p><?= $w->desc ?></p>
                      </div>
                    </div>
                  <?php } ?>
                </div>
              </div>
            </div>

          </div>
        </div>

        <?php $blogCount = $this->db->count_all_results('blog');
          if ($blogCount > 0) { ?>
            <div class="on-blog">
          <div class="container">

            <div class="on-title-2">
              <h3>Blog</h3>
            </div>

            <div class="row">
              <?php foreach ($footerBlog as $b) { ?>
                <div class="col-md-12 col-lg-6">
                  <div class="box">
                    <img class="lazyload" data-src="<?= base_url('assets/img/blog/') . $b->img ?>" alt="<?= $b->title ?>">
                    <div class="content">
                      <a href="<?= base_url('makale/') . $b->slug ?>"><?= $b->title ?></a>
                      <p><?= substr($b->content, 0, 200); ?>...</p>
                      <small><i class="far fa-clock"></i> <?= $b->date ?></small>
                    </div>
                  </div>
                </div>
              <?php } ?>
            </div>

          </div>
        </div>
      <?php } ?>

      </main>

      <script>
        $("img").lazyload();
      </script>