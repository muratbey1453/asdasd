<main class="on-main">
    <div class="container">
        <div class="on-page-content">

            <h1 class="on-pcs-title"><?= $page->title ?></h1>

            <p><?= $page->content ?></p>

        </div>
    </div>
</main>