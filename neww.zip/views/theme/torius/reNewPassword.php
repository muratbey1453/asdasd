    <main class="on-main">

        <div class="on-account">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 mx-auto">
                        <div class="box p-5">
                            <h4 class="font-weight-bold">Şifremi Unuttum</h4>
                            <form action="<?= base_url('home/reNewPassword') ?>" method="POST">
                                <div class="form-group">
                                    <label for="pp1">E-Posta Adresi</label>
                                    <input type="email" class="form-control" id="pp1" name="email">
                                </div>
                                <button type="submit" class="btn btn-primary btn-block">Bağlantı Gönder</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </main>