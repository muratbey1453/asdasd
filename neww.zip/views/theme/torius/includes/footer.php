</div>

<footer class="on-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="on-footer-1">
                        <?= ($properties->choose == 0) ? '<a href="'. base_url() . '?>"><img src="'. base_url() .'/assets/img/site/' . $properties->img . '" alt="Logo"></a>' : '<h2 class="mb-0">' . $properties->name .'</h2>' ?>
                        <p>© <?= date('Y'); ?> <?= $properties->name ?> Tüm hakları saklıdır.</p>
                        <?php if ($properties->address): ?>
                        <h6 class="mt-3"><i class="fa fa-location-arrow"></i> Adres</h6>
                        <p class="on-footer-address"><?= $properties->address ?></p>
                        <?php endif ?>
                          
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="on-footer-2">
                        <h5>Sayfalar</h5>
                        <ul>
                          <?php foreach ($footerPage as $p) { ?>
                            <li><a href="<?= base_url('sayfa/' . $p->slug); ?>"><?= $p->title ?></a></li>
                           <?php } ?>
                        </ul>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="on-footer-2">
                        <h5>Ürünler</h5>
                        <ul>
                          <?php foreach ($footerProduct as $fp) { ?>
                            <li><a href="<?= base_url($fp->slug); ?>"><?= $fp->name ?></a></li>
                          <?php } ?>
                        </ul>
                    </div>
                </div>
                <div class="col-12 col-md-3">
                    <div class="on-footer-3">
                        <?php foreach ($footerBlog as $fb) { ?>
                            <div class="on-footer-blog">
                            <img src="<?= base_url('assets/img/blog/') . $fb->img ?>" alt="Blog Resmi">
                            <div class="content">
                                <a href="<?= base_url('makale/') . $fb->slug; ?>"><?= $fb->title ?></a>
                                <small><i class="far fa-clock"></i> <?= $fb->date ?> </small>
                            </div>
                        </div>
                    <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="<?= base_url('assets/' . $properties->theme) ?>/js/jquery-3.5.1.min.js"></script>
    <script src="<?= base_url('assets/' . $properties->theme) ?>/js/owl.carousel.min.js"></script>
    <script src="<?= base_url('assets/' . $properties->theme) ?>/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.5/swiper-bundle.min.js"></script>
    <script src="<?= base_url('assets/' . $properties->theme) ?>/js/orius.js"></script>
    <?= $properties->online_support ?>
<script type="text/javascript">
  function search_form() {
    var value = $('#searchInput').val();
    if (value.length > 0) {

       $.ajax({
          url: "<?= base_url('home/getSearchFormProducts'); ?>", 
          type: "POST",
          data: {words: $('#searchInput').val()},
          success: function(data) {
            $("#serch-results").html(data);
            $('#serch-results').removeClass('d-none');
            $('#serch-results').slideDown('slow');
          }
        }); 

    }else{
      $('#serch-results').addClass('d-none');
    }
  }

  function disable_form()
  {
    $('#serch-results').slideUp(800, function(){
      $('#serch-results').addClass('d-none');
    }).delay(800).fadeIn(400);
  }

</script>
</body>
</html>