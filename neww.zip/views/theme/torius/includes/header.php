<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="title" content="<?= $properties->title ?>">
    <meta name="description" content="<?= (!empty($meta)) ? $meta->meta : $properties->description ?>">
    <meta name="robots" content="index">
    <meta http-equiv="Content-Type" content="text/html; charset=utf8">
    <meta name="language" content="Turkish">
    <title><?= (!empty($title)) ? $title : $properties->title  ?></title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito+Sans:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/' . $properties->theme) ?>/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/' . $properties->theme) ?>/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/' . $properties->theme) ?>/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/' . $properties->theme) ?>/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.5/swiper-bundle.min.css" />
    <script src="<?= base_url('assets/' . $properties->theme) ?>/js/jquery-3.5.1.min.js"></script>
    <script src="<?= base_url('assets/' . $properties->theme) ?>/js/lazyload.js"></script>
    <?= $properties->google_analytics ?>
</head>

<div class="bs-example">
        <div style="position: relative; z-index: 2; top: 70px; background-color: gray;">
            <div style="position: absolute; top: 0; right: 20px; min-width: 300px;" id="toastArea">

                <?= alert() ?>

            </div>
        </div>
    </div>

<body class="on-dark">

    <div class="on-area">

    <header class="on-header">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <ul>
                        <?php foreach ($pages as $page) { ?>
                            <li><a href="<?= base_url('sayfa/') . $page->slug ?>"><?= $page->title ?></a></li>
                        <?php } ?>
                        <li class="mdb"><a href="<?= base_url('makale-listesi'); ?>">Blog</a></li>
                        <?php if ($properties->contact) { ?>
                        <li class="mdb"><a href="tel:<?= $properties->contact ?>"><?= $properties->contact ?></a></li>
                        <?php } ?>
                        <?= ($properties->instagram) ? '<li class="mdb"><a href="'.$properties->instagram .'"><i class="fab fa-instagram"></i></a></li>' : NULL; ?>
                        <?= ($properties->twitter) ? '<li class="mdb"><a href="'. $properties->twitter .'"><i class="fab fa-twitter"></i></a></li>' : NULL; ?>
                        <?= ($properties->facebook) ? '<li class="mdb"><a href="'. $properties->facebook .'"><i class="fab fa-facebook"></i></a></li>' : NULL; ?>
                    </ul>
                </div>
                <div class="col-md-6" id="cart">
                    <ul class="float-right">
                        <?php if (!empty($this->session->userdata('info'))) { ?>
                            <?php $user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row(); ?>
                            <li><a href="<?= base_url('client'); ?>"><i class="fa fa-coins"></i> Bakiye: <?=$user->balance?>₺</a></li>
                            <li><a href="<?= base_url('sepet'); ?>"><i class="fa fa-shopping-basket"></i> Sepet (<?= count($this->advanced_cart->contents()); ?>)</a></li>
                            <li><a href="<?= base_url('client'); ?>" class="text-success"><i class="fa fa-user-circle"></i> <?=$user->name?></a></li>
                            <li><a href="<?= base_url('client/logOut'); ?>" class="text-danger"><i class="fa fa-sign-out-alt"></i> Çıkış</a></li>
                       <?php }else{ ?>
                            <li><a href="<?= base_url('sepet'); ?>"><i class="fa fa-shopping-basket"></i> Sepet (<?= count($this->advanced_cart->contents()); ?>)</a></li>
                            <li><a href="<?= base_url('hesap'); ?>">Kayıt Ol</a></li>
                            <li><a href="<?= base_url('hesap'); ?>" class="text-success">Giriş Yap</a></li>
                    <?php } ?>
                    </ul>
                </div>
            </div>
        </div>
    </header>
    
    <nav class="on-nav navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="<?= base_url(); ?>"><?= ($properties->choose == 0) ? '<img src="'. base_url() .'/assets/img/site/' . $properties->img . '" alt="Logo">' : $properties->name ?></a>
            <a class="nav-link nav-search-mobile" href="#modalSearch" data-toggle="modal"><i class="fa fa-search"></i></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fa fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="<?= base_url(); ?>">Ana Sayfa</a></li>
                    <?php foreach ($category as $c) { ?>
                            <?php if ($this->db->where('mother_category_id', $c->id)->count_all_results('category') > 0){ ?>
                                 <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown<?= $c->id ?>" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <?= $c->name ?>
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown<?= $c->id ?>">
                                        <?php $subCategory = $this->db->where('isActive', 1)->where('mother_category_id', $c->id)->get('category')->result(); ?>
                                        <?php foreach ($subCategory as $sc) { ?>
                                        <?php if ($sc->isMenu == 1) { ?>
                                            <a class="dropdown-item" href="<?= base_url('kategori/') . $sc->slug ?>">
                                            <?= $sc->name ?></a>
                                        <?php } ?>
                                        <?php } ?>
                                    </div>
                                </li>
                            <?php }else{ ?>
                                <li class="nav-item"><a class="nav-link" href="<?= base_url('kategori/') . $c->slug ?>">
                                <?= $c->name ?></a></li>
                        <?php } }?>
                    <li class="nav-item nav-search d-none d-lg-block"><a class="nav-link" href="#modalSearch" data-toggle="modal"><i class="fa fa-search"></i></a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="modal fade" id="modalSearch" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body">
                    <form action="">
                        <input type="text" class="form-control form-control-lg" placeholder="Ürün ara" id="searchInput" oninput="search_form()" autocomplete="off"/>
                        <button type="submit" class="btn btn-link"><i class="fa fa-search"></i></button>
                    </form>
                    <div class="search-results d-none" id="serch-results">

                    </div>
                </div>
            </div>
        </div>
    </div>
