    <main class="on-main">

        <div class="on-blogs mt-5 mb-5">
            <div class="container">

                <div class="on-title-1">
                    <h3>Eklediğimiz Makaleler</h3>
                </div>

                <div class="on-blog">
                    <div class="row">
                        
                       <?php foreach ($blogs as $blog) { ?>
                        <div class="col-md-12 col-lg-6">
                            <div class="box">
                                <img src="<?= base_url('assets/img/blog/') . $blog->img ?>" alt="<?= $blog->title ?>">
                                <div class="content">
                                    <a href="<?= base_url('makale/') . $blog->slug; ?>"><?= $blog->title ?></a>
                                    <p><?= substr($blog->content, 0, 200); ?>...</p>
                                    <small><i class="far fa-clock"></i> <?= $blog->date ?></small>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                        
                    </div>
                </div>
                <?= $links; ?>

            </div>
        </div>

    </main>