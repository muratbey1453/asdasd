
<div class="container mt-4">
    <div class="title mb-2">
        <h3>Yayıncılar</h3>
    </div>
    <div class="mr-streamer-form">
        <div class="row">

            <div class="col-lg-3">
                <div class="user">
                    <img src="<?= $streamer->streamer_info->streamlabs->thumbnail ?>" alt="twitch image">
                    <h1 class="title"><?= mb_strtoupper($streamer->streamer_title) ?></h1>
                    <a class="link" href="<?= $streamer->streamer_stream_url ?>"><?= $streamer->streamer_stream_url ?></a>
                    <ul class="list-unstyled">
                        <?php foreach ($streamer->streamer_social as $key => $value) { ?>
                            <li><a href="<?= $value ?>"><i class="fab fa-<?= $key ?>"></i></a></li>
                        <?php } ?>
                    </ul>
                </div>
            </div>

            <div class="col-lg-9">
                <form action="">

                    <div class="mb-3">
                        <label>Gönderen Kullanıcı Adı</label>
                        <input type="text" class="form-control" placeholder="Örn. Bağışçı1">
                    </div>

                    <div class="mb-3">
                        <label>Bağış Tutarı</label>
                        <input type="number" class="form-control" placeholder="Örn. 5">
                    </div>

                    <div class="mb-3">
                        <label>Bağış Mesajı</label>
                        <textarea rows="5" class="form-control" placeholder="Mesaj"></textarea>
                    </div>

                    <div class="form-check">
                        <input id="hide_in_screen" class="form-check-input" type="checkbox" name="hide_in_screen" value="yes">
                        <label class="form-check-label" for="hide_in_screen">
                            Ekranda gözükmesin
                        </label>
                    </div>

                    <a href="#" class="btn btn-primary w-100">Gönder <i class="fa fa-arrow-right ms-2"></i></a>

                </form>
            </div>

        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <?php foreach ($streamers as $key => $value) {
            $value->streamer_info = json_decode($value->streamer_info, false);
            ?>
            <div class="col-md-6 col-lg-3">
                <a href="<?= base_url("yayinci/").$value->streamer_slug ?>" class="link-unstyled">
                    <div class="mr-streamer-item">
                        <img src="<?= $value->streamer_info->streamlabs->thumbnail ?>" alt="">
                        <h3 class="title"><?= mb_strtoupper($value->streamer_title) ?></h3>
                        <a class="link" href="<?= $value->streamer_stream_url ?>"><?= $value->streamer_stream_url ?></a>
                        <a href="<?= base_url("yayinci/").$value->streamer_slug ?>" class="btn btn-primary"><i class="fab fa-twitch"></i> Bağış Yap</a>
                    </div>
                </a>
            </div>
        <?php } ?>
    </div>
</div>