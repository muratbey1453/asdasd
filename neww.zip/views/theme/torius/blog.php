    <div class="on-blog-page">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="on-blog-content">
                        <div class="on-blog-info">
                            <img src="<?php echo base_url('assets/img/blog/') . $blog->img ?>" alt="<?= $blog->title ?>" class="blog-img">
                            <h1><?= $blog->title ?></h1>
                            <small><i class="far fa-clock"></i> <?= $blog->date ?> </small>
                        </div>
                        <p><?= $blog->content ?></p>
                    </div>
                </div>
                <div class="col-md-4">
                    
                    <div class="on-blog">
                        <?php foreach ($blogs as $b) { ?>
                            <div class="box box-mini">
                                <img src="<?php echo base_url('assets/img/blog/') . $b->img ?>" alt="<?= $b->title ?>">
                                <div class="content">
                                    <a href="<?= base_url('makale/') . $b->slug; ?>"><?= $b->title ?></a>
                                    <small><i class="far fa-clock"></i> <?= $b->date ?> </small>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>