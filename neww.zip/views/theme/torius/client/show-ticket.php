<main class="on-main">
    <div class="container">
        <a href="<?php echo base_url('client') ?>" class="btn btn-light mt-4"><i class="fa fa-chevron-left"></i> Geri Dön</a>
        <div class="on-support">
            <div class="profile-box">

                <div class="on-support-info">
                    <h5><?= $ticket->title; ?></h5>
                    <span class="badge badge-primary"><?php if ($ticket->status == 0) { echo "Kapandı"; }else if($ticket->status == 1){ echo "Cevap Verdiniz"; }else{ echo "Cevabınız Bekleniyor";} ?></span>
                    <small><i class="far fa-clock"></i> <?= $ticket->date ?></small>
                </div>

                <div class="on-support-content">
                    <div class="row">
                        <?php if ($ticket_answer_result > 0) { ?>
                            <?php foreach ($ticket_answer as $t) { ?>
                                <?php $user = $this->db->where("id", $t->user_id)->get("user")->row(); ?>
                                <div class="col-md-7 <?= ($user->isAdmin == 1) ? NULL : 'offset-md-5'; ?>">
                                    <div class="on-msg <?= ($user->isAdmin == 1) ? NULL : 'on-msg-my'; ?>">
                                        <p><?= $t->answer ?></p>
                                    </div>
                                </div>
                            <?php } ?>
                        <?php } ?>
                    </div>
                </div>

                <div class="on-support-send">
                    <form action="<?= base_url('client/answerTicket/') . $ticket->id ?>" method="POST">
                        <div class="form-row">
                            <div class="col-10 col-md-11"><textarea rows="2" class="form-control" placeholder="Cevap gönder" name="content"></textarea></div>
                            <div class="col-2 col-md-1"><button type="submit" class="btn btn-success btn-block"><i class="fa fa-chevron-right"></i></button></div>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
</main>