                    <div class="col-12 col-sm-12 col-md-8">
                        <div class="profile-box">
                            <div class="tab-content">

                                <div class="tab-pane active" id="urunlerim" role="tabpanel">
                                    <div class="table-responsive">
                                        <table class="table table-product">
                                            <thead>
                                                <th>Ürün</th>
                                                <th>Tarih</th>
                                                <th>Fiyat</th>
                                                <th></th>
                                            </thead>
                                            <tbody>
                                            <?php 
                                                $pending_product = $this->db->where('user_id', $this->session->userdata('info')['id'])->where('isActive', 1)->get('pending_product')->result();
                                                foreach ($pending_product as $pp) { ?>
                                                     <tr>
                                                        <?php $product = $this->db->where('id', $pp->product_id)->get('product')->row(); ?>
                                                        <td><img src="<?= base_url('assets/img/product/') . $product->img ?>" ?> <?= $product->name ?> 
                                                            <td><?= $pp->date ?></td>
                                                            <td><span class="text-primary fw-500"><?= $product->price ?>₺</span></td>
                                                            <td>Yönetici Tarafından Teslim Edilecek.</td>
                                                        </tr>
                                                        <tr>
                                                <?php } ?>
                                                <?php if (isset($products)): ?>
                                                    <?php foreach ($products as $product) { ?>
                                                    <tr>
                                                    <td><img src="<?= base_url('assets/img/product/') . $product->img ?>" alt="Ürün Resmi"> <?= $product->name ?>
                                                    <?php if ($product->isComment == 1) { ?>
                                                        <a href="#modalComment<?=$product->id?>" class="table-mpc" data-toggle="modal"><i class="fa fa-comment-alt"></i> Yorum Yap</a>
                                                        <div class="modal fade modal-dark" id="modalComment<?=$product->id?>" tabindex="-1" aria-hidden="true">
                                                            <div class="modal-dialog modal-dialog-centered">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h6 class="modal-title" id="exampleModalLabel">Yorum Yap <small>(<?= $product->name ?>)</small></h6>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <form action="<?= base_url('client/dashboard/addStars/') . $product->id ?>" method="POST">
                                                                            <div class="form-group">
                                                                                <select class="custom-select custom-select-sm" name="stars">
                                                                                    <option selected disabled>Puan Seç</option>
                                                                                    <option value="1">1</option>
                                                                                    <option value="2">2</option>
                                                                                    <option value="3">3</option>
                                                                                    <option value="4">4</option>
                                                                                    <option value="5">5</option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for="">Yorum</label>
                                                                                <textarea rows="4" class="form-control" name="comment"></textarea>
                                                                            </div>
                                                                            <button type="submit" class="btn btn-primary float-right">Gönder</button>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php } ?>
                                                    </td>
                                                    <td><?= $product->date ?></td>
                                                    <td class="text-success"><?= $product->price ?>₺</td>
                                                    <td>
                                                    <?php if ($product->isStock == 1){ ?>
                                                    <a href="#modalProduct<?=$product->id?>" data-toggle="modal"> Görüntüle <i class="fa fa-chevron-right"></i></a>
                                                        <div class="modal fade modal-dark" id="modalProduct<?=$product->id?>" tabindex="-1" aria-hidden="true">
                                                            <div class="modal-dialog modal-dialog-centered">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h6 class="modal-title" id="exampleModalLabel">Ürün Bilgisi</h6>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body text-left">
                                                                        <?php if ($product->product) {
                                                                            echo $product->product;
                                                                          } ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                          </div>
                                                      <?php }else{
                                                        if ($product->isActive == 1) {
                                                          echo "Teslim Bekleniyor";
                                                        }else if($product->isActive == 0){
                                                          echo "Ürün Teslim Edildi.";
                                                        }else {
                                                          echo "Ürün İptal Edildi.";
                                                        }
                                                      } ?>
                                                    <?php } ?>
                                                <?php endif ?>
                                                </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div class="tab-pane" id="destek" role="tabpanel">
                                    <a href="#modalDestek" data-toggle="modal" class="btn btn-primary mb-2"><i class="fa fa-plus"></i> Yeni Destek Talebi</a>
                                    <div class="table-responsive">
                                        <table class="table table-product">
                                            <thead>
                                                <th>Konu</th>
                                                <th>Tarih</th>
                                                <th>Durum</th>
                                                <th></th>
                                            </thead>
                                            <tbody>
                                                <?= ($tickets) ? NULL : '<div class="alert alert-info">Henüz hiç destek talebi oluşturulmamış.</div>'; ?>
                                                 <?php foreach ($tickets as $ticket) { ?>
                                                  <tr>
                                                    <td><?= $ticket->title ?></td>
                                                    <td><?= $ticket->date ?></td>
                                                    <td><span class="badge badge-primary"><?php 
                                                    if ($ticket->status == 0) {
                                                      echo "Kapandı";
                                                    }else if($ticket->status == 1){
                                                      echo "Cevap Verdiniz";
                                                    }else{
                                                      echo "Cevabınız Bekleniyor";
                                                    } ?></span></td>
                                                    <td><a href="<?= base_url('client/showTicket/') . $ticket->id ?>">Görüntüle <i class="fa fa-chevron-right"></i></a></td>
                                                </tr>
                                              <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div class="tab-pane" id="bakiye" role="tabpanel">
                                    <h5 class="profile-box-title"><img src="<?= base_url('assets/torius/img/icons/2.png') ?>" alt=""> Bakiye Yükle</h5>
                                    <form action="<?= base_url('payment') ?>" method="POST">
                                        <div class="form-group">
                                            <label for="bakiye1">Miktar</label>
                                            <input type="number" class="form-control" id="bakiye1" name="amount" required step="0.1">
                                        </div>
                                        <div class="text-center"><button type="submit" class="btn btn-success btn-profile-form">Yükle</button></div>
                                    </form>
                                    <div class="havale-box" data-toggle="modal" data-target="#modalHavale">
                                        <i class="fa fa-receipt"></i>
                                        <h5>Havale Bildir</h5>
                                    </div>
                                </div>

                                <div class="tab-pane" id="ref" role="tabpanel">
                                    <h5 class="profile-box-title"><img src="<?= base_url('assets/img/icons/link.png') ?>" alt=""> Referans</h5>
                                    <ul class="vt-bank-list list-unstyled">
                                        <li><strong>Şu Kullanıcının Referansıyla Kaydoldunuz:</strong> <?= ($referrer_user) ? $referrer_user->name." ".$referrer_user->surname . " (" . $referrer_user->ref_code . ")" : "-" ?></li>
                                    <?php if (!$refcode) { ?>
                                    </ul>
                                        <form action="<?= base_url('client/createRefcode') ?>">
                                            <button type="submit" class="btn btn-primary btn-block">Referans Kodu Oluştur</button>
                                        </form>
                                    <?php } else { ?>
                                        <li><strong>Referans Kodunuz:</strong> <?= $refcode ?></li>
                                        <li><strong>Referans Linkiniz:</strong> <?= base_url("hesap")."?ref_code=".$refcode ?></li>
                                        <hr>
                                            <?php $reference_settings = $this->db->where('id', 2)->get('reference_settings')->row(); ?>
                                            <li><small>Şu ana kadar <?= $this->db->where('referrer_id', $this->session->userdata('info')['id'])->count_all_results('user_references'); ?> kişi davet ederek <?= $this->db->where('referrer_id', $this->session->userdata('info')['id'])->count_all_results('user_references') * $reference_settings->percent_referrer; ?> TL kazandınız.</small></li>
                                    </ul>
                                    <?php } ?>
                                </div>

                                <div class="tab-pane" id="hesap" role="tabpanel">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <h6 class="profile-box-title">E-Posta Adresi Değiştir</h6>
                                            <form action="<?= base_url('client/changeMail') ?>" method="POST">
                                                <div class="form-group">
                                                    <label for="s1">Mevcut E-Posta Adresi</label>
                                                    <input type="text" class="form-control" id="s1" required name="email">
                                                </div>
                                                <div class="form-group">
                                                    <label for="s2">Yeni E-Posta Adresi</label>
                                                    <input type="text" class="form-control" id="s2" required name="newmail">
                                                </div>
                                                <button type="submit" class="btn btn-success">Değiştir</button>
                                            </form>
                                        </div>
                                        <div class="col-md-6">
                                            <h6 class="profile-box-title">Şifre Değiştir</h6>
                                            <form action="<?= base_url('client/changePassword') ?>" method="POST"> 
                                                <div class="form-group">
                                                    <label for="s3">Mevcut Şifre</label>
                                                    <input type="password" class="form-control" id="s3" required name="password">
                                                </div>
                                                <div class="form-group">
                                                    <label for="s4">Yeni Şifre</label>
                                                    <input type="password" class="form-control" id="s4" required name="newPassword">
                                                </div>
                                                <button type="submit" class="btn btn-success">Değiştir</button>
                                            </form>
                                        </div>
                                        <div class="col-md-12">
                                            <h6 class="profile-box-title mt-4">Bildirim Ayarları</h6>
                                            <div class="custom-control custom-checkbox">
                                                <form action="<?= base_url('client/changeSettingsUser') ?>" method="POST">
                                                    <?php $user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row(); ?>
                                                     <input type="checkbox" name="isMail" class="custom-control-input" id="checkMail" <?= ($user->isMail == 1) ? "checked" : NULL; ?>>
                                                    <label class="custom-control-label" for="checkMail">E-Posta bildirimlerini almak istiyorum.</label>
                                                    <button type="submit" class="btn btn-primary">Kaydet</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="modal fade modal-dark" id="modalDestek" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h6 class="modal-title">Destek Talebi</h6>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?= base_url('client/addSupport'); ?>" method="POST">
                            <div class="form-group">
                                <label for="inputK">Başlık</label>
                                <input type="text" class="form-control" id="inputK" required="required" name="title">
                            </div>
                            <div class="form-group">
                                <label for="inputT">Konu</label>
                                <textarea class="form-control" id="inputT" required="required" name="message"></textarea>
                            </div>
                            <div class="float-right">
                                <button type="submit" class="btn btn-primary"><i class="fa fa-share"></i> Gönder</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade modal-dark" id="modalHavale" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h6 class="modal-title">Havale Bildir</h6>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <a href="#modalBanka" data-toggle="modal" class="modal-bnk" data-dismiss="modal">Bankalar için tıkla</a>
                        <hr>
                        <form action="<?= base_url('client/addTransfer'); ?>" method="POST">
                            <div class="form-group">
                                <label for="inputOG">Gönderen Adı</label>
                                <input type="text" class="form-control form-control-sm" id="inputOG" required="required" name="name">
                            </div>
                            <div class="form-group">
                                <label for="inputOA">Tarih</label>
                                <input type="text" class="form-control form-control-sm" id="inputOA" required="required" name="date">
                            </div>
                            <div class="form-group">
                                <label for="inputOB">Miktar</label>
                                <input type="text" class="form-control form-control-sm" id="inputOB" required="required" name="price">
                            </div>
                            <div class="form-group">
                                <label for="inputWTT">Banka</label>
                                <select name="bank" id="inputWTT" class="custom-select custom-select-sm">
                                    <?php foreach ($banks as $b) { ?>
                                        <option value="<?= $b->id ?>"><?= $b->bank_name ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="float-right">
                                <button type="submit" class="btn btn-primary"><i class="fa fa-share"></i> Bildir</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade modal-dark modal-bank" id="modalBanka" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h6 class="modal-title">Bankalar</h6>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <?php foreach ($banks as $bank) { ?>
                            <div class="modal-bank">
                            <ul>
                                <li><?= $bank->bank_name ?></li>
                                <li><?= $bank->owner_name ?></li>
                                <li><?= $bank->iban ?></li>
                            </ul>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>

    </main>
