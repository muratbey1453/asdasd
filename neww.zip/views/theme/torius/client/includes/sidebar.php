    <main class="on-main">

        <div class="on-profile mt-5 mb-5">
            <div class="container">
                <div class="row">

                    <div class="col-12 col-sm-12 col-md-4">
                        <div class="profile-box profile-info">
                            <div class="on-pi-info">
                                <img src="<?php echo base_url('assets/img/icons/profile.png'); ?>" alt="Profil Resmi">
                                <?php $user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row(); ?>
                                <div class="content">
                                    <h6><?= $user->name . " " . $user->surname ?></h6>
                                    <small><?= $user->email ?></small>
                                </div>
                            </div>
                            <div class="on-pi-alt">
                                <img src="<?= base_url('assets/torius/img/icons/2.png') ?>" alt="">
                                <h5>Bakiye: <?=$user->balance?>₺</h5>
                            </div>
                        </div>

                        <div class="profile-box">
                            <ul class="nav nav-pills flex-column profile-nav" id="myTab2" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link active" id="1" data-toggle="tab" href="#urunlerim" role="tab" aria-controls="urunlerim" aria-selected="true">Ürünlerim</a>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link" id="2" data-toggle="tab" href="#destek" role="tab" aria-controls="destek" aria-selected="false">Destek Taleplerim</a>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link" id="3" data-toggle="tab" href="#bakiye" role="tab" aria-controls="bakiye" aria-selected="false">Bakiye Yükle</a>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link" id="4" data-toggle="tab" href="#ref" role="tab" aria-controls="ref" aria-selected="false">Referans</a>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link" id="5" data-toggle="tab" href="#hesap" role="tab" aria-controls="hesap" aria-selected="false">Hesap Ayarları</a>
                                </li>
                            </ul>
                        </div>
                    </div>