    <div class="blogs">
        <div class="container">

            <h3 class="blog-title">Eklediğimiz Makaleler</h3>

            <div class="row">

                <?php foreach ($blogs as $blog) { ?>
                <div class="col-md-6">
                    <div class="blog-box">
                         <img src="<?= base_url('assets/img/blog/') . $blog->img ?>" alt="<?= $blog->title ?>">
                        <div class="content">
                            <a href="<?= base_url('makale/') . $blog->slug; ?>"><?= $blog->title ?></a>
                            <p><?= substr($blog->content, 0, 200); ?>...</p>
                            <small><i class="far fa-clock"></i> <?= $blog->date ?></small>
                        </div>
                    </div>
                </div>
            <?php } ?>

            </div>


            <?= $links; ?>

        </div>
    </div>



