
<div class="container mt-4">
    <div class="title mb-2">
        <h3>Yayıncılar</h3>
    </div>
</div>

<div class="container">
    <div class="row">
        <?php foreach ($streamers as $key => $value) {
            $value->streamer_info = json_decode($value->streamer_info, false);
            ?>
            <div class="col-md-6 col-lg-3">
                <a href="<?= base_url("yayinci/").$value->streamer_slug ?>" class="link-unstyled">
                    <div class="mr-streamer-item">
                        <img src="<?= $value->streamer_info->streamlabs->thumbnail ?>" alt="">
                        <h3 class="title"><?= mb_strtoupper($value->streamer_title) ?></h3>
                        <a class="link" href="<?= $value->streamer_stream_url ?>"><?= $value->streamer_stream_url ?></a>
                        <a href="<?= base_url("yayinci/").$value->streamer_slug ?>" class="btn btn-primary"><i class="fab fa-twitch"></i> Bağış Yap</a>
                    </div>
                </a>
            </div>
        <?php } ?>
    </div>
</div>