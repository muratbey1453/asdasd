<div class="page-auth">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 mx-auto">
                <div class="box">
                    <img src="<?= base_url('assets/img/icons/profile.png'); ?>" alt="Profil" class="on-acc-img">
                    <div>
                        <ul class="nav nav-pills nav-justified" id="tabLogin" role="tablist">
                            <li class="nav-item" role="presentation">
                                <a class="nav-link active" id="login-1" data-toggle="tab" href="#login" role="tab" aria-controls="login" aria-selected="true">Giriş Yap</a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" id="register-1" data-toggle="tab" href="#register" role="tab" aria-controls="register" aria-selected="false">Kayıt Ol</a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div id="formAlert" class="alert-warning mt-4"><?php if (!$this->session->userdata('clientFlashSession')): ?>
                                <?= $this->session->userdata('clientFlashSession'); ?>
                            <?php endif ?></div>
                            <div id="formAlert" class="alert-warning mt-4"></div>
                            <div class="tab-pane fade show active" id="login" role="tabpanel">
                                <?php echo form_open(base_url('login/loginClient'));?>
                                    <div class="form-group">
                                        <label for="login1">E-Posta Adresi</label>
                                        <input type="email" id="loginemail" class="form-control" name="mail">
                                    </div>
                                    <div class="form-group">
                                        <label for="login2">Şifre</label>
                                        <input type="password" id="loginpassword" class="form-control" name="password">
                                    </div>
                                    <div class="text-center">
                                        <?php echo form_submit('btn btn-success', 'Giriş Yap', ['class'=>'btn btn-success']); ?>
                                        <div class="d-block"><a href="<?= base_url('sifremi-unuttum') ?>" class="on-acc-pass">Şifremi unuttum</a></div>
                                    </div>
                                <?php echo form_close();?>
                            </div>

                            <div class="tab-pane fade" id="register" role="tabpanel">

                                <?php echo form_open(base_url('login/regUser'));?>
                                    <div class="form-group">
                                        <label for="email">E-Posta Adresi</label>
                                        <input type="email" id="email" name="email" class="form-control">
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-12 col-lg-6">
                                            <label for="name">Ad</label>
                                            <input type="text" id="name" class="form-control" name="name" required>
                                        </div>
                                        <div class="form-group col-12 col-lg-6">
                                            <label for="surname">Soyad</label>
                                            <input type="text" id="surname" class="form-control" name="surname" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="password">Şifre</label>
                                        <input type="password" id="password" name="password" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label for="phone">Telefon Numarası</label>
                                        <input type="text" id="phone"  name="phone" class="form-control">
                                    </div>
                                    <?php if ($properties->isConfirmTc == 1): ?>
                                        <div class="form-group">
                                            <label for="tc">TC Kimlik NO</label>
                                            <input type="text" id="tc" name="tc" class="form-control" minlength="11" maxlength="11" required="">
                                        </div>
                                        <div class="form-group">
                                            <label for="birthday">Doğum Yılı</label>
                                            <input type="text" id="birthday" name="birthday" class="form-control" minlength="4" maxlength="4" required="">
                                        </div>
                                        <?php endif ?>
                                    <div class="form-group">
                                                <label for="ref_code">Referans Kodu</label>
                                                <input type="text" id="ref_code" name="ref_code" class="form-control" 
                                                    <?php if (!empty($ref_code)) { ?>
                                                        value="<?= $ref_code ?>" readonly 
                                                    <?php } ?>
                                                >
                                            </div>
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="confirm" name="confirm" required="" checked="">
                                            <label class="custom-control-label" for="confirm"><a href="#modalContract" data-toggle="modal">Şartları</a> okudum ve kabul ediyorum.</label>
                                        </div>
                                    </div>
                                    <div class="text-center">
                                        <?php echo form_submit('btn btn-success', 'Kayıt Ol', ['class'=>'btn btn-success']); ?>
                                    </div>
                                <?php echo form_close();?>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modalContract" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h6 class="modal-title">Şartlar ve Gizlilik Sözleşmesi</h6>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <?= $properties->contract ?>
                            </div>
                        </div>
                    </div>
                </div>