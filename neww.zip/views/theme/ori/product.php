<?php if ($product->discount > 0){
  $price = $product->discount;
}else{
  $price = $product->price;
} ?>
 <div class="page-product-info">
  <div class="container">

    <div class="product-info">
      <div class="row">
        <div class="col-12 col-md-3 col-lg-3">
          <?php $path = "assets/img/product/" . $product->img; ?>
          <img src="<?php if (file_exists($path)) { echo base_url('assets/img/product/') . $product->img; } else { echo base_url('assets/img/unknown.png'); }?>" ? alt="product" class="product-info-img">
        </div>
        <div class="col-12 col-md-9 col-lg-9">
          <h2><?= $product->name ?></h2>
          <p><?= $product->desc ?></p>
          <div class="product-info-alt d-flex justify-content-start align-items-center">
            <?php $inf = json_decode($product->text); ?>
            <?php $a = 1; ?>
            <?php foreach ($inf as $i) {
              if (!empty($i)) { ?>
                <input class="form-control form-border form-pubg" type="text" id="extras<?=$a?>" name="<?= $i ?>" placeholder="<?= $i ?>" required>
                <?php $a++; }
              } ?>
            <div class="d-block"></div>
            <h1><?php $price = json_decode(calculatePrice($product->id, 1), true); ?><?= $price['price']; ?>₺</h1>
          <input class="form-control form-border col-1 mr-3" type="number" name="amount" id="amount" value="1" min="1">
          <?php if (!empty($this->session->userdata('info')) || $properties->isGuest == 1) { ?>
            <?php if ($product->isStock == 0 || $stock > 0 || $properties->isStock == 1){ ?>
              <a class="btn btn-success" id="addItem" onclick="addItem();"><i class="fa fa-shopping-basket"></i> Sepete Ekle</a>
            <?php }else{ ?>
              <a class="btn btn-danger">Stok Bulunamadı</a>
            <?php } ?>
          <?php }else{ ?>
            <a href="<?= base_url('hesap') ?>" class="btn btn-success"><i class="fa fa-user"></i> Giriş Yap</a>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>

  <div class="product-comments">
    <h3><i class="far fa-comment-alt"></i> Yorumlar</h3>
    <div class="row">

      <?php if ($history) {
        foreach ($history as $h) { ?>
          <div class="col-12 col-md-6 col-lg-6">
            <div class="product-comment">
              <div class="d-flex justify-content-between align-items-center">
                <h5><?= substr($h->name, 0, 3) . "** " . substr($h->surname, 0, 5) . "***" ?> <small>| <?=$h->date?></small></h5> 
                <div class="product-star">
                  <?php $i = 0; ?>
                  <?php while ($i < $h->star) { ?>
                    <i class="fa fa-star"></i>
                    <?php $i++; } ?>
                  </div>
                </div>
                <p><?= $h->comment ?></p>
              </div>
            </div>
          <?php } }else{ ?>
          </div>
          <div class="alert alert-info mt-4">Henüz hiç yorum yapılmamış.</div>
        <?php } ?>
      </div>

    </div>
  </div>

  <div class="products mt-4 mb-5">
    <div class="container">
      <div class="section-header">
        <h4>Diğer Ürünlere Gözat</h4>
      </div>
      <div class="row">

       <?php foreach ($likeProducts as $lp) {
        $stars = $this->db->where(['product_id' => $lp->id, 'isActive' => 1])->get('product_comments')->result();
        if (!empty($stars))
        {
          $totalStars = count($stars);
          $amount = 0;
          foreach ($stars as $s) {
            $amount = $amount + $s->star;
          }
          $totalStars = ceil($amount / $totalStars);
        }else{
          $totalStars = 0;
        }
        ?>
        <?php if ($product->id != $lp->id): ?>
          <div class="col-1-5">
            <div class="product-box" onclick="window.location='<?= $lp->slug ?>'">
              <?php $path = "assets/img/product/" . $lp->img; ?>
              <img src="<?php 
              if (file_exists($path)) {
                echo base_url('assets/img/product/') . $lp->img;
                } else {
                  echo base_url('assets/img/unknown.png');
                }?>" ?>
                <p><?= $lp->name ?></p>
                <div class="d-flex justify-content-start align-items-center">
                  <a href="<?= base_url($lp->slug); ?>"><span class="badge badge-success"><i class="fa fa-shopping-basket"></i></span></a>
                  <div class="product-box-price">
                    <?php $price = json_decode(calculatePrice($lp->id, 1), true); 
                       if ($price['isDiscount'] == 1) { ?>
                        <s><?= $price['normalPrice']; ?>₺</s>
                      <?php } ?>
                    <h4><?= $price['price']; ?>₺</h4>
                  </div>
                  <div class="product-star">
                    <?php
                    if ($totalStars == 0) { ?>
                      <i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i>
                    <?php }else {
                      $i = 0;
                      while($i < $totalStars) { ?>
                        <i class="fa fa-star"></i>
                        <?php
                        $i++;
                      }
                    }
                    ?>
                  </div>
                </div>
              </div>
            </div>
          <?php endif ?>
        <?php } ?>

      </div>
    </div>
  </div>

</div>

<script type="text/javascript">
  function addItem() {
    var extras = {};
    extras.name1 = $("#extras1").attr("name"); 
    extras.number1 = $("#extras1").val();
    extras.name2 = $("#extras2").attr("name"); 
    extras.number2 = $("#extras2").val(); 
    extras.name3 = $("#extras3").attr("name"); 
    extras.number3 = $("#extras3").val(); 
    
    var amount = $("#amount").val(); 


    $.post({
      url: "<?= base_url('home/addToCartItem'); ?>",
      type: "POST",
      data: {"id": <?= $product->id ?>, "extras": extras, "amount": amount},          
      success:function(e){ 
        $("#cart").html(e);
      }
    });
  }
</script>