<?php if (!empty($this->session->userdata('info'))) {
  $user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row();
  $userDiscount = $user->discount;
}else{
  $userDiscount = 0;
}

?>          

<div class="float-right">
  <ul>
    <?php if ($this->session->userdata('info')): ?>                               
      <?php $user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row(); ?>
      <li class="header-bakiye"><a href="<?= base_url('client/balance') ?>"><img src="<?php echo base_url('assets/img/icons/icon-coin.png'); ?>" alt="Bakiye"><span><?= $user->balance ?>₺</span></a></li>
    <?php endif ?>
    <li class="dropdown btn-cart">
      <a href="#" class="btn btn-primary btn-sm dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <div id="cartinicon" class="animate__animated animate__swing"><i class="fa fa-shopping-bag"></i> <span>(<?= count($this->advanced_cart->contents()); ?>)</span></div>
      </a>
      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink">
        <h6 class="dropdown-header">Sepet</h6>
        <?php $amount = 0; ?>
        <?php foreach ($this->advanced_cart->contents() as $items){ ?>

          <a class="dropdown-item dropdown-item-cart" href="#">
            <?php $product = $this->db->where('id', $items['product_id'])->get('product')->row(); ?>
            <?php $path = "assets/img/product/" . $product->img; ?>
            <img src="<?php 
            if (file_exists($path)) {
              echo base_url('assets/img/product/') . $product->img;
              } else {
                echo base_url('assets/img/unknown.png');
              }?>" alt="<?= $product->name ?>">
              <span>
                <?php $product = $this->db->where('id', $items['product_id'])->get('product')->row(); ?>
                <h6><?= $product->name ?> (<?= $items['qty'] ?>)</h6>
                <h6 class="text-success"><?php $price = json_decode(calculatePrice($product->id, $items['qty']), true); echo $price['price']; ?>₺</h6>
              </span>
            </a>

          <?php } ?>
          <?php $properties = $this->db->where('id', 1)->get('properties')->row(); ?>
          <?php if (!empty($this->session->userdata('info')) || $properties->isGuest == 0) { ?>
            <a class="dropdown-item btn-ode" href="<?= base_url('sepet') ?>">Ödemeyi Tamamla <i class="fa fa-long-arrow-alt-right"></i></a>
          <?php }else{ ?>
            <a class="dropdown-item btn-ode" href="<?= base_url('sepet') ?>">Misafir Olarak Devam Et <i class="fa fa-long-arrow-alt-right"></i></a>
          <?php } ?>
        </div>
      </li>
      <li><a href="#modalLogin" class="btn btn-success btn-sm" data-toggle="modal"><i class="fa fa-user"></i></a></li>
    </ul>
  </div>
