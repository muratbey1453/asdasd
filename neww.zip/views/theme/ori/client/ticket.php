        <div class="profile-content">

            <a href="#modalDestek" data-toggle="modal" class="btn btn-success mb-3"><i class="fa fa-plus"></i> Yeni Destek Talebi</a>

        <?= ($tickets) ? NULL : '<div class="alert alert-info mt-4">Henüz hiç destek talebi oluşturulmamış.</div>'; ?>
          <div class="table-responsive">
            <table class="table table-bordered table-mp">
              <thead class="thead-light">
                <tr>
                  <th>Konu</th>
                  <th>Tarih</th>
                  <th>Durum</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($tickets as $ticket) { ?>
                  <tr>
                    <td><?= $ticket->title ?></td>
                    <td><?= $ticket->date ?></td>
                    <td><span class="badge badge-primary"><?php 
                    if ($ticket->status == 0) {
                      echo "Kapandı";
                    }else if($ticket->status == 1){
                      echo "Cevap Verdiniz";
                    }else{
                      echo "Cevabınız Bekleniyor";
                    } ?></span></td>
                    <td><a href="<?= base_url('client/showTicket/') . $ticket->id ?>">Görüntüle <i class="fa fa-chevron-right"></i></a></td>
                </tr>
              <?php } ?>
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>

        <div class="modal fade" id="modalDestek" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h6 class="modal-title">Destek Talebi</h6>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?= base_url('client/addSupport'); ?>" method="POST">
                            <div class="form-group">
                                <label for="inputK">Başlık</label>
                                <input type="text" class="form-control" id="inputK" required="required" name="title">
                            </div>
                            <div class="form-group">
                                <label for="inputT">Konu</label>
                                <textarea class="form-control" id="inputT" required="required" name="message"></textarea>
                            </div>
                            <div class="float-right">
                                <button type="submit" class="btn btn-primary"><i class="fa fa-share"></i> Gönder</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

  </div>
