<div class="profile-content">

  <div class="row">
    <div class="col-lg-6 mx-auto">
      <h2 class="form-title">Referans</h2>
      <ul class="vt-bank-list list-unstyled">
        <li><strong>Şu Kullanıcının Referansıyla Kaydoldunuz:</strong> <?= ($referrer_user) ? $referrer_user->name." ".$referrer_user->surname . " (" . $referrer_user->ref_code . ")" : "-" ?></li>
        <?php if (!$refcode) { ?>
        </ul>
        <form action="<?= base_url('client/createRefcode') ?>">
          <button type="submit" class="btn btn-primary btn-block">Referans Kodu Oluştur</button>
        </form>
      <?php } else { ?>
        <li><strong>Referans Kodunuz:</strong> <?= $refcode ?></li>
        <li><strong>Referans Linkiniz:</strong> <?= base_url("hesap")."?ref_code=".$refcode ?></li>
        <hr>
          <?php $reference_settings = $this->db->where('id', 2)->get('reference_settings')->row(); ?>
          <li><small>Şu ana kadar <?= $this->db->where('referrer_id', $this->session->userdata('info')['id'])->count_all_results('user_references'); ?> kişi davet ederek <?= $this->db->where('referrer_id', $this->session->userdata('info')['id'])->count_all_results('user_references') * $reference_settings->percent_referrer; ?> TL kazandınız.</small></li>
      </ul>
    <?php } ?>
  </div>
</div>      

</div>
</div>



