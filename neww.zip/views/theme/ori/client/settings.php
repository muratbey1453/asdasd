
        <div class="profile-content">
          <div class="row">

            <div class="col-md-6">
              <div class="profile-cash">
                <h5>E-Posta Değiştir</h5>
                <form action="<?= base_url('client/changeMail') ?>" method="POST">
                  <div class="form-group">
                    <label for="">Mevcut E-Posta Adresi</label>
                    <input type="email" class="form-control" required name="email">
                  </div>
                  <div class="form-group">
                    <label for="">Yeni E-Posta Adresi</label>
                    <input type="email" class="form-control" required name="newmail">
                  </div>
                  <button type="submit" class="btn btn-primary">Değiştir</button>
                </form>
              </div>
            </div>

            <div class="col-md-6">
              <div class="profile-cash">
                <h5>Şifre</h5>
                <form action="<?= base_url('client/changePassword') ?>" method="POST">
                  <div class="form-group">
                    <label for="">Mevcut Şifre</label>
                    <input type="password" class="form-control" required name="password">
                  </div>
                  <div class="form-group">
                    <label for="">Yeni Şifre</label>
                    <input type="password" class="form-control" required name="newPassword">
                  </div>
                  <button type="submit" class="btn btn-primary">Değiştir</button>
                </form>
              </div>
            </div>

              <div class="col-md-12">
                  <h6 class="profile-box-title mt-4">Bildirim Ayarları</h6>
                  <form action="<?= base_url('client/changeSettingsUser') ?>" method="POST">
                  <div class="custom-control custom-checkbox">
                    <?php $user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row(); ?>
                      <input type="checkbox" name="isMail" class="custom-control-input" id="checkMail" <?= ($user->isMail == 1) ? "checked" : NULL; ?>>
                      <label class="custom-control-label" for="checkMail">E-Posta bildirimlerini almak istiyorum.</label>
                  </div>
                  <button type="submit" class="btn btn-primary">Kaydet</button>
                </form>
              </div>

          </div>
        </div>

      </div>
    </div>

  </div>