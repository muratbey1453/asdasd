

        <div class="profile-content">
          <div class="row">

            <div class="col-md-6">
              <div class="profile-cash">
                <form action="<?= base_url('payment'); ?>" method="POST">
                  <div class="form-group">
                    <label for="">Miktar</label>
                    <input type="number" name="amount" min="0" class="form-control form-control-lg" placeholder="Yüklemek istediğin bakiye miktarı" required>
                  </div>
                  <button type="submit" class="btn btn-primary btn-block">Bakiye Yükle</button>
                </form>
              </div>
            </div>

            <div class="col-md-3">
              <div class="profile-cash-box">
                <i class="fa fa-coins"></i>
                <?php $user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row(); ?>
                <h4>Bakiye: <br><?= $user->balance ?>₺</h4>
              </div>
            </div>

              <div class="col-md-3">
                  <a href="#modalHavale" data-toggle="modal">
                      <div class="profile-havale-box">
                          <i class="fa fa-receipt"></i>
                          <h4>Havale Bildir</h4>
                      </div>
                  </a>
              </div>

          </div>
        </div>

      </div>
    </div>

        <div class="modal fade" id="modalHavale" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h6 class="modal-title">Havale Bildir</h6>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <a href="#modalBanka" data-toggle="modal" class="modal-bnk" data-dismiss="modal">Bankalar için tıkla</a>
                        <hr>
                        <form action="<?= base_url('client/addTransfer'); ?>" method="POST">
                            <div class="form-group">
                                <label for="inputOG">Gönderen Adı</label>
                                <input type="text" class="form-control form-control-sm" id="inputOG" required="required" name="name">
                            </div>
                            <div class="form-group">
                                <label for="inputOA">Tarih</label>
                                <input type="text" class="form-control form-control-sm" id="inputOA" required="required" name="date">
                            </div>
                            <div class="form-group">
                                <label for="inputOB">Miktar</label>
                                <input type="text" class="form-control form-control-sm" id="inputOB" required="required" name="price">
                            </div>
                            <div class="form-group">
                                <label for="inputWTT">Banka</label>
                                <select name="bank" id="inputWTT" class="custom-select custom-select-sm">
                                    <?php foreach ($banks as $b) { ?>
                                        <option value="<?= $b->id ?>"><?= $b->bank_name ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="float-right">
                                <button type="submit" class="btn btn-primary"><i class="fa fa-share"></i> Bildir</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="modalBanka" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h6 class="modal-title">Bankalar</h6>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                       <?php foreach ($banks as $bank) { ?>
                            <div class="modal-bank">
                            <ul>
                                <li><?= $bank->bank_name ?></li>
                                <li><?= $bank->owner_name ?></li>
                                <li><?= $bank->iban ?></li>
                            </ul>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>

  </div>
