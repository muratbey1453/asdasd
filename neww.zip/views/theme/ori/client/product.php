        <div class="profile-content">

          <div class="table-responsive">

            <table class="table table-bordered table-mp">

              <thead class="thead-light">

                <tr>

                  <th>Ürün</th>

                  <th>Alım Tarihi</th>

                  <th>Fiyat</th>

                  <th></th>

                </tr>

              </thead>

              <tbody>

              	<?php 

              	$pending_product = $this->db->where('user_id', $this->session->userdata('info')['id'])->where('isActive', 1)->get('pending_product')->result();

              		foreach ($pending_product as $pp) { ?>

              			 <tr>

              			 	<?php $product = $this->db->where('id', $pp->product_id)->get('product')->row(); ?>

              			 	<td><img src="<?= base_url('assets/img/product/') . $product->img ?>" ?> <?= $product->name ?> 

              			 		<td><?= $pp->date ?></td>

              			 		<td><span class="text-primary fw-500"><?= $product->price ?>₺</span></td>

              			 		<td>Yönetici Tarafından Teslim Edilecek.</td>

              			 	</tr>

              			 	<tr>

              			 	<?php } ?>

                <?php foreach ($data as $bp) { ?>

                  <tr>

                  <td><?php $path = "assets/img/product/" . $bp->img; ?>

                      <img src="<?php 

                  if (file_exists($path)) {

                      echo base_url('assets/img/product/') . $bp->img;

                  } else {

                      echo base_url('assets/img/unknown.png');

                  }?>" ?> <?= $bp->name ?> 

                  <?php if ($bp->isComment == 1) { ?>

                  	<a href="#modalComment<?=$bp->id?>" class="table-mpc" data-toggle="modal"><i class="fa fa-comment-alt"></i> Yorum Yap</a></td>

                  <div class="modal fade modal-dark" id="modalComment<?=$bp->id?>" tabindex="-1" aria-hidden="true">

	                    <div class="modal-dialog modal-dialog-centered">

	                        <div class="modal-content">

	                            <div class="modal-header">

	                                <h6 class="modal-title" id="exampleModalLabel">Yorum Yap <small>(<?= $bp->name ?>)</small></h6>

	                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">

	                                    <span aria-hidden="true">&times;</span>

	                                </button>

	                            </div>

	                            <div class="modal-body">

	                                <form action="<?= base_url('client/dashboard/addStars/') . $bp->id ?>" method="POST">

	                                    <div class="form-group">

	                                        <select class="custom-select custom-select-sm" name="stars">

	                                            <option selected disabled>Puan Seç</option>

	                                            <option value="1">1</option>

	                                            <option value="2">2</option>

	                                            <option value="3">3</option>

	                                            <option value="4">4</option>

	                                            <option value="5">5</option>

	                                        </select>

	                                    </div>

	                                    <div class="form-group">

	                                        <label for="">Yorum</label>

	                                        <textarea rows="4" class="form-control" name="comment"></textarea>

	                                    </div>

	                                    <button type="submit" class="btn btn-primary float-right">Gönder</button>

	                                </form>

	                            </div>

	                        </div>

	                    </div>

	                </div>

	            <?php } ?>

                  <td><?= $bp->date; ?></td>

                  <td><span class="text-primary fw-500"><?= $bp->price ?>₺</span></td>

                  <td>

                  <?php if ($bp->isStock == 1){ ?>

                    <a href="#modal-product<?=$bp->id?>" data-toggle="modal">Ürün Bilgisi <i class="fa fa-chevron-right"></i></a>

                  <div class="modal fade" id="modal-product<?=$bp->id?>" tabindex="-1" aria-hidden="true">

                    <div class="modal-dialog modal-dialog-centered">

                      <div class="modal-content">

                        <div class="modal-header">

                          <h6 class="modal-title"><?= $bp->name ?> <small class="text-muted">Ürün Bilgisi</small></h6>

                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">

                            <span aria-hidden="true">&times;</span>

                          </button>

                        </div>

                        <div class="modal-body text-left">

                          <?php if ($bp->product) {

                            echo $bp->product;

                          } ?>

                        </div>

                      </div>

                    </div>

                  </div>

                  <?php }else{ ?>

                    <?php if ($bp->isActive == 1) {

                      echo "Teslim Bekleniyor.";

                    }else if($bp->isActive == 0){

                      echo "Ürün Teslim Edildi.";

                    }else {
                      echo "Ürün İptal Edildi.";
                    } ?>

                  <?php } ?>

                  </td>

                </tr>

              <?php } ?>

              </tbody>

            </table>

          </div>

        </div>

        <nav aria-label="Page navigation example">

        <?php echo $links; ?>

        </nav>

      </div>

    </div>



  </div>



