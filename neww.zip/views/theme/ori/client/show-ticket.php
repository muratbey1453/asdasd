            <div class="profile-content">
              
              <div class="support-title mb-3">
                <h5 class="mb-0"><?= $ticket->title ?></h5>
                <small class="text-muted"><i class="far fa-clock"></i> <?= $ticket->date ?> </small>
              </div>

              <div class="sp2-content">
                <div class="sp2-messages">
                  <div class="message-right">
                    <div class="sp2-message">
                        <?= $ticket->message ?>
                    </div>
                    <small><?= $ticket->date ?></small>
                </div>
                  <?php if ($ticket_answer_result > 0) { ?>
                   <?php foreach ($ticket_answer as $t) { ?>
                  <?php $user = $this->db->where("id", $t->user_id)->get("user")->row(); ?>
                  <div class="message<?= ($user->isAdmin == 1) ? "-left" : '-right'; ?>">
                    <div class="sp2-message <?= ($user->isAdmin == 1) ? 'message-left' : NULL; ?>">
                        <?= $t->answer ?>
                    </div>
                    <small><?= $t->date ?></small>
                </div>
                <?php } ?>
              <?php } ?>

                </div>

                <div class="sp2-form">
                    <form action="<?= base_url('client/answerTicket/') . $ticket->id ?>" method="POST">
                        <div class="form-row">
                            <div class="col-11"><textarea class="form-control" rows="2" name="content"></textarea></div>
                            <div class="col-1"><button type="submit" class="btn btn-primary btn-block"><i class="fa fa-chevron-right"></i></button></div>
                        </div>
                    </form>
                </div>

              </div>

            </div>

      </div>
    </div>

  </div>