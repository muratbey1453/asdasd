    <div class="page-profile">

      <div class="container">

        

        <div class="profile-card">

          <div class="row align-items-center">

            <div class="col-md-8">

              <div class="profile-card-flex">

                <i class="fa fa-user-circle"></i>

                <div class="profile-card-content">

                  <?php $user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row(); ?>

                  <h2><?= $user->name . " " . $user->surname ?></h2>

                  <h5 class="text-muted mb-0"><?= $user->email ?></h5>

                </div>

              </div>

            </div>

            <div class="col-md-4">

              <div class="float-right">

                <a href="<?= base_url('client/logOut') ?>" class="text-danger">Çıkış Yap <i class="fa fa-sign-out-alt"></i></a>

              </div>

            </div>

          </div>

        </div>



        <div class="profile-tabs<?php if(isset($mini)){echo '-mini';} ?>">

          <div class="row">



            <div class="col-md-3">

              <div class="profile-box" onclick="window.location='<?= base_url('client/balance') ?>'">

                <img src="<?php echo base_url('assets/img/icons/icon-coin.png'); ?>" alt="">

                <h5>Bakiye: <span class="text-success"><?= $user->balance ?>₺</span></h5>

              </div>

            </div>



            <div class="col-md-2">

              <div class="profile-box" onclick="window.location='<?= base_url('client/product') ?>'">

                <img src="<?php echo base_url('assets/img/icons/icon-pack.png'); ?>" alt="">

                <h5>Ürünlerim</h5>

              </div>

            </div>



            <div class="col-md-2">

              <div class="profile-box" onclick="window.location='<?= base_url('client/ticket') ?>'">

                <img src="<?php echo base_url('assets/img/icons/icon-sms.png'); ?>" alt="">

                <h5>Destek</h5>

              </div>

            </div>


             <div class="col-md-2">

              <div class="profile-box" onclick="window.location='<?= base_url('client/reference') ?>'">

                <img src="<?php echo base_url('assets/img/icons/link.png'); ?>" alt="">

                <h5>Referans</h5>

              </div>

            </div>



            <div class="col-md-3">

              <div class="profile-box" onclick="window.location='<?= base_url('client/settings') ?>'">

                <img src="<?php echo base_url('assets/img/icons/icon-settings.png'); ?>" alt="">

                <h5>Hesap Ayarlarım</h5>

              </div>

            </div>



          </div>

        </div>



      <?php if (empty($mini)): ?>

            </div>

        </div>



      </div>

      <?php endif ?>