<main class="page-content">
    <div class="container">

        <h1 class="oi-pt-title"><?= $page->title ?></h1>

        <p><?= $page->content ?></p>

    </div>
</main>