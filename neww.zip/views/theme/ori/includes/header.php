<?php $properties = $this->db->where('id', 1)->get('properties')->row(); ?>
<!DOCTYPE html>
<html lang="tr">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="title" content="<?= $properties->title ?>">
    <meta name="description" content="<?= (!empty($meta)) ? $meta->meta : $properties->description ?>">
    <meta name="robots" content="index">
    <meta http-equiv="Content-Type" content="text/html; charset=utf8">
    <meta name="language" content="Turkish">
	<title><?= (!empty($title)) ? $title : $properties->title  ?></title>
	<link rel="stylesheet" href="<?= base_url('assets/' . $properties->theme) ?>/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?= base_url('assets/' . $properties->theme) ?>/css/owl.carousel.min.css">
	<link rel="stylesheet" href="<?= base_url('assets/' . $properties->theme) ?>/css/owl.theme.default.min.css">
	<link rel="stylesheet" href="<?= base_url('assets/' . $properties->theme) ?>/css/style.css">
	<link rel="stylesheet" href="<?= base_url('assets/' . $properties->theme) ?>/fonts/poppins/font.css">
	<link rel="stylesheet" href="<?= base_url('assets/' . $properties->theme) ?>/fonts/fontawesome/css/all.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.5/swiper-bundle.min.css">
	<script src="<?= base_url('assets/' . $properties->theme) ?>/js/jquery-3.5.1.min.js"></script>
	<script src="<?= base_url('assets/' . $properties->theme) ?>/js/lazyload.js"></script>
	<?= $properties->google_analytics ?>


</head>
<body>

<div class="bs-example">
    <div style="position: relative; z-index: 2; top: 70px; background-color: gray;">
        <div style="position: absolute; top: 0; right: 20px; min-width: 300px;" id="toastArea">

            <?= alert() ?>

        </div>
    </div>
</div>

<div class="oi-main-area">

	<header class="oi-main-header">

		<div class="oi-main-topnav">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-3 col-lg-3">
						<?= ($properties->choose == 0) ? '<a href="'. base_url() .'"><img src="'. base_url() .'/assets/img/site/' . $properties->img . '" alt="Logo"></a>' : '<h2 class="mb-0">' . $properties->name .'</h2>' ?>
					</div>
					<div class="col-lg-6">
						<form action="" class="oi-form-search">
							<input type="text" class="form-control form-control-lg" placeholder="Bir ürün mü arıyorsun?" id="searchInput" onfocusout="disable_form()" oninput="search_form()" autocomplete="off">
							<button type="submit"><i class="fa fa-search"></i></button>
						</form>
                        <div class="search-results d-none" id="serch-results">
                            
                        </div>
					</div>
					<div class="col-9 col-lg-3 animate__pulse" id="cart">
						<div class="float-right">
                            <ul>
                            	<?php if ($this->session->userdata('info')): ?>                            		
                            	<?php $user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row(); ?>
                                	<li class="header-bakiye"><a href="<?= base_url('client/balance') ?>"><img src="<?php echo base_url('assets/img/icons/icon-coin.png'); ?>" alt="Bakiye"><span><?= $user->balance ?>₺</span></a></li>
                                <?php endif ?>
                                <li class="dropdown btn-cart">
                                    <a href="#" class="btn btn-primary btn-sm dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fa fa-shopping-bag"></i> <span>(<?= count($this->advanced_cart->contents()); ?>)</span>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink">
                                        <h6 class="dropdown-header">Sepet</h6>

                                       <?php foreach ($this->advanced_cart->contents() as $items){ ?>

                                        <a class="dropdown-item dropdown-item-cart" href="#">
                                              	<?php $product = $this->db->where('id', $items['product_id'])->get('product')->row(); ?>
                                              <?php $path = "assets/img/product/" . $product->img; ?>
                                                  <img src="<?php 
                                                  if (file_exists($path)) {
                                                      echo base_url('assets/img/product/') . $product->img;
                                                  } else {
                                                      echo base_url('assets/img/unknown.png');
                                                  }?>" ?>
                                              <span>
                                                <h6><?= $product->name ?> (<?= $items['qty'] ?>)</h6>
                                                <h6 class="text-success"><?php $price = json_decode(calculatePrice($product->id, $items['qty']), true); echo $price['price']; ?>₺</h6>
                                            </span>
                                        </a>

                                    <?php } ?>

                                        <a class="dropdown-item btn-ode" href="<?= base_url('sepet') ?>">Ödemeyi Tamamla <i class="fa fa-long-arrow-alt-right"></i></a>
                                    </div>
                                </li>
                                <?php if (!empty($this->session->userdata('info'))){ ?>
                                	<li><a href="<?= base_url('client') ?>" class="btn btn-success btn-sm"><i class="fa fa-user"></i></a></li>
                                <?php }else{ ?>
                                	<li><a href="<?= base_url('hesap') ?>" class="btn btn-success btn-sm"><i class="fa fa-user"></i></a></li>
                                <?php } ?>
                            </ul>
						</div>
					</div>
				</div>
			</div>
		</div>

		<nav class="oi-main-navbar navbar navbar-expand-lg">
			<div class="container">
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
					<i class="fa fa-bars"></i>
				</button>
				<div class="collapse navbar-collapse" id="navbarNav">
					<ul class="navbar-nav">
						<li class="nav-item"><a class="nav-link" href="<?= base_url() ?>">Ana Sayfa</a></li>
						<?php foreach ($category as $c) { ?>
    						<?php if ($this->db->where('mother_category_id', $c->id)->count_all_results('category') > 0){ ?>
                                 <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown<?= $c->id ?>" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <?= $c->name ?>
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown<?= $c->id ?>">
                                        <?php $subCategory = $this->db->where('isActive', 1)->where('mother_category_id', $c->id)->get('category')->result(); ?>
                                        <?php foreach ($subCategory as $sc) { ?>
                                        <?php if ($sc->isMenu == 1) { ?>
                                            <a class="dropdown-item" href="<?= base_url('kategori/') . $sc->slug ?>">
                                            <?= $sc->name ?></a>
                                        <?php } ?>
                                        <?php } ?>
                                    </div>
                                </li>
                            <?php }else{ ?>
                                <li class="nav-item"><a class="nav-link" href="<?= base_url('kategori/') . $c->slug ?>">
                                <?= $c->name ?></a></li>
						<?php } }?>

					</ul>
				</div>
			</div>
		</nav>

	</header>
