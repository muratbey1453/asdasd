<div class="footer-alts">
<footer class="oi-main-footer">
	<div class="container">
		<div class="row">

			<div class="col-6 col-md-3 col-lg-3">
        <h6>Sayfalar</h6>
        <ul>
          <?php foreach ($footerPage as $p) { ?>
            <li><a href="<?= base_url('sayfa/' . $p->slug); ?>"><?= $p->title ?></a></li>
          <?php } ?>
        </ul>
      </div>

			<div class="col-6 col-md-3 col-lg-3">
				<h6>Blog</h6>
				<ul>
					<?php foreach ($footerBlog as $b) { ?>
            <li><a href="<?= base_url('makale/' . $b->slug); ?>"><?= $b->title ?></a></li>
          <?php } ?>
				</ul>
			</div>

			<div class="col-6 col-md-3 col-lg-3">
				<h6>Ürünler</h6>
				<ul>
					<?php foreach ($footerProduct as $fp) { ?>
            <li><a href="<?= base_url($fp->slug); ?>"><?= $fp->name ?></a></li>
          <?php } ?>
				</ul>
			</div>

			<div class="col-6 col-md-3 col-lg-3">
				<h6>Sosyal Medya</h6>
				<ul class="social-media">
					<?= ($properties->facebook) ? '<li><a href="'. $properties->facebook .'" id="facebook"><i class="fab fa-facebook-f"></i></a></li>' : NULL ?>
          <?= ($properties->twitter) ? '<li><a href="'. $properties->twitter .'" id="twitter"><i class="fab fa-twitter"></i></a></li>' : NULL ?>
          <?= ($properties->instagram) ? '<li><a href="'. $properties->instagram .'" id="instagram"><i class="fab fa-instagram"></i></a></li>' : NULL ?>
				</ul>
                <?php if ($properties->contact) { ?>
                  <h6>Telefon: <a href="tel:<?= $properties->contact ?>"><?= $properties->contact ?></a></h6>
                <?php } ?>
                <?php if ($properties->address) { ?>
                <h6 class="mb-1">Adres:</h6>
                <p><?= $properties->address ?></p>
              <?php } ?>
			</div>

		</div>
	</div>
	<span class="oi-main-footer-copy">© <?= date('Y'); ?> <?= $properties->name ?> Tüm hakları saklıdır.</span>
</footer>
</div>

<script src="<?= base_url('assets/' . $properties->theme) ?>/js/popper.min.js"></script>
<script src="<?= base_url('assets/' . $properties->theme) ?>/js/bootstrap.min.js"></script>
<script src="<?= base_url('assets/' . $properties->theme) ?>/js/owl.carousel.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.5/swiper-bundle.min.js"></script>
<script src="<?= base_url('assets/' . $properties->theme) ?>/js/main.js"></script>
<?= $properties->online_support ?>

<script type="text/javascript">

  function search_form() {
    var value = $('#searchInput').val();
    if (value.length > 0) {

       $.ajax({
          url: "<?= base_url('home/getSearchFormProducts'); ?>", 
          type: "POST",
          data: {words: $('#searchInput').val()},
          success: function(data) {
            $("#serch-results").html(data);
            $('#serch-results').removeClass('d-none');
            $('#serch-results').slideDown('slow');
          }
        }); 

    }else{
      $('#serch-results').addClass('d-none');
    }
  }

  function disable_form()
  {
    $('#serch-results').slideUp(800, function(){
      $('#serch-results').addClass('d-none');
    }).delay(800).fadeIn(400);
  }

</script>
</body>
</html>

