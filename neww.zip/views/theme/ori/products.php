 <div class="products mt-3">
      <div class="container">
        <div class="section-header">
          <h4><?= $categories->name ?></h4>
        </div>
        <div class="row">
          <?php foreach ($products as $p) { ?>
          <?php
        $stars = $this->db->where(['product_id' => $p->id, 'isActive' => 1])->get('product_comments')->result();
        if (!empty($stars))
          {
          $totalStars = count($stars);
          $amount = 0;
          foreach ($stars as $s) {
            $amount = $amount + $s->star;
          }
          $totalStars = ceil($amount / $totalStars);
          }else{
          $totalStars = 0;
        }
        ?>
        <div class="col-1-5">
            <div class="product-box" onclick="window.location='<?= base_url($p->slug); ?>'">
              <?php $path = "assets/img/product/" . $p->img; ?>
                <img src="<?php 
                if (file_exists($path)) {
                    echo base_url('assets/img/product/') . $p->img;
                } else {
                    echo base_url('assets/img/unknown.png');
                }?>" alt="<?= $p->name ?>">

              <p><?= $p->name ?></p>
              <div class="d-flex justify-content-start align-items-center">
                <a href="<?= base_url($p->slug); ?>"><span class="badge badge-success"><i class="fa fa-shopping-basket"></i></span></a>
                  <div class="product-box-price">
                      <?= ($p->discount > 0) ? '<s>'.$p->price.'₺</s>' : NULL; ?>
                      <h4><?php if (!empty($this->session->userdata('info'))) {
                           $user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row();
                           if ($p->discount > 0) { $discount = ($p->discount / 100) * $user->discount; echo $p->discount - $discount; } else { $discount = ($p->price / 100) * $user->discount; echo $p->price - $discount; }
                       }else{
                        echo ($p->discount > 0) ? $p->discount : $p->price;
                    }?>₺</h4>
                  </div>
                <div class="product-star">
          <?php
          if ($totalStars == 0) { ?>
            <i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i>
          <?php }else {
            $i = 0;
            while($i < $totalStars) { ?>
              <i class="fa fa-star"></i>
              <?php
              $i++;
            }
          }
          ?>
                </div>
              </div>
            </div>
          </div>
      <?php } ?>
        </div>
      </div>
    </div>

    

  </div>
