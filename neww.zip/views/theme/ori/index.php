<div class="oi-story">
  <div class="container">
    <div class="oi-slider-story owl-carousel">

      <?php foreach ($stories as $story) { ?>
        <div class="item">
          <div class="box">
            <img src="<?= base_url('assets/img/story/') . $story->img ?>" alt="Story Image" data-toggle="modal" data-target="#story<?=$story->id?>">
          </div>
        </div>
      <?php } ?>

    </div>
  </div>
</div>

<?php foreach ($stories as $story) { ?>
<div class="modal fade oi-story-modal" id="story<?=$story->id?>" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body">
                        <img src="<?= base_url('assets/img/story/') . $story->img ?>" alt="Story">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
<?php } ?>

<div class="oi-main-slider">
  <div class="container">
    <div class="oi-slider-game owl-carousel">
      
      <?php foreach ($slider as $s){ ?>

       <div class="item" style="background-image:url('assets/img/sliders/<?= $s->img ?>')">
        <div class="row">
         <div class="col-lg-5">
          <div class="oi-sg-content">
           <h1><?= $s->title ?></h1>
           <span class="badge badge-primary"><?= $s->tag ?></span>
           <p><?= $s->description ?></p>
           <div class="row">
            <?php if($s->buton_1_text != ""){ ?><div class="col-6"><span class="badge badge-success btn-block"><?php echo $s->buton_1_text; ?></span></div><?php } ?>
            <?php if($s->buton_2_text != "" && $s->buton_2_link != "") { ?>
              <div class="col-6"><a href="<?= $s->buton_2_link ?>" class="btn btn-darkness btn-block"><?= ($s->buton_2_text) ?></a></div>
            <?php } ?>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php } ?>

</div>
</div>
</div>
<div class="on-choice">
  <div class="container">
    <div class="row">
      
      <?php foreach ($editor_choice as $ec) { ?>
        <div class="col-6 col-md-2">
          <div class="on-choice-box" onclick="window.location='<?= $ec->link ?>'">
            <img src="<?= base_url("assets/img/home_choice/") . $ec->img ?>" alt="Editörün Seçimi Ürün Linki">
            <h6><?= $ec->text ?></h6>
          </div>
        </div>
      <?php } ?>
      
    </div>
  </div>
</div>

  <?php $a = 0; ?>
  <?php foreach ($products as $product) { ?>
    <?php if ($a == 1) { ?>
      <div class="suggestions">
        <div class="container">
          <div class="row">
            <?php foreach ($home_category as $hc) { ?>
                <div class="col-6 col-md-3 col-lg-3">
                    <a href="<?= $hc->link ?>">
                        <div class="suggestion-box" style="background-image:url('assets/img/home_category/<?=$hc->img?>') "></div>
                    </a>
                </div>
            <?php } ?>
          </div>
        </div>
      </div>
    <?php } 
    $a++; ?>


      <div class="products">
      <div class="container">
        <div class="section-header">
          <h4><?= $product['title'] ?></h4>
        </div>
        <div class="row">
          <?php foreach ($product['products'] as $lp) {
            $stars = $this->db->where(['product_id' => $lp->id, 'isActive' => 1])->get('product_comments')->result();
            if (!empty($stars))
            {
              $totalStars = count($stars);
              $amount = 0;
              foreach ($stars as $s) {
                $amount = $amount + $s->star;
              }
              $totalStars = ceil($amount / $totalStars);
            }else{
              $totalStars = 0;
            }
            ?>
            <div class="col-1-5">
              <div class="product-box">
                <?php $path = "assets/img/product/" . $lp->img; ?>
                <img class="lazyload" data-src="<?php 
                if (file_exists($path)) {
                  echo base_url('assets/img/product/') . $lp->img;
                  } else {
                    echo base_url('assets/img/unknown.png');
                  }?>" onclick="window.location='<?= base_url($lp->slug); ?>'" alt="<?= $lp->name ?>">
                  <p><?= $lp->name ?></p>
                  <div class="d-flex justify-content-start align-items-center">
                    <a href="<?= base_url($lp->slug); ?>"><span class="badge badge-success"><i class="fa fa-shopping-basket"></i></span></a>
                    <div class="product-box-price">
                      <?php $price = json_decode(calculatePrice($lp->id, 1), true); ?>
                      <?php if ($price['isDiscount'] == 1) { ?>
                        <s><?= $price['normalPrice']; ?>₺</s>
                      <?php } ?>
                      <h4><?= $price['price']; ?>₺</h4>
                      </div>
                      <div class="product-star">
                        <?php
                        if ($totalStars == 0) { ?>
                          <i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i>
                        <?php }else {
                          $i = 0;
                          while($i < $totalStars) { ?>
                            <i class="fa fa-star"></i>
                            <?php
                            $i++;
                          }
                        }
                        ?>
                      </div>
                    </div>
                  </div>

                </div>
            <?php } //product if ?>
            </div>
          </div>
        </div>
              <?php } // products if ?>
    </div>
  </div>

</div>
</div>

<div class="features">
  <div class="container">
    <div class="row">
      
      <?php foreach ($why as $w) { ?>
       <div class="col-12 col-md-6 col-lg-3">
        <div class="feature-box">
          <img src="<?php echo base_url('assets/img/why/') . $w->img ?>" alt="">
          <h6><?= $w->title ?></h6>
          <p><?= $w->desc ?></p>
        </div>
      </div>
    <?php } ?>

  </div>
</div>
</div>

</div>

<script>
  $("img").lazyload();
</script>


