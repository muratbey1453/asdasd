<?php if ($result) {
	foreach ($result as $r) { ?>
    <div class="search-result" onclick="window.location=' <?= base_url($r->slug); ?> '">
        <img src="<?= base_url('assets/img/product/') . $r->img ?>" alt="<?= $r->name ?>">
        <div class="sr-alt">
            <h6><?= $r->name ?></h6>
            <h5><?= $r->price ?>₺</h5>
        </div>
    </div>
<?php }
}else{
	echo "Sonuç Bulunamadı.";
} ?>