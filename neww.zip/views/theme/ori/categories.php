<div class="container py-5">
	<h1 class="text-center mb-4 title-top-categories" style="font-size:34px">Tüm Kategoriler</h1>
	<?php
	usort($categories, function($a, $b) {
		setlocale(LC_COLLATE, 'tr_TR.UTF-8'); // Türkçe sıralama için
		return strcoll($a->name, $b->name);
	});

	// Alfabetik sıraya göre kategorileri gruplayacak bir dizi oluşturun
	$grupluKategoriler = array();
	foreach ($categories as $kategori) {
		$harf = strtoupper(substr($kategori->name, 0, 1));
		if (!isset($grupluKategoriler[$harf])) {
			$grupluKategoriler[$harf] = array();
		}
		$grupluKategoriler[$harf][] = $kategori;
	}
	?>

	<div class="ori-categories-search">
		<i class="fa fa-search icon"></i>
		<input type="text" class="form-control" placeholder="Kategorileri filtreleyin..." id="category-filter">
	</div>

	<?php foreach ($grupluKategoriler as $harf => $kategoriler) { ?>
		<h2 class="ori-categories-letter"><?=$harf;?></h2>
		<div class="ori-categories">
			<?php foreach ($kategoriler as $cat) { ?>
				<a href="<?=base_url('kategori/') . $cat->slug?>" class="category-item">
					<div class="ori-categories-item">
						<div class="img"><img src="<?=base_url('assets/img/category/') . $cat->img?>" alt="Kategori Resmi"></div>
						<div class="name"><?= $cat->name ?></div>
					</div>
				</a>
			<?php } ?>
		</div>
	<?php } ?>
</div>

<script>
	document.addEventListener("DOMContentLoaded", function () {
		const kategoriFiltresi = document.getElementById("category-filter");
		const kategoriElemanlari = document.querySelectorAll(".category-item");

		kategoriFiltresi.addEventListener("input", function () {
			const arananKelime = kategoriFiltresi.value.toLowerCase();

			kategoriElemanlari.forEach(function (eleman) {
				const kategoriAdi = eleman.querySelector(".name").textContent.toLowerCase();
				if (kategoriAdi.includes(arananKelime)) {
					eleman.style.display = "block";
				} else {
					eleman.style.display = "none";
				}
			});

			// Alfabetik grup başlıklarını da kontrol edin
			const grupBasliklari = document.querySelectorAll(".ori-categories-letter");
			grupBasliklari.forEach(function (baslik) {
				const kategoriler = baslik.nextElementSibling.querySelectorAll(".category-item");
				let herhangiGosteriliyor = false;

				kategoriler.forEach(function (kategori) {
					if (kategori.style.display === "block") {
						herhangiGosteriliyor = true;
					}
				});

				if (herhangiGosteriliyor) {
					baslik.style.display = "block";
				} else {
					baslik.style.display = "none";
				}
			});
		});
	});

</script>





