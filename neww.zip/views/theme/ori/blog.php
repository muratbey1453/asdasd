    <div class="blog-page">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="blog-content">
                        <img src="<?php echo base_url('assets/img/blog/') . $blog->img ?>" alt="" class="blog-img">
                        <h1><?= $blog->title ?></h1>
                        <small><i class="far fa-clock"></i> <?= $blog->date ?> </small>
                        <p><?= $blog->content ?></p>
                    </div>
                </div>
                <div class="col-md-4">
                    
                    <?php foreach ($blogs as $b) { ?>
                      <div class="blog-box blog-mini">
                        <img src="<?php echo base_url('assets/img/blog/') . $b->img ?>" alt="Blog Image">
                        <div class="content">
                            <a href="<?=base_url('makale/') . $b->slug ?>"><?= $b->title ?></a>
                            <small><i class="far fa-clock"></i> <?= $b->date ?> </small>
                        </div>
                    </div>
                  <?php } ?>
                    
                </div>
            </div>
        </div>
    </div>
