<div class="page-password">
    <div class="container">
        <div class="row">

            <div class="col-md-5 mx-auto">
                <div class="pp-card">
                    <h4 class="mb-3">Şifremi Unuttum</h4>
                    <form action="<?= base_url('home/reNewPassword') ?>" method="POST">
                        <div class="form-group">
                            <label for="pp1">E-Posta Adresi</label>
                            <input type="email" class="form-control" id="pp1" name="email">
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Bağlantı Gönder</button>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
