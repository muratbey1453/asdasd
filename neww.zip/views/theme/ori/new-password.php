<div class="page-password">
    <div class="container">
        <div class="row">

            <div class="col-md-5 mx-auto">
                <div class="pp-card">
                    <h4 class="mb-3">Şifre Yenile</h4>
                    <form action="<?= base_url('home/setNewPassword'); ?>" method="POST">
                        <div class="form-group">
                            <label for="p1">Yeni Şifre</label>
                            <input type="password" class="form-control" id="p1" name="newPassword">
                        </div>
                        <div class="form-group">
                            <label for="p1">Yeni Şifre Tekrar</label>
                            <input type="password" class="form-control" id="p2" name="reNewPassword">
                        </div>
                        <input type="hidden" name="hash" value="<?= $hash ?>">
                        <button type="submit" class="btn btn-primary btn-block">Yenile</button>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
