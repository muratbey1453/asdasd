<?php
/**
 * BU BLOĞU servers/detail.php içinde,
 *  - açıklama alanının hemen ALTINA
 *  - </div> (blog-body card-like) kapanışından SONRA
 * yapıştır.
 *
 * Kullanılan değişkenler (Servers::detail içinde gönderilecek):
 *  - $serverProducts
 *  - $serverProductsLinks
 *  - $relatedServers
 *  - $canAddServerProduct (bool)
 */
?>

<!-- Sunucu Ürünleri -->
<div id="sunucu-urunleri" class="server-products-wrap card-like" style="margin-top:16px;">
  <div class="sp-head">
    <h3 class="sp-title">
      <i class="ri-shopping-bag-3-line"></i> Sunucu Ürünleri
    </h3>

    <?php if (!empty($canAddServerProduct)): ?>
      <a href="<?= base_url('sunucular/urun-ekle/'.(int)$server->id) ?>" class="sp-add-btn">
        <i class="ri-add-line"></i> Ürün Ekle
      </a>
    <?php else: ?>
      <a href="<?= base_url('hesap') ?>" class="sp-add-btn">
        <i class="ri-login-box-line"></i> Giriş Yap
      </a>
    <?php endif; ?>
  </div>

  <?php if (empty($serverProducts)): ?>
    <div class="sp-empty">
      <i class="ri-information-line"></i>
      Bu sunucuya ait onaylı ürün bulunamadı.
    </div>
  <?php else: ?>
    <div class="sp-list">
      <?php foreach ($serverProducts as $p): ?>
        <div class="sp-item">
          <a class="sp-img" href="<?= base_url($p->slug) ?>">
            <img src="<?= base_url('assets/img/product/') . $p->img ?>" alt="Ürün">
          </a>

          <div class="sp-body">
            <a class="sp-name" href="<?= base_url($p->slug) ?>"><?= html_escape($p->name) ?></a>

            <div class="sp-meta">
              <?php $price = json_decode(calculatePrice($p->id, 1), true); ?>
              <?php if (!empty($price) && (int)($price['isDiscount'] ?? 0) === 1): ?>
                <div class="sp-price">
                  <span class="new"><?= html_escape($price['price']) ?> TL</span>
                  <span class="old"><?= html_escape($price['normalPrice']) ?> TL</span>
                </div>
              <?php else: ?>
                <div class="sp-price">
                  <span class="new"><?= html_escape($price['price'] ?? $p->price) ?> TL</span>
                </div>
              <?php endif; ?>

              <?php if (!empty($p->seller_id) && (int)$p->seller_id > 0): ?>
                <a class="sp-seller" href="<?= base_url('magaza/'.($p->shop_slug ?? '')) ?>">
                  <?php if (!empty($p->shop_img)): ?>
                    <img src="<?= base_url('assets/img/shop/') . $p->shop_img ?>" alt="Shop">
                  <?php else: ?>
                    <i class="ri-user-3-line"></i>
                  <?php endif; ?>
                  <span><?= html_escape($p->shop_name ?: trim(($p->seller_name ?? '').' '.($p->seller_surname ?? ''))) ?></span>
                </a>
              <?php else: ?>
                <span class="sp-seller official">
                  <i class="ri-shield-check-line"></i> Resmi
                </span>
              <?php endif; ?>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <?php if (!empty($serverProductsLinks)): ?>
      <div class="sp-pagination">
        <?= $serverProductsLinks ?>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</div>

<!-- Benzer Sunucular -->
<?php if (!empty($relatedServers)): ?>
  <div class="related-servers card-like" style="margin-top:16px;">
    <div class="sp-head">
      <h3 class="sp-title">
        <i class="ri-links-line"></i> Benzer Sunucular (<?= html_escape($games[$server->game] ?? $server->game) ?>)
      </h3>
    </div>

    <div class="swiper relSrvSwiper">
      <div class="swiper-wrapper">
        <?php foreach ($relatedServers as $rs): ?>
          <?php
            $b = !empty($rs->banner)
              ? base_url('assets/img/servers/'.$rs->banner)
              : base_url('assets/img/server_banners/default.webp');
          ?>
          <div class="swiper-slide">
            <a href="<?= base_url('sunucular/detay/'.(int)$rs->id) ?>" class="rs-card">
              <div class="rs-thumb">
                <img src="<?= html_escape($b) ?>" alt="<?= html_escape($rs->title) ?>">
                <span class="rs-like"><i class="ri-heart-3-fill"></i> <?= (int)($rs->likes_count ?? 0) ?></span>
              </div>
              <div class="rs-body">
                <div class="rs-title"><?= html_escape($rs->title) ?></div>
                <div class="rs-ip"><i class="ri-navigation-line"></i> <?= html_escape($rs->ip) ?></div>
                <?php if (!empty($rs->short_desc)): ?>
                  <div class="rs-desc"><?= html_escape($rs->short_desc) ?></div>
                <?php endif; ?>
              </div>
            </a>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="swiper-pagination"></div>
    </div>
  </div>

  <script>
  document.addEventListener('DOMContentLoaded', function(){
    if (typeof Swiper === 'undefined') return;
    new Swiper('.relSrvSwiper', {
      slidesPerView: 1.15,
      spaceBetween: 12,
      pagination: { el: '.relSrvSwiper .swiper-pagination', clickable: true },
      breakpoints: {
        576: { slidesPerView: 1.6 },
        768: { slidesPerView: 2.2 },
        992: { slidesPerView: 3.1 },
        1200:{ slidesPerView: 3.6 }
      }
    });
  });
  </script>
<?php endif; ?>

<style>
/* Sunucu ürünleri */
.server-products-wrap{ padding: 14px; }
.sp-head{ display:flex; align-items:center; justify-content:space-between; gap: 10px; flex-wrap: wrap; margin-bottom: 10px; }
.sp-title{ margin:0; color:#fff; font-weight: 950; font-size: 18px; display:flex; align-items:center; gap: 8px; }
.sp-add-btn{
  display:inline-flex; align-items:center; gap:8px;
  padding: 10px 12px; border-radius: 14px;
  border: 1px solid rgba(255,255,255,.12);
  background: rgba(0,0,0,.18);
  color:#fff; text-decoration:none; font-weight: 950; font-size: 13px;
  transition: .18s ease;
}
.sp-add-btn:hover{ transform: translateY(-1px); filter: brightness(1.06); }

.sp-empty{
  border-radius: 14px;
  border: 1px dashed rgba(255,255,255,.18);
  background: rgba(0,0,0,.14);
  color: rgba(255,255,255,.85);
  padding: 14px 12px;
  display:flex; align-items:center; gap: 10px;
  font-weight: 800;
}

.sp-list{ display:flex; flex-direction:column; gap: 10px; }
.sp-item{
  display:grid; grid-template-columns: 86px 1fr;
  gap: 12px;
  padding: 10px;
  border-radius: 16px;
  border: 1px solid rgba(255,255,255,.10);
  background: rgba(0,0,0,.16);
}
.sp-img{ border-radius: 14px; overflow:hidden; border:1px solid rgba(255,255,255,.10); display:block; height: 86px; }
.sp-img img{ width:100%; height:100%; object-fit: cover; display:block; }

.sp-name{
  color:#fff; text-decoration:none; font-weight: 950; font-size: 14.5px; line-height: 1.25;
  display:block; margin-top: 2px;
}
.sp-name:hover{ text-decoration: underline; text-underline-offset: 3px; }

.sp-meta{ margin-top: 10px; display:flex; align-items:center; justify-content:space-between; gap: 10px; flex-wrap: wrap; }

.sp-price .new{ font-weight: 950; }
.sp-price .old{ opacity:.6; text-decoration: line-through; font-weight: 900; margin-left: 8px; }

.sp-seller{
  display:inline-flex; align-items:center; gap: 8px;
  padding: 6px 10px; border-radius: 999px;
  border: 1px solid rgba(255,255,255,.10);
  background: rgba(255,255,255,.06);
  color:#fff; text-decoration:none; font-weight: 900; font-size: 12px;
}
.sp-seller img{ width: 22px; height:22px; border-radius: 999px; object-fit: cover; }
.sp-seller.official{ opacity:.85; }

.sp-pagination .pagination{ margin-bottom: 0; }

/* Benzer sunucular */
.related-servers{ padding: 14px; }
.rs-card{
  display:block; text-decoration:none;
  border-radius: 16px; overflow:hidden;
  border: 1px solid rgba(255,255,255,.10);
  background: rgba(0,0,0,.18);
  transition: .2s ease;
}
.rs-card:hover{ transform: translateY(-2px); box-shadow: 0 18px 45px rgba(0,0,0,.35); border-color: rgba(255,255,255,.18); }
.rs-thumb{ position: relative; height: 140px; overflow:hidden; }
.rs-thumb img{ width:100%; height:100%; object-fit: cover; display:block; }
.rs-like{
  position:absolute; right:10px; top:10px;
  display:inline-flex; align-items:center; gap: 6px;
  padding: 6px 8px; border-radius: 999px;
  background: rgba(0,0,0,.45);
  border:1px solid rgba(255,255,255,.12);
  color:#fff; font-weight: 950; font-size: 12px;
}
.rs-body{ padding: 12px; }
.rs-title{ color:#fff; font-weight: 950; font-size: 14px; line-height: 1.25; margin-bottom: 6px; }
.rs-ip{ color: rgba(255,255,255,.75); font-weight: 900; font-size: 12px; display:flex; align-items:center; gap:6px; }
.rs-desc{
  margin-top: 8px;
  color: rgba(255,255,255,.78);
  font-weight: 700;
  font-size: 12.5px;
  line-height: 1.35;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

/* Light mode */
html[data-theme="light"] .server-products-wrap .sp-title,
html[data-theme="light"] .related-servers .sp-title,
html[data-theme="light"] .sp-name,
html[data-theme="light"] .rs-title{ color:#0f172a; }
html[data-theme="light"] .sp-item,
html[data-theme="light"] .rs-card,
html[data-theme="light"] .sp-add-btn,
html[data-theme="light"] .sp-seller{
  background:#fff !important; color:#0f172a !important; border:1px solid rgba(0,0,0,.10) !important;
}
html[data-theme="light"] .sp-empty{ background:rgba(0,0,0,.02); border:1px dashed rgba(0,0,0,.18); color:#334155; }
html[data-theme="light"] .rs-ip,
html[data-theme="light"] .rs-desc{ color:#475569; }
</style>
