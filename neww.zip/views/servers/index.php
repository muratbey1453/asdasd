<?php
// application/views/servers/index.php
// Variables expected: $title, $grouped, $games
?>

<section class="fp-section-page serverhub" style="padding:2.25rem 0">
  <div class="container">
    <div class="serverhub-head">
      <div>
        <h1 class="serverhub-title"><?= html_escape($title) ?></h1>
        <p class="serverhub-sub">Kullanıcıların eklediği sunucular. Admin onaylı olanlar listelenir.</p>
      </div>
      <a href="<?= base_url('client/sunucu-ekle') ?>" class="serverhub-add">
        <i class="ri-add-line"></i>
        <span>Sunucu Ekle</span>
      </a>
    </div>

    <?php foreach ($games as $key => $label): ?>
      <div class="serverhub-section" id="<?= html_escape($key) ?>">
        <div class="serverhub-section-title">
          <span class="badge-game"><?= html_escape($label) ?></span>
          <div class="line"></div>
        </div>

      <?php $items = isset($grouped[$key]) ? $grouped[$key]['items'] : []; ?>
        <?php if (empty($items)): ?>
          <div class="serverhub-empty">
            <i class="ri-inbox-2-line"></i>
            <div>
              <div class="t">Bu kategoriye eklenmiş sunucu yok.</div>
              <div class="s">İlk ekleyen sen olabilirsin.</div>
            </div>
          </div>
        <?php else: ?>
          <div class="serverhub-grid">
            <?php foreach ($items as $s): ?>
              <div class="servercard">
                <div class="servercard-top">
                  <div class="servercard-name">
                    <div class="logo">
                      <i class="ri-server-line"></i>
                    </div>
                    <div class="txt">
                      <div class="h"><?= html_escape($s->title) ?></div>
                      <div class="m">
                        <span class="chip"><i class="ri-global-line"></i> <?= $s->website ? html_escape($s->website) : '—' ?></span>
                        <span class="chip"><i class="ri-radar-line"></i> <?= html_escape($s->ip) ?></span>
                      </div>
                    </div>
                  </div>

                  <?php
                    $isOnline = false;
                    if (!empty($s->owner_last_seen)) {
                      $isOnline = (strtotime($s->owner_last_seen) >= (time() - 3*60*60));
                    }
                  ?>
                  <div class="presence <?= $isOnline ? 'online' : 'offline' ?>" title="<?= $isOnline ? 'Çevrimiçi' : 'Çevrimdışı' ?>">
                    <span class="dot"></span>
                    <span class="label"><?= $isOnline ? 'Online' : 'Offline' ?></span>
                  </div>
                </div>

                <?php if (!empty($s->description)): ?>
                  <div class="servercard-desc"><?= nl2br(html_escape($s->description)) ?></div>
                <?php endif; ?>

                <div class="servercard-bottom">
                  <div class="owner">
                    <div class="avatar">
                      <i class="ri-user-3-line"></i>
                    </div>
                    <div class="owner-txt">
                      <div class="o"><?= html_escape(trim(($s->owner_name ?? '') . ' ' . ($s->owner_surname ?? ''))) ?></div>
                      <div class="small">Ekleyen kullanıcı</div>
                    </div>
                  </div>

                  <div class="actions">
                    <?php if (!empty($s->discord)): ?>
                      <a class="btn-ghost" target="_blank" rel="noopener" href="<?= html_escape($s->discord) ?>">
                        <i class="ri-discord-line"></i>
                        <span>Discord</span>
                      </a>
                    <?php endif; ?>
                    <?php if (!empty($s->website)): ?>
                      <a class="btn-primary" target="_blank" rel="noopener" href="<?= html_escape($s->website) ?>">
                        <i class="ri-external-link-line"></i>
                        <span>Siteye Git</span>
                      </a>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<style>
  /* Dark/Light uyumlu, mevcut temayı bozmadan sadece bu sayfaya scope */
  .serverhub{
    --bg: rgba(255,255,255,.65);
    --card: rgba(255,255,255,.75);
    --text: #0f172a;
    --muted: rgba(15,23,42,.7);
    --border: rgba(15,23,42,.10);
    --shadow: 0 16px 40px rgba(2,6,23,.10);
    --accent: rgba(99,102,241,.35);
    --accent2: rgba(34,211,238,.25);
  }
  [data-theme="dark"] .serverhub,
  .dark .serverhub{
    --bg: rgba(2,6,23,.55);
    --card: rgba(2,6,23,.65);
    --text: rgba(255,255,255,.92);
    --muted: rgba(255,255,255,.72);
    --border: rgba(255,255,255,.10);
    --shadow: 0 18px 50px rgba(0,0,0,.45);
    --accent: rgba(99,102,241,.35);
    --accent2: rgba(34,211,238,.22);
  }

  .serverhub .serverhub-head{
    display:flex; align-items:flex-end; justify-content:space-between; gap:16px;
    padding:18px 18px;
    border:1px solid var(--border);
    border-radius:18px;
    background:
      radial-gradient(1200px 300px at 10% 0%, var(--accent), transparent 60%),
      radial-gradient(900px 260px at 90% 20%, var(--accent2), transparent 55%),
      var(--bg);
    box-shadow: var(--shadow);
    backdrop-filter: blur(12px);
  }
  .serverhub-title{ margin:0; font-size:28px; color:var(--text); letter-spacing:-.02em; }
  .serverhub-sub{ margin:6px 0 0; color:var(--muted); }
  .serverhub-add{
    display:inline-flex; align-items:center; gap:8px;
    padding:10px 14px;
    border-radius:12px;
    border:1px solid var(--border);
    background: var(--card);
    color:var(--text);
    text-decoration:none;
    transition:.2s ease;
  }
  .serverhub-add:hover{ transform: translateY(-1px); box-shadow: 0 10px 24px rgba(0,0,0,.12); }

  .serverhub-section{ margin-top:22px; }
  .serverhub-section-title{ display:flex; align-items:center; gap:12px; margin:18px 2px 12px; }
  .serverhub-section-title .line{ height:1px; flex:1; background:linear-gradient(90deg, var(--border), transparent); }
  .badge-game{ display:inline-flex; align-items:center; padding:6px 10px; border-radius:999px; border:1px solid var(--border); background:var(--card); color:var(--text); font-weight:600; }

  .serverhub-grid{ display:grid; grid-template-columns: repeat(12, 1fr); gap:14px; }
  .servercard{ grid-column: span 6; min-width:0;
    border:1px solid var(--border);
    border-radius:18px;
    background:
      radial-gradient(700px 180px at 10% 0%, rgba(99,102,241,.16), transparent 60%),
      radial-gradient(600px 200px at 90% 20%, rgba(34,211,238,.12), transparent 55%),
      var(--card);
    box-shadow: var(--shadow);
    backdrop-filter: blur(12px);
    padding:14px;
    transition: transform .2s ease, box-shadow .2s ease, border-color .2s ease;
  }
  .servercard:hover{ transform: translateY(-2px); border-color: rgba(99,102,241,.35); box-shadow: 0 22px 60px rgba(0,0,0,.18); }
  @media (max-width: 992px){ .servercard{ grid-column: span 12; } }

  .servercard-top{ display:flex; align-items:flex-start; justify-content:space-between; gap:12px; }
  .servercard-name{ display:flex; gap:12px; min-width:0; }
  .servercard-name .logo{
    width:44px; height:44px; border-radius:14px;
    display:grid; place-items:center;
    border:1px solid var(--border);
    background: rgba(99,102,241,.12);
    color: var(--text);
  }
  .servercard-name .txt{ min-width:0; }
  .servercard-name .h{ font-weight:800; color:var(--text); line-height:1.15; }
  .servercard-name .m{ margin-top:6px; display:flex; gap:8px; flex-wrap:wrap; }
  .chip{
    display:inline-flex; align-items:center; gap:6px;
    padding:6px 10px;
    border-radius:999px;
    border:1px solid var(--border);
    background: rgba(255,255,255,.12);
    color:var(--muted);
    font-size:12px;
  }
  [data-theme="dark"] .serverhub .chip, .dark .serverhub .chip{ background: rgba(0,0,0,.18); }

  .presence{
    display:inline-flex; align-items:center; gap:7px;
    padding:6px 10px;
    border-radius:999px;
    border:1px solid var(--border);
    background: rgba(255,255,255,.12);
    color: var(--muted);
    font-weight:700;
    font-size:12px;
    white-space:nowrap;
  }
  .presence .dot{ width:8px; height:8px; border-radius:999px; background:#94a3b8; box-shadow: 0 0 0 3px rgba(148,163,184,.15); }
  .presence.online .dot{ background:#22c55e; box-shadow: 0 0 0 3px rgba(34,197,94,.15), 0 0 18px rgba(34,197,94,.25); }
  .presence.offline .dot{ background:#ef4444; box-shadow: 0 0 0 3px rgba(239,68,68,.12); }

  .servercard-desc{ margin-top:12px; color:var(--muted); font-size:13px; line-height:1.55; }
  .servercard-bottom{ margin-top:14px; display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; }
  .owner{ display:flex; align-items:center; gap:10px; }
  .owner .avatar{
    width:38px; height:38px; border-radius:14px;
    display:grid; place-items:center;
    border:1px solid var(--border);
    background: rgba(34,211,238,.10);
    color: var(--text);
  }
  .owner-txt .o{ color:var(--text); font-weight:800; line-height:1.1; }
  .owner-txt .small{ color:var(--muted); font-size:12px; }

  .actions{ display:flex; gap:8px; }
  .btn-ghost,
  .btn-primary{
    display:inline-flex; align-items:center; gap:8px;
    padding:9px 12px;
    border-radius:12px;
    text-decoration:none;
    border:1px solid var(--border);
    transition:.2s ease;
    font-weight:700;
    font-size:13px;
  }
  .btn-ghost{ background: rgba(255,255,255,.10); color:var(--text); }
  [data-theme="dark"] .serverhub .btn-ghost, .dark .serverhub .btn-ghost{ background: rgba(0,0,0,.18); }
  .btn-ghost:hover{ transform: translateY(-1px); box-shadow: 0 12px 30px rgba(0,0,0,.12); }

  .btn-primary{
    background: linear-gradient(135deg, rgba(99,102,241,.90), rgba(34,211,238,.75));
    color: #0b1220;
    border-color: rgba(99,102,241,.25);
  }
  .btn-primary:hover{ transform: translateY(-1px); box-shadow: 0 16px 40px rgba(99,102,241,.18); }

  .serverhub-empty{
    display:flex; align-items:center; gap:12px;
    padding:16px;
    border:1px dashed var(--border);
    border-radius:16px;
    background: var(--card);
    color:var(--muted);
  }
  .serverhub-empty .t{ color:var(--text); font-weight:800; }
  .serverhub-empty .s{ font-size:13px; }
</style>
