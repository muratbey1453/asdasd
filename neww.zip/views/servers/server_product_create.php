<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<section class="fp-section-page" style="padding: 2.2rem 0 3rem;">
  <div class="container">

    <div class="d-flex align-items-center justify-content-between mb-3">
      <div>
        <h1 class="title mb-1" style="font-size:26px">Sunucuya Ürün Ekle</h1>
        <div style="opacity:.75; font-weight:800">
          <i class="ri-gamepad-line me-1"></i> <?= html_escape($server->title) ?>
        </div>
      </div>

      <a href="<?= base_url('sunucular/detay/'.(int)$server->id) ?>" class="btn btn-outline-light">
        <i class="ri-arrow-left-line me-1"></i> Geri
      </a>
    </div>

    <div class="card-like p-3 p-md-4">
      <form action="<?= base_url('sunucular/urun-ekle/'.(int)$server->id.'/kaydet') ?>" method="post" enctype="multipart/form-data">
        <!-- CSRF (CI CSRF açıksa şart) -->
        <?php if (isset($this->security)): ?>
          <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
        <?php endif; ?>

        <div class="row g-3">
          <div class="col-12 col-md-8">
            <label class="form-label fw-bold">Başlık</label>
            <input type="text" name="name" class="form-control" placeholder="Örn: Metin2 EP (1000 adet)" value="<?= set_value('name') ?>" required>
          </div>

          <div class="col-12 col-md-2">
            <label class="form-label fw-bold">Fiyat (TL)</label>
            <input type="number" step="0.01" min="0" name="price" class="form-control" placeholder="199.90" value="<?= set_value('price') ?>" required>
          </div>

          <div class="col-12 col-md-2">
            <label class="form-label fw-bold">İndirimli (ops.)</label>
            <input type="text" name="discount" class="form-control" placeholder="159.90" value="<?= set_value('discount') ?>">
          </div>

          <div class="col-12">
            <label class="form-label fw-bold">Açıklama</label>
            <textarea name="description" class="form-control" rows="5" placeholder="Ürün detayları..."><?= set_value('description') ?></textarea>
          </div>

          <div class="col-12 col-md-6">
            <label class="form-label fw-bold">Ürün Görseli</label>
            <input type="file" name="img" class="form-control" accept="image/*" required>
            <div class="small mt-1" style="opacity:.7">jpg / png / webp • max 4MB</div>
          </div>

          <div class="col-12">
            <button type="submit" class="btn btn-primary px-4">
              <i class="ri-add-line me-1"></i> Ürünü Oluştur
            </button>
            <span class="ms-2 small" style="opacity:.7">Ürün admin onayı sonrası sunucuda görünecek.</span>
          </div>
        </div>
      </form>
    </div>

  </div>
</section>

<style>
.card-like{
  background: rgba(255,255,255,.06);
  border: 1px solid rgba(255,255,255,.10);
  border-radius: 18px;
  backdrop-filter: blur(10px);
  box-shadow: 0 18px 60px rgba(0,0,0,.35);
}
html[data-theme="light"] .card-like{
  background:#fff; border:1px solid rgba(0,0,0,.10); box-shadow:0 18px 60px rgba(0,0,0,.10); backdrop-filter:none;
}
</style>
