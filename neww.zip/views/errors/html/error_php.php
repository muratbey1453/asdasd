<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<div style="border:1px solid #990000;padding:10px;margin:10px;font-family:monospace;">
    <h4>PHP Hatası</h4>
    <p><b>Tür:</b> <?php echo $severity; ?></p>
    <p><b>Mesaj:</b> <?php echo $message; ?></p>
    <p><b>Dosya:</b> <?php echo $filepath; ?></p>
    <p><b>Satır:</b> <?php echo $line; ?></p>
</div>