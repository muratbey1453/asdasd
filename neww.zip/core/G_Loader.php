<?php
defined("BASEPATH") or exit("No direct script access allowed");
class G_Loader extends CI_Loader
{
    private $is_controlled = false;
    private $last_data = [];
    private $product = "orius_webscript";
    public function initialize($controller = NULL)
    {
        parent::initialize($controller);
        if (!file_exists(FCPATH . "/application/core/G_Controller.php")) {
            exit("Sistem dosyalarının bütünlüğünü doğrulayamadık. Lütfen bizimle iletişime geç.");
        }
        $dt = date("l");
        $dtd = date("d");
        $dtm = date("m");
        $dt = substr($dt, 0, 1) . substr($dtd, 0, 1) . substr($dtm, 0, 1) . substr($dt, -1) . substr($dtd, -1) . substr($dtm, -1);
        define("GCO_" . $dt, true);
    }
    public function get_update_info()
    {
        $license = self::controll_license(true);
        if ($license["message"] == "Update") {
            return ["status" => $license["status"], "patch_notes" => $license["patch_notes"], "version" => $license["version"], "old_patches" => $license["old_patches"] ?? [], "exp_date" => $license["exp_date"], "is_offline" => $license["is_offline"], "offline_time" => $license["next_control_time"] ?? ""];
        }
        return ["status" => false, "old_patches" => $license["old_patches"] ?? [], "exp_date" => $license["exp_date"], "is_offline" => $license["is_offline"], "offline_time" => $license["next_control_time"] ?? ""];
    }
    public function update_script()
    {
        $control = self::controll_license(true);
        if ($control["message"] == "Update") {
            $CI =& get_instance();
            $update_url = $control["update_url"];
            set_time_limit(0);
            if (!file_exists(FCPATH . "/updates")) {
                mkdir(FCPATH . "/updates");
            }
            $fp = fopen(FCPATH . "/updates/updated.zip", "w+");
            $ch = curl_init($update_url);
            curl_setopt($ch, CURLOPT_TIMEOUT, 50);
            curl_setopt($ch, CURLOPT_FILE, $fp);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_exec($ch);
            curl_close($ch);
            fclose($fp);
            $zip = new ZipArchive();
            if ($zip->open(FCPATH . "/updates/updated.zip") === true) {
                $acma = $zip->extractTo(".");
                if ($acma) {
                    if (file_exists("GleoxUpdater.php")) {
                        require_once FCPATH . "/GleoxUpdater.php";
                        $updater = new GleoxUpdater($CI);
                        $updater->runUpdate();
                        unlink(FCPATH . "/GleoxUpdater.php");
                        unlink(FCPATH . "/updates/updated.zip");
                    }
                    return json_encode(["status" => true, "message" => "Güncelleme başarılı!"]);
                }
                return json_encode(["status" => false, "message" => "İndirilen dosya çıkartılırken bir hata oluştu!"]);
            }
            return json_encode(["status" => false, "message" => "İndirilen dosya açılırken bir hata oluştu!"]);
        }
        return json_encode(["status" => false, "message" => "Zaten güncel bir sürüm kullanıyorsunuz!"]);
    }
    public function view($view, $vars = [], $return = false)
    {
        $control = self::controll_license();
        if (!$control["status"]) {
            //exit("\n\t    \t\t<html>\n\t\t\t\t    <head>\n\t\t\t\t        <title>Hata!</title>\n\t\t\t\t        <style type=\"text/css\">\n\t\t\t\t            body, html\n\t\t\t\t            {\n\t\t\t\t                margin: 0; padding: 0; height: 100%; overflow: hidden;\n\t\t\t\t            }\n\n\t\t\t\t            #content\n\t\t\t\t            {\n\t\t\t\t                position:absolute; left: 0; right: 0; bottom: 0; top: 0px; \n\t\t\t\t            }\n\t\t\t\t        </style>\n\t\t\t\t    </head>\n\t\t\t\t    <body>\n\t\t\t\t        <div id=\"content\">\n\t\t\t\t            <iframe width=\"100%\" height=\"100%\" frameborder=\"0\" src=\"https://error.asfasf.com/?product=" . $this->product . "\"></iframe>\n\t\t\t\t        </div>\n\t\t\t\t    </body>\n\t\t\t\t</html>\n    \t\t");
        }
        parent::view($view, $vars, $return);
    }
    private function controll_license($for_update = false)
    {
        if (!$this->is_controlled) {
            $this->is_controlled = true;
            $CI =& get_instance();
            $properties = $CI->db->where("id", 1)->get("properties")->row();
            $version = $properties->version;
            $module = $this->product;
            $license_file = FCPATH . "/license.key";
            if (!file_exists($license_file)) {
                $data = ["status" => false, "message" => "License key is not exists!"];
            } else {
                $license_key = file_get_contents($license_file);
                if (1264 <= strlen($license_key)) {
                    $time = substr($license_key, 1264);
                    $license_key = substr($license_key, 0, 1264);
                    $license_data = strrev($time);
                    $med = strlen($license_data) / 2;
                    $license_data = substr($license_data, $med) . substr($license_data, 0, $med);
                    $license_data = base64_decode($license_data);
                    $license_data = json_decode($license_data, true) ?? ["next_control" => 1, "offline_time" => 1, "next_offline_check" => 1, "next_control_time" => 0, "is_offline" => false, "exp_date" => "", "time" => time()];
                    $server_url = preg_replace("/(https*:\\/\\/)(([^.]+)(\\.[^\\/]+))([\\s\\S]*)/", "\$2", base_url());
                    $serverIp = "";
                    if (isset($_SERVER["SERVER_ADDR"])) {
                        $serverIp = $_SERVER["SERVER_ADDR"];
                    } else if (isset($_SERVER["LOCAL_ADDR"])) {
                        $serverIp = $_SERVER["LOCAL_ADDR"];
                    } else if (function_exists("gethostname") && function_exists("gethostbyname")) {
                        $serverIp = gethostbyname(gethostname());
                    }
                    $selected_server = "https://lisans.com/query";
                    //if ($license_data["is_offline"] && time() < $license_data["offline_time"] && time() < $license_data["next_offline_check"]) {
                    if (1==1) {
                        $data = ["status" => true, "message" => "License key valid!", "exp_date" => $license_data["exp_date"], "is_offline" => true, "offline_check_time" => $license_data["next_control_time"]];
                        $this->last_data = $data;
                        return $data;
                    }
                    if (time() < $license_data["next_control"] && !$for_update) {
                        $data = ["status" => true, "message" => "License key valid!", "exp_date" => $license_data["exp_date"], "is_offline" => false];
                        $this->last_data = $data;
                        return $data;
                    }
                    if (!($license_data["is_offline"] && time() < $license_data["offline_time"])) {
                        file_put_contents($license_file, $license_key);
                    }
                    $curl = self::g_send_request($selected_server, ["domain" => $server_url, "ip" => $serverIp, "license_key" => $license_key, "product_version" => $version, "product" => $this->product]);
                    if (is_array($curl)) {
                        if ($license_data["offline_time"] < time()) {
                            $data = ["status" => false, "message" => "License key not valid!"];
                        } else {
                            $data = ["status" => true, "message" => "License key valid!", "exp_date" => $license_data["exp_date"]];
                            $new_time = base64_encode(json_encode(["next_control" => $license_data["next_control"], "offline_time" => $license_data["offline_time"], "next_offline_check" => strtotime("+" . $license_data["next_control_time"]), "next_control_time" => $license_data["next_control_time"], "is_offline" => true, "exp_date" => $license_data["exp_date"], "time" => time()]));
                            $med = strlen($new_time) / 2;
                            $new_time = substr($new_time, $med) . substr($new_time, 0, $med);
                            $new_time = strrev($new_time);
                            file_put_contents($license_file, $license_key . $new_time);
                        }
                    } else {
                        $json = json_decode($curl, true);
                        if ($json["status"]) {
                            $data = $json;
                            $data["is_offline"] = false;
                            $new_time = base64_encode(json_encode(["next_control" => strtotime("+" . $data["next_control"]), "offline_time" => strtotime("+" . $data["offline_time"]), "next_offline_check" => strtotime("+" . $data["next_control"]), "next_control_time" => $data["next_control"], "is_offline" => false, "exp_date" => $data["exp_date"], "time" => time()]));
                            $med = strlen($new_time) / 2;
                            $new_time = substr($new_time, $med) . substr($new_time, 0, $med);
                            $new_time = strrev($new_time);
                            file_put_contents($license_file, $license_key . $new_time);
                        } else {
                            $data = $json;
                        }
                    }
                } else {
                    $data = ["status" => false, "message" => "License key has a problem!"];
                }
            }
            $this->last_data = $data;
            return $data;
        }
        return $this->last_data;
    }
    private function g_send_request($url, $params)
    {
        $options = [CURLOPT_RETURNTRANSFER => true, CURLOPT_HEADER => false, CURLOPT_ENCODING => "", CURLOPT_AUTOREFERER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => 3, CURLOPT_MAXREDIRS => 10, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_USERAGENT => "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13", CURLOPT_CUSTOMREQUEST => "POST", CURLOPT_POSTFIELDS => http_build_query($params)];
        $ch = curl_init($url);
        curl_setopt_array($ch, $options);
        $content = curl_exec($ch);
        $err = curl_errno($ch);
        $errmsg = curl_error($ch);
        $header = curl_getinfo($ch);
        $redirectURL = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        curl_close($ch);
        $header["errno"] = $err;
        $header["errmsg"] = $errmsg;
        $header["redirect"] = $redirectURL;
        $header["content"] = $content;
        if (empty($errmsg) && $header["http_code"] == 200) {
            return $header["content"];
        }
        return ["error" => "code: " . $err . " message:" . $errmsg];
    }
}

?>