<?php
defined("BASEPATH") or exit("No direct script access allowed");
class G_Controller extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->benchmark->mark("start");
        if (!file_exists(FCPATH . "/application/core/G_Loader.php")) {
            exit("Sistem dosyalarının bütünlüğünü doğrulayamadık. Lütfen bizimle iletişime geç.");
        }
        $dt = date("l");
        $dtd = date("d");
        $dtm = date("m");
        $dt = "GCO_" . substr($dt, 0, 1) . substr($dtd, 0, 1) . substr($dtm, 0, 1) . substr($dt, -1) . substr($dtd, -1) . substr($dtm, -1);
        if (!defined($dt)) {
            exit("Sistem dosyalarının bütünlüğünü doğrulayamadık. Lütfen bizimle iletişime geç.");
        }
    }
    public function view($fileName, $data = NULL)
    {
        $properties = $this->db->where("id", 1)->get("properties")->row();
        $this->load->view("theme/" . $properties->theme . "/includes/header", $data);
        $this->load->view("theme/" . $properties->theme . "/" . $fileName, $data);
        $this->load->view("theme/" . $properties->theme . "/includes/footer", $data);
    }
    public function clientView($fileName, $data = NULL)
    {
        $properties = $this->db->where("id", 1)->get("properties")->row();
        $this->load->view("theme/" . $properties->theme . "/includes/header", $data);
        $this->load->view("theme/" . $properties->theme . "/client/includes/sidebar", $data);
        $this->load->view("theme/" . $properties->theme . "/client/" . $fileName, $data);
        $this->load->view("theme/" . $properties->theme . "/includes/footer", $data);
    }
    public function adminView($fileName, $data = NULL)
    {
        $this->load->view("admin/includes/header", $data);
        $this->load->view("admin/includes/sidebar", $data);
        $this->load->view("admin/" . $fileName, $data);
        $this->load->view("admin/includes/footer");
    }
    public function insert($page, $table, $imgPath = NULL)
    {
        $data = [];
        foreach ($this->input->post() as $p => $value) {
            if (is_array($value)) {
                $data[$p] = json_encode($value);
            } else {
                $data[$p] = $value;
            }
        }
        if (!empty($_FILES["img"]) && $_FILES["img"]["error"] == 0) {
            $nameFile = changePhoto("assets/img/" . $imgPath, "img");
            $data["img"] = $nameFile;
        }
        $result = $this->db->insert($table, $data);
        if ($result) {
            flash("Başarılı", "Ekleme İşlemi Başarılı");
            redirect(base_url("admin/") . $page, "refresh");
        } else {
            flash("Başarılı", "Bir Sorundan Ötürü Veri Eklenemedi.");
            redirect(base_url("admin/") . $page, "refresh");
        }
    }
    public function delete($page, $table, $id)
    {
        $result = $this->db->where(["id" => $id])->delete($table);
        if ($result) {
            flash("Başarılı", "Silme İşlemi Başarılı");
            redirect(base_url("admin/") . $page, "refresh");
        } else {
            flash("Başarısız", "Bir Sorundan Ötürü Veri Silinemedi.");
            redirect(base_url("admin/") . $page, "refresh");
        }
    }
    public function edit($page, $table, $id, $imgPath = NULL)
    {
        $this->load->helper("helpers");
        $data = [];
        foreach ($this->input->post() as $p => $value) {
            if (is_array($value)) {
                $data[$p] = json_encode($value);
            } else if ($value == "on") {
                $data[$p] = "1";
            } else {
                $data[$p] = $value;
            }
        }
        if (!empty($_FILES["img"]) && $_FILES["img"]["error"] == 0) {
            $nameFile = changePhoto("assets/img/" . $imgPath, "img");
            $data["img"] = $nameFile;
            $imgData = $this->db->where(["id" => $id])->get($table)->row();
            @unlink("assets/img/" . $imgPath . "/" . $imgData->img);
        }
        $result = $this->db->where(["id" => $id])->update($table, $data);
        if ($result) {
            flash("Başarılı", "Düzenleme İşlemi Başarılı");
            redirect(base_url("admin/") . $page, "refresh");
        } else {
            flash("Başarısız", "Bir Sorundan Ötürü Veri Düzenlenemedi.");
            redirect(base_url("admin/") . $page, "refresh");
        }
    }
}

?>