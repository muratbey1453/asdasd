<?php
function weighted_random($items, $chances) {
    $sum = array_sum($chances);
    $rand = mt_rand(1, $sum);
    foreach ($items as $key => $item) {
        $rand -= $chances[$key];
        if ($rand <= 0) {
            return $item;
        }
    }
}

function get_color_by_chance($chance) {
    //red, orange, blue, grey (25,50,75,100)
    if ($chance <= 25) {
        return 'red';
    } else if ($chance <= 50) {
        return 'orange';
    } else if ($chance <= 75) {
        return 'blue';
    } else {
        return 'grey';
    }
}

function weighted_random_all($items, $chances, $count) {
    $selected_items = [];
    $sum = array_sum($chances);
    for ($i = 0; $i < $count; $i++) {
        $rand = mt_rand(1, $sum);
        foreach ($items as $key => $item) {
            $rand -= $chances[$key];
            if ($rand <= 0) {
                $selected_items[] = unserialize(serialize($item)); //aynı objeden birden fazla olursa referansı değişiyor, böylece aynı objeyi kopyalıyoruz
                break;
            }
        }
    }
    return $selected_items;
}
