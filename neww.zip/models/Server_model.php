<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Server_model extends CI_Model
{
    /**
     * DB status mapping
     * 0 = pending, 1 = approved, 2 = rejected
     */
    public const STATUS_PENDING  = 0;
    public const STATUS_APPROVED = 1;
    public const STATUS_REJECTED = 2;

    public function game_options()
    {
        return [
            'metin2'    => 'Metin2',
            'bombom'    => 'Bombom',
            'minecraft' => 'Minecraft',
            'knight'    => 'Knight Online',
            'cs2'       => 'CS2',
        ];
    }

    private function likes_join()
    {
        // server_likes tablon yoksa bu join'i kaldır.
        $this->db->join('(SELECT server_id, COUNT(*) AS likes_count FROM server_likes GROUP BY server_id) sl', 'sl.server_id = s.id', 'left');
        $this->db->select('COALESCE(sl.likes_count,0) AS likes_count', false);
    }

    public function get_approved_by_id($id)
    {
        $this->db
            ->select('s.*, u.name AS owner_name, u.surname AS owner_surname, u.last_login AS owner_last_login')
            ->from('servers s')
            ->join('user u', 'u.id = s.user_id', 'left')
            ->where('s.id', (int)$id)
            ->where('s.status', self::STATUS_APPROVED)
            ->limit(1);

        $this->likes_join();

        return $this->db->get()->row();
    }

    public function get_grouped_approved()
    {
        $this->db
            ->select('s.*, u.name AS owner_name, u.surname AS owner_surname, u.last_login AS owner_last_login')
            ->from('servers s')
            ->join('user u', 'u.id = s.user_id', 'left')
            ->where('s.status', self::STATUS_APPROVED)
            ->order_by('s.created_at', 'DESC');

        $this->likes_join();

        $rows = $this->db->get()->result();

        $grouped = [];
        foreach ($rows as $r) {
            $game = !empty($r->game) ? $r->game : 'other';
            if (!isset($grouped[$game])) {
                $grouped[$game] = [];
            }
            $grouped[$game][] = $r;
        }
        return $grouped;
    }

    public function get_by_game_approved($game)
    {
        $this->db
            ->select('s.*, u.name AS owner_name, u.surname AS owner_surname, u.last_login AS owner_last_login')
            ->from('servers s')
            ->join('user u', 'u.id = s.user_id', 'left')
            ->where('s.status', self::STATUS_APPROVED)
            ->where('s.game', $game)
            ->order_by('s.created_at', 'DESC');

        $this->likes_join();

        return $this->db->get()->result();
    }

    // Benzer sunucular (aynı oyun, kendisi hariç)
    public function get_related_approved($game, $excludeId, $limit = 12)
    {
        $this->db
            ->select('s.id, s.title, s.game, s.ip, s.banner, s.short_desc')
            ->from('servers s')
            ->where('s.status', self::STATUS_APPROVED)
            ->where('s.game', $game)
            ->where('s.id !=', (int)$excludeId)
            ->order_by('s.created_at', 'DESC')
            ->limit((int)$limit);

        $this->likes_join();

        return $this->db->get()->result();
    }

    public function create_server(array $data)
    {
        $this->db->insert('servers', $data);
        return $this->db->insert_id();
    }
}
