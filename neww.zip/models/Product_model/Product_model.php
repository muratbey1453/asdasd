<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model
{
    public function count_by_server($serverId)
    {
        return (int)$this->db->from('product')
            ->where('isActive', 1)
            ->where('server_id', (int)$serverId)
            ->count_all_results();
    }

    public function get_by_server_paginated($serverId, $limit, $offset)
    {
        return $this->db
            ->select('p.id, p.name, p.slug, p.img, p.seller_id')
            ->select('u.name AS seller_name, u.surname AS seller_surname, u.shop_slug, u.shop_img, u.shop_name', false)
            ->from('product p')
            ->join('user u', 'u.id = p.seller_id', 'left')
            ->where('p.isActive', 1)
            ->where('p.server_id', (int)$serverId)
            ->order_by('p.id', 'DESC')
            ->limit((int)$limit, (int)$offset)
            ->get()->result();
    }

   public function create_for_server($serverId, $sellerId, $name, $price, $discountPrice, $imgFile, $description = null)
{
    $now = date('Y-m-d H:i:s');

    $payload = [
        'seller_id' => (int)$sellerId,
        'server_id' => (int)$serverId,
        'name'      => $name,
        'img'       => $imgFile,
        'price'     => (float)$price,
        'discount'  => (float)$discountPrice, // indirimli fiyat (yoksa 0)
        'isActive'  => 1,
    ];

    if ($this->db->field_exists('description', 'product')) $payload['description'] = $description;
    if ($this->db->field_exists('created_at', 'product')) $payload['created_at'] = $now;
    if ($this->db->field_exists('updated_at', 'product')) $payload['updated_at'] = $now;

    $this->db->insert('product', $payload);
    $productId = (int)$this->db->insert_id();

    // slug tek segment olsun (route catch-all (:any) buna uygun)
    if ($productId > 0 && $this->db->field_exists('slug', 'product')) {
        $slugBase = url_title($name, '-', true);
        $slug = $productId . '-' . $slugBase; // örn: 123-metin2-ep
        $this->db->where('id', $productId)->update('product', ['slug' => $slug]);
    }

    return $productId;
}
public function create_for_server($serverId, $sellerId, $name, $price, $discountPrice, $imgFile, $description = null)
{
    $this->load->helper('url');

    $now = date('Y-m-d H:i:s');

    $payload = [
        'seller_id' => (int)$sellerId,
        'server_id' => (int)$serverId,
        'name'      => $name,
        'img'       => $imgFile,
        'price'     => (float)$price,
        'discount'  => (float)$discountPrice,  // ✅ calculatePrice direkt buradan okuyor
        'isActive'  => 0,                      // ✅ BEKLEMEDE (admin onayı)
    ];

    if ($this->db->field_exists('description', 'product')) $payload['description'] = $description;
    if ($this->db->field_exists('created_at', 'product'))  $payload['created_at']  = $now;
    if ($this->db->field_exists('updated_at', 'product'))  $payload['updated_at']  = $now;

    $this->db->insert('product', $payload);
    $productId = (int)$this->db->insert_id();
    if ($productId <= 0) return 0;

    // slug (catch-all route senin sisteminde slug’ı kullanıyor)
    if ($this->db->field_exists('slug', 'product')) {
        $slug = $productId . '-' . url_title($name, '-', true);
        $this->db->where('id', $productId)->update('product', ['slug' => $slug]);
    }

    return $productId;
}

public function count_active_by_server($serverId)
{
    return (int)$this->db->from('product')
        ->where('server_id', (int)$serverId)
        ->where('isActive', 1)
        ->count_all_results();
}

public function get_active_by_server_paginated($serverId, $limit, $offset)
{
    return $this->db->from('product')
        ->where('server_id', (int)$serverId)
        ->where('isActive', 1)
        ->order_by('id', 'DESC')
        ->limit((int)$limit, (int)$offset)
        ->get()->result();
}


    private function try_set_price($productId, $price)
    {
        $price = (float)$price;

        // 1) product.price varsa
        if ($this->db->field_exists('price', 'product')) {
            $this->db->where('id', (int)$productId)->update('product', ['price' => $price]);
            return;
        }

        // 2) product_price tablosu varsa (sende varsa çalışır)
        if ($this->db->table_exists('product_price')
            && $this->db->field_exists('product_id', 'product_price')
            && $this->db->field_exists('price', 'product_price')) {

            $row = ['product_id' => (int)$productId, 'price' => $price];
            $this->db->insert('product_price', $row);
            return;
        }

        // Buraya düşerse: sende fiyat başka tabloda tutuluyor.
        // calculatePrice hangi tablodan okuyorsa, onu söyleyebilirsen burayı ona göre yazarım.
    }
}
