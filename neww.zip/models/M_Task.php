<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_Task extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function get_tasks($status = null, $limit = null, $offset = null) {
        if ($status !== null) {
            $this->db->where('status', $status);
        }
        if ($limit !== null) {
            $this->db->limit($limit, $offset);
        }
        $this->db->order_by('created_at', 'DESC');
        return $this->db->get('tasks')->result();
    }

    public function get_task($id) {
        return $this->db->where('id', $id)->get('tasks')->row();
    }

    public function create_task($data) {
        $this->db->insert('tasks', $data);
        return $this->db->insert_id();
    }

    public function submit_proof($data) {
        $this->db->insert('task_proofs', $data);
        return $this->db->insert_id();
    }

    public function get_proofs($task_id = null, $user_id = null) {
        if ($task_id) {
            $this->db->where('task_id', $task_id);
        }
        if ($user_id) {
            $this->db->where('user_id', $user_id);
        }
        $this->db->order_by('created_at', 'DESC');
        return $this->db->get('task_proofs')->result();
    }

    public function get_user_proof_for_task($task_id, $user_id) {
        return $this->db->where('task_id', $task_id)
                        ->where('user_id', $user_id)
                        ->get('task_proofs')
                        ->row();
    }

    public function get_proof($id) {
        return $this->db->where('id', $id)->get('task_proofs')->row();
    }

    public function update_task_status($id, $status) {
        return $this->db->where('id', $id)->update('tasks', ['status' => $status]);
    }

    public function update_proof_status($id, $status, $reason = null) {
        $data = ['status' => $status];
        if ($reason !== null) {
            $data['rejection_reason'] = $reason;
        }
        return $this->db->where('id', $id)->update('task_proofs', $data);
    }

    public function get_user_tasks($user_id) {
        return $this->db->where('user_id', $user_id)->order_by('created_at', 'DESC')->get('tasks')->result();
    }
    
    public function increment_task_count($task_id) {
        $this->db->set('current_count', 'current_count+1', FALSE);
        $this->db->where('id', $task_id);
        return $this->db->update('tasks');
    }

    public function get_task_with_user_proof($task_id, $user_id) {
        $task = $this->get_task($task_id);
        if (!$task) return null;
        
        $proof = $this->db->where('task_id', $task_id)->where('user_id', $user_id)->get('task_proofs')->row();
        $task->user_proof = $proof;
        return $task;
    }
}
