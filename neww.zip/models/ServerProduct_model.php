<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * ServerProduct_model
 * - product tablosuna "server_id" alanı üzerinden sunucu ürünlerini yazar/okur.
 * - Sunucu ürünleri marketplace genel listesinde görünmesin diye:
 *   Marketplace query'lerine ayrıca "where('server_id', 0)" ekle (aşağıda not var).
 */
class ServerProduct_model extends CI_Model
{
    public function count_by_server($serverId)
    {
        return (int)$this->db->from('product')
            ->where('isActive', 1)
            ->where('server_id', (int)$serverId)
            ->count_all_results();
    }

    public function get_by_server_paginated($serverId, $limit, $offset)
    {
        return $this->db
            ->select('p.id, p.name, p.slug, p.img, p.seller_id, p.price, p.discount')
            ->select('u.name AS seller_name, u.surname AS seller_surname, u.shop_slug, u.shop_img, u.shop_name', false)
            ->from('product p')
            ->join('user u', 'u.id = p.seller_id', 'left')
            ->where('p.isActive', 1)
            ->where('p.server_id', (int)$serverId)
            ->order_by('p.id', 'DESC')
            ->limit((int)$limit, (int)$offset)
            ->get()->result();
    }

    /**
     * Sunucuya yeni ürün oluşturur.
     * - isActive = 0 (admin onayı beklesin)
     */
    public function create_for_server($serverId, $sellerId, $name, $price, $discountPrice, $imgFile, $description = null, $galleryJson = null)
    {
        $this->load->helper('url'); // url_title için

        $now = date('Y-m-d H:i:s');

        $payload = [
            'seller_id' => (int)$sellerId,
            'server_id' => (int)$serverId,
            'name'      => $name,
            'img'       => $imgFile,
        ];

        // Galeri (JSON) - product.gallery varsa yaz
        if (!empty($galleryJson) && $this->db->field_exists('gallery', 'product')) {
            $payload['gallery'] = (string)$galleryJson;
        }


        // Fiyat kolonları (senin tablonda "price" ve "discount" var)
        if ($this->db->field_exists('price', 'product'))    $payload['price'] = (float)$price;
        if ($this->db->field_exists('discount', 'product')) $payload['discount'] = (float)$discountPrice;

        // Onay alanı (marketplace ile aynı)
        if ($this->db->field_exists('isActive', 'product')) $payload['isActive'] = 0;

        // Opsiyonel alanlar: tablonda varsa doldurur
        if ($this->db->field_exists('description', 'product')) $payload['description'] = $description;
        if ($this->db->field_exists('created_at', 'product'))  $payload['created_at'] = $now;
        if ($this->db->field_exists('updated_at', 'product'))  $payload['updated_at'] = $now;

        // Eğer zorunlu başka kolonların varsa (NOT NULL ve default yok) burada eklemen gerekir.
        // Örn: stock, category_id vb. varsa ve NOT NULL ise; DB default'u yoksa insert hata verir.

        $ok = $this->db->insert('product', $payload);
        if (!$ok) return 0;

        $productId = (int)$this->db->insert_id();
        if ($productId <= 0) return 0;

        // slug tek segment olsun (catch-all (:any) buna uygun)
        if ($this->db->field_exists('slug', 'product')) {
            $slugBase = url_title($name, '-', true);
            $slug = $productId . '-' . $slugBase; // örn: 123-metin2-ep
            $this->db->where('id', $productId)->update('product', ['slug' => $slug]);
        }

        return $productId;
    }
}
