<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_Wheel extends CI_Model {

    /**
     * Tüm çark öğelerini getir
     */
    public function get_all_items($active_only = false) {
        if ($active_only) {
            $this->db->where('is_active', 1);
        }
        return $this->db->order_by('sort_order', 'ASC')->get('wheel_items')->result();
    }
    
    /**
     * Tek bir çark öğesi getir
     */
    public function get_item($id) {
        return $this->db->where('id', $id)->get('wheel_items')->row();
    }
    
    /**
     * Çark öğesi ekle
     */
    public function insert_item($data) {
        return $this->db->insert('wheel_items', $data);
    }
    
    /**
     * Çark öğesi güncelle
     */
    public function update_item($id, $data) {
        return $this->db->where('id', $id)->update('wheel_items', $data);
    }
    
    /**
     * Çark öğesi sil
     */
    public function delete_item($id) {
        return $this->db->where('id', $id)->delete('wheel_items');
    }
    
    /**
     * Toplam olasılık hesapla
     */
    public function get_total_probability() {
        $this->db->select_sum('probability');
        $this->db->where('is_active', 1);
        $result = $this->db->get('wheel_items')->row();
        return $result->probability ?: 0;
    }
    
    /**
     * Kullanıcının son çevirme zamanını kontrol et
     */
    public function can_user_spin($user_id) {
        $last_spin = $this->db
            ->where('user_id', $user_id)
            ->order_by('spin_date', 'DESC')
            ->get('wheel_spins')
            ->row();
        
        if (!$last_spin) {
            return ['can_spin' => true, 'next_spin' => null];
        }
        
        $last_spin_time = strtotime($last_spin->spin_date);
        $next_spin_time = $last_spin_time + (24 * 60 * 60); // 24 saat
        $now = time();
        
        if ($now >= $next_spin_time) {
            return ['can_spin' => true, 'next_spin' => null];
        }
        
        return [
            'can_spin' => false, 
            'next_spin' => date('Y-m-d H:i:s', $next_spin_time),
            'remaining_seconds' => $next_spin_time - $now
        ];
    }
    
    /**
     * Ağırlıklı rastgele seçim
     */
    public function get_random_item() {
        $items = $this->get_all_items(true);
        
        if (empty($items)) {
            return null;
        }
        
        $total_weight = 0;
        foreach ($items as $item) {
            $total_weight += $item->probability;
        }
        
        $random = mt_rand(1, $total_weight);
        $current_weight = 0;
        
        foreach ($items as $item) {
            $current_weight += $item->probability;
            if ($random <= $current_weight) {
                return $item;
            }
        }
        
        return $items[0]; // Fallback
    }
    
    /**
     * Çevirme kaydı ekle
     */
    public function record_spin($user_id, $item, $ip_address = null) {
        $data = [
            'user_id' => $user_id,
            'wheel_item_id' => $item->id,
            'reward_type' => $item->type,
            'reward_value' => $item->value,
            'reward_label' => $item->label,
            'spin_date' => date('Y-m-d H:i:s'),
            'ip_address' => $ip_address
        ];
        
        return $this->db->insert('wheel_spins', $data);
    }
    
    /**
     * Son çevirmeleri getir
     */
    public function get_recent_spins($limit = 10, $user_id = null) {
        $this->db->select('wheel_spins.*, user.name, user.surname, user.shop_name');
        $this->db->join('user', 'user.id = wheel_spins.user_id', 'left');
        
        if ($user_id) {
            $this->db->where('wheel_spins.user_id', $user_id);
        }
        
        return $this->db
            ->order_by('wheel_spins.spin_date', 'DESC')
            ->limit($limit)
            ->get('wheel_spins')
            ->result();
    }
    
    /**
     * Kullanıcının toplam kazancını hesapla
     */
    public function get_user_total_winnings($user_id) {
        $this->db->select_sum('reward_value');
        $this->db->where('user_id', $user_id);
        $this->db->where('reward_type', 'balance');
        $result = $this->db->get('wheel_spins')->row();
        return $result->reward_value ?: 0;
    }
}
