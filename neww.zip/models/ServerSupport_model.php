<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ServerSupport_model extends CI_Model
{
    /**
     * Destek siparişi oluştur.
     * status: 1=aktif/ödendi
     */
    public function add_support(int $serverId, int $userId, int $days, float $amount, string $startAt, string $endAt): int
    {
        if (!$this->db->table_exists('server_support_orders')) {
            return 0;
        }

        $data = [
            'server_id'   => (int)$serverId,
            'user_id'     => (int)$userId,
            'days'        => (int)$days,
            'amount'      => (float)$amount,
            'start_at'    => $startAt,
            'end_at'      => $endAt,
            'status'      => 1,
            'created_at'  => date('Y-m-d H:i:s'),
        ];

        $this->db->insert('server_support_orders', $data);
        return (int)$this->db->insert_id();
    }

    /**
     * Sunucu destekleyenler (toplam gün bazında)
     * En çok destek (toplam gün) en üstte.
     */
    public function get_supporters($serverId, $limit = 12)
    {
        if (!$this->db->table_exists('server_support_orders')) {
            return [];
        }

        $now = date('Y-m-d H:i:s');

        return $this->db
            ->select('u.id, u.name, u.surname, u.shop_name, u.shop_slug, u.shop_img,
                      SUM(o.days) AS total_days, MAX(o.end_at) AS last_end_at', false)
            ->from('server_support_orders o')
            ->join('user u', 'u.id = o.user_id', 'left')
            ->where('o.server_id', (int)$serverId)
            ->where('o.status', 1)
            ->where('o.end_at >', $now)
            ->group_by('o.user_id')
            ->order_by('total_days', 'DESC')
            ->order_by('last_end_at', 'DESC')
            ->limit((int)$limit)
            ->get()->result();
    }

    public function count_active_supporters($serverId): int
    {
        if (!$this->db->table_exists('server_support_orders')) {
            return 0;
        }

        $now = date('Y-m-d H:i:s');

        $row = $this->db
            ->select('COUNT(DISTINCT user_id) AS c', false)
            ->from('server_support_orders')
            ->where('server_id', (int)$serverId)
            ->where('status', 1)
            ->where('end_at >', $now)
            ->get()->row();

        return (int)($row->c ?? 0);
    }
}
