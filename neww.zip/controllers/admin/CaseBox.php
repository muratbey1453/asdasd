<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CaseBox extends G_Controller
{

    public function __construct()
    {
        parent::__construct();
        if (!isset($this->session->userdata('info')['isAdmin']) || $this->session->userdata('info')['isAdmin'] != 1) {
            redirect(base_url(), 'refresh');
            exit();
        }
    }

    public function cases()
    {
        $cases = $this->db->get('cases')->result();
        //add cases to items, add items to product
        foreach ($cases as $case) {
            $case->items = $this->db->where('case_id', $case->id)->get('case_items')->result();
            foreach ($case->items as $item) {
                $item->product = $this->db->where('id', $item->product_id)->get('product')->row();
            }
        }
        $data = [
            'cases' => $cases,
            'status' => 'cases'
        ];


        $this->adminView('cases', $data);
    }

    public function caseEdit($id) {
        $case = $this->db->where('id', $id)->get('cases')->row();
        if (!$case) {
            redirect(base_url('admin/cases'), 'refresh');
            exit();
        }
        $case->items = $this->db->where('case_id', $case->id)->get('case_items')->result();
        foreach ($case->items as $item) {
            $item->product = $this->db->where('id', $item->product_id)->get('product')->row();
        }
        $data = [
            'case' => $case,
            'products' => $this->db->where("isActive", 1)->get('product')->result(),
            'status' => 'cases'
        ];
        $this->adminView('cases-detail', $data);
    }

    public function caseAdd() {
        $data = [
            'products' => $this->db->where("isActive", 1)->get('product')->result(),
            'status' => 'cases'
        ];
        $this->adminView('cases-add', $data);
    }
    
    public function caseDelete($id) {
        $this->db->where('id', $id)->update('cases', ['active' => 0]);
        redirect(base_url('admin/cases'), 'refresh');
        exit();
    }

    public function userCases() {
        $user_cases = $this->db->get('user_cases')->result();
        foreach ($user_cases as $user_case) {
            $user_case->user = $this->db->where('id', $user_case->user_id)->get('user')->row();
            $user_case->case = $this->db->where('id', $user_case->case_id)->get('cases')->row();
            $user_case->product = $this->db->where('id', $user_case->product_id)->get('product')->row();
            $user_case->stock = $this->db->where('id', $user_case->stock_id)->get('stock')->row();
        }

        $data = [
            'user_cases' => $user_cases,
            'status' => 'userCases'
        ];
        $this->adminView('case-user-list', $data);
    }


}