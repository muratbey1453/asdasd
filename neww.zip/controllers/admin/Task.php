<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Task extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        if (!isset($this->session->userdata('info')['isAdmin']) || $this->session->userdata('info')['isAdmin'] != 1) {
            redirect(base_url(), 'refresh');
            exit();
        }
        $this->load->model('M_Task');
        $this->load->model('M_Balance');
    }
    public function index() {
        $data['tasks'] = $this->M_Task->get_tasks();
        $this->load->view('admin/includes/header');
        $this->load->view('admin/includes/sidebar');
        $this->load->view('admin/task/index', $data);
        $this->load->view('admin/includes/footer');
    }

    public function approve_task($id) {
        $this->M_Task->update_task_status($id, 1); // Active
        $this->session->set_flashdata('message', 'Görev onaylandı.');
        redirect(base_url('admin/task'));
    }

    public function reject_task($id) {
        // Refund logic
        $task = $this->M_Task->get_task($id);
        if ($task && $task->status != 3) {
            $user = $this->db->where('id', $task->user_id)->get('user')->row();
            $refund_amount = ($task->total_limit - $task->current_count) * $task->reward_amount;
            
            if ($refund_amount > 0) {
                $this->db->trans_start();
                $new_balance = $user->balance + $refund_amount;
                $this->db->where('id', $task->user_id)->update('user', ['balance' => $new_balance]);
                
                $transaction = [
                    'user_id' => $task->user_id,
                    'transaction_type' => 'task_refund',
                    'amount' => $refund_amount,
                    'description' => 'Görev iptal iadesi: ' . $task->title,
                    'status' => 1,
                    'created_at' => date('Y-m-d H:i:s'),
                    'balance_before' => $user->balance,
                    'balance_after_transaction' => $new_balance,
                    'related_id' => $id
                ];
                $this->db->insert('wallet_transactions', $transaction);
                $this->db->trans_complete();
            }
            
            $this->M_Task->update_task_status($id, 3); // Rejected/Cancelled
            $this->session->set_flashdata('message', 'Görev reddedildi/iptal edildi ve ücret iade edildi.');
        }
        redirect(base_url('admin/task'));
    }

    public function proofs($task_id = null) {
        $data['proofs'] = $this->M_Task->get_proofs($task_id);
        $this->load->view('admin/includes/header');
        $this->load->view('admin/includes/sidebar');
        $this->load->view('admin/task/proofs', $data);
        $this->load->view('admin/includes/footer');
    }

    public function approve_proof($id) {
        $proof = $this->M_Task->get_proof($id);
        if ($proof && $proof->status == 0) {
            $task = $this->M_Task->get_task($proof->task_id);
            
            $this->db->trans_start();
            
            // Update proof status
            $this->M_Task->update_proof_status($id, 1); // Approved
            
            // Add balance to worker
            $worker = $this->db->where('id', $proof->user_id)->get('user')->row();
            $new_balance = $worker->balance + $task->reward_amount;
            $this->db->where('id', $proof->user_id)->update('user', ['balance' => $new_balance]);
            
            // Log transaction
            $transaction = [
                'user_id' => $proof->user_id,
                'transaction_type' => 'task_earning',
                'amount' => $task->reward_amount,
                'description' => 'Görev kazancı: ' . $task->title,
                'status' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'balance_before' => $worker->balance,
                'balance_after_transaction' => $new_balance,
                'related_id' => $proof->task_id
            ];
            $this->db->insert('wallet_transactions', $transaction);
            
            // Increment task count
            $this->M_Task->increment_task_count($proof->task_id);
            
            // Check if task completed
            if ($task->current_count + 1 >= $task->total_limit) {
                $this->M_Task->update_task_status($proof->task_id, 4); // Completed
            }
            
            $this->db->trans_complete();
            
            $this->session->set_flashdata('message', 'Kanıt onaylandı ve ücret gönderildi.');
        }
        redirect(base_url('admin/task/proofs'));
    }

    public function reject_proof($id) {
        $reason = $this->input->post('reason');
        $this->M_Task->update_proof_status($id, 2, $reason); // Rejected
        $this->session->set_flashdata('message', 'Kanıt reddedildi.');
        redirect(base_url('admin/task/proofs'));
    }
}
