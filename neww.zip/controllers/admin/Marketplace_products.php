<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Marketplace_products extends G_Controller {

    public function __construct() {
        parent::__construct();
        
        if (!isset($this->session->userdata('info')['isAdmin']) || $this->session->userdata('info')['isAdmin'] != 1) {
            redirect(base_url(), 'refresh');
            exit();
        }
        $this->load->helper('form');
    }
    
    public function index() {
        $data['title'] = 'İlan Pazarı İlanları';
        $this->db->select('product.*, user.shop_name as seller_name, category.name as category_name, servers.title as server_title, servers.game as server_game');
        $this->db->from('product');
        $this->db->join('user', 'user.id = product.seller_id');
        $this->db->join('category', 'category.id = product.category_id', 'left');
        $this->db->join('servers', 'servers.id = product.server_id', 'left');
        $this->db->where('product.seller_id >', 0);
        $this->db->order_by('product.id', 'DESC');
        $data['products'] = $this->db->get()->result();
        $data['status'] = 'store';
        
        $this->adminView('marketplace_products/list', $data);
    }
    
    public function edit_product($id) {
        $product = $this->db->where('id', $id)->where('seller_id >', 0)->get('product')->row();
        
        if (!$product) {
            $this->session->set_flashdata('error', 'Ürün bulunamadı.');
            redirect('admin/marketplace_products');
        }
        
        if ($this->input->post()) {
            $data = [
                'name' => $this->input->post('name'),
                'price' => $this->input->post('price'),
                'isActive' => $this->input->post('isActive')
            ];

            // Sunucu ürünü ise kategori yerine sunucu kullan
            $isServerProduct = isset($product->server_id) && (int)$product->server_id > 0;
            if ($isServerProduct) {
                $serverId = (int)$this->input->post('server_id');
                if ($serverId > 0) {
                    $ok = $this->db->where('id', $serverId)->where('status', 1)->count_all_results('servers');
                    if (!$ok) {
                        $this->session->set_flashdata('error', 'Geçersiz sunucu.');
                        redirect('admin/marketplace_products/edit_product/' . $id);
                        return;
                    }
                    $data['server_id'] = $serverId;
                } else {
                    $data['server_id'] = (int)$product->server_id;
                }

                // kategori boş/0 kalsın
                $data['category_id'] = 0;
            } else {
                $data['category_id'] = (int)$this->input->post('category_id');
            }
            
            // Image upload logic if needed, but usually admin just edits details or deletes
            if (!empty($_FILES['image']['name'])) {
                $config['upload_path'] = './assets/img/product/';
                $config['allowed_types'] = 'gif|jpg|png|jpeg|webp';
                $config['encrypt_name'] = TRUE;
                
                if (!is_dir($config['upload_path'])) {
                    mkdir($config['upload_path'], 0777, true);
                }

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('image')) {
                    $upload_data = $this->upload->data();
                    $data['img'] = $upload_data['file_name'];
                } else {
                    $this->session->set_flashdata('error', $this->upload->display_errors());
                    redirect('admin/marketplace_products/edit_product/' . $id);
                }
            }
            
            $this->db->where('id', $id)->update('product', $data);
            $this->session->set_flashdata('success', 'Ürün başarıyla güncellendi.');
            redirect('admin/marketplace_products');
        }
        
        $data['title'] = 'Ürün Düzenle';
        $data['product'] = $product;
        $data['categories'] = $this->db->where('isActive', 1)->get('category')->result();
        $data['approvedServers'] = $this->db->select('id,title,game')->where('status', 1)->order_by('created_at', 'DESC')->get('servers')->result();
        $data['status'] = 'store';
        $this->adminView('marketplace_products/edit', $data);
    }
    
    public function delete_product($id) {
        $this->db->where('id', $id)->where('seller_id >', 0)->delete('product');
        $this->session->set_flashdata('success', 'Ürün başarıyla silindi.');
        redirect('admin/marketplace_products');
    }
}
