<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Wheel extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('M_Wheel');
        
        // Admin kontrolü (diğer admin controller'larla tutarlı)
        if (!isset($this->session->userdata('info')['isAdmin']) || $this->session->userdata('info')['isAdmin'] != 1) {
            redirect(base_url('admin'));
        }
    }
    
    /**
     * Çark öğeleri listesi
     */
    public function index() {
        $data = [
            'title' => 'Çark Yönetimi',
            'status' => 'wheel',
            'items' => $this->M_Wheel->get_all_items(),
            'total_probability' => $this->M_Wheel->get_total_probability(),
            'recent_spins' => $this->M_Wheel->get_recent_spins(20)
        ];
        
        $this->load->view('admin/includes/header', $data);
        $this->load->view('admin/includes/sidebar', $data);
        $this->load->view('admin/wheel/index', $data);
        $this->load->view('admin/includes/footer');
    }
    
    /**
     * Yeni çark öğesi ekle
     */
    public function add() {
        if ($this->input->post()) {
            $data = [
                'label' => $this->input->post('label'),
                'type' => $this->input->post('type'),
                'value' => floatval($this->input->post('value')),
                'probability' => intval($this->input->post('probability')),
                'color' => $this->input->post('color'),
                'icon' => $this->input->post('icon') ?: 'ri-gift-line',
                'is_active' => $this->input->post('is_active') ? 1 : 0,
                'sort_order' => intval($this->input->post('sort_order'))
            ];
            
            $this->M_Wheel->insert_item($data);
            $this->session->set_flashdata('message', 'Çark öğesi başarıyla eklendi.');
            redirect(base_url('admin/wheel'));
        }
        
        $data = [
            'title' => 'Çark Öğesi Ekle',
            'status' => 'wheelAdd'
        ];
        
        $this->load->view('admin/includes/header', $data);
        $this->load->view('admin/includes/sidebar', $data);
        $this->load->view('admin/wheel/add', $data);
        $this->load->view('admin/includes/footer');
    }
    
    /**
     * Çark öğesi düzenle
     */
    public function edit($id) {
        $item = $this->M_Wheel->get_item($id);
        
        if (!$item) {
            $this->session->set_flashdata('message', 'Öğe bulunamadı.');
            redirect(base_url('admin/wheel'));
        }
        
        if ($this->input->post()) {
            $data = [
                'label' => $this->input->post('label'),
                'type' => $this->input->post('type'),
                'value' => floatval($this->input->post('value')),
                'probability' => intval($this->input->post('probability')),
                'color' => $this->input->post('color'),
                'icon' => $this->input->post('icon') ?: 'ri-gift-line',
                'is_active' => $this->input->post('is_active') ? 1 : 0,
                'sort_order' => intval($this->input->post('sort_order'))
            ];
            
            $this->M_Wheel->update_item($id, $data);
            $this->session->set_flashdata('message', 'Çark öğesi güncellendi.');
            redirect(base_url('admin/wheel'));
        }
        
        $data = [
            'title' => 'Çark Öğesi Düzenle',
            'status' => 'wheel',
            'item' => $item
        ];
        
        $this->load->view('admin/includes/header', $data);
        $this->load->view('admin/includes/sidebar', $data);
        $this->load->view('admin/wheel/edit', $data);
        $this->load->view('admin/includes/footer');
    }
    
    /**
     * Çark öğesi sil
     */
    public function delete($id) {
        $this->M_Wheel->delete_item($id);
        $this->session->set_flashdata('message', 'Çark öğesi silindi.');
        redirect(base_url('admin/wheel'));
    }
    
    /**
     * Öğe durumunu değiştir (AJAX)
     */
    public function toggle_status($id) {
        $item = $this->M_Wheel->get_item($id);
        if ($item) {
            $new_status = $item->is_active ? 0 : 1;
            $this->M_Wheel->update_item($id, ['is_active' => $new_status]);
            echo json_encode(['success' => true, 'status' => $new_status]);
        } else {
            echo json_encode(['success' => false]);
        }
    }
}
