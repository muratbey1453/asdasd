<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends G_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('M_Settings');
        
        // CSRF koruması otomatik olarak etkin
        // CodeIgniter 3'te Security sınıfı otomatik olarak yüklenir
        
        // Oturum kontrolü
        if (!isset($this->session->userdata('info')['isAdmin']) || $this->session->userdata('info')['isAdmin'] != 1) {
            redirect(base_url(), 'refresh');
            exit();
        }
    }
    
    public function index() {
        redirect('admin/settings/balance');
    }
    
    public function balance() {
        $data['title'] = 'Bakiye Ayarları';
        $data['status'] = 'settings';
        $data['settings'] = $this->M_Settings->getAllSettings();
        
        // Views klasörü altındaki settings klasöründeki balance.php dosyasını göster
        $this->adminView('settings/balance', $data);
    }
    
    public function update_setting() {
        // CSRF kontrolü ve AJAX istek kontrolü
        if (!$this->input->is_ajax_request()) {
            show_error('Bu sayfaya doğrudan erişim yok!', 403);
            return;
        }
        
        $setting_key = $this->input->post('setting_key');
        $setting_value = $this->input->post('setting_value');
        
        $result = $this->M_Settings->updateSetting($setting_key, $setting_value);
        
        if ($result) {
            echo json_encode(['status' => 'success', 'message' => 'Ayar başarıyla güncellendi']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Ayar güncellenirken bir hata oluştu']);
        }
    }
    
    public function update_settings() {
        $settings = $this->input->post('settings');
        $success = true;
        
        // Tüm checkbox ayarları için kontrol
        $checkbox_settings = [
            'enable_balance_transfer',
            'enable_balance_exchange',
            'enable_credit_operations'
        ];
        
        // Checkbox'lar işaretlenmediğinde POST verisi gelmeyeceği için bunları 0 olarak işleyelim
        foreach ($checkbox_settings as $key) {
            if (!isset($settings[$key])) {
                $settings[$key] = '0';
            }
        }
        
        foreach ($settings as $key => $value) {
            $result = $this->M_Settings->updateSetting($key, $value);
            if (!$result) {
                $success = false;
            }
        }
        
        if ($success) {
            $this->session->set_flashdata('success', 'Bakiye ayarları başarıyla güncellendi.');
        } else {
            $this->session->set_flashdata('error', 'Bakiye ayarları güncellenirken bir hata oluştu.');
        }
        
        redirect('admin/settings/balance', 'refresh');
    }
} 