<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home_featured extends G_Controller {

    public function __construct() {
        parent::__construct();
        
        if (!isset($this->session->userdata('info')['isAdmin']) || $this->session->userdata('info')['isAdmin'] != 1) {
            redirect(base_url(), 'refresh');
            exit();
        }
        $this->load->helper('form');
    }
    
    public function index() {
        $data['title'] = 'Ana Sayfa Öne Çıkan Kartlar';
        $data['cards'] = $this->db->order_by('sort_order', 'ASC')->get('home_featured_cards')->result();
        $this->adminView('home_featured/list', $data);
    }
    
    public function add() {
        $count = $this->db->count_all('home_featured_cards');
        if ($count >= 4) {
            $this->session->set_flashdata('error', 'En fazla 4 adet kart ekleyebilirsiniz.');
            redirect('admin/home_featured');
        }

        if ($this->input->post()) {
            $config['upload_path'] = './assets/img/home_featured/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg|webp';
            $config['encrypt_name'] = TRUE;
            
            if (!is_dir($config['upload_path'])) {
                mkdir($config['upload_path'], 0777, true);
            }

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('image')) {
                $upload_data = $this->upload->data();
                $image_name = $upload_data['file_name'];
                
                $data = [
                    'title' => $this->input->post('title'),
                    'link' => $this->input->post('link'),
                    'sort_order' => $this->input->post('sort_order'),
                    'image' => $image_name
                ];
                
                $this->db->insert('home_featured_cards', $data);
                $this->session->set_flashdata('success', 'Kart başarıyla eklendi.');
                redirect('admin/home_featured');
            } else {
                $this->session->set_flashdata('error', $this->upload->display_errors());
            }
        }
        
        $data['title'] = 'Yeni Kart Ekle';
        $this->adminView('home_featured/form', $data);
    }
    
    public function edit_card($id) {
        $card = $this->db->where('id', $id)->get('home_featured_cards')->row();
        
        if (!$card) {
            redirect('admin/home_featured');
        }
        
        if ($this->input->post()) {
            $data = [
                'title' => $this->input->post('title'),
                'link' => $this->input->post('link'),
                'sort_order' => $this->input->post('sort_order')
            ];
            
            if (!empty($_FILES['image']['name'])) {
                $config['upload_path'] = './assets/img/home_featured/';
                $config['allowed_types'] = 'gif|jpg|png|jpeg|webp';
                $config['encrypt_name'] = TRUE;
                
                if (!is_dir($config['upload_path'])) {
                    mkdir($config['upload_path'], 0777, true);
                }

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('image')) {
                    $upload_data = $this->upload->data();
                    $data['image'] = $upload_data['file_name'];
                } else {
                    $this->session->set_flashdata('error', $this->upload->display_errors());
                    redirect('admin/home_featured/edit_card/' . $id);
                }
            }
            
            $this->db->where('id', $id)->update('home_featured_cards', $data);
            $this->session->set_flashdata('success', 'Kart başarıyla güncellendi.');
            redirect('admin/home_featured');
        }
        
        $data['title'] = 'Kart Düzenle';
        $data['card'] = $card;
        $this->adminView('home_featured/form', $data);
    }
    
    public function delete_card($id) {
        $this->db->where('id', $id)->delete('home_featured_cards');
        $this->session->set_flashdata('success', 'Kart başarıyla silindi.');
        redirect('admin/home_featured');
    }
}
