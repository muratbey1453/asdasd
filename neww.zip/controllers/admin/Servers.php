<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Admin: Sunucular
 *
 * DB status (int): 0=pending, 1=approved, 2=rejected
 */
class Servers extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        // Admin kontrol
        $info = $this->session->userdata('info');
        if (empty($info) || (int)($info['isAdmin'] ?? 0) !== 1) {
            redirect(base_url('hesap'), 'refresh');
            exit;
        }

        $this->load->model('Server_model');
    }

    public function index()
{
    $pending = $this->db
        ->select('s.*, u.name, u.surname, u.email, u.shop_name')
        ->from('servers s')
        ->join('user u', 'u.id = s.user_id', 'left')
        ->where('s.status', Server_model::STATUS_PENDING)
        ->order_by('s.created_at', 'DESC')
        ->get()->result();

    $approved = $this->db
        ->select('s.*, u.name, u.surname, u.email, u.shop_name')
        ->from('servers s')
        ->join('user u', 'u.id = s.user_id', 'left')
        ->where('s.status', Server_model::STATUS_APPROVED)
        ->order_by('s.approved_at', 'DESC')
        ->get()->result();

    $data = [
        'title'    => 'Sunucular',
        'pending'  => $pending,
        'approved' => $approved,
        'games'    => $this->Server_model->game_options(),
    ];

    // Admin tema include’ları (senin projedeki path’e göre düzenle)
    $this->load->view('admin/includes/header', $data);
    $this->load->view('admin/includes/sidebar', $data);

    // Sayfanın içeriği
    $this->load->view('admin/servers/list', $data);

    $this->load->view('admin/includes/footer', $data);
}

    public function approve($id)
    {
        $id = (int)$id;
        $info = $this->session->userdata('info');
        $adminId = (int)($info['id'] ?? 0);

        $this->db->where('id', $id)->update('servers', [
            'status'      => Server_model::STATUS_APPROVED,
            'approved_at' => date('Y-m-d H:i:s'),
            'approved_by' => $adminId,
            'updated_at'  => date('Y-m-d H:i:s'),
        ]);

        $this->session->set_flashdata('adminMsg', 'Sunucu onaylandı.');
        redirect(base_url('admin/servers'), 'refresh');
    }

    public function reject($id)
    {
        $id = (int)$id;

        $this->db->where('id', $id)->update('servers', [
            'status'     => Server_model::STATUS_REJECTED,
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        $this->session->set_flashdata('adminMsg', 'Sunucu reddedildi.');
        redirect(base_url('admin/servers'), 'refresh');
    }
}
