<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Wheel extends G_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('M_Wheel');
    }
    
    /**
     * Çark sayfası
     */
    public function index() {
        addlog('Wheel', 'Sayfa ziyaret edildi: Şans Çarkı');
        
        // Kullanıcı giriş kontrolü
        $user_id = $this->session->userdata('info')['id'] ?? null;
        $can_spin_data = ['can_spin' => false, 'next_spin' => null];
        
        if ($user_id) {
            $can_spin_data = $this->M_Wheel->can_user_spin($user_id);
        }
        
        $data = [
            'properties' => $this->db->where('id', 1)->get('properties')->row(),
            'category' => $this->db->where('isActive', 1)->where('mother_category_id', 0)->where('isMenu', 1)->get('category')->result(),
            'wheel_items' => $this->M_Wheel->get_all_items(true),
            'can_spin' => $can_spin_data['can_spin'],
            'next_spin' => $can_spin_data['next_spin'] ?? null,
            'remaining_seconds' => $can_spin_data['remaining_seconds'] ?? 0,
            'recent_winners' => $this->M_Wheel->get_recent_spins(10),
            'pages' => $this->db->get('pages')->result(),
            'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct' => $this->db->limit(3)->where('isActive', 1)->order_by('id', 'DESC')->get('product')->result(),
            'title' => 'Şans Çarkı'
        ];
        
        $this->view('wheel', $data);
    }
    
    /**
     * Çark çevirme (AJAX)
     */
    public function spin() {
        header('Content-Type: application/json');
        
        // Giriş kontrolü
        $user_id = $this->session->userdata('info')['id'] ?? null;
        
        if (!$user_id) {
            echo json_encode([
                'success' => false,
                'message' => 'Çark çevirmek için giriş yapmalısınız.'
            ]);
            return;
        }
        
        // 24 saat kontrolü
        $can_spin_data = $this->M_Wheel->can_user_spin($user_id);
        
        if (!$can_spin_data['can_spin']) {
            echo json_encode([
                'success' => false,
                'message' => 'Çarkı tekrar çevirebilmek için 24 saat beklemelisiniz.',
                'next_spin' => $can_spin_data['next_spin'],
                'remaining_seconds' => $can_spin_data['remaining_seconds']
            ]);
            return;
        }
        
        // Rastgele dilim seç
        $item = $this->M_Wheel->get_random_item();
        
        if (!$item) {
            echo json_encode([
                'success' => false,
                'message' => 'Çarkta aktif dilim bulunamadı.'
            ]);
            return;
        }
        
        // Çevirmeyi kaydet
        $this->M_Wheel->record_spin($user_id, $item, $this->input->ip_address());
        
        // Bakiye ekleme (eğer bakiye kazandıysa)
        if ($item->type == 'balance' && $item->value > 0) {
            $user = $this->db->where('id', $user_id)->get('user')->row();
            $new_balance = $user->balance + $item->value;
            $this->db->where('id', $user_id)->update('user', ['balance' => $new_balance]);
            
            // Wallet transaction log
            $this->db->insert('wallet_transactions', [
                'user_id' => $user_id,
                'transaction_type' => 'wheel_win',
                'amount' => $item->value,
                'description' => 'Şans Çarkı Kazancı: ' . $item->label,
                'status' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'balance_before' => $user->balance,
                'balance_after_transaction' => $new_balance
            ]);
        }
        
        // Tüm öğeleri getir (index hesaplaması için)
        $all_items = $this->M_Wheel->get_all_items(true);
        $winning_index = 0;
        foreach ($all_items as $index => $wheel_item) {
            if ($wheel_item->id == $item->id) {
                $winning_index = $index;
                break;
            }
        }
        
        echo json_encode([
            'success' => true,
            'item' => $item,
            'winning_index' => $winning_index,
            'total_items' => count($all_items),
            'message' => $item->type == 'nothing' ? 'Maalesef bu sefer şansınız yaver gitmedi!' : 'Tebrikler! ' . $item->label . ' kazandınız!'
        ]);
    }
    
    /**
     * Mini widget için durum kontrolü (AJAX)
     */
    public function check_status() {
        header('Content-Type: application/json');
        
        $user_id = $this->session->userdata('info')['id'] ?? null;
        
        if (!$user_id) {
            echo json_encode(['logged_in' => false, 'can_spin' => false]);
            return;
        }
        
        $can_spin_data = $this->M_Wheel->can_user_spin($user_id);
        
        echo json_encode([
            'logged_in' => true,
            'can_spin' => $can_spin_data['can_spin'],
            'remaining_seconds' => $can_spin_data['remaining_seconds'] ?? 0
        ]);
    }
}
