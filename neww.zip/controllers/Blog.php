<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blog extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
    }

    public function detail($slug = null)
    {
        if (empty($slug)) {
            redirect(base_url('makale-listesi'), 'refresh');
        }

        addlog('blog_detail', 'Sayfa ziyaret edildi: Makale Detay - ' . $slug);
        
        $blog = $this->db->where('slug', $slug)->get('blog')->row();
        
        if (!$blog) {
            redirect(base_url('makale-listesi'), 'refresh');
        }

        $properties = $this->db->where('id', 1)->get('properties')->row();
        
        $data = [
            'properties' => $properties,
            'blog' => $blog,
            'title' => $blog->title . ' - ' . $properties->name,
            'pages' => $this->db->get('pages')->result(),
            'category' => getActiveCategories(),
            'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct' => $this->db->limit(6)->where('isActive', 1)->order_by('id', 'DESC')->get('product')->result(),
            'relatedBlogs' => $this->db->where('id !=', $blog->id)->limit(3)->order_by('id', 'DESC')->get('blog')->result()
        ];

        $this->view('blog-detail', $data);
    }

    private function view($page, $data)
    {
        $this->load->view('theme/future/includes/head', $data);
        $this->load->view('theme/future/includes/header', $data);
        $this->load->view('theme/future/' . $page, $data);
        $this->load->view('theme/future/includes/footer', $data);
    }
}
