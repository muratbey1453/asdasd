<?php
require 'application/libraries/Shopier.php';
defined('BASEPATH') OR exit('No direct script access allowed');


class Payment extends G_Controller {
	public function index()
	{
		addlog('Ödeme sayfası - index', 'Sayfa ziyaret edildi: Bakiye yükleme adım 1 - Sayfa ziyareti');

		if (!isset($this->session->userdata('info')['id'])) {
        	flash('Ups.', 'Yetkin Olmayan Bir Yere Giriş Yapmaya Çalışıyorsun.');
            redirect(base_url(), 'refresh');
            exit;
        }

		$amount = $this->input->post('amount');

		if ($amount == 0) {
			flash('Ups.', '0 Lira yükleyemezsin.');
            redirect(base_url(), 'refresh');
            exit;
		}

			if(isset($amount))
			{
				addlog('Ödeme sayfası - index', 'Bakiye yükleme adım 2 - Miktar seçimi. Miktar:' . $amount);
				$this->load->model('M_Payment');
				$user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row();
		    	$properties = $this->db->where('id', 1)->get('properties')->row();
		    	$payment = $this->db->where('status', 1)->get('payment')->row();
				$coupon = $this->advanced_cart->has_cart_extra("coupon_id") ? $this->advanced_cart->get_cart_extra("coupon_id") : null;
				$encode = json_encode($this->advanced_cart->contents(), JSON_UNESCAPED_UNICODE);
                $this->advanced_cart->destroy();

                $paymentCommission = number_format(($amount * getCommission($user->id)) / 100, 2, '.', '');
                $totalAmount = $amount + $paymentCommission;
				$order_id = $this->M_Payment->addShop($user->id, $encode, $amount, 'deposit', $paymentCommission, $coupon);
		    	if ($payment->id == 1) {
		    		$this->paytr($user->id, $totalAmount, 0, $order_id);
		    	}else if ($payment->id == 3) {
		    		$this->shopier($user->id, $totalAmount, 0, $order_id);
		    	}else if ($payment->id == 4) {
		    		$this->payhesap($user->id, $totalAmount, 0, $order_id);
		    	}
			}else{
				addlog('Ödeme sayfası - index', 'Sayfa hatası. Hata: Yüklenecek bakiye miktarı seçilmedi.');
				flash('Ups.', 'Yüklenecek Miktarı Seçin.');
				redirect(base_url('client'), 'refresh');
				exit;
			}
	}
	
	public function buyOnCart()
	{
		addlog('Ödeme sayfası - index', 'Sayfa ziyaret edildi: Kart ileç ödeme. Adım 1 - Sayfa ziyareti. Sepet içeriği: '. json_encode($this->advanced_cart->contents(), JSON_UNESCAPED_UNICODE));
		$properties = $this->db->where('id', 1)->get('properties')->row();
		$this->load->model('M_Payment');
		$coupon = $this->advanced_cart->has_cart_extra("coupon_id") ? $this->advanced_cart->get_cart_extra("coupon_id") : null;
		$encode = json_encode($this->advanced_cart->contents(), JSON_UNESCAPED_UNICODE);
		$user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row();
		$cart = $this->advanced_cart->contents();
		$price = $this->M_Payment->calculate($encode);

		if ($price == 0) {
			flash('Ups.', '0 Lira ödeyemezsin.');
            redirect(base_url(), 'refresh');
            exit;
		}

		$priceWithCommission = $price + number_format(($price * getCommission($user->id)) / 100, 2, '.', '');
		$order_id = $this->M_Payment->addShop($user->id, $encode, $price, 'credit_card', $price, $coupon);
		$shop = $this->db->where('order_id', $order_id)->get('shop')->row();
		$properties = $this->db->where('id', 1)->get('properties')->row();
		$payment = $this->db->where('status', 1)->get('payment')->row();
		if ($payment->id == 1) {
			$this->paytr($user->id, $priceWithCommission, 1, $order_id);
		}else if ($payment->id == 3) {
			$this->shopier($user->id, $priceWithCommission, 1, $order_id);
		}else if ($payment->id == 4) {
			$this->payhesap($user->id, $priceWithCommission, 1, $order_id);
		}
	}

	public function callback()
    {
    	$payment = $this->db->where('status', 1)->get('payment')->row();
    	if ($payment->id == 1) {
    		$shop = $this->db->where('order_id', $_POST['merchant_oid'])->get('shop')->row();
            $this->paytrCallback();
    	}else if ($payment->id == 3) {
    		$shop = $this->db->where('order_id', $_POST['platform_order_id'])->get('shop')->row();
            $this->shopierCallback();
    	}else if ($payment->id == 4) {
    		$shop = $this->db->where('order_id', $_POST['ORDER_REF_NUMBER'])->get('shop')->row();
            $this->payhesapCallback();
    	}
    }
	
    private function shopier($user_id, $price, $type, $order_id)
    {		
    		$properties = $this->db->where('id', 1)->get('properties')->row();
    		$user = $this->db->where('id', $user_id)->get('user')->row();
    		$this->load->model('M_Payment');
    		$shop = $this->db->where('id', '3')->get('payment')->row();
    		$shopier = new Shopier($shop->api_key, $shop->secret_key);
			$shopier->setBuyer([
				'id' => $user->id,
				'first_name' => $user->name,
				'last_name' => $user->surname,
				'email' => $user->email,
				'phone' => $user->phone,
				'price' => $price
			]);
			$shopier->setOrderBilling([
				'billing_address' => 'N/A - Dijital Ürün',
				'billing_city' => 'Istanbul',
				'billing_country' => 'Turkey',
				'billing_postcode' => '34000',
			]);
			$shopier->setOrderShipping([
				'shipping_address' => 'N/A - Dijital Ürün',
				'shipping_city' => 'Istanbul',
				'shipping_country' => 'Turkey',
				'shipping_postcode' => '34000',
			]);
			$shop = $this->db->where('order_id', $order_id)->get('shop')->row();
			/*if($shop->type == 0){
				$price = $price + number_format(($price * $properties->commission) / 100, 2, '.', '');
			}*/

			die($shopier->run($order_id, $price, base_url('payment/callback')));
    }
    private function shopierCallback()
    {
    	if ($_POST) {
            $this->load->model('M_Payment');
            $shop = $this->db->where('order_id', $_POST['platform_order_id'])->get('shop')->row();
	    	$payment = $this->db->where('id', 3)->get('payment')->row();
				$shopiers = new Shopier($payment->api_key, $payment->secret_key);
				if($shopiers->verifyShopierSignature($_POST)) {
					if(isset($shop->id) && $shop->status != 0) {
                        if($shop->type == 'deposit') {
                            $this->M_Payment->confirmShopForBalance($shop->id);
                        }else{
                            $this->M_Payment->confirmShopForCart($shop->id);
                        }
						flash('Harika!', 'Bakiye Yüklemesi Tamamlandı.');
						redirect(base_url(), 'refresh');
						exit;
					}else {
						flash('Ups!', 'Bir sorun oluştu.');
						redirect(base_url(), 'refresh');
						exit;
					}
				}else {
						flash('Ups!', 'Bir sorun oluştu.');
						redirect(base_url(), 'refresh');
						exit;
				}
    	}else{
    		echo "Eksik Bilgiler Mevcut";
			exit;
    	}
    }
    private function paytr(int $user_id, $amount, $type, $order_id)
    {
            $properties = $this->db->where('id', 1)->get('properties')->row();
    		$this->load->model('M_Payment');
    		$user = $this->db->where('id', $user_id)->get('user')->row();
    		$payment = $this->db->where('id', '1')->get('payment')->row();
            $this->advanced_cart->destroy();
	        $shop = $this->db->where('order_id', $order_id)->get('shop')->row();
	        ## 1. ADIM için örnek kodlar ##
			####################### DÜZENLEMESİ ZORUNLU ALANLAR #######################
			#
			## API Entegrasyon Bilgileri - Mağaza paneline giriş yaparak BİLGİ sayfasından alabilirsiniz.
			$merchant_id 	= $payment->api_key;
			$merchant_key 	= $payment->secret_key;
			$merchant_salt	= $payment->token;
			#
			## Müşterinizin sitenizde kayıtlı veya form vasıtasıyla aldığınız eposta adresi
			$email = $user->email;
			#
			## Tahsil edilecek tutar.
			/*if($shop->type == 0){
				$amount = $amount + number_format(($amount * $properties->commission) / 100, 2, '.', '');
			}*/

			$payment_amount	= $amount * 100; //9.99 için 9.99 * 100 = 999 gönderilmelidir.
			#
			## Sipariş numarası: Her işlemde benzersiz olmalıdır!! Bu bilgi bildirim sayfanıza yapılacak bildirimde geri gönderilir.
			$merchant_oid = $order_id;
			#
			## Müşterinizin sitenizde kayıtlı veya form aracılığıyla aldığınız ad ve soyad bilgisi
			$user_name = $user->name . " " . $user->surname;
			#
			## Müşterinizin sitenizde kayıtlı veya form aracılığıyla aldığınız adres bilgisi
			$user_address = "Istanbul";
			#
			## Müşterinizin sitenizde kayıtlı veya form aracılığıyla aldığınız telefon bilgisi
			$user_phone = $user->phone;
			#
			## Başarılı ödeme sonrası müşterinizin yönlendirileceği sayfa
			## !!! Bu sayfa siparişi onaylayacağınız sayfa değildir! Yalnızca müşterinizi bilgilendireceğiniz sayfadır!
			## !!! Siparişi onaylayacağız sayfa "Bildirim URL" sayfasıdır (Bakınız: 2.ADIM Klasörü).
			$merchant_ok_url = base_url('client/success');
			#
			## Ödeme sürecinde beklenmedik bir hata oluşması durumunda müşterinizin yönlendirileceği sayfa
			## !!! Bu sayfa siparişi iptal edeceğiniz sayfa değildir! Yalnızca müşterinizi bilgilendireceğiniz sayfadır!
			## !!! Siparişi iptal edeceğiniz sayfa "Bildirim URL" sayfasıdır (Bakınız: 2.ADIM Klasörü).
			$merchant_fail_url = base_url('client/fail');
			#
			## Müşterinin sepet/sipariş içeriği
			$user_basket = base64_encode(json_encode(array(
				array("Dijital Ürün", $amount, 1) // 1. ürün (Ürün Ad - Birim Fiyat - Adet )
			)));
			#
			/* ÖRNEK $user_basket oluşturma - Ürün adedine göre array'leri çoğaltabilirsiniz
			$user_basket = base64_encode(json_encode(array(
				array("Örnek ürün 1", "18.00", 1), // 1. ürün (Ürün Ad - Birim Fiyat - Adet )
				array("Örnek ürün 2", "33.25", 2), // 2. ürün (Ürün Ad - Birim Fiyat - Adet )
				array("Örnek ürün 3", "45.42", 1)  // 3. ürün (Ürün Ad - Birim Fiyat - Adet )
			)));
			*/
			############################################################################################
			## Kullanıcının IP adresi
			if( isset( $_SERVER["HTTP_CLIENT_IP"] ) ) {
				$ip = $_SERVER["HTTP_CLIENT_IP"];
			} elseif( isset( $_SERVER["HTTP_X_FORWARDED_FOR"] ) ) {
				$ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
			} else {
				$ip = $_SERVER["REMOTE_ADDR"];
			}
			## !!! Eğer bu örnek kodu sunucuda değil local makinanızda çalıştırıyorsanız
			## buraya dış ip adresinizi (https://www.whatismyip.com/) yazmalısınız. Aksi halde geçersiz paytr_token hatası alırsınız.
			$user_ip=$ip;
			##
			## İşlem zaman aşımı süresi - dakika cinsinden
			$timeout_limit = "30";
			## Hata mesajlarının ekrana basılması için entegrasyon ve test sürecinde 1 olarak bırakın. Daha sonra 0 yapabilirsiniz.
			$debug_on = 1;
		    ## Mağaza canlı modda iken test işlem yapmak için 1 olarak gönderilebilir.
		    $test_mode = 0;
			$no_installment	= 1; // Taksit yapılmasını istemiyorsanız, sadece tek çekim sunacaksanız 1 yapın
			## Sayfada görüntülenecek taksit adedini sınırlamak istiyorsanız uygun şekilde değiştirin.
			## Sıfır (0) gönderilmesi durumunda yürürlükteki en fazla izin verilen taksit geçerli olur.
			$max_installment = 0;
			$currency = "TL";
			
			####### Bu kısımda herhangi bir değişiklik yapmanıza gerek yoktur. #######
			$hash_str = $merchant_id .$user_ip .$merchant_oid .$email .$payment_amount .$user_basket.$no_installment.$max_installment.$currency.$test_mode;
			$paytr_token=base64_encode(hash_hmac('sha256',$hash_str.$merchant_salt,$merchant_key,true));
			$post_vals=array(
					'merchant_id'=>$merchant_id,
					'user_ip'=>$user_ip,
					'merchant_oid'=>$merchant_oid,
					'email'=>$email,
					'payment_amount'=>$payment_amount,
					'paytr_token'=>$paytr_token,
					'user_basket'=>$user_basket,
					'debug_on'=>$debug_on,
					'no_installment'=>$no_installment,
					'max_installment'=>$max_installment,
					'user_name'=>$user_name,
					'user_address'=>$user_address,
					'user_phone'=>$user_phone,
					'merchant_ok_url'=>$merchant_ok_url,
					'merchant_fail_url'=>$merchant_fail_url,
					'timeout_limit'=>$timeout_limit,
					'currency'=>$currency,
		            'test_mode'=>$test_mode
				);
			
			$ch=curl_init();
			curl_setopt($ch, CURLOPT_URL, "https://www.paytr.com/odeme/api/get-token");
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_POST, 1) ;
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post_vals);
			curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
			curl_setopt($ch, CURLOPT_TIMEOUT, 20);
			
			 // XXX: DİKKAT: lokal makinanızda "SSL certificate problem: unable to get local issuer certificate" uyarısı alırsanız eğer
		     // aşağıdaki kodu açıp deneyebilirsiniz. ANCAK, güvenlik nedeniyle sunucunuzda (gerçek ortamınızda) bu kodun kapalı kalması çok önemlidir!
		     // curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			 
			$result = @curl_exec($ch);
			if(curl_errno($ch))
				die("PAYTR IFRAME connection error. err:".curl_error($ch));
			curl_close($ch);
			
			$result = json_decode($result,1);
			if($result['status']=='success')
				$token=$result['token'];
			else
				die("PAYTR IFRAME failed. reason:".$result['reason']);
			echo '<script src="https://www.paytr.com/js/iframeResizer.min.js"></script>
    <iframe src="https://www.paytr.com/odeme/guvenli/'. $token .'" id="paytriframe" frameborder="0" scrolling="no" style="width: 100%;"></iframe>
	<script>iFrameResize({},\'#paytriframe\');</script>';
    }
    private function paytrCallback()
    {
        $shop = $this->db->where('order_id', $_POST['merchant_oid'])->get('shop')->row();
		$post = $_POST;
		$payment = $this->db->where('id', '1')->get('payment')->row();
		$merchant_key 	= $payment->secret_key;
		$merchant_salt	= $payment->token;
		$hash = base64_encode( hash_hmac('sha256', $post['merchant_oid'].$merchant_salt.$post['status'].$post['total_amount'], $merchant_key, true) );
		if( $hash != $post['hash'] )
			die('PAYTR notification failed: bad hash');
		$order = $this->db->where('order_id', $post['merchant_oid'])->get('shop')->row();
		if($order->status == 0){
			echo "OK";
			exit;
		}
        
		if( $post['status'] == 'success' ) { ## Ödeme Onaylandı
			$this->load->model('M_Payment');

            if($shop->type == 'deposit') {
                $this->M_Payment->confirmShopForBalance($order->id);
            }else{
                $this->M_Payment->confirmShopForCart($order->id);
            }

			echo "OK";
			exit;
		} else { ## Ödemeye Onay Verilmedi
			echo "OK";
			exit;
		}
		## Bildirimin alındığını PayTR sistemine bildir.
		echo "OK";
		exit;
    }
    private function payhesap(int $user_id, $amount, $type, $order_id)
    {
    		$this->load->model('M_Payment');
    		$user = $this->db->where('id', $user_id)->get('user')->row();
    		$payment = $this->db->where('id', '4')->get('payment')->row();
	        $shop = $this->db->where('order_id', $order_id)->get('shop')->row();
	        $properties = $this->db->where('id', 1)->get('properties')->row();

    		$posts = [
		    "hash" => $payment->api_key,
		    "order_id" => $order_id,
		    "callback_url" => base_url('payment/callback'), //İşlem durumu hakkında bilgiler ve Payhesap üzerinden ödeme sorgulama aşaması
		    "amount" => $amount,
		    "installment" => "1",
		    "success_url" => base_url('client/success'), //Ödeme başarılı ise sayfa buraya yönlencek
		    "fail_url" => base_url('client/fail'),  //Ödeme başarısız ise sayfa buraya yönlencek
		    "name" => $user->name,
			"email" => $user->email,
			"phone" => $user->phone,
		    "city" => "İstanbul",
		    "state" => "Şişli",
		    "address" => "N/A - Bakiye Yüklemesi",
		    "ip" => $_SERVER['REMOTE_ADDR']
		];
		$encode = json_encode($posts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
		$ch = curl_init('https://www.payhesap.com/api/iframe/pay');
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $encode);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, [
		        'Content-Type: application/json',
		        'Content-Length: ' . strlen($encode)
		    ]
		);
		$result = curl_exec($ch);
		$decode = json_decode($result, true);
		if(isset($decode['data']['token'])){ ?>
		    <script src="https://www.payhesap.com/iframe/iframeResizer.min.js"></script>
		    <iframe src="https://payhesap.com/api/iframe/<?=$decode['data']['token'];?>" id="payhesapiframe" frameborder="0" scrolling="yes" style="width: 100%; height: 100%;"></iframe>
		    <script>iFrameResize({},'#payhesapiframe');</script>
		<?php
		}else{
		    print_r($decode); // Bir sorun var mesajlar burada
		}
    }
    private function payhesapCallback()
 	{
 		if ($_POST['STATUS']) {
            $shop = $this->db->where('order_id', $_POST['ORDER_REF_NUMBER'])->get('shop')->row();
		    $orderID = $_POST['ORDER_REF_NUMBER'];
		    $hash = $_POST['HASH'];
		    $ch = curl_init('https://www.payhesap.com/api/pay/checkOrder');
		    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		    curl_setopt($ch, CURLOPT_POSTFIELDS, array('hash' => $hash));
		    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);;
		    $result = json_decode(curl_exec($ch),true);

		    if($result['data']['merchant_oid'] != $shop->order_id){
				echo $result['data']['merchant_oid'];
				exit;
			}

		    if($result['statusID'] == 1 ){
		        $payment = $this->db->where('order_id', $orderID)->get('shop')->row();
		        if ($payment && $payment->status != 0) {
		        	$this->load->model('M_Payment');
		        	$cart = json_decode($payment->product, true);
                    if($shop->type == 'deposit') {
                        $this->M_Payment->confirmShopForBalance($payment->id);
                    }else{
                        $this->M_Payment->confirmShopForCart($payment->id);
                    }
		        	echo "OK";
		        	exit;
					}else {
						echo "OK";
						exit;
					}
		    }else{
            echo "OK";
            exit;
		    }
        }else{
    		redirect(base_url('client/account'), 'refresh');
    	}
 	}
}
