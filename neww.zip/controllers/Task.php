<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Task extends G_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('M_Task');
        $this->load->model('M_Balance'); // For balance operations
        $this->load->helper('form');
    }

    public function index() {
        addlog('Task Wall', 'Sayfa ziyaret edildi: Görev Duvarı');
        $data = [
            'properties' => $this->db->where('id', 1)->get('properties')->row(),
            'category' => $this->db->where('isActive', 1)->where('mother_category_id', 0)->where('isMenu', 1)->get('category')->result(),
            'tasks' => $this->M_Task->get_tasks(1), // 1: Active
            'pages' => $this->db->get('pages')->result(),
            'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct' => $this->db->limit(3)->where('isActive', 1)->order_by('id', 'DESC')->get('product')->result(),
        ];

        $this->load->view('theme/future/includes/header', $data);
        $this->load->view('theme/future/client/task/index', $data);
        $this->load->view('theme/future/includes/footer', $data);
    }

    public function detail($id) {
        addlog('Task Detail', 'Sayfa ziyaret edildi: Görev Detayı ' . $id);
        $user_id = $this->session->userdata('info')['id'];
        $task = $this->M_Task->get_task_with_user_proof($id, $user_id);

        if (!$task || $task->status != 1) {
             flash('Hata', 'Görev bulunamadı veya aktif değil.');
             redirect(base_url('client/task'));
        }

        $data = [
            'properties' => $this->db->where('id', 1)->get('properties')->row(),
            'category' => $this->db->where('isActive', 1)->where('mother_category_id', 0)->where('isMenu', 1)->get('category')->result(),
            'task' => $task,
            'pages' => $this->db->get('pages')->result(),
            'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct' => $this->db->limit(3)->where('isActive', 1)->order_by('id', 'DESC')->get('product')->result(),
            'mini' => 1,
            'user_proof' => null
        ];

        // Check if user is logged in
        if (isset($this->session->userdata('info')['id'])) {
            $user_id = $this->session->userdata('info')['id'];
            $data['user_proof'] = $this->M_Task->get_user_proof_for_task($id, $user_id);
        }

        $this->load->view('theme/future/includes/header', $data);
        $this->load->view('theme/future/client/task/detail', $data);
        $this->load->view('theme/future/includes/footer', $data);
    }

    public function do_proof($task_id) {
        // Check if user is logged in
        if (!isset($this->session->userdata('info')['id'])) {
            flash('Hata', 'Kanıt göndermek için giriş yapmalısınız.');
            redirect(base_url('hesap'), 'refresh');
            return;
        }
        
        $user_id = $this->session->userdata('info')['id'];
        $task = $this->M_Task->get_task($task_id);

        if (!$task || $task->status != 1) {
            flash('Hata', 'Görev bulunamadı.');
            redirect(base_url('client/task'));
        }
        
        // Check if already submitted
        $existing = $this->db->where('task_id', $task_id)->where('user_id', $user_id)->get('task_proofs')->row();
        if ($existing) {
             flash('Hata', 'Bu görev için zaten kanıt gönderdiniz.');
             redirect(base_url('tasks/detail/'.$task_id));
        }
        
        // Check limit
        if ($task->current_count >= $task->total_limit) {
             flash('Hata', 'Bu görevin kotası dolmuş.');
             redirect(base_url('tasks'));
        }

        $proof_text = $this->input->post('proof_text');
        
        // Image upload
        $proof_image = '';
        if (!empty($_FILES['proof_image']['name'])) {
             $proof_image = changePhoto('assets/img/proofs', 'proof_image');
        }

        $data = [
            'task_id' => $task_id,
            'user_id' => $user_id,
            'proof_text' => $proof_text,
            'proof_image' => $proof_image,
            'status' => 0, // Pending
            'created_at' => date('Y-m-d H:i:s')
        ];

        $this->M_Task->submit_proof($data);
        flash('Başarılı', 'Kanıtınız gönderildi, onay bekleniyor.');
        redirect(base_url('tasks/detail/'.$task_id));
    }

    public function create() {
        addlog('Create Task', 'Sayfa ziyaret edildi: Görev Oluştur');
        $data = [
            'properties' => $this->db->where('id', 1)->get('properties')->row(),
            'category' => $this->db->where('isActive', 1)->where('mother_category_id', 0)->where('isMenu', 1)->get('category')->result(),
            'pages' => $this->db->get('pages')->result(),
            'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct' => $this->db->limit(3)->where('isActive', 1)->order_by('id', 'DESC')->get('product')->result(),
            'mini' => 1
        ];

        $this->clientView('task/create', $data);
    }

    public function do_create() {
        // Check if user is logged in
        if (!isset($this->session->userdata('info')['id'])) {
            flash('Hata', 'Görev oluşturmak için giriş yapmalısınız.');
            redirect(base_url('hesap'), 'refresh');
            return;
        }
        
        $user_id = $this->session->userdata('info')['id'];
        $user = $this->db->where('id', $user_id)->get('user')->row();

        $title = $this->input->post('title');
        $description = $this->input->post('description');
        $reward_amount = floatval($this->input->post('reward_amount'));
        $total_limit = intval($this->input->post('total_limit'));
        $is_repeatable = $this->input->post('is_repeatable') ? 1 : 0;

        if ($reward_amount <= 0 || $total_limit <= 0) {
            flash('Hata', 'Geçersiz miktar veya limit.');
            redirect(base_url('client/task/create'));
        }

        $total_cost = $reward_amount * $total_limit;

        if ($user->balance < $total_cost) {
            flash('Hata', 'Yetersiz bakiye. Gerekli: ' . $total_cost . ' TL');
            redirect(base_url('client/task/create'));
        }

        // Deduct balance
        $this->db->trans_start();
        $new_balance = $user->balance - $total_cost;
        $this->db->where('id', $user_id)->update('user', ['balance' => $new_balance]);

        // Create Task
        $image = '';
        if (!empty($_FILES['image']['name'])) {
             $image = changePhoto('assets/img/tasks', 'image');
        }

        $task_data = [
            'user_id' => $user_id,
            'title' => $title,
            'description' => $description,
            'image' => $image,
            'reward_amount' => $reward_amount,
            'total_limit' => $total_limit,
            'current_count' => 0,
            'status' => 0, // Pending admin approval
            'is_repeatable' => $is_repeatable,
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $task_id = $this->M_Task->create_task($task_data);

        // Log transaction
        $transaction = [
            'user_id' => $user_id,
            'transaction_type' => 'task_create',
            'amount' => -$total_cost,
            'description' => 'Görev oluşturma ücreti: ' . $title,
            'status' => 1,
            'created_at' => date('Y-m-d H:i:s'),
            'balance_before' => $user->balance,
            'balance_after_transaction' => $new_balance,
            'related_id' => $task_id
        ];
        $this->db->insert('wallet_transactions', $transaction);

        $this->db->trans_complete();

        if ($this->db->trans_status() === FALSE) {
            flash('Hata', 'Bir hata oluştu, lütfen tekrar deneyin.');
            redirect(base_url('tasks/create'));
        } else {
            flash('Başarılı', 'Görev başarıyla oluşturuldu ve onay için gönderildi.');
            redirect(base_url('tasks/my-tasks'));
        }
    }

    public function my_tasks() {
        addlog('My Tasks', 'Sayfa ziyaret edildi: Görevlerim');
        $user_id = $this->session->userdata('info')['id'];
        $data = [
            'properties' => $this->db->where('id', 1)->get('properties')->row(),
            'category' => $this->db->where('isActive', 1)->where('mother_category_id', 0)->where('isMenu', 1)->get('category')->result(),
            'tasks' => $this->M_Task->get_user_tasks($user_id),
            'pages' => $this->db->get('pages')->result(),
            'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct' => $this->db->limit(3)->where('isActive', 1)->order_by('id', 'DESC')->get('product')->result(),
            'mini' => 1
        ];

        $this->clientView('task/my_tasks', $data);
    }
    
    public function my_proofs() {
        addlog('My Proofs', 'Sayfa ziyaret edildi: Kanıtlarım');
        $user_id = $this->session->userdata('info')['id'];
        $data = [
            'properties' => $this->db->where('id', 1)->get('properties')->row(),
            'category' => $this->db->where('isActive', 1)->where('mother_category_id', 0)->where('isMenu', 1)->get('category')->result(),
            'proofs' => $this->M_Task->get_proofs(null, $user_id),
            'pages' => $this->db->get('pages')->result(),
            'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct' => $this->db->limit(3)->where('isActive', 1)->order_by('id', 'DESC')->get('product')->result(),
            'mini' => 1
        ];

        $this->clientView('task/my_proofs', $data);
    }
}
