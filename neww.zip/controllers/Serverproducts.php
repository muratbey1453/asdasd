<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Sunucu Ürünleri
 * Routes:
 *  GET  /sunucular/urun-ekle/{serverId}           -> Serverproducts::create($serverId)
 *  POST /sunucular/urun-ekle/{serverId}/kaydet    -> Serverproducts::store($serverId)
 *
 * Not:
 * - Her üye ürün ekleyebilir (giriş şart).
 * - Sadece ONAYLI sunuculara ürün eklenir.
 * - Ürünler 'product' tablosuna kaydolur ve admin onayı için isActive=0 başlar.
 */
class Serverproducts extends G_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Server_model');
        $this->load->model('ServerProduct_model');
        $this->load->helper(['url','form']);
        $this->load->library(['form_validation']);
    }

    // GET: /sunucular/urun-ekle/{serverId}
    public function create($serverId)
    {
        if (!$this->session->userdata('info')) {
            flash('Ups.', 'Ürün eklemek için giriş yapmalısın.');
            redirect(base_url('hesap'), 'refresh');
            return;
        }

        // Sadece onaylı sunucuya ürün ekleme
        $server = $this->Server_model->get_approved_by_id((int)$serverId);
        if (!$server) { show_404(); return; }

        $properties = $this->db->where('id', 1)->get('properties')->row();

        $data = [
            'properties' => $properties,
            'title'      => 'Sunucuya Ürün Ekle - ' . ($properties->name ?? ''),
            'server'     => $server,
        ];

        // View dosya adı: application/views/servers/server_product_create.php
        $this->view('servers/server_product_create', $data);
    }

    // POST: /sunucular/urun-ekle/{serverId}/kaydet
    public function store($serverId)
    {
        if (!$this->session->userdata('info')) {
            show_error('Unauthorized', 401);
            return;
        }

        // Sadece onaylı sunucuya ürün ekleme
        $server = $this->Server_model->get_approved_by_id((int)$serverId);
        if (!$server) { show_404(); return; }

        // Validations
        $this->form_validation->set_rules('name', 'Başlık', 'required|trim|min_length[3]|max_length[120]');
        $this->form_validation->set_rules('price', 'Fiyat', 'required|trim|numeric');
        // discount opsiyonel: numeric kontrolünü aşağıda yapıyoruz
        $this->form_validation->set_rules('discount', 'İndirimli Fiyat', 'trim');
        $this->form_validation->set_rules('description', 'Açıklama', 'trim|max_length[2000]');
        $this->form_validation->set_message(['required' => '<bold>{field}</bold> Alanı boş bırakılamaz.']);

        if ($this->form_validation->run() === FALSE) {
            flash('!', validation_errors());
            redirect(base_url('sunucular/urun-ekle/'.(int)$serverId), 'refresh');
            return;
        }

        $name  = (string)$this->input->post('name', true);
        $price = (float)$this->input->post('price', true);

        $discountRaw = (string)$this->input->post('discount', true);
        $discountRaw = trim($discountRaw);
        $discount = 0.0;

        if ($discountRaw !== '') {
            // "199,90" gibi girilirse noktaya çevir
            $discountRaw2 = str_replace(',', '.', $discountRaw);

            if (!is_numeric($discountRaw2)) {
                flash('Ups.', 'İndirimli fiyat sayısal olmalı.');
                redirect(base_url('sunucular/urun-ekle/'.(int)$serverId), 'refresh');
                return;
            }
            $discount = (float)$discountRaw2;

            if ($discount <= 0) {
                flash('Ups.', 'İndirimli fiyat 0’dan büyük olmalı (boş bırakabilirsin).');
                redirect(base_url('sunucular/urun-ekle/'.(int)$serverId), 'refresh');
                return;
            }

            if ($discount >= $price) {
                flash('Ups.', 'İndirimli fiyat, normal fiyattan küçük olmalı.');
                redirect(base_url('sunucular/urun-ekle/'.(int)$serverId), 'refresh');
                return;
            }
        }

        $desc = (string)$this->input->post('description', true);

        // Images required (multi)
        if (empty($_FILES['imgs']['name']) || !is_array($_FILES['imgs']['name']) || empty($_FILES['imgs']['name'][0])) {
            flash('Ups.', 'En az 1 görsel yüklemelisin.');
            redirect(base_url('sunucular/urun-ekle/'.(int)$serverId), 'refresh');
            return;
        }

        // Upload (multi)
        $uploadDir = FCPATH . 'assets/img/product/';
        if (!is_dir($uploadDir)) { @mkdir($uploadDir, 0755, true); }

        $config = [
            'upload_path'   => $uploadDir,
            'allowed_types' => 'jpg|jpeg|png|webp',
            'max_size'      => 4096,
            'encrypt_name'  => true,
            'remove_spaces' => true,
        ];
        $this->load->library('upload');

        $uploaded = [];
        $names = $_FILES['imgs']['name'];
        $types = $_FILES['imgs']['type'];
        $tmps  = $_FILES['imgs']['tmp_name'];
        $errs  = $_FILES['imgs']['error'];
        $sizes = $_FILES['imgs']['size'];

        $maxFiles = 8;
        $total = count($names);
        $limit = min($total, $maxFiles);

        for ($i = 0; $i < $limit; $i++) {
            if (empty($names[$i])) continue;

            $_FILES['__img'] = [
                'name'     => $names[$i],
                'type'     => $types[$i] ?? '',
                'tmp_name' => $tmps[$i] ?? '',
                'error'    => $errs[$i] ?? 0,
                'size'     => $sizes[$i] ?? 0,
            ];

            $this->upload->initialize($config, true);

            if (!$this->upload->do_upload('__img')) {
                $err = strip_tags($this->upload->display_errors('', ''));

                // cleanup uploaded so far
                foreach ($uploaded as $f) {
                    $p = $uploadDir . $f;
                    if (is_file($p)) @unlink($p);
                }

                flash('Ups.', 'Resim yüklenemedi: '.$err);
                redirect(base_url('sunucular/urun-ekle/'.(int)$serverId), 'refresh');
                return;
            }

            $uploaded[] = $this->upload->data('file_name');
        }

        if (empty($uploaded)) {
            flash('Ups.', 'Görsel yüklenemedi.');
            redirect(base_url('sunucular/urun-ekle/'.(int)$serverId), 'refresh');
            return;
        }

        // İlk görsel ana resim, hepsi galeride
        $imgFile = $uploaded[0];
        $galleryList = array_values(array_filter(array_slice($uploaded, 1)));
        $galleryJson = !empty($galleryList)
            ? json_encode($galleryList, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
            : null;

$userId = (int)$this->session->userdata('info')['id'];

        $newId = $this->ServerProduct_model->create_for_server(
            (int)$serverId,
            $userId,
            $name,
            $price,
            $discount,
            $imgFile,
            $desc,
            $galleryJson
        );

        if (!$newId) {
            flash('Ups.', 'Ürün oluşturulamadı.');
            redirect(base_url('sunucular/urun-ekle/'.(int)$serverId), 'refresh');
            return;
        }

        flash('Harika!', 'Ürün eklendi. Onay sonrası bu sunucuda listelenecek.');
        redirect(base_url('sunucular/detay/'.(int)$serverId).'?sp=1#sunucu-urunleri', 'refresh');
    }
}
