<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CaseBox extends G_Controller
{
    public function __construct()
    {
        parent::__construct();
        $segments_def = $this->uri->segment_array();
        $segments = array_slice($segments_def, 1);
        //ByPass account controll for trying to open case
        if (count($segments) == 4) {
            if ($segments[0] == "CaseBox" && $segments[1] == "openCase" && $segments[3]) {
                $this->load->helper('case');
                return;
            }
        } else if (count($segments_def) == 2) {
            if ($segments[0] == "CaseBox" && $segments[1] == "showCase") {
                return;
            }
        }

        if (!isset($this->session->userdata('info')['id'])) {
            $this->output->set_content_type('application/json')->set_output(json_encode([
                'status' => false,
                'message' => 'Lütfen giriş yapınız.'
            ]));
            exit($this->output->_display());
        }
        $properties = $this->db->where('id', 1)->get('properties')->row();
        $user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row();
        if ($properties->isConfirmTc == 1 && $user->tc == "11111111111") {
            $this->output->set_content_type('application/json')->set_output(json_encode([
                'status' => false,
                'message' => 'Lütfen hesabınızı onaylayınız.'
            ]));
            exit($this->output->_display());
        }

        $this->load->helper('case');
    }

    public function openCase($case_id, $try=false) {
        //case (id, name, price, image, description, active, created_at, updated_at)
        //case_item (id, case_id, product_id, chance, active, created_at, updated_at)

        $case = $this->db->where('id', $case_id)->where('active', 1)->get('cases')->row();
        if (!$case) {
            $this->output->set_content_type('application/json')->set_output(json_encode([
                'status' => false,
                'message' => 'Kasa bulunamadı veya aktif değil.'
            ]));
            return;
        }

        //check user balance
        if (!$try) {
            $user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row();
            if ($user->balance < $case->price) {
                $this->output->set_content_type('application/json')->set_output(json_encode([
                    'status' => false,
                    'message' => 'Yeterli bakiyeniz bulunmamaktadır.',
                    'retry' => true
                ]));
                return;
            }
        }

        //get case items
        $case_items = $this->db->where('case_id', $case_id)->where('active', 1)->get('case_items')->result();
        if (!$case_items) {
            $this->output->set_content_type('application/json')->set_output(json_encode([
                'status' => false,
                'message' => 'Kasa içerisinde ürün bulunmamaktadır.'
            ]));
            return;
        }
        $case_items = array_map(function ($item) {
            $item->product = $this->db->where('id', $item->product_id)->get('product')->row();
            $item->color = get_color_by_chance($item->chance);
            return $item;
        }, $case_items);

        //get random item with chance
        $chances = array_column($case_items, 'chance');
        $random_items = weighted_random_all($case_items, $chances, 56);
        if (!$random_items) {
            $this->output->set_content_type('application/json')->set_output(json_encode([
                'status' => false,
                'message' => 'Kasa içerisinde ürün1 bulunmamaktadır.'
            ]));
            return;
        }
        $half = count($random_items) / 2;
        $half = round($half);
        $random_index = rand($half, count($random_items) - 1 - 6);
        $random_item = $random_items[$random_index];
        if (!$random_item) {
            $this->output->set_content_type('application/json')->set_output(json_encode([
                'status' => false,
                'message' => 'Kasa içerisinde ürün2 bulunmamaktadır.'
            ]));
            return;
        }
        $random_item->selected = true;

        //get product
        $product = $this->db->where('id', $random_item->product_id)->get('product')->row();
        if (!$product) {
            $this->output->set_content_type('application/json')->set_output(json_encode([
                'status' => false,
                'message' => 'Ürün bulunamadı.'
            ]));
            return;
        }

        if (!$try) {
            //transaction for balance change, add shop (price, date 'd.m.Y H:i:s', status 1, order_id rand_string, user_id, product, ip_address, type 1)   and give from stock (add to the invoice table)
            $this->db->trans_begin();
            $this->db->where('id', $this->session->userdata('info')['id'])->update('user', [
                'balance' => $user->balance - $case->price
            ]);

			$stock = $this->db->where('product_id', $product->id)->where('isActive', 1)->get('stock')->row();
			if (!$stock) {
				$data = [
					'user_id' => $user->id,
					'product_id' => $product->id,
					'isActive' => 1,
					'date' => date('Y-m-d H:i:m'),
					'shop_id' => 8544,
					'price' => $product->price,
					'balance' => $user->balance,
					'new_balance' => $user->balance - $case->price
				];
				
				$this->db->insert('pending_product', $data);
				$pendingProductLastInsertId = $this->db->insert_id();
            }else{
				 $this->db->where('id', $stock->id)->update('stock', ['isActive' => 0]);
			}
			
            // Wallet transaction kaydı ekle
            $transaction_data = [
                'user_id' => $this->session->userdata('info')['id'],
                'transaction_type' => 'case_purchase',
                'amount' => -$case->price, // Negatif değer olarak ekle (bakiyeden düşüyor)
                'description' => $case->name . ' kasası açıldı',
                'status' => 1, // Onaylı
                'created_at' => date('Y-m-d H:i:s'),
                'balance_before' => $user->balance, // İşlem öncesi bakiye
                'balance_after_transaction' => $user->balance - $case->price, // Güncellenmiş bakiye
                'related_id' => $case->id
            ];
            $this->db->insert('wallet_transactions', $transaction_data);

            //user_cases (	id	user_id	case_id	product_id	stock_id	price	date	)
            $this->db->insert('user_cases', [
                'user_id' => $this->session->userdata('info')['id'],
                'case_id' => $case->id,
                'case_item_id' => $random_item->id,
                'product_id' => $product->id,
                'stock_id' => !$stock ? -1 : $stock->id,
                'price' => $case->price,
                'date' => date('Y-m-d H:i:s')
            ]);
			
			$userCasesLastInsertId = $this->db->insert_id();
			if(!$stock){
			    $this->db->where('id', $pendingProductLastInsertId)->update('pending_product', ['case_id' => $userCasesLastInsertId]);
			}
			
			$nowShop = $this->db->where('id', '8544')->get('shop')->row();
			$this->db->where('id', '8544')->update('shop', [
                'price' => $nowShop->price + $case->price,
            ]);

            if ($this->db->trans_status() === FALSE) {
                $this->db->trans_rollback();

                $this->output->set_content_type('application/json')->set_output(json_encode([
                    'status' => false,
                    'message' => 'Bir hata oluştu. Lütfen tekrar deneyiniz.',
                    'retry' => true
                ]));
                return;
            } else {
                $this->db->trans_commit();

                $this->output->set_content_type('application/json')->set_output(json_encode([
                    'status' => true,
                    'products' => $random_items,
                    'case_price' => $case->price
                ]));
                return;
            }
        } else {
            $this->output->set_content_type('application/json')->set_output(json_encode([
                'status' => true,
                'products' => $random_items,
                'case_price' => $case->price
            ]));
            return;
        }
    }


}
