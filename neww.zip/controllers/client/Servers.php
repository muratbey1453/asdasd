<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Servers extends G_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Server_model');

        if (!$this->session->userdata('info')) {
            redirect(base_url('hesap'), 'refresh');
        }
    }

    // GET /client/sunucu-ekle
    public function create()
    {
        $properties = $this->db->where('id', 1)->get('properties')->row();

        $data = [
            'properties' => $properties,
            'category' => getActiveCategories(),
            'pages' => $this->db->get('pages')->result(),
            'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage' => $this->db->limit(3)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct' => $this->db->limit(3)->where('isActive', 1)->order_by('id', 'DESC')->get('product')->result(),
            'title' => 'Sunucu Ekle - ' . $properties->name,
            'games' => $this->Server_model->game_options()
        ];

        // views/theme/future/client/server_add.php
        $this->clientView('server_add', $data);
    }

    // POST /client/sunucu-kaydet
    public function store()
    {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('game', 'Oyun', 'required|trim');
        $this->form_validation->set_rules('title', 'Sunucu Adı', 'required|trim|min_length[2]|max_length[80]');
        $this->form_validation->set_rules('ip', 'IP/Domain', 'required|trim|min_length[2]|max_length[100]');
        $this->form_validation->set_rules('website', 'Website', 'trim|max_length[255]');
        $this->form_validation->set_rules('discord', 'Discord', 'trim|max_length[255]');
        $this->form_validation->set_rules('short_desc', 'Kısa Açıklama', 'trim|max_length[140]');
        $this->form_validation->set_rules('description', 'Açıklama', 'required|trim|max_length[5000]');

        if ($this->form_validation->run() == FALSE) {
            flash('Ups.', validation_errors());
            redirect(base_url('client/sunucu-ekle'), 'refresh');
            return;
        }

        $user_id = (int)$this->session->userdata('info')['id'];

        $this->Server_model->create_server([
            'user_id' => $user_id,
            'game' => strip_tags(trim($this->input->post('game'))),
            'title' => strip_tags(trim($this->input->post('title'))),
            'ip' => strip_tags(trim($this->input->post('ip'))),
            'website' => strip_tags(trim($this->input->post('website'))),
            'discord' => strip_tags(trim($this->input->post('discord'))),
            'short_desc' => strip_tags(trim($this->input->post('short_desc'))),
            'description' => trim($this->input->post('description')),
            'status' => 'pending'
        ]);

        flash('Harika!', 'Sunucu talebin alındı. Admin onayından sonra listede görünecek.');
        redirect(base_url('client'), 'refresh');
    }
}
