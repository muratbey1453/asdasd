<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends G_Controller {
    function __construct() {
        parent::__construct();
    }
    public function index()
    {
        addlog('Ana sayfa - index', 'Sayfa ziyaret edildi: Anasayfa');
        $this->load->helper('ai_helper');
        $this->load->helper('shop_helper');
        $this->load->helper('streamer_helper');
        $this->load->model('M_Task');
        $products = getAIProducts($this->db->get('home_products')->result());
        $data = [
            'properties' => $this->db->where('id', 1)->get('properties')->row(),
            'category' => getActiveCategories(),
            'slider' => $this->db->order_by('id', 'DESC')->get('slider')->result(),
            'lastProducts' => $this->db->order_by('id', 'DESC')->where('isActive', 1)->limit('5')->get('product')->result(),
            'home_products' => $this->db->get('home_products')->result(),
            'editor_choice' => $this->db->get('home_choice')->result(),
            'home_category' => $this->db->select('home_category.*, category.name')->join('category', 'category.id = category_id', 'left')->get('home_category')->result(),
            'products' => $products,
            'streamers' => $this->db->limit(10)->where("isStreamer", 1)->order_by('id', 'DESC')->get('user')->result(),
            'why' => $this->db->get('why')->result(),
            'pages' => $this->db->get('pages')->result(),
            'stories' => $this->db->get('story')->result(),
            'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct' => $this->db->limit(6)->where('isActive', 1)->where('server_id', 0)->order_by('id', 'DESC')->get('product')->result(),
            'featured_cards' => $this->db->order_by('sort_order', 'ASC')->get('home_featured_cards')->result(),
            'cases' => $this->db->where('active', 1)->limit(12)->order_by('id', 'DESC')->get('cases')->result(),
            'tasks' => $this->M_Task->get_tasks(1, 12)
        ];
        $this->view('index', $data);
    }
    
    public function showCase($case_slug) {
        $properties = $this->db->where('id', 1)->get('properties')->row();
        $case = $this->db->where('slug', $case_slug)->where('active', 1)->get('cases')->row();
        if (!$case) {
            redirect(base_url(), 'refresh');
        }
        $this->load->helper('case');

        $case->items = $this->db->where('case_id', $case->id)->where('active', 1)->get('case_items')->result();
        if (!$case->items) {
            redirect(base_url(), 'refresh');
        }
        if (count($case->items) == 0) {
            redirect(base_url(), 'refresh');
        }
        $chances = array_column($case->items, 'chance');
        $case->items = weighted_random_all($case->items, $chances, 50);

        $case->items = array_map(function ($item) {
            $item->product = $this->db->where('id', $item->product_id)->get('product')->row();
            return $item;
        }, $case->items);

        $data = [
            'properties' => $this->db->where('id', 1)->get('properties')->row(),
            'category' => $this->db->where('isActive', 1)->where('mother_category_id', 0)->where('isMenu', 1)->get('category')->result(),
            'pages' => $this->db->get('pages')->result(),
            'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct' => $this->db->limit(6)->where('isActive', 1)->where('server_id', 0)->order_by('id', 'DESC')->get('product')->result(),
            'title' => $case->name. ' - ' . $properties->name,
            'case' => $case,
        ];
        $this->view('case', $data);
    }

	public function cases()
	{
		 $data = [
            'properties' => $this->db->where('id', 1)->get('properties')->row(),
            'category' => $this->db->where('isActive', 1)->where('mother_category_id', 0)->where('isMenu', 1)->get('category')->result(),
            'pages' => $this->db->get('pages')->result(),
            'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct' => $this->db->limit(6)->where('isActive', 1)->where('server_id', 0)->order_by('id', 'DESC')->get('product')->result(),
            'cases' => $this->db->where('active', 1)->get('cases')->result(),
        ];
        $this->view('cases', $data);
	}
	
    public function marketPlace($page = 1)
    {
        addlog('Ana sayfa - marketPlace', 'Sayfa ziyaret edildi: Oyuncu Pazarı');
        $this->load->helper('ai_helper');
        $this->load->helper('shop_helper');
        $this->load->library("pagination");
        
        // Get filter parameters
        $search = $this->input->get('search');
        $category = $this->input->get('category');
        $min_price = $this->input->get('min_price');
        $max_price = $this->input->get('max_price');
        $seller_types = $this->input->get('seller_type');
        $sort = $this->input->get('sort');
        
        // Build query with filters for counting
        $this->db->where('seller_id >', 0)->where('isActive', 1);

        
        if ($search) {
            $this->db->like('name', $search);
        }
        if ($category) {
            $this->db->where('category_id', $category);
        }
        if ($min_price) {
            $this->db->where('price >=', $min_price);
        }
        if ($max_price) {
            $this->db->where('price <=', $max_price);
        }
        if (!empty($seller_types)) {
            if (in_array('user', $seller_types) && !in_array('official', $seller_types)) {
                $this->db->where('seller_id >', 0);
            } elseif (in_array('official', $seller_types) && !in_array('user', $seller_types)) {
                $this->db->where('seller_id', 0);
            }
        }
        
        // Get total count for pagination
        $total_rows = $this->db->count_all_results('product');
        
        // Rebuild query for actual data fetch
        $this->db->where('seller_id >', 0)->where('isActive', 1);

        
        if ($search) {
            $this->db->like('name', $search);
        }
        if ($category) {
            $this->db->where('category_id', $category);
        }
        if ($min_price) {
            $this->db->where('price >=', $min_price);
        }
        if ($max_price) {
            $this->db->where('price <=', $max_price);
        }
        if (!empty($seller_types)) {
            if (in_array('user', $seller_types) && !in_array('official', $seller_types)) {
                $this->db->where('seller_id >', 0);
            } elseif (in_array('official', $seller_types) && !in_array('user', $seller_types)) {
                $this->db->where('seller_id', 0);
            }
        }
        
        // Sorting
        if ($sort == 'price_asc') {
            $this->db->order_by('price', 'ASC');
        } elseif ($sort == 'price_desc') {
            $this->db->order_by('price', 'DESC');
        } elseif ($sort == 'newest') {
            $this->db->order_by('id', 'DESC');
        } else {
            $this->db->order_by('id', 'DESC');
        }
        
        // Get products with limit
        $products = $this->db->limit(50, ($page - 1) * 50)->get('product')->result();
        
        $config['base_url'] = base_url('ilan-pazari');
        $config['total_rows'] = $total_rows;
        $config['per_page'] = 50;
        $config['uri_segment'] = 3;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'Önceki';
        $config['prev_tag_open'] = '<li class="prev"><div class="page-link">';
        $config['prev_tag_close'] = '</div></li>';
        $config['next_link'] = 'Sonraki';
        $config['next_tag_open'] = '<li><div class="page-link">';
        $config['next_tag_close'] = '</div></li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item"><a class="page-link" href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li class="page-item"><div class="page-link">';
        $config['num_tag_close'] = '</div></li>';
        $config['reuse_query_string'] = TRUE;
        
        $this->pagination->initialize($config);
        
        $data = [
            'properties' => $this->db->where('id', 1)->get('properties')->row(),
            'category' => getActiveCategories(),
            'categories' => $this->db->where(['isActive' => 1, 'isMarketPlace' => 1])->get('category')->result(),
            'slider' => $this->db->get('slider')->result(),
            'lastProducts' => $this->db->order_by('id', 'DESC')->limit('5')->get('product')->result(),
            'products' => $products,
            'why' => $this->db->get('why')->result(),
            'pages' => $this->db->get('pages')->result(),
            'stories' => $this->db->get('story')->result(),
            'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct' => $this->db->limit(6)->where('isActive', 1)->where('server_id', 0)->order_by('id', 'DESC')->get('product')->result()
        ];
        $this->view('market-place', $data);
    }
    public function categories()
    {
        addlog('Tüm Kategoriler - categories', 'Sayfa ziyaret edildi: Tüm Kategoriler');
        $this->load->helper('ai_helper');
        $this->load->helper('shop_helper');
        $this->load->helper('streamer_helper');
        $categories = $this->db->where('isActive', 1)->get('category')->result();
        $data = [
            'properties' => $this->db->where('id', 1)->get('properties')->row(),
            'category' => getActiveCategories(),
            'slider' => $this->db->get('slider')->result(),
            'lastProducts' => $this->db->order_by('id', 'DESC')->limit('5')->get('product')->result(),
            'home_products' => $this->db->get('home_products')->result(),
            'editor_choice' => $this->db->get('home_choice')->result(),
            'home_category' => $this->db->select('home_category.*, category.name')->join('category', 'category.id = category_id', 'left')->get('home_category')->result(),
            'categories' => $categories,
            'streamers' => $this->db->limit(10)->where("isStreamer", 1)->order_by('id', 'DESC')->get('user')->result(),
            'why' => $this->db->get('why')->result(),
            'pages' => $this->db->get('pages')->result(),
            'stories' => $this->db->get('story')->result(),
            'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct' => $this->db->limit(6)->where('isActive', 1)->where('server_id', 0)->order_by('id', 'DESC')->get('product')->result()
        ];
        $this->view('categories', $data);
    }
    public function getProduct($slug = NULL)
    {
        $this->load->helper('shop');
        $product = $this->db->where('slug', $slug)->where('isActive', 1)->get('product')->row();
        $properties = $this->db->where('id', 1)->get('properties')->row();
        if (!empty($product)) {
            
            // Sunucu ürünü ise breadcrumb vb. için sunucuyu da gönderelim
            $serverForProduct = null;
            if (isset($product->server_id) && (int)$product->server_id > 0) {
                $serverForProduct = $this->db
                    ->where('id', (int)$product->server_id)
                    ->where('status', 1)
                    ->get('servers')->row();
            }
addlog('getProduct', 'Sayfa ziyaret edildi: Ürünler - ' . $product->name);
            if (!empty($this->session->userdata('info'))) {
                $data = [
                    'user_id' => $this->session->userdata('info')['id'],
                    'category_id' => $product->category_id,
                    'product_id' => $product->id
                ];
                $this->db->insert('category_review', $data);
                $date = date('Y-m-d', strtotime('-15 days'));
                $getDate = $this->db->where('user_id', $this->session->userdata('info')['id'])->where('date <', $date)->get('category_review')->result();
                foreach ($getDate as $gd) {
                    $this->db->where('id', $gd->id)->delete('category_review');
                }
            }
            $data = [
                'properties' => $this->db->where('id', 1)->get('properties')->row(),
                'category' => getActiveCategories(),
                'product' => $product,
                                'serverForProduct' => $serverForProduct,
'stock' => $this->db->where('isActive', 1)->where('product_id', $product->id)->count_all_results('stock'),
                'comments' => $this->db->where('product_comments.product_id', $product->id)->where('product_comments.isActive', 1)->order_by('product_comments.id', 'DESC')->select('product_comments.*, user.name, user.surname')->join('user', 'user.id = user_id', 'left')->get('product_comments')->result(),
                'history' => $this->db->where('product_comments.product_id', $product->id)->where('product_comments.isActive', 1)->order_by('product_comments.id', 'DESC')->select('product_comments.*, user.name, user.surname')->join('user', 'user.id = user_id', 'left')->get('product_comments')->result(),
                'why' => $this->db->get('why')->result(),
                'pages' => $this->db->get('pages')->result(),
                'title' => $product->name . ' - ' . $properties->name,
                'likeProducts' => $this->db->limit(4)->where('category_id', $product->category_id)->where('isActive', 1)->get('product')->result(),
                'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
                'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
                'footerProduct' => $this->db->limit(6)->where('isActive', 1)->where('server_id', 0)->order_by('id', 'DESC')->get('product')->result()
            ];
            $this->view('product', $data);
        }else{
            addlog('getProduct', 'Sayfa ziyaret edildi: Ürün bulunamadı - ' . $slug);
            //flash('Ups.', 'Aradık Taradık Ancak Ürünü Bulamadık');
            redirect(base_url());
        }
    }
    public function addToCartItem()
    {
        if (abs($this->input->post('amount')) < 1) {
            addlog('addToCartItem', 'Sepete eklenecek ürün adeti yetersiz: ' . $this->input->post('amount'));
            echo "En düşük 1 adet ürün alınabilir.";
            exit;
        }
        $extras = [];
        if (!empty($_POST['extras']['name1'])) {
            $name1 = $_POST['extras']['name1'];
            $number1 = $_POST['extras']['number1'];
            $extras[$name1] = $number1;
        }
        if (!empty($_POST['extras']['name2'])) {
            $name2 = $_POST['extras']['name2'];
            $number2 = $_POST['extras']['number2'];
            $extras[$name2] = $number2;
        }
        if (!empty($_POST['extras']['name3'])) {
            $name3 = $_POST['extras']['name3'];
            $number3 = $_POST['extras']['number3'];
            $extras[$name3] = $number3;
        }
        $id = $this->input->post('id');
        if ($this->db->where('isActive', 1)->where('id', $id)->get('product')->row()) {
            $product = $this->db->where('isActive', 1)->where('id', $id)->get('product')->row();
            $properties = $this->db->where("id", 1)->get('properties')->row();
            
            // Kendine ait ürünü satın almayı engelle
            if (!empty($this->session->userdata('info'))) {
                if ($product->seller_id == $this->session->userdata('info')['id']) {
                    $this->load->view('theme/' .$properties->theme . '/cartView');
                    echo '<div class="toast fade show" data-delay="100">
						<div class="toast-header">
							<strong class="mr-auto"><i class="fa fa-globe"></i> ' . "Hata!" . '</strong>
							<small class="text-muted">1 Saniye Önce</small>
							<button type="button" class="ml-2 mb-1 close" data-dismiss="toast">&times;</button>
						</div>
						<div class="toast-body" style="color: #6c757d;">
							'. "Kendine ait bir ürünü satın alamazsın." . '
						</div>
						<div style="height: 2px; background-color: blue; width: 100%; transition: all 3s ease 0s;" id="timer"></div>
					</div>
					<script>
						toastTimer("timer", 4);
						function toastTimer(toastId, time=10) {
							setTimeout(function() {
								if (time==-2) {
									document.getElementById(toastId).parentElement.hidden = true
								} else {
									var width = document.getElementById(toastId).style.width.replace("%", ""); 
									document.getElementById(toastId).style.width = width-(170/time)+"%";
									//console.log("toast", time)
									toastTimer(toastId, time-1);
								}
							}, 1000)
						}
					</script>';
                    return;
                }
            }
            
            // Bayilik indirimini calculatePrice ile hesapla
            $user_id = !empty($this->session->userdata('info')) ? $this->session->userdata('info')['id'] : 0;
            $qty = abs($this->input->post('amount'));
            $priceData = json_decode(calculatePrice($product->id, $qty), true);
            $price = $priceData['price'] / $qty; // Birim fiyatı almak için toplam fiyatı miktara böl
            
            $data = [
                'id'      => (!empty($_POST['extras']['name1']) || !empty($_POST['extras']['name2']) || !empty($_POST['extras']['name3'])) ? $product->id . rand(0, 999) : $product->id,
                'product_id' => $product->id,
                'qty'     => $qty,
                'price'   => $price,
                'name'    => sefLink($product->name),
                'extras' => json_encode($extras)
            ];
            $this->advanced_cart->insert($data);
            addlog('addToCartItem', 'Sepete ürün eklendi: ' . $product->name);
            return $this->load->view('theme/' .$properties->theme . '/cartView');
        }else{
            addlog('addToCartItem', 'Sepete eklenecek ürün bulunamadı: ' . $id);
            echo "Ürün Bulunamadı.";
        }
    }
    public function cart()
    {
        addlog('cart', 'Sayfa ziyaret edildi: Sepet');
        $this->load->helper('form');
        $cart = $this->advanced_cart->contents();
        foreach($cart as $item) {
            $product = $this->db->where('id', $item['product_id'])->get('product')->row();
            $is_admin_product = false;
            if ($product->isStock == 1) {
                if ($product->seller_id==0) {
                    $is_admin_product = true;
                } else {
                    $seller = $this->db->where('id', $product->seller_id)->get('user')->row();
                    if ($seller->isAdmin == 1) {
                        $is_admin_product = true;
                    }
                }
            } else {
                $is_admin_product = true;
                if ($product->seller_id!=0) {
                    $seller = $this->db->where('id', $product->seller_id)->get('user')->row();
                    if ($seller->isAdmin != 1) {
                        $this->advanced_cart->remove($item["rowid"]);
                        flash("Ups.", "Sepetinizdeki ürün sistemsel bir sorun nedeniyle kaldırıldı.");
                    }
                }
            }
            if (!$is_admin_product) {
                $stockCount = $this->db->where('product_id', $item['product_id'])->where('isActive', 1)->count_all_results('stock');
                if ($stockCount < $item['qty']) {
                    $this->advanced_cart->remove($item["rowid"]);
                    flash("Ups.", "Sepetindeki ürün satıcının stoğunda kalmamış.");
                }
            }
        }
        $data = [
            'properties' => $this->db->where('id', 1)->get('properties')->row(),
            'pages' => $this->db->get('pages')->result(),
            'category' => getActiveCategories(),
            'why' => $this->db->get('why')->result(),
            'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct' => $this->db->limit(6)->where('isActive', 1)->where('server_id', 0)->order_by('id', 'DESC')->get('product')->result(),
        ];
        $this->view('cart', $data);
    }
    public function category($slug)
    {
        $result = $this->db->where('slug', $slug)->where('isActive', 1)->get('category')->row();
        $properties = $this->db->where('id', 1)->get('properties')->row();
        if ($result) {
            addlog('category', 'Sayfa ziyaret edildi: Kategori - ' . $result->name);
            $data = [];
            $this->load->library("pagination");
            $config['uri_segment'] = 3;
            $config['per_page'] = 50;
            $config['total_rows'] = $this->db->where('category_id', $result->id)->where('isActive', 1)->where('seller_id', 0)->count_all_results('product');
            $config['base_url'] = base_url('kategori/') . $slug;
            $config['use_page_numbers'] = TRUE;
            $config['full_tag_open'] = '<ul class="pagination justify-content-end">';
            $config['full_tag_close'] = '</ul>';
            $config['first_link'] = false;
            $config['last_link'] = false;
            $config['first_tag_open'] = '<li>';
            $config['first_tag_close'] = '</li>';
            $config['prev_link'] = 'Önceki';
            $config['prev_tag_open'] = '<li class="prev"><div class="page-link">';
            $config['prev_tag_close'] = '</div></li>';
            $config['next_link'] = 'Sonraki';
            $config['next_tag_open'] = '<li><div class="page-link">';
            $config['next_tag_close'] = '</div></li>';
            $config['last_tag_open'] = '<li>';
            $config['last_tag_close'] = '</li>';
            $config['cur_tag_open'] = '<li class="page-item"><a class="page-link" href="#">';
            $config['cur_tag_close'] = '</a></li>';
            $config['num_tag_open'] = '<li class="page-item"><div class="page-link">';
            $config['num_tag_close'] = '</div></li>';
            $this->pagination->initialize($config);
            $data["links"] = $this->pagination->create_links();
            $sayfa = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
            if($sayfa > 0)
            {
                $offset = ($sayfa*$config['per_page']) - $config['per_page'];
            }else
            {
                $offset = $sayfa;
            }
            $data = [
                'properties' => $this->db->where('id', 1)->get('properties')->row(),
                'category' => getActiveCategories(),
                'categories' => $result,
                'subCategories' => $this->db->where('isActive', 1)->where('mother_category_id', $result->id)->get('category')->result(),
                'pages' => $this->db->get('pages')->result(),
                'products' => $this->db->order_by('id', 'DESC')->where('category_id', $result->id)->where('isActive', 1)->where('seller_id', 0)->limit($config['per_page'], $offset)->get('product')->result(),
                'title' =>  $result->name . ' - ' . $properties->name,
                'why' => $this->db->get('why')->result(),
                'links' => $this->pagination->create_links(),
                'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
                'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
                'footerProduct' => $this->db->limit(6)->where('isActive', 1)->where('server_id', 0)->order_by('id', 'DESC')->get('product')->result()
            ];
            $this->view('products', $data);
        }else{
            addlog('category', 'Kategori bulunamadı - ' . $slug);
            flash('Ups.', 'Kategori Bulunamadı');
            redirect(base_url());
        }
    }
    public function blogs()
    {
        addlog('blogs', 'Sayfa ziyaret edildi: Makale Listesi');
        $properties = $this->db->where('id', 1)->get('properties')->row();
        $data = [];
        $this->load->library("pagination");
        $config['uri_segment'] = 2;
        $config['per_page'] = 9;
        $config['total_rows'] = $this->db->count_all_results('blog');
        $config['base_url'] = base_url('makale-listesi');
        $config['use_page_numbers'] = TRUE;
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'Önceki';
        $config['prev_tag_open'] = '<li class="prev"><div class="page-link">';
        $config['prev_tag_close'] = '</div></li>';
        $config['next_link'] = 'Sonraki';
        $config['next_tag_open'] = '<li><div class="page-link">';
        $config['next_tag_close'] = '</div></li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item"><a class="page-link" href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li class="page-item"><div class="page-link">';
        $config['num_tag_close'] = '</div></li>';
        $this->pagination->initialize($config);
        $data["links"] = $this->pagination->create_links();
        $sayfa = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
        if($sayfa > 0)
        {
            $offset = ($sayfa*$config['per_page']) - $config['per_page'];
        }else
        {
            $offset = $sayfa;
        }
        $data = [
            'properties' => $this->db->where('id', 1)->get('properties')->row(),
            'pages' => $this->db->get('pages')->result(),
            'category' => getActiveCategories(),
            'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct' => $this->db->limit(6)->where('isActive', 1)->where('server_id', 0)->order_by('id', 'DESC')->get('product')->result(),
            'links' => $this->pagination->create_links(),
            'title' => 'BLOG - ' . $properties->name,
            'blogs' => $this->db->order_by('id', 'DESC')->limit($config['per_page'], $offset)->get('blog')->result()
        ];
        $this->view('blogs', $data);
    }
    public function blog($slug)
{
    if (empty($slug)) {
        addlog('blog', 'Makale bulunamadı - slug boş');
        flash('Ups.', 'Aradığın Yazıyı Bulamadık');
        redirect(base_url(), 'refresh');
        return;
    }

    $blog = $this->db->where('slug', $slug)->get('blog')->row();

    if (!$blog) {
        addlog('blog', 'Makale bulunamadı - ' . $slug);
        flash('Ups.', 'Aradığın yazıyı bulamadık.');
        redirect(base_url(), 'refresh');
        return;
    }

    addlog('blog', 'Makale ziyaret edildi - ' . $blog->title);

    $properties = $this->db->where('id', 1)->get('properties')->row();

    // ✅ Rastgele yazılar (mevcut yazı hariç)
    $relatedBlogs = $this->db
        ->where('id !=', (int)$blog->id)
        ->order_by('RAND()', null, false) // CI escape problemini önler
        ->limit(3)
        ->get('blog')
        ->result();

    // ✅ Eğer tek yazı varsa vb. yine boş gelirse:
    if (empty($relatedBlogs)) {
        $relatedBlogs = $this->db
            ->order_by('RAND()', null, false)
            ->limit(3)
            ->get('blog')
            ->result();
    }

    $data = [
        'properties'     => $properties,
        'category'       => getActiveCategories(),
        'blog'           => $blog,
        'pages'          => $this->db->get('pages')->result(),

        // Eski sidebar/blog listesi kullanıyorsan kalsın:
        'blogs'          => $this->db->order_by('id', 'DESC')->limit(5)->get('blog')->result(),

        // ✅ View tarafında kullanacağımız liste:
        'relatedBlogs'   => $relatedBlogs,

        'footerBlog'     => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
        'footerPage'     => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
        'footerProduct'  => $this->db->limit(6)->where('isActive', 1)->where('server_id', 0)->order_by('id', 'DESC')->get('product')->result(),
        'title'          => $blog->title . ' - ' . ($properties->name ?? '')
    ];

    // Eğer senin detay view dosyan "blog-detail" ise şunu yap:
    // $this->view('blog-detail', $data);
    $this->view('blog', $data);
}

    public function page($slug)
    {
        if (!empty($slug)) {
            $page = $this->db->where('slug', $slug)->get('pages')->row();
            if ($page) {
                addlog('page', 'Sayfa ziyaret edildi - ' . $page->title);
                $properties = $this->db->where('id', 1)->get('properties')->row();
                $data = [
                    'properties' => $this->db->where('id', 1)->get('properties')->row(),
                    'category' => getActiveCategories(),
                    'pages' => $this->db->get('pages')->result(),
                    'page' => $page,
                    'meta' => $this->db->where('id', $page->id)->get('pages')->row(),
                    'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
                    'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
                    'footerProduct' => $this->db->limit(6)->where('isActive', 1)->where('server_id', 0)->order_by('id', 'DESC')->get('product')->result(),
                ];
                $this->view('page', $data);
            }else{
                addlog('page', 'Sayfa bulunamadı - ' . $slug);
                flash('Ups.', 'Aradığın sayfayı bulamadık.');
                redirect(base_url(), 'refresh');
            }
        }else{
            addlog('page', 'Sayfa bulunamadı - ' . $slug);
            flash('Ups.', 'Aradığın Sayfayı Bulamadık');
            redirect(base_url(), 'refresh');
        }
    }
    public function shop($slug)
    {
        $this->load->helper('shop_helper');
        $properties = $this->db->where('id', 1)->get('properties')->row();
        if ($properties->shop_active != 1) {
            return redirect(base_url(), 'refresh');
        }
        $seller = $this->db->where('shop_slug', $slug)->get('user')->row();
        if ($seller && $seller->isActive == 1) {
            addlog('shop', 'Satıcı ziyaret edildi - ' . $seller->shop_name);
            $data = [
                'properties' => $this->db->where('id', 1)->get('properties')->row(),
                'category' => getActiveCategories(),
                'pages' => $this->db->get('pages')->result(),
                'seller' => $seller,
                'why' => $this->db->get('why')->result(),
                'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
                'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
                'footerProduct' => $this->db->limit(6)->where('isActive', 1)->where('server_id', 0)->order_by('id', 'DESC')->get('product')->result(),
            ];
            $this->view('shop', $data);
        }else{
            addlog('shop', 'Satıcı bulunamadı - ' . $slug);
            flash('Ups.', 'Aradığın satıcı yok veya profili kısıtlanmış.');
            redirect(base_url(), 'refresh');
        }
    }
    public function streamer($streamer)
    {
        addlog('streamer', 'Sayfa ziyaret edildi - Yayıncı');
        $this->load->helper('streamer_helper');
        $properties = $this->db->where('id', 1)->get('properties')->row();
        //$streamer = $this->db->where("isStreamer", 1)->where("JSON_EXTRACT(`streamer_info` -> '$.streamlabs', '$.username') = '$streamer'", null, FALSE)->order_by('id', 'DESC')->get('user')->row();
        $streamer = $this->db->where("isStreamer", 1)->where("streamer_slug", $streamer)->order_by('id', 'DESC')->get('user')->row();
        if (!$streamer) return redirect(base_url("yayincilar"), 'refresh');
        $streamer->streamer_info = streamer_refresh_token(
            $streamer->id,
            json_decode($streamer->streamer_info, false),
            strtotime($streamer->streamer_refresh_date)
        );
        $streamer->streamer_social = @json_decode($streamer->streamer_social, false);
        if ($streamer->streamer_social === null) $streamer->streamer_social = [];
        $data = [
            'properties' => $this->db->where('id', 1)->get('properties')->row(),
            'category' => getActiveCategories(),
            'pages' => $this->db->get('pages')->result(),
            'streamer' => $streamer,
            'streamers' => $this->db->limit(12)->where("isStreamer", 1)->where("id !=", $streamer->id)->order_by('id', 'DESC')->get('user')->result(),
            'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct' => $this->db->limit(6)->where('isActive', 1)->where('server_id', 0)->order_by('id', 'DESC')->get('product')->result(),
            'title' => 'Yayıncı'
        ];
        $this->view('streamer', $data);
    }
    public function streamers()
    {
        addlog('streamer', 'Sayfa ziyaret edildi - Yayıncı');
        $this->load->helper('streamer_helper');
        $properties = $this->db->where('id', 1)->get('properties')->row();
        $data = [
            'properties' => $this->db->where('id', 1)->get('properties')->row(),
            'category' => getActiveCategories(),
            'pages' => $this->db->get('pages')->result(),
            'streamers' => $this->db->where("isStreamer", 1)->order_by('id', 'DESC')->get('user')->result(),
            'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct' => $this->db->limit(6)->where('isActive', 1)->where('server_id', 0)->order_by('id', 'DESC')->get('product')->result(),
            'title' => 'Yayıncı'
        ];
        $this->view('streamers', $data);
    }
    public function getSearchFormProducts()
    {
        $words = $this->input->post('words');
        $properties = $this->db->where('id', 1)->get('properties')->row();
        $result = $this->db->where('isActive', 1)->limit(6)->like('name', $words, 'both')->get('product')->result();
        $data = [
            'result' => $result
        ];
        $this->load->view('theme/'.$properties->theme.'/searchForm', $data);
    }
    public function removeCart($rowid)
    {
        addlog('remoevCart', 'Sepetten ürün silindi - ' . $rowid);
        $this->advanced_cart->remove($rowid);
        flash('Başarılı.', 'Ürün sepetten silindi.');
        redirect(base_url('sepet'));
    }
    public function reNewPassword() {
        if ($this->input->post()) {
            // Mail adresi kontrolü
            $login = $this->db->where('email', $this->input->post('email'))->get('user')->row();

            if (empty($login)) {
                addlog('reNewPassword', 'Şifre sıfırlama isteği gönderildi. Mail - ' . $this->input->post('email'));
                flash('İşlem Başarılı', "Mail adresiniz kayıtlarımızla eşleşirse size şifre sıfırlama bağlantısı göndereceğiz.");
                redirect(base_url('reNewPassword'), 'refresh');
            }

            // Benzersiz hash oluştur
            $hash = randString(25) . date('d');
            while ($this->db->where('paspas', $hash)->get('user')->num_rows() > 0) {
                $hash = rand(1, 999) . $hash;
            }

            // Hash'i kaydet
            $this->db->where('id', $login->id)->update('user', ['paspas' => $hash]);

            // Mail gönder
            $this->load->library('mailer');
            $properties = $this->db->where('id', 1)->get('properties')->row();

            $result = $this->mailer->send(
                $this->input->post('email'),
                'password_reset',
                [
                    'name' => $login->name,
                    'surname' => $login->surname,
                    'email' => $login->email,
                    'reset_link' => base_url("newPassword/" . $hash)
                ]
            );

            if ($result) {
                flash('İşlem Başarılı', "Mail adresiniz kayıtlarımızla eşleşirse size şifre sıfırlama bağlantısı göndereceğiz.");
            } else {
                flash('Ups.', "Sistemde oluşan bir sorundan dolayı işleminizi gerçekleştiremiyoruz. Lütfen yöneticiye bildiriniz.");
            }

            redirect(base_url('reNewPassword'), 'refresh');

        } else {
            $properties = $this->db->where('id', 1)->get('properties')->row();
            $data = [
                'properties' => $properties,
                'pages' => $this->db->get('pages')->result(),
                'category' => getActiveCategories(),
                'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
                'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
                'footerProduct' => $this->db->limit(6)->where('isActive', 1)->where('server_id', 0)->order_by('id', 'DESC')->get('product')->result(),
                'title' => 'Şifremi Unuttum - ' . $properties->name
            ];
            $this->view('reNewPassword', $data);
        }
    }

    public function newPassword($hash)
    {
        $controlhash = $this->db->where('paspas', $hash)->get('user')->row();
        $properties = $this->db->where('id', 1)->get('properties')->row();
        if ($controlhash) {
            addlog('newPassword', 'Sayfa ziyaret edildi: Yeni şifre belirleme. HASH - ' . $hash);
            $data = [
                'properties' => $this->db->where('id', 1)->get('properties')->row(),
                'category' => getActiveCategories(),
                'pages' => $this->db->get('pages')->result(),
                'hash' => $hash,
                'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
                'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
                'footerProduct' => $this->db->limit(6)->where('isActive', 1)->where('server_id', 0)->order_by('id', 'DESC')->get('product')->result(),
                'title' => 'Yeni Şifre - ' . $properties->name
            ];
            $this->view('new-password', $data);
        }else{
            addlog('newPassword', 'Şifre sıfırlama HASH hatası. HASH - ' . $hash);
            flash('UPS', 'Yanlış veya tarihi geçmiş kod.');
            redirect(base_url());
        }
    }
    public function setNewPassword()
    {
        if ($this->input->post('hash')) {
            $hash = $this->db->where('paspas', $this->input->post('hash'))->get('user')->row();
            if ($hash) {
                $newPassword = $this->input->post('newPassword');
                $reNewPassword = $this->input->post('reNewPassword');
                if ($newPassword == $reNewPassword) {
                    $result = $this->db->where('id', $hash->id)->update('user', ['password'=>paspas($newPassword), 'paspas' => NULL]);
                    if ($result) {
                        addlog('newPassword', 'Şifre sıfırlama gerçekleştirildi. Kullanıcı:' . $hash->email);
                        flash('Harika!', 'Yeni şifrenle giriş yapabilirsin.');
                        redirect(base_url());
                    }else{
                        addlog('newPassword', 'Şifre sıfırlama gerçekleştirilemedi (Hash hatası). HASH:' . $hash);
                        flash('UPS', 'Bir sorundan ötürü şifreni yenileyemedik.');
                        redirect(base_url());
                    }
                }else{
                    addlog('newPassword', 'Şifre sıfırlama gerçekleştirilemedi (Şifre eşleşme hatası). HASH - ' . $hash);
                    flash('UPS', 'Şifreler birbiri ile uyuşmuyor.');
                    redirect(base_url('home/newPassword/') . $this->input->post('hash'));
                }
            }else{
                addlog('newPassword', 'Şifre sıfırlama gerçekleştirilemedi (Hash hatası). HASH - ' . $hash);
                flash('UPS', 'Yanlış veya tarihi geçmiş kod.');
                redirect(base_url());
            }
        }else{
            addlog('newPassword', 'Şifre sıfırlama gerçekleştirilemedi (Hash hatası). HASH - ' . $hash);
            flash('UPS', 'Yanlış veya tarihi geçmiş kod.');
            redirect(base_url());
        }
    }
    public function sitemap()
    {
        $this->load->view('Sitemap');
    }
    public function error()
    {
        addlog('error', 'Sayfa ziyaret edildi: Hata Sayfası');
        $data = [
            'properties' => $this->db->where('id', 1)->get('properties')->row(),
            'category' => getActiveCategories(),
            'why' => $this->db->get('why')->result(),
            'pages' => $this->db->get('pages')->result(),
            'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct' => $this->db->limit(6)->where('isActive', 1)->where('server_id', 0)->order_by('id', 'DESC')->get('product')->result(),
            'status' => 0
        ];
        $this->view('../../404', $data);
    }
    public function confirmUserMail($mail_code)
    {
        $user = $this->db->where('mail_code', $mail_code)->get('user')->row();
        if ($user) {
            addlog('confirmUserMail', 'Sayfa ziyaret edildi. Mail doğrulama - ' . $user->email);
            $result = $this->db->where('id', $user->id)->update('user', ['isConfirmMail' => 1, 'mail_code' => '']);
            if ($result) {
                addlog('confirmUserMail', 'Mail doğrulama başarılı. Mail - ' . $user->email);
                flash('Harika!', 'Hesabın onaylandı. Artık giriş yapabilirsin.');
                redirect(base_url('hesap'));
                exit;
            }else{
                addlog('confirmUserMail', 'Mail doğrulama başarısız. Doğrulama kodu: ' . $mail_code);
                flash('UPS', 'Bir sorun oluştu. Lütfen sistem yöneticisi ile iletişime geç.');
                redirect(base_url());
                exit;
            }
        }else{
            $data = [
                'properties' => $this->db->where('id', 1)->get('properties')->row(),
                'category' => getActiveCategories(),
                'why' => $this->db->get('why')->result(),
                'pages' => $this->db->get('pages')->result(),
                'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
                'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
                'footerProduct' => $this->db->limit(6)->where('isActive', 1)->where('server_id', 0)->order_by('id', 'DESC')->get('product')->result(),
                'status' => 0
            ];
            $this->view('../../404', $data);
        }
    }
    public function newMailCode()
    {
        addlog('newMailCode', 'Sayfa ziyaret edildi: Mail doğrulama kodu alma sayfası');
        if (!empty($this->session->userdata('newmailcode')) && $this->session->userdata('newmailcode')['newCode'] == 1) {
            $user = $this->db->where('id', $this->session->userdata('newmailcode')['id'])->get('user')->row();
            $sendMailDate = strtotime($user->send_mail_date) + 600;
            if ($sendMailDate < time()) {
                $randString = randString(25);
                $randString = md5($this->input->post('name') . $randString);

                // Mail gönder
                $this->load->library('mailer');
                $properties = $this->db->where('id', 1)->get('properties')->row();

                $result = $this->mailer->send(
                    $user->email,
                    'mail_verification',
                    [
                        'name' => $user->name,
                        'surname' => $user->surname,
                        'verification_link' => base_url('mail-onay/') . $randString
                    ]
                );

                $this->db->where('id', $this->session->userdata('newmailcode')['id'])->update('user', ['mail_code' => $randString, 'send_mail_date' => date('Y-m-d h:i:s')]);
                addlog('newMailCode', 'Mail doğrulama kodu gönderildi. Kod: ' . $randString);
                flash('İşlem Başarılı.', 'Mail adresine yeni bir kod gönderdik.');
                $this->session->unset_userdata('newmailcode');
                redirect(base_url('hesap'), 'refresh');
                exit;
            }else{
                addlog('newMailCode', 'Mail doğrulama kodu gönderilemedi (10 Dakikadan daha önce talep edildi).');
                flash('Ups.', '10 Dakikada sadece 1 kez kod gönderebilirsin.');
                redirect(base_url('hesap'), 'refresh');
                exit;
            }
        }
    }
    public function addTc(){
        addlog('addTc', 'Sayfa ziyaret edildi. TC Ekleme.');
        $properties = $this->db->where('id', 1)->get('properties')->row();
        $user = $this->db->where('id', $this->session->userdata('info')['id'])->get('user')->row();
        if ($properties->isConfirmTc == 0 && $user->tc != "11111111111") {
            flash('Ups.', 'Buraya giremezsin.');
            redirect(base_url(), 'refresh');
        }
        $this->load->library('form_validation');
        $data = [
            'properties' => $this->db->where('id', 1)->get('properties')->row(),
            'category' => getActiveCategories(),
            'pages' => $this->db->get('pages')->result(),
            'footerBlog' => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage' => $this->db->limit(6)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct' => $this->db->limit(3)->where('isActive', 1)->where('server_id', 0)->order_by('id', 'DESC')->get('product')->result(),
        ];
        $this->view('../../tc', $data);
    }
}