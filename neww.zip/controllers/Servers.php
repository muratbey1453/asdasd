<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Frontend: Sunucular
 *
 * Routes (application/config/routes.php):
 *   $route['sunucular'] = 'servers/index';
 *   $route['client/sunucu-ekle'] = 'servers/create';
 *   $route['client/sunucu-ekle/kaydet'] = 'servers/store';
 */
class Servers extends G_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Server_model');
        $this->load->helper(['form', 'url']);
        $this->load->library('form_validation');
    }

    /**
     * /sunucular
     */
    public function index()
    {
        $properties = $this->db->where('id', 1)->get('properties')->row();

        $data = [
            'properties'   => $properties,
            'category'     => getActiveCategories(),
            'pages'        => $this->db->get('pages')->result(),
            'footerBlog'   => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage'   => $this->db->limit(3)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct'=> $this->db->limit(3)->where('isActive', 1)->order_by('id', 'DESC')->get('product')->result(),
            'title'        => 'Sunucular - ' . $properties->name,
            'groups'       => $this->Server_model->get_grouped_approved(),
            'games' => $this->Server_model->game_options(),

        ];

        $this->view('servers/index', $data);
    }
public function like($id)
{
    if ($this->input->method(TRUE) !== 'POST') {
        show_404(); return;
    }

    $id = (int)$id;

    // sunucu var mı?
    $exists = $this->db->where('id', $id)->limit(1)->get('servers')->row();
    if (!$exists) {
        $this->output->set_content_type('application/json')
            ->set_output(json_encode(['ok'=>false]));
        return;
    }

    $ip = $this->input->ip_address();
    $ua = (string)$this->input->user_agent();
    $ipHash = hash('sha256', $id.'|'.$ip.'|'.substr($ua,0,120));

    $already = $this->db->where('server_id', $id)->where('ip_hash', $ipHash)->limit(1)->get('server_likes')->row();
    if (!$already) {
        $this->db->insert('server_likes', [
            'server_id' => $id,
            'ip_hash'   => $ipHash,
            'created_at'=> date('Y-m-d H:i:s'),
        ]);
    }

    $count = (int)$this->db->where('server_id', $id)->count_all_results('server_likes');

    $this->output->set_content_type('application/json')
  ->set_output(json_encode([
    'ok' => true,
    'count' => $count,
    'csrfHash' => $this->security->get_csrf_hash()
  ]));

}

    /**
     * /client/sunucu-ekle
     */
    public function create()
    {
        if (!$this->session->userdata('info')) {
            flash('Ups.', 'Sunucu eklemek için giriş yapmalısın.');
            redirect(base_url('hesap'), 'refresh');
            return;
        }

        $properties = $this->db->where('id', 1)->get('properties')->row();

        $data = [
            'properties'   => $properties,
            'category'     => getActiveCategories(),
            'pages'        => $this->db->get('pages')->result(),
            'footerBlog'   => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
            'footerPage'   => $this->db->limit(3)->order_by('id', 'DESC')->get('pages')->result(),
            'footerProduct'=> $this->db->limit(3)->where('isActive', 1)->order_by('id', 'DESC')->get('product')->result(),
            'title'        => 'Sunucu Ekle - ' . $properties->name,
            'game_options' => $this->Server_model->game_options(),
        ];

        $this->view('servers/create', $data);
    }
    
public function detail($id)
{
    $properties = $this->db->where('id', 1)->get('properties')->row();

    $server = $this->Server_model->get_approved_by_id((int)$id);
    if (!$server) { show_404(); return; }

    // Sunucu ürünleri
    $this->load->model('ServerProduct_model');
    $this->load->library('pagination');

    $perPage = 8;
    $page   = max(1, (int)$this->input->get('sp'));
    $offset = ($page - 1) * $perPage;

    $total = $this->ServerProduct_model->count_by_server($server->id);
    $serverProducts = $this->ServerProduct_model->get_by_server_paginated($server->id, $perPage, $offset);

    $config = [
        'base_url' => base_url('sunucular/detay/'.(int)$server->id),
        'total_rows' => $total,
        'per_page' => $perPage,
        'page_query_string' => TRUE,
        'query_string_segment' => 'sp',
        'use_page_numbers' => TRUE,
        'reuse_query_string' => TRUE,
        'suffix' => '#sunucu-urunleri',
        'first_url' => base_url('sunucular/detay/'.(int)$server->id).'?sp=1#sunucu-urunleri',

        'full_tag_open' => '<ul class="pagination justify-content-center mt-3">',
        'full_tag_close' => '</ul>',
        'num_tag_open' => '<li class="page-item">',
        'num_tag_close' => '</li>',
        'cur_tag_open' => '<li class="page-item active"><span class="page-link">',
        'cur_tag_close' => '</span></li>',
        'attributes' => ['class' => 'page-link'],
        'prev_tag_open' => '<li class="page-item">',
        'prev_tag_close' => '</li>',
        'next_tag_open' => '<li class="page-item">',
        'next_tag_close' => '</li>',
    ];
    $this->pagination->initialize($config);

    $relatedServers = $this->Server_model->get_related_approved($server->game, $server->id, 12);
    $canAddServerProduct = !empty($this->session->userdata('info'));

    // Footer ürünlerinde server ürünü çıkmasın (varsa)
    $footerQ = $this->db->limit(3)->where('isActive', 1)->order_by('id', 'DESC');
    if ($this->db->field_exists('server_id', 'product')) $footerQ->where('server_id', 0);
    $footerProduct = $footerQ->get('product')->result();

    $data = [
        'properties'    => $properties,
        'category'      => getActiveCategories(),
        'pages'         => $this->db->get('pages')->result(),
        'footerBlog'    => $this->db->limit(3)->order_by('id', 'DESC')->get('blog')->result(),
        'footerPage'    => $this->db->limit(3)->order_by('id', 'DESC')->get('pages')->result(),
        'footerProduct' => $footerProduct,

        'games'         => $this->Server_model->game_options(),
        'server'        => $server,
        'title'         => $server->title . ' - ' . $properties->name,

        // NEW:
        'serverProducts'      => $serverProducts,
        'serverProductsLinks' => $this->pagination->create_links(),
        'relatedServers'      => $relatedServers,
        'canAddServerProduct' => $canAddServerProduct,
    ];

    $this->view('servers/detail', $data);
}


    /**
     * POST /client/sunucu-ekle/kaydet
     */
    public function store()
{
    if (!$this->session->userdata('info')) {
        show_error('Unauthorized', 401);
        return;
    }

    $this->form_validation->set_rules('game', 'Oyun', 'required|trim');
    $this->form_validation->set_rules('title', 'Sunucu Adı', 'required|trim|min_length[3]|max_length[80]');
    $this->form_validation->set_rules('ip', 'IP/Host', 'required|trim|min_length[3]|max_length[120]');
    $this->form_validation->set_rules('website', 'Web Sitesi', 'trim|valid_url');
    $this->form_validation->set_rules('discord', 'Discord', 'trim|valid_url');
    $this->form_validation->set_rules('short_desc', 'Tanıtım', 'trim|max_length[140]');
    $this->form_validation->set_rules('description', 'Açıklama', 'trim|max_length[800]');

    $message = [
        'required'  => '<bold>{field}</bold> Alanı boş bırakılamaz.',
        'valid_url' => '{field} geçerli bir URL olmalı. Örn: https://...',
    ];
    $this->form_validation->set_message($message);

    if ($this->form_validation->run() === FALSE) {
        flash('!', validation_errors());
        redirect(base_url('client/sunucu-ekle'), 'refresh');
        return;
    }

    // ===== Banner upload =====
    $bannerFileName = null;

    if (!empty($_FILES['banner']['name'])) {
        $uploadDir = FCPATH . 'assets/img/servers/'; // /public_html/assets/img/servers/

        if (!is_dir($uploadDir)) {
            @mkdir($uploadDir, 0755, true);
        }

        $config = [
            'upload_path'   => $uploadDir,
            'allowed_types' => 'jpg|jpeg|png|webp',
            'max_size'      => 4096, // 4MB
            'encrypt_name'  => true,
            'remove_spaces' => true,
        ];

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('banner')) {
            $err = strip_tags($this->upload->display_errors('', ''));
            flash('Ups.', 'Banner yüklenemedi: ' . $err);
            redirect(base_url('client/sunucu-ekle'), 'refresh');
            return;
        }

        $up = $this->upload->data();
        $bannerFileName = $up['file_name'];
    }
    // =========================

    $userId = (int)$this->session->userdata('info')['id'];

    $payload = [
        'user_id'     => $userId,
        'game'        => strip_tags($this->input->post('game', true)),
        'title'       => strip_tags($this->input->post('title', true)),
        'ip'          => strip_tags($this->input->post('ip', true)),
        'website'     => strip_tags($this->input->post('website', true)),
        'discord'     => strip_tags($this->input->post('discord', true)),
        'banner'      => $bannerFileName, // DB'de banner kolonu var
        'short_desc'  => strip_tags($this->input->post('short_desc', true)),
        'description' => strip_tags($this->input->post('description', true)),
        'status'      => 0, // 0=pending, 1=approved, 2=rejected
        'created_at'  => date('Y-m-d H:i:s'),
        'updated_at'  => date('Y-m-d H:i:s'),
    ];

    $this->db->insert('servers', $payload);

    flash('Harika!', 'Sunucun başarıyla gönderildi. Admin onayından sonra listede görünecek.');
    redirect(base_url('sunucular'), 'refresh');
}

}
